﻿Public Class Form1

    'todo:
    'display passed or failed
    'get the value from the textbox
    Dim ave As Double
    Dim remarks As String

    'try to challenge your self

    Private Sub txtAverage_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAverage.TextChanged

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub txtRemarks_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRemarks.TextChanged

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtAverage.Clear()
        txtRemarks.Clear()
        txtRemarks2.Clear()
        txtRemarks3.Clear()
    End Sub

    Private Sub btnRemarks_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemarks.Click
        Try
            ave = Convert.ToDouble(txtAverage.Text)

            ' Remarks 1
            txtRemarks.Text = If(ave >= 75, "Passed", If(ave >= 70, "Conditional", "Failed"))

            ' Remarks 2
            txtRemarks2.Text = If(ave >= 94, "A",
                               If(ave >= 89, "B",
                               If(ave >= 84, "C",
                               If(ave >= 80, "D",
                               If(ave >= 75, "E", "F")))))

            ' Remarks 3 
            txtRemarks3.Text = If(ave >= 98, "1.00",
                               If(ave >= 95, "1.25",
                               If(ave >= 92, "1.50",
                               If(ave >= 89, "1.75",
                               If(ave >= 86, "2.00",
                               If(ave >= 83, "2.25",
                               If(ave >= 80, "2.50",
                               If(ave >= 77, "2.75",
                               If(ave >= 75, "3.00",
                               If(ave >= 70, "5.00", "Invalid Grade..."))))))))))

        Catch ex As Exception
            txtRemarks.Text = "There's something wrong with your code.."
            txtRemarks2.Text = "Make sure to enter the right grade number"
            txtRemarks3.Text = "Enter only numbers or decimal numbers"
        End Try

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub txtRemarks2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRemarks2.TextChanged

    End Sub

    Private Sub txtRemarks3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRemarks3.TextChanged

    End Sub
End Class
