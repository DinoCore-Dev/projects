<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits Form

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then components.Dispose()
        MyBase.Dispose(disposing)
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents menuMain As MenuStrip
    Friend WithEvents menuDemo As ToolStripMenuItem
    Friend WithEvents menuPanel As ToolStripMenuItem
    Friend WithEvents menuSplitPanel As ToolStripMenuItem
    Friend WithEvents menuExit As ToolStripMenuItem
    Friend WithEvents pnlHeader As Panel
    Friend WithEvents pnlTools As Panel
    Friend WithEvents btnVisible As Button
    Friend WithEvents btnBackColor As Button
    Friend WithEvents btnBorder As Button
    Friend WithEvents btnRefresh As Button
    Friend WithEvents btnInvalidate As Button
    Friend WithEvents btnFocus As Button
    Friend WithEvents btnContains As Button
    Friend WithEvents btnDispose As Button
    Friend WithEvents pnlWorkspace As Panel
    Friend WithEvents pnlGroup As Panel
    Friend WithEvents lblGroup As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtCourse As TextBox
    Friend WithEvents btnSave As Button
    Friend WithEvents pnlNested As Panel
    Friend WithEvents lblNested As Label
    Friend WithEvents pnlScrollable As Panel
    Friend WithEvents lblScrollable As Label
    Friend WithEvents pnlStatus As Panel
    Friend WithEvents lblStatus As Label

    Private Sub InitializeComponent()
        Me.menuMain = New MenuStrip()
        Me.menuDemo = New ToolStripMenuItem()
        Me.menuPanel = New ToolStripMenuItem()
        Me.menuSplitPanel = New ToolStripMenuItem()
        Me.menuExit = New ToolStripMenuItem()
        Me.pnlHeader = New Panel()
        Me.pnlTools = New Panel()
        Me.btnVisible = New Button()
        Me.btnBackColor = New Button()
        Me.btnBorder = New Button()
        Me.btnRefresh = New Button()
        Me.btnInvalidate = New Button()
        Me.btnFocus = New Button()
        Me.btnContains = New Button()
        Me.btnDispose = New Button()
        Me.pnlWorkspace = New Panel()
        Me.pnlGroup = New Panel()
        Me.lblGroup = New Label()
        Me.txtName = New TextBox()
        Me.txtCourse = New TextBox()
        Me.btnSave = New Button()
        Me.pnlNested = New Panel()
        Me.lblNested = New Label()
        Me.pnlScrollable = New Panel()
        Me.lblScrollable = New Label()
        Me.pnlStatus = New Panel()
        Me.lblStatus = New Label()
        Me.menuMain.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.pnlTools.SuspendLayout()
        Me.pnlWorkspace.SuspendLayout()
        Me.pnlGroup.SuspendLayout()
        Me.pnlNested.SuspendLayout()
        Me.pnlScrollable.SuspendLayout()
        Me.pnlStatus.SuspendLayout()
        Me.SuspendLayout()
        Me.menuMain.Items.AddRange(New ToolStripItem() {Me.menuDemo})
        Me.menuMain.Dock = DockStyle.Top
        Me.menuDemo.DropDownItems.AddRange(New ToolStripItem() {Me.menuPanel, Me.menuSplitPanel, New ToolStripSeparator(), Me.menuExit})
        Me.menuDemo.Text = "Demonstration"
        Me.menuPanel.Checked = True
        Me.menuPanel.Text = "Panel Form"
        Me.menuSplitPanel.Text = "SplitPanel Form"
        Me.menuExit.Text = "Exit"
        Me.pnlHeader.BackColor = Color.SteelBlue
        Me.pnlHeader.Dock = DockStyle.Top
        Me.pnlHeader.Size = New Size(920, 10)
        Me.pnlTools.BackColor = Color.WhiteSmoke
        Me.pnlTools.BorderStyle = BorderStyle.FixedSingle
        Me.pnlTools.Controls.Add(Me.btnVisible)
        Me.pnlTools.Controls.Add(Me.btnBackColor)
        Me.pnlTools.Controls.Add(Me.btnBorder)
        Me.pnlTools.Controls.Add(Me.btnRefresh)
        Me.pnlTools.Controls.Add(Me.btnInvalidate)
        Me.pnlTools.Controls.Add(Me.btnFocus)
        Me.pnlTools.Controls.Add(Me.btnContains)
        Me.pnlTools.Controls.Add(Me.btnDispose)
        Me.pnlTools.Dock = DockStyle.Top
        Me.pnlTools.Size = New Size(920, 48)
        Me.btnVisible.Location = New Point(8, 9)
        Me.btnVisible.Size = New Size(92, 28)
        Me.btnVisible.Text = "Hide Group"
        Me.btnBackColor.Location = New Point(105, 9)
        Me.btnBackColor.Size = New Size(88, 28)
        Me.btnBackColor.Text = "BackColor"
        Me.btnBorder.Location = New Point(198, 9)
        Me.btnBorder.Size = New Size(82, 28)
        Me.btnBorder.Text = "BorderStyle"
        Me.btnRefresh.Location = New Point(285, 9)
        Me.btnRefresh.Size = New Size(68, 28)
        Me.btnRefresh.Text = "Refresh"
        Me.btnInvalidate.Location = New Point(358, 9)
        Me.btnInvalidate.Size = New Size(72, 28)
        Me.btnInvalidate.Text = "Invalidate"
        Me.btnFocus.Location = New Point(435, 9)
        Me.btnFocus.Size = New Size(58, 28)
        Me.btnFocus.Text = "Focus"
        Me.btnContains.Location = New Point(498, 9)
        Me.btnContains.Size = New Size(70, 28)
        Me.btnContains.Text = "Contains"
        Me.btnDispose.Location = New Point(573, 9)
        Me.btnDispose.Size = New Size(88, 28)
        Me.btnDispose.Text = "Dispose Test"
        Me.pnlWorkspace.AutoScroll = True
        Me.pnlWorkspace.BackColor = Color.White
        Me.pnlWorkspace.BorderStyle = BorderStyle.Fixed3D
        Me.pnlWorkspace.Controls.Add(Me.pnlGroup)
        Me.pnlWorkspace.Controls.Add(Me.pnlNested)
        Me.pnlWorkspace.Controls.Add(Me.pnlScrollable)
        Me.pnlWorkspace.Dock = DockStyle.Fill
        Me.pnlWorkspace.TabStop = True
        Me.pnlGroup.BackColor = Color.AliceBlue
        Me.pnlGroup.BorderStyle = BorderStyle.FixedSingle
        Me.pnlGroup.Controls.Add(Me.lblGroup)
        Me.pnlGroup.Controls.Add(Me.txtName)
        Me.pnlGroup.Controls.Add(Me.txtCourse)
        Me.pnlGroup.Controls.Add(Me.btnSave)
        Me.pnlGroup.Location = New Point(25, 25)
        Me.pnlGroup.Size = New Size(270, 210)
        Me.lblGroup.AutoSize = True
        Me.lblGroup.Font = New Font("Segoe UI", 11.0!, FontStyle.Bold)
        Me.lblGroup.Location = New Point(14, 14)
        Me.lblGroup.Text = "Grouped Controls"
        Me.txtName.Location = New Point(18, 55)
        Me.txtName.Size = New Size(230, 20)
        Me.txtName.Text = "Student name"
        Me.txtCourse.Location = New Point(18, 90)
        Me.txtCourse.Size = New Size(230, 20)
        Me.txtCourse.Text = "Course"
        Me.btnSave.Location = New Point(18, 130)
        Me.btnSave.Size = New Size(90, 30)
        Me.btnSave.Text = "Save"
        Me.pnlNested.BackColor = Color.PaleGreen
        Me.pnlNested.BorderStyle = BorderStyle.FixedSingle
        Me.pnlNested.Controls.Add(Me.lblNested)
        Me.pnlNested.Location = New Point(320, 25)
        Me.pnlNested.Size = New Size(250, 210)
        Me.pnlNested.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Me.lblNested.Dock = DockStyle.Fill
        Me.lblNested.Font = New Font("Segoe UI", 11.0!, FontStyle.Bold)
        Me.lblNested.Text = "Nested Panel" & vbCrLf & vbCrLf & "Dock and Anchor keep this area aligned while the form is resized."
        Me.lblNested.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlScrollable.AutoScroll = True
        Me.pnlScrollable.BackColor = Color.Moccasin
        Me.pnlScrollable.BorderStyle = BorderStyle.FixedSingle
        Me.pnlScrollable.Controls.Add(Me.lblScrollable)
        Me.pnlScrollable.Location = New Point(595, 25)
        Me.pnlScrollable.Size = New Size(250, 210)
        Me.lblScrollable.AutoSize = False
        Me.lblScrollable.Location = New Point(15, 15)
        Me.lblScrollable.Size = New Size(430, 360)
        Me.lblScrollable.Text = "AutoScroll Panel" & vbCrLf & vbCrLf & "This content is intentionally larger than its panel." & vbCrLf & vbCrLf & "Use the horizontal and vertical scrollbars." & vbCrLf & vbCrLf & "Panel properties:" & vbCrLf & "BackColor" & vbCrLf & "BorderStyle" & vbCrLf & "AutoScroll" & vbCrLf & "Dock" & vbCrLf & "Anchor" & vbCrLf & "Visible"
        Me.pnlStatus.BackColor = SystemColors.ControlLight
        Me.pnlStatus.BorderStyle = BorderStyle.FixedSingle
        Me.pnlStatus.Controls.Add(Me.lblStatus)
        Me.pnlStatus.Dock = DockStyle.Bottom
        Me.pnlStatus.Size = New Size(920, 31)
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New Point(10, 8)
        Me.lblStatus.Text = "Use the menu to open the SplitPanel form."
        Me.AutoScaleDimensions = New SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = AutoScaleMode.Font
        Me.ClientSize = New Size(920, 560)
        Me.Controls.Add(Me.pnlWorkspace)
        Me.Controls.Add(Me.pnlStatus)
        Me.Controls.Add(Me.pnlTools)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.menuMain)
        Me.MainMenuStrip = Me.menuMain
        Me.MinimumSize = New Size(760, 480)
        Me.Name = "Form1"
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.Text = "Activity 3 - Panel Form"
        Me.menuMain.ResumeLayout(False)
        Me.menuMain.PerformLayout()
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlTools.ResumeLayout(False)
        Me.pnlWorkspace.ResumeLayout(False)
        Me.pnlGroup.ResumeLayout(False)
        Me.pnlGroup.PerformLayout()
        Me.pnlNested.ResumeLayout(False)
        Me.pnlScrollable.ResumeLayout(False)
        Me.pnlScrollable.PerformLayout()
        Me.pnlStatus.ResumeLayout(False)
        Me.pnlStatus.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()
    End Sub
End Class
