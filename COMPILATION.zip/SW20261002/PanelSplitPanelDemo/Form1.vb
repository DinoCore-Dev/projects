Option Strict On
Option Explicit On

Public Class Form1
    Private colorChanged As Boolean = False

    Private Sub menuSplitPanel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles menuSplitPanel.Click
        Dim nextForm As New Form2()
        nextForm.Owner = Me
        AddHandler nextForm.FormClosed, AddressOf SplitFormClosed
        nextForm.Show()
        Me.Hide()
    End Sub

    Private Sub SplitFormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        If Not Me.IsDisposed Then Me.Show()
    End Sub

    Private Sub menuExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles menuExit.Click
        Application.Exit()
    End Sub

    Private Sub btnVisible_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnVisible.Click
        pnlGroup.Visible = Not pnlGroup.Visible
        btnVisible.Text = If(pnlGroup.Visible, "Hide Group", "Show Group")
        lblStatus.Text = "Visible = " & pnlGroup.Visible.ToString()
    End Sub

    Private Sub btnBackColor_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnBackColor.Click
        colorChanged = Not colorChanged
        pnlNested.BackColor = If(colorChanged, Color.LightSkyBlue, Color.PaleGreen)
        lblStatus.Text = "BackColor changed on the nested panel."
    End Sub

    Private Sub btnBorder_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnBorder.Click
        If pnlWorkspace.BorderStyle = BorderStyle.Fixed3D Then
            pnlWorkspace.BorderStyle = BorderStyle.FixedSingle
        Else
            pnlWorkspace.BorderStyle = BorderStyle.Fixed3D
        End If
        lblStatus.Text = "BorderStyle = " & pnlWorkspace.BorderStyle.ToString()
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRefresh.Click
        pnlWorkspace.Refresh()
        lblStatus.Text = "Refresh() repainted the workspace panel."
    End Sub

    Private Sub btnInvalidate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnInvalidate.Click
        pnlWorkspace.Invalidate(True)
        lblStatus.Text = "Invalidate() requested a redraw of the panel and child controls."
    End Sub

    Private Sub btnFocus_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFocus.Click
        Dim result As Boolean = pnlWorkspace.Focus()
        lblStatus.Text = "Focus() result = " & result.ToString()
    End Sub

    Private Sub btnContains_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnContains.Click
        Dim result As Boolean = pnlWorkspace.Contains(pnlGroup)
        lblStatus.Text = "Contains(pnlGroup) = " & result.ToString()
    End Sub

    Private Sub btnDispose_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDispose.Click
        Dim sample As New Panel()
        sample.Controls.Add(New Label())
        sample.Dispose()
        lblStatus.Text = "Dispose() released a temporary panel and its controls."
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        lblStatus.Text = txtName.Text & " - " & txtCourse.Text & " saved from grouped controls."
    End Sub
End Class
