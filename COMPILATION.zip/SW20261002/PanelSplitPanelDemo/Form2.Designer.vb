<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits Form

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then components.Dispose()
        MyBase.Dispose(disposing)
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents menuMain As MenuStrip
    Friend WithEvents menuDemo As ToolStripMenuItem
    Friend WithEvents menuPanel As ToolStripMenuItem
    Friend WithEvents menuSplitPanel As ToolStripMenuItem
    Friend WithEvents menuExit As ToolStripMenuItem
    Friend WithEvents pnlHeader As Panel
    Friend WithEvents pnlTools As Panel
    Friend WithEvents btnCollapse1 As Button
    Friend WithEvents btnCollapse2 As Button
    Friend WithEvents btnExpand As Button
    Friend WithEvents btnOrientation As Button
    Friend WithEvents btnLock As Button
    Friend WithEvents btnRefresh As Button
    Friend WithEvents btnInvalidate As Button
    Friend WithEvents btnDispose As Button
    Friend WithEvents splitMain As SplitContainer
    Friend WithEvents lblPanel1 As Label
    Friend WithEvents lstNavigation As ListBox
    Friend WithEvents splitInner As SplitContainer
    Friend WithEvents lblPanel2 As Label
    Friend WithEvents lvRecords As ListView
    Friend WithEvents colName As ColumnHeader
    Friend WithEvents colType As ColumnHeader
    Friend WithEvents lblDetails As Label
    Friend WithEvents txtDetails As TextBox
    Friend WithEvents pnlStatus As Panel
    Friend WithEvents lblStatus As Label

    Private Sub InitializeComponent()
        Me.menuMain = New MenuStrip()
        Me.menuDemo = New ToolStripMenuItem()
        Me.menuPanel = New ToolStripMenuItem()
        Me.menuSplitPanel = New ToolStripMenuItem()
        Me.menuExit = New ToolStripMenuItem()
        Me.pnlHeader = New Panel()
        Me.pnlTools = New Panel()
        Me.btnCollapse1 = New Button()
        Me.btnCollapse2 = New Button()
        Me.btnExpand = New Button()
        Me.btnOrientation = New Button()
        Me.btnLock = New Button()
        Me.btnRefresh = New Button()
        Me.btnInvalidate = New Button()
        Me.btnDispose = New Button()
        Me.splitMain = New SplitContainer()
        Me.lblPanel1 = New Label()
        Me.lstNavigation = New ListBox()
        Me.splitInner = New SplitContainer()
        Me.lblPanel2 = New Label()
        Me.lvRecords = New ListView()
        Me.colName = New ColumnHeader()
        Me.colType = New ColumnHeader()
        Me.lblDetails = New Label()
        Me.txtDetails = New TextBox()
        Me.pnlStatus = New Panel()
        Me.lblStatus = New Label()
        Me.menuMain.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.pnlTools.SuspendLayout()
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.splitMain.Panel1.SuspendLayout()
        Me.splitMain.Panel2.SuspendLayout()
        Me.splitMain.SuspendLayout()
        CType(Me.splitInner, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.splitInner.Panel1.SuspendLayout()
        Me.splitInner.Panel2.SuspendLayout()
        Me.splitInner.SuspendLayout()
        Me.pnlStatus.SuspendLayout()
        Me.SuspendLayout()
        Me.menuMain.Items.AddRange(New ToolStripItem() {Me.menuDemo})
        Me.menuMain.Dock = DockStyle.Top
        Me.menuDemo.DropDownItems.AddRange(New ToolStripItem() {Me.menuPanel, Me.menuSplitPanel, New ToolStripSeparator(), Me.menuExit})
        Me.menuDemo.Text = "Demonstration"
        Me.menuPanel.Text = "Panel Form"
        Me.menuSplitPanel.Checked = True
        Me.menuSplitPanel.Text = "SplitPanel Form"
        Me.menuExit.Text = "Exit"
        Me.pnlHeader.BackColor = Color.SeaGreen
        Me.pnlHeader.Dock = DockStyle.Top
        Me.pnlHeader.Size = New Size(960, 10)
        Me.pnlTools.BackColor = Color.WhiteSmoke
        Me.pnlTools.BorderStyle = BorderStyle.FixedSingle
        Me.pnlTools.Controls.Add(Me.btnCollapse1)
        Me.pnlTools.Controls.Add(Me.btnCollapse2)
        Me.pnlTools.Controls.Add(Me.btnExpand)
        Me.pnlTools.Controls.Add(Me.btnOrientation)
        Me.pnlTools.Controls.Add(Me.btnLock)
        Me.pnlTools.Controls.Add(Me.btnRefresh)
        Me.pnlTools.Controls.Add(Me.btnInvalidate)
        Me.pnlTools.Controls.Add(Me.btnDispose)
        Me.pnlTools.Dock = DockStyle.Top
        Me.pnlTools.Size = New Size(960, 48)
        Me.btnCollapse1.Location = New Point(8, 9)
        Me.btnCollapse1.Size = New Size(100, 28)
        Me.btnCollapse1.Text = "Collapse Panel1"
        Me.btnCollapse2.Location = New Point(113, 9)
        Me.btnCollapse2.Size = New Size(100, 28)
        Me.btnCollapse2.Text = "Collapse Panel2"
        Me.btnExpand.Location = New Point(218, 9)
        Me.btnExpand.Size = New Size(82, 28)
        Me.btnExpand.Text = "Expand All"
        Me.btnOrientation.Location = New Point(305, 9)
        Me.btnOrientation.Size = New Size(105, 28)
        Me.btnOrientation.Text = "Change Direction"
        Me.btnLock.Location = New Point(415, 9)
        Me.btnLock.Size = New Size(88, 28)
        Me.btnLock.Text = "Lock Splitters"
        Me.btnRefresh.Location = New Point(508, 9)
        Me.btnRefresh.Size = New Size(68, 28)
        Me.btnRefresh.Text = "Refresh"
        Me.btnInvalidate.Location = New Point(581, 9)
        Me.btnInvalidate.Size = New Size(72, 28)
        Me.btnInvalidate.Text = "Invalidate"
        Me.btnDispose.Location = New Point(658, 9)
        Me.btnDispose.Size = New Size(88, 28)
        Me.btnDispose.Text = "Dispose Test"
        Me.splitMain.Dock = DockStyle.Fill
        Me.splitMain.FixedPanel = FixedPanel.Panel1
        Me.splitMain.IsSplitterFixed = False
        Me.splitMain.Orientation = Orientation.Vertical
        Me.splitMain.Size = New Size(960, 463)
        Me.splitMain.Panel1MinSize = 130
        Me.splitMain.Panel2MinSize = 350
        Me.splitMain.SplitterWidth = 7
        Me.splitMain.Panel1.BackColor = Color.Honeydew
        Me.splitMain.Panel1.Controls.Add(Me.lstNavigation)
        Me.splitMain.Panel1.Controls.Add(Me.lblPanel1)
        Me.splitMain.Panel2.Controls.Add(Me.splitInner)
        Me.lblPanel1.Dock = DockStyle.Top
        Me.lblPanel1.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        Me.lblPanel1.Padding = New Padding(10)
        Me.lblPanel1.Size = New Size(210, 42)
        Me.lblPanel1.Text = "Panel1 - Navigation"
        Me.lstNavigation.Dock = DockStyle.Fill
        Me.lstNavigation.Items.AddRange(New Object() {"Dashboard", "Students", "Courses", "Reports", "Settings"})
        Me.splitInner.Dock = DockStyle.Fill
        Me.splitInner.FixedPanel = FixedPanel.None
        Me.splitInner.IsSplitterFixed = False
        Me.splitInner.Orientation = Orientation.Horizontal
        Me.splitInner.Size = New Size(743, 463)
        Me.splitInner.Panel1MinSize = 120
        Me.splitInner.Panel2MinSize = 100
        Me.splitInner.SplitterWidth = 7
        Me.splitInner.Panel1.BackColor = Color.White
        Me.splitInner.Panel1.Controls.Add(Me.lvRecords)
        Me.splitInner.Panel1.Controls.Add(Me.lblPanel2)
        Me.splitInner.Panel2.BackColor = Color.WhiteSmoke
        Me.splitInner.Panel2.Controls.Add(Me.txtDetails)
        Me.splitInner.Panel2.Controls.Add(Me.lblDetails)
        Me.lblPanel2.Dock = DockStyle.Top
        Me.lblPanel2.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        Me.lblPanel2.Padding = New Padding(10)
        Me.lblPanel2.Size = New Size(743, 42)
        Me.lblPanel2.Text = "Panel1 of Inner SplitContainer - Records"
        Me.lvRecords.Columns.AddRange(New ColumnHeader() {Me.colName, Me.colType})
        Me.lvRecords.Dock = DockStyle.Fill
        Me.lvRecords.FullRowSelect = True
        Me.lvRecords.GridLines = True
        Me.lvRecords.View = View.Details
        Me.colName.Text = "Name"
        Me.colName.Width = 240
        Me.colType.Text = "Category"
        Me.colType.Width = 160
        Me.lblDetails.Dock = DockStyle.Top
        Me.lblDetails.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        Me.lblDetails.Padding = New Padding(10)
        Me.lblDetails.Size = New Size(743, 42)
        Me.lblDetails.Text = "Panel2 of Inner SplitContainer - Details"
        Me.txtDetails.BackColor = Color.White
        Me.txtDetails.Dock = DockStyle.Fill
        Me.txtDetails.Multiline = True
        Me.txtDetails.ReadOnly = True
        Me.txtDetails.ScrollBars = ScrollBars.Both
        Me.pnlStatus.BackColor = SystemColors.ControlLight
        Me.pnlStatus.BorderStyle = BorderStyle.FixedSingle
        Me.pnlStatus.Controls.Add(Me.lblStatus)
        Me.pnlStatus.Dock = DockStyle.Bottom
        Me.pnlStatus.Size = New Size(960, 31)
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New Point(10, 8)
        Me.lblStatus.Text = "Drag the splitter bars to resize the panels."
        Me.AutoScaleDimensions = New SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = AutoScaleMode.Font
        Me.ClientSize = New Size(960, 600)
        Me.Controls.Add(Me.splitMain)
        Me.Controls.Add(Me.pnlStatus)
        Me.Controls.Add(Me.pnlTools)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.menuMain)
        Me.MainMenuStrip = Me.menuMain
        Me.MinimumSize = New Size(760, 500)
        Me.Name = "Form2"
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.Text = "Activity 3 - SplitPanel Form"
        Me.menuMain.ResumeLayout(False)
        Me.menuMain.PerformLayout()
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlTools.ResumeLayout(False)
        Me.splitMain.Panel1.ResumeLayout(False)
        Me.splitMain.Panel2.ResumeLayout(False)
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.splitMain.ResumeLayout(False)
        Me.splitInner.Panel1.ResumeLayout(False)
        Me.splitInner.Panel2.ResumeLayout(False)
        Me.splitInner.Panel2.PerformLayout()
        CType(Me.splitInner, System.ComponentModel.ISupportInitialize).EndInit()
        Me.splitInner.ResumeLayout(False)
        Me.pnlStatus.ResumeLayout(False)
        Me.pnlStatus.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()
    End Sub
End Class
