Option Strict On
Option Explicit On

Public Class Form2
    Private locked As Boolean = False

    Private Sub Form2_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        SetSafeDistance(splitMain, 210)
        SetSafeDistance(splitInner, CInt(splitInner.Height * 0.62))
        AddRecord("Student Records", "ListView in Panel1")
        AddRecord("Course Information", "Independent content")
        AddRecord("Enrollment Report", "Resizable section")
        AddRecord("System Settings", "Navigation example")
    End Sub

    Private Sub AddRecord(ByVal title As String, ByVal category As String)
        Dim item As New ListViewItem(title)
        item.SubItems.Add(category)
        lvRecords.Items.Add(item)
    End Sub

    Private Sub lvRecords_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles lvRecords.SelectedIndexChanged
        If lvRecords.SelectedItems.Count = 0 Then Return
        txtDetails.Text = "Selected record: " & lvRecords.SelectedItems(0).Text & vbCrLf & vbCrLf & _
                          "This information is displayed independently inside Panel2." & vbCrLf & vbCrLf & _
                          "Both panels can be resized by dragging the splitter."
    End Sub

    Private Sub menuPanel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles menuPanel.Click
        If Me.Owner IsNot Nothing Then
            Me.Owner.Show()
        Else
            Dim panelForm As New Form1()
            panelForm.Show()
        End If
        Me.Close()
    End Sub

    Private Sub menuExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles menuExit.Click
        Application.Exit()
    End Sub

    Private Sub btnCollapse1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCollapse1.Click
        CollapsePanel(splitMain, 1)
        lblStatus.Text = "CollapsePanel() collapsed Panel1 of the main SplitContainer."
    End Sub

    Private Sub btnCollapse2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCollapse2.Click
        CollapsePanel(splitInner, 2)
        lblStatus.Text = "CollapsePanel() collapsed Panel2 of the inner SplitContainer."
    End Sub

    Private Sub btnExpand_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnExpand.Click
        ExpandPanel(splitMain)
        ExpandPanel(splitInner)
        SetSafeDistance(splitMain, 210)
        If splitInner.Orientation = Orientation.Horizontal Then
            SetSafeDistance(splitInner, CInt(splitInner.Height * 0.62))
        Else
            SetSafeDistance(splitInner, CInt(splitInner.Width * 0.62))
        End If
        lblStatus.Text = "ExpandPanel() displayed Panel1 and Panel2."
    End Sub

    Private Sub btnOrientation_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnOrientation.Click
        Try
            splitInner.Panel1MinSize = 60
            splitInner.Panel2MinSize = 60
            SetSafeDistance(splitInner, 150)
            If splitInner.Orientation = Orientation.Horizontal Then
                splitInner.Orientation = Orientation.Vertical
                splitInner.Panel1MinSize = 180
                splitInner.Panel2MinSize = 160
                SetSafeDistance(splitInner, CInt(splitInner.Width * 0.62))
                lblStatus.Text = "Orientation = Vertical, panels are left and right."
            Else
                splitInner.Orientation = Orientation.Horizontal
                splitInner.Panel1MinSize = 120
                splitInner.Panel2MinSize = 100
                SetSafeDistance(splitInner, CInt(splitInner.Height * 0.62))
                lblStatus.Text = "Orientation = Horizontal, panels are top and bottom."
            End If
        Catch ex As Exception
            lblStatus.Text = ex.Message
        End Try
    End Sub

    Private Sub btnLock_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLock.Click
        locked = Not locked
        splitMain.IsSplitterFixed = locked
        splitInner.IsSplitterFixed = locked
        btnLock.Text = If(locked, "Unlock Splitters", "Lock Splitters")
        lblStatus.Text = "IsSplitterFixed = " & locked.ToString()
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRefresh.Click
        splitMain.Refresh()
        splitInner.Refresh()
        lblStatus.Text = "Refresh() repainted both SplitContainer controls."
    End Sub

    Private Sub btnInvalidate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnInvalidate.Click
        splitMain.Invalidate(True)
        splitInner.Invalidate(True)
        lblStatus.Text = "Invalidate() requested a redraw of every split panel."
    End Sub

    Private Sub btnDispose_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDispose.Click
        Dim sample As New SplitContainer()
        sample.Panel1.Controls.Add(New Label())
        sample.Panel2.Controls.Add(New Button())
        sample.Dispose()
        lblStatus.Text = "Dispose() released a temporary SplitContainer and both panels."
    End Sub

    Private Sub CollapsePanel(ByVal target As SplitContainer, ByVal panelNumber As Integer)
        If panelNumber = 1 Then
            target.Panel1Collapsed = True
        Else
            target.Panel2Collapsed = True
        End If
    End Sub

    Private Sub ExpandPanel(ByVal target As SplitContainer)
        target.Panel1Collapsed = False
        target.Panel2Collapsed = False
    End Sub

    Private Sub SetSafeDistance(ByVal target As SplitContainer, ByVal requested As Integer)
        Dim available As Integer
        If target.Orientation = Orientation.Vertical Then
            available = target.ClientSize.Width
        Else
            available = target.ClientSize.Height
        End If
        Dim minimum As Integer = target.Panel1MinSize
        Dim maximum As Integer = available - target.Panel2MinSize - target.SplitterWidth
        If maximum >= minimum Then target.SplitterDistance = Math.Max(minimum, Math.Min(requested, maximum))
    End Sub

    Private Sub splitMain_SplitterMoved(ByVal sender As Object, ByVal e As SplitterEventArgs) Handles splitMain.SplitterMoved
        lblStatus.Text = "Main SplitterDistance = " & splitMain.SplitterDistance.ToString()
    End Sub

    Private Sub splitInner_SplitterMoved(ByVal sender As Object, ByVal e As SplitterEventArgs) Handles splitInner.SplitterMoved
        lblStatus.Text = "Inner SplitterDistance = " & splitInner.SplitterDistance.ToString()
    End Sub
End Class
