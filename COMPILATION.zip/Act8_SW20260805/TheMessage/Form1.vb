﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub messageInfoGroupBox_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles messageInfoGroupBox.Enter

    End Sub

    Private Sub titleTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles titleTextBox.TextChanged

    End Sub

    Private Sub messageTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles messageTextBox.TextChanged

    End Sub

    Private Sub displayButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles displayButton.Click

        Dim messageDescription As String = messageTextBox.Text
        Dim messageTitle As String = titleTextBox.Text

        Dim iconType As MessageBoxIcon
        Dim buttonType As MessageBoxButtons
        Dim defaultButton As MessageBoxDefaultButton

        Dim result As DialogResult

        Try

            If String.IsNullOrWhiteSpace(titleTextBox.Text) Then
                MessageBox.Show("Please enter a title.",
                                "Missing Title",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning)

                titleTextBox.Focus()
                Return
            End If

            If String.IsNullOrWhiteSpace(messageTextBox.Text) Then
                MessageBox.Show("Please enter a message.",
                                "Missing Message",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning)

                messageTextBox.Focus()
                Return
            End If

            If Not informationRadioButton.Checked AndAlso
               Not warningRadioButton.Checked AndAlso
               Not questionRadioButton.Checked AndAlso
               Not criticalRadioButton.Checked Then

                MessageBox.Show("Please select an icon.",
                                "Icon Required",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning)

                Return
            End If

            If Not okRadioButton.Checked AndAlso
               Not okCancelRadioButton.Checked AndAlso
               Not yesNoRadioButton.Checked AndAlso
               Not yesNoCancelRadioButton.Checked AndAlso
               Not retryCancelRadioButton.Checked AndAlso
               Not abortRetryIgnoreRadioButton.Checked Then

                MessageBox.Show("Please select a button type.",
                                "Button Required",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning)

                Return
            End If

            If Not defaultButton1RadioButton.Checked AndAlso
               Not defaultButton2RadioButton.Checked AndAlso
               Not defaultButton3RadioButton.Checked Then

                MessageBox.Show("Please select a default button.",
                                "Default Button Required",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning)

                Return
            End If

            If informationRadioButton.Checked Then
                iconType = MessageBoxIcon.Information

            ElseIf warningRadioButton.Checked Then
                iconType = MessageBoxIcon.Warning

            ElseIf questionRadioButton.Checked Then
                iconType = MessageBoxIcon.Question

            Else
                iconType = MessageBoxIcon.Error
            End If

            If okRadioButton.Checked Then
                buttonType = MessageBoxButtons.OK

            ElseIf okCancelRadioButton.Checked Then
                buttonType = MessageBoxButtons.OKCancel

            ElseIf yesNoRadioButton.Checked Then
                buttonType = MessageBoxButtons.YesNo

            ElseIf yesNoCancelRadioButton.Checked Then
                buttonType = MessageBoxButtons.YesNoCancel

            ElseIf retryCancelRadioButton.Checked Then
                buttonType = MessageBoxButtons.RetryCancel

            Else
                buttonType = MessageBoxButtons.AbortRetryIgnore
            End If

            If defaultButton1RadioButton.Checked Then
                defaultButton = MessageBoxDefaultButton.Button1

            ElseIf defaultButton2RadioButton.Checked Then
                defaultButton = MessageBoxDefaultButton.Button2

            Else
                defaultButton = MessageBoxDefaultButton.Button3
            End If

            result = MessageBox.Show(
                messageDescription,
                messageTitle,
                buttonType,
                iconType,
                defaultButton)

            Select Case result

                Case DialogResult.OK
                    MessageBox.Show("OK has been clicked!",
                                    "Result",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                Case DialogResult.Cancel
                    MessageBox.Show("Cancel has been clicked!",
                                    "Result",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                Case DialogResult.Yes
                    MessageBox.Show("Yes has been clicked!",
                                    "Result",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                Case DialogResult.No
                    MessageBox.Show("No has been clicked!",
                                    "Result",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                Case DialogResult.Retry
                    MessageBox.Show("Retry has been clicked!",
                                    "Result",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                Case DialogResult.Abort
                    MessageBox.Show("Abort has been clicked!",
                                    "Result",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                Case DialogResult.Ignore
                    MessageBox.Show("Ignore has been clicked!",
                                    "Result",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

            End Select

        Catch ex As Exception

            MessageBox.Show(ex.Message,
                            "There is an error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)

        End Try

    End Sub

    Private Sub clearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearButton.Click

        titleTextBox.Clear()
        messageTextBox.Clear()

        informationRadioButton.Checked = False
        warningRadioButton.Checked = False
        questionRadioButton.Checked = False
        criticalRadioButton.Checked = False

        okRadioButton.Checked = False
        okCancelRadioButton.Checked = False
        yesNoRadioButton.Checked = False
        yesNoCancelRadioButton.Checked = False
        retryCancelRadioButton.Checked = False
        abortRetryIgnoreRadioButton.Checked = False

        defaultButton1RadioButton.Checked = False
        defaultButton2RadioButton.Checked = False
        defaultButton3RadioButton.Checked = False

        titleTextBox.Focus()

    End Sub

    Private Sub exitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitButton.Click

        Application.Exit()

    End Sub

    Private Sub iconsGroupBox_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles iconsGroupBox.Enter

    End Sub

    Private Sub informationRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles informationRadioButton.CheckedChanged

    End Sub

    Private Sub questionRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles questionRadioButton.CheckedChanged

    End Sub

    Private Sub warningRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles warningRadioButton.CheckedChanged

    End Sub

    Private Sub criticalRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles criticalRadioButton.CheckedChanged

    End Sub

    Private Sub buttonsGroupBox_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonsGroupBox.Enter

    End Sub

    Private Sub okRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okRadioButton.CheckedChanged

    End Sub

    Private Sub okCancelRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okCancelRadioButton.CheckedChanged

    End Sub

    Private Sub yesNoRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles yesNoRadioButton.CheckedChanged

    End Sub

    Private Sub yesNoCancelRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles yesNoCancelRadioButton.CheckedChanged

    End Sub

    Private Sub retryCancelRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles retryCancelRadioButton.CheckedChanged

    End Sub

    Private Sub abortRetryIgnoreRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles abortRetryIgnoreRadioButton.CheckedChanged

    End Sub

    Private Sub defaultButtonGroupBox_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles defaultButtonGroupBox.Enter

    End Sub

    Private Sub defaultButton1RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles defaultButton1RadioButton.CheckedChanged

    End Sub

    Private Sub defaultButton2RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles defaultButton2RadioButton.CheckedChanged

    End Sub

    Private Sub defaultButton3RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles defaultButton3RadioButton.CheckedChanged

    End Sub

End Class