﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.abortRetryIgnoreRadioButton = New System.Windows.Forms.RadioButton()
        Me.displayButton = New System.Windows.Forms.Button()
        Me.authorLabel = New System.Windows.Forms.Label()
        Me.messageInfoGroupBox = New System.Windows.Forms.GroupBox()
        Me.titleLabel = New System.Windows.Forms.Label()
        Me.titleTextBox = New System.Windows.Forms.TextBox()
        Me.messageLabel = New System.Windows.Forms.Label()
        Me.messageTextBox = New System.Windows.Forms.TextBox()
        Me.criticalRadioButton = New System.Windows.Forms.RadioButton()
        Me.buttonsGroupBox = New System.Windows.Forms.GroupBox()
        Me.okRadioButton = New System.Windows.Forms.RadioButton()
        Me.okCancelRadioButton = New System.Windows.Forms.RadioButton()
        Me.yesNoRadioButton = New System.Windows.Forms.RadioButton()
        Me.yesNoCancelRadioButton = New System.Windows.Forms.RadioButton()
        Me.retryCancelRadioButton = New System.Windows.Forms.RadioButton()
        Me.warningRadioButton = New System.Windows.Forms.RadioButton()
        Me.defaultButtonGroupBox = New System.Windows.Forms.GroupBox()
        Me.clearButton = New System.Windows.Forms.Button()
        Me.exitButton = New System.Windows.Forms.Button()
        Me.headingLabel = New System.Windows.Forms.Label()
        Me.questionRadioButton = New System.Windows.Forms.RadioButton()
        Me.informationRadioButton = New System.Windows.Forms.RadioButton()
        Me.iconsGroupBox = New System.Windows.Forms.GroupBox()
        Me.defaultButton1RadioButton = New System.Windows.Forms.RadioButton()
        Me.defaultButton2RadioButton = New System.Windows.Forms.RadioButton()
        Me.defaultButton3RadioButton = New System.Windows.Forms.RadioButton()
        Me.messageInfoGroupBox.SuspendLayout()
        Me.buttonsGroupBox.SuspendLayout()
        Me.defaultButtonGroupBox.SuspendLayout()
        Me.iconsGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'abortRetryIgnoreRadioButton
        '
        Me.abortRetryIgnoreRadioButton.AutoSize = True
        Me.abortRetryIgnoreRadioButton.Location = New System.Drawing.Point(175, 72)
        Me.abortRetryIgnoreRadioButton.Name = "abortRetryIgnoreRadioButton"
        Me.abortRetryIgnoreRadioButton.Size = New System.Drawing.Size(105, 17)
        Me.abortRetryIgnoreRadioButton.TabIndex = 5
        Me.abortRetryIgnoreRadioButton.Text = "AbortRetryIgnore"
        Me.abortRetryIgnoreRadioButton.UseVisualStyleBackColor = True
        '
        'displayButton
        '
        Me.displayButton.Location = New System.Drawing.Point(335, 69)
        Me.displayButton.Name = "displayButton"
        Me.displayButton.Size = New System.Drawing.Size(128, 28)
        Me.displayButton.TabIndex = 30
        Me.displayButton.Text = "Display"
        Me.displayButton.UseVisualStyleBackColor = True
        '
        'authorLabel
        '
        Me.authorLabel.AutoSize = True
        Me.authorLabel.Location = New System.Drawing.Point(17, 45)
        Me.authorLabel.Name = "authorLabel"
        Me.authorLabel.Size = New System.Drawing.Size(101, 13)
        Me.authorLabel.TabIndex = 28
        Me.authorLabel.Text = "Author: Rex Alvarez"
        '
        'messageInfoGroupBox
        '
        Me.messageInfoGroupBox.Controls.Add(Me.titleLabel)
        Me.messageInfoGroupBox.Controls.Add(Me.titleTextBox)
        Me.messageInfoGroupBox.Controls.Add(Me.messageLabel)
        Me.messageInfoGroupBox.Controls.Add(Me.messageTextBox)
        Me.messageInfoGroupBox.Location = New System.Drawing.Point(17, 69)
        Me.messageInfoGroupBox.Name = "messageInfoGroupBox"
        Me.messageInfoGroupBox.Size = New System.Drawing.Size(294, 108)
        Me.messageInfoGroupBox.TabIndex = 29
        Me.messageInfoGroupBox.TabStop = False
        Me.messageInfoGroupBox.Text = "Message Info:"
        '
        'titleLabel
        '
        Me.titleLabel.AutoSize = True
        Me.titleLabel.Location = New System.Drawing.Point(44, 30)
        Me.titleLabel.Name = "titleLabel"
        Me.titleLabel.Size = New System.Drawing.Size(30, 13)
        Me.titleLabel.TabIndex = 0
        Me.titleLabel.Text = "Title:"
        '
        'titleTextBox
        '
        Me.titleTextBox.Location = New System.Drawing.Point(80, 27)
        Me.titleTextBox.Name = "titleTextBox"
        Me.titleTextBox.Size = New System.Drawing.Size(197, 20)
        Me.titleTextBox.TabIndex = 1
        '
        'messageLabel
        '
        Me.messageLabel.AutoSize = True
        Me.messageLabel.Location = New System.Drawing.Point(16, 57)
        Me.messageLabel.Name = "messageLabel"
        Me.messageLabel.Size = New System.Drawing.Size(53, 13)
        Me.messageLabel.TabIndex = 2
        Me.messageLabel.Text = "Message:"
        '
        'messageTextBox
        '
        Me.messageTextBox.Location = New System.Drawing.Point(80, 54)
        Me.messageTextBox.Name = "messageTextBox"
        Me.messageTextBox.Size = New System.Drawing.Size(197, 20)
        Me.messageTextBox.TabIndex = 3
        '
        'criticalRadioButton
        '
        Me.criticalRadioButton.AutoSize = True
        Me.criticalRadioButton.Location = New System.Drawing.Point(116, 52)
        Me.criticalRadioButton.Name = "criticalRadioButton"
        Me.criticalRadioButton.Size = New System.Drawing.Size(56, 17)
        Me.criticalRadioButton.TabIndex = 3
        Me.criticalRadioButton.Text = "Critical"
        Me.criticalRadioButton.UseVisualStyleBackColor = True
        '
        'buttonsGroupBox
        '
        Me.buttonsGroupBox.Controls.Add(Me.okRadioButton)
        Me.buttonsGroupBox.Controls.Add(Me.okCancelRadioButton)
        Me.buttonsGroupBox.Controls.Add(Me.yesNoRadioButton)
        Me.buttonsGroupBox.Controls.Add(Me.yesNoCancelRadioButton)
        Me.buttonsGroupBox.Controls.Add(Me.retryCancelRadioButton)
        Me.buttonsGroupBox.Controls.Add(Me.abortRetryIgnoreRadioButton)
        Me.buttonsGroupBox.Location = New System.Drawing.Point(254, 189)
        Me.buttonsGroupBox.Name = "buttonsGroupBox"
        Me.buttonsGroupBox.Size = New System.Drawing.Size(288, 108)
        Me.buttonsGroupBox.TabIndex = 34
        Me.buttonsGroupBox.TabStop = False
        Me.buttonsGroupBox.Text = "Buttons"
        '
        'okRadioButton
        '
        Me.okRadioButton.AutoSize = True
        Me.okRadioButton.Checked = True
        Me.okRadioButton.Location = New System.Drawing.Point(18, 24)
        Me.okRadioButton.Name = "okRadioButton"
        Me.okRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.okRadioButton.TabIndex = 0
        Me.okRadioButton.TabStop = True
        Me.okRadioButton.Text = "Ok"
        Me.okRadioButton.UseVisualStyleBackColor = True
        '
        'okCancelRadioButton
        '
        Me.okCancelRadioButton.AutoSize = True
        Me.okCancelRadioButton.Location = New System.Drawing.Point(18, 48)
        Me.okCancelRadioButton.Name = "okCancelRadioButton"
        Me.okCancelRadioButton.Size = New System.Drawing.Size(77, 17)
        Me.okCancelRadioButton.TabIndex = 1
        Me.okCancelRadioButton.Text = "Ok/Cancel"
        Me.okCancelRadioButton.UseVisualStyleBackColor = True
        '
        'yesNoRadioButton
        '
        Me.yesNoRadioButton.AutoSize = True
        Me.yesNoRadioButton.Location = New System.Drawing.Point(18, 72)
        Me.yesNoRadioButton.Name = "yesNoRadioButton"
        Me.yesNoRadioButton.Size = New System.Drawing.Size(62, 17)
        Me.yesNoRadioButton.TabIndex = 2
        Me.yesNoRadioButton.Text = "Yes/No"
        Me.yesNoRadioButton.UseVisualStyleBackColor = True
        '
        'yesNoCancelRadioButton
        '
        Me.yesNoCancelRadioButton.AutoSize = True
        Me.yesNoCancelRadioButton.Location = New System.Drawing.Point(175, 24)
        Me.yesNoCancelRadioButton.Name = "yesNoCancelRadioButton"
        Me.yesNoCancelRadioButton.Size = New System.Drawing.Size(90, 17)
        Me.yesNoCancelRadioButton.TabIndex = 3
        Me.yesNoCancelRadioButton.Text = "YesNoCancel"
        Me.yesNoCancelRadioButton.UseVisualStyleBackColor = True
        '
        'retryCancelRadioButton
        '
        Me.retryCancelRadioButton.AutoSize = True
        Me.retryCancelRadioButton.Location = New System.Drawing.Point(175, 48)
        Me.retryCancelRadioButton.Name = "retryCancelRadioButton"
        Me.retryCancelRadioButton.Size = New System.Drawing.Size(83, 17)
        Me.retryCancelRadioButton.TabIndex = 4
        Me.retryCancelRadioButton.Text = "RetryCancel"
        Me.retryCancelRadioButton.UseVisualStyleBackColor = True
        '
        'warningRadioButton
        '
        Me.warningRadioButton.AutoSize = True
        Me.warningRadioButton.Location = New System.Drawing.Point(116, 26)
        Me.warningRadioButton.Name = "warningRadioButton"
        Me.warningRadioButton.Size = New System.Drawing.Size(65, 17)
        Me.warningRadioButton.TabIndex = 1
        Me.warningRadioButton.Text = "Warning"
        Me.warningRadioButton.UseVisualStyleBackColor = True
        '
        'defaultButtonGroupBox
        '
        Me.defaultButtonGroupBox.Controls.Add(Me.defaultButton1RadioButton)
        Me.defaultButtonGroupBox.Controls.Add(Me.defaultButton2RadioButton)
        Me.defaultButtonGroupBox.Controls.Add(Me.defaultButton3RadioButton)
        Me.defaultButtonGroupBox.Location = New System.Drawing.Point(17, 307)
        Me.defaultButtonGroupBox.Name = "defaultButtonGroupBox"
        Me.defaultButtonGroupBox.Size = New System.Drawing.Size(525, 84)
        Me.defaultButtonGroupBox.TabIndex = 35
        Me.defaultButtonGroupBox.TabStop = False
        Me.defaultButtonGroupBox.Text = "DefaultButton"
        '
        'clearButton
        '
        Me.clearButton.Location = New System.Drawing.Point(335, 103)
        Me.clearButton.Name = "clearButton"
        Me.clearButton.Size = New System.Drawing.Size(128, 28)
        Me.clearButton.TabIndex = 31
        Me.clearButton.Text = "Clear"
        Me.clearButton.UseVisualStyleBackColor = True
        '
        'exitButton
        '
        Me.exitButton.Location = New System.Drawing.Point(335, 137)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(128, 28)
        Me.exitButton.TabIndex = 32
        Me.exitButton.Text = "Exit"
        Me.exitButton.UseVisualStyleBackColor = True
        '
        'headingLabel
        '
        Me.headingLabel.AutoSize = True
        Me.headingLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.headingLabel.Location = New System.Drawing.Point(17, 19)
        Me.headingLabel.Name = "headingLabel"
        Me.headingLabel.Size = New System.Drawing.Size(103, 16)
        Me.headingLabel.TabIndex = 27
        Me.headingLabel.Text = "The Message"
        '
        'questionRadioButton
        '
        Me.questionRadioButton.AutoSize = True
        Me.questionRadioButton.Location = New System.Drawing.Point(16, 52)
        Me.questionRadioButton.Name = "questionRadioButton"
        Me.questionRadioButton.Size = New System.Drawing.Size(67, 17)
        Me.questionRadioButton.TabIndex = 2
        Me.questionRadioButton.Text = "Question"
        Me.questionRadioButton.UseVisualStyleBackColor = True
        '
        'informationRadioButton
        '
        Me.informationRadioButton.AutoSize = True
        Me.informationRadioButton.Checked = True
        Me.informationRadioButton.Location = New System.Drawing.Point(16, 26)
        Me.informationRadioButton.Name = "informationRadioButton"
        Me.informationRadioButton.Size = New System.Drawing.Size(77, 17)
        Me.informationRadioButton.TabIndex = 0
        Me.informationRadioButton.TabStop = True
        Me.informationRadioButton.Text = "Information"
        Me.informationRadioButton.UseVisualStyleBackColor = True
        '
        'iconsGroupBox
        '
        Me.iconsGroupBox.Controls.Add(Me.informationRadioButton)
        Me.iconsGroupBox.Controls.Add(Me.warningRadioButton)
        Me.iconsGroupBox.Controls.Add(Me.questionRadioButton)
        Me.iconsGroupBox.Controls.Add(Me.criticalRadioButton)
        Me.iconsGroupBox.Location = New System.Drawing.Point(17, 189)
        Me.iconsGroupBox.Name = "iconsGroupBox"
        Me.iconsGroupBox.Size = New System.Drawing.Size(225, 108)
        Me.iconsGroupBox.TabIndex = 33
        Me.iconsGroupBox.TabStop = False
        Me.iconsGroupBox.Text = "Icons"
        '
        'defaultButton1RadioButton
        '
        Me.defaultButton1RadioButton.AutoSize = True
        Me.defaultButton1RadioButton.Checked = True
        Me.defaultButton1RadioButton.Location = New System.Drawing.Point(94, 34)
        Me.defaultButton1RadioButton.Name = "defaultButton1RadioButton"
        Me.defaultButton1RadioButton.Size = New System.Drawing.Size(96, 17)
        Me.defaultButton1RadioButton.TabIndex = 3
        Me.defaultButton1RadioButton.TabStop = True
        Me.defaultButton1RadioButton.Text = "DefaultButton1"
        Me.defaultButton1RadioButton.UseVisualStyleBackColor = True
        '
        'defaultButton2RadioButton
        '
        Me.defaultButton2RadioButton.AutoSize = True
        Me.defaultButton2RadioButton.Location = New System.Drawing.Point(217, 34)
        Me.defaultButton2RadioButton.Name = "defaultButton2RadioButton"
        Me.defaultButton2RadioButton.Size = New System.Drawing.Size(96, 17)
        Me.defaultButton2RadioButton.TabIndex = 4
        Me.defaultButton2RadioButton.Text = "DefaultButton2"
        Me.defaultButton2RadioButton.UseVisualStyleBackColor = True
        '
        'defaultButton3RadioButton
        '
        Me.defaultButton3RadioButton.AutoSize = True
        Me.defaultButton3RadioButton.Location = New System.Drawing.Point(334, 34)
        Me.defaultButton3RadioButton.Name = "defaultButton3RadioButton"
        Me.defaultButton3RadioButton.Size = New System.Drawing.Size(96, 17)
        Me.defaultButton3RadioButton.TabIndex = 5
        Me.defaultButton3RadioButton.Text = "DefaultButton3"
        Me.defaultButton3RadioButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(558, 411)
        Me.Controls.Add(Me.displayButton)
        Me.Controls.Add(Me.authorLabel)
        Me.Controls.Add(Me.messageInfoGroupBox)
        Me.Controls.Add(Me.buttonsGroupBox)
        Me.Controls.Add(Me.defaultButtonGroupBox)
        Me.Controls.Add(Me.clearButton)
        Me.Controls.Add(Me.exitButton)
        Me.Controls.Add(Me.headingLabel)
        Me.Controls.Add(Me.iconsGroupBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.messageInfoGroupBox.ResumeLayout(False)
        Me.messageInfoGroupBox.PerformLayout()
        Me.buttonsGroupBox.ResumeLayout(False)
        Me.buttonsGroupBox.PerformLayout()
        Me.defaultButtonGroupBox.ResumeLayout(False)
        Me.defaultButtonGroupBox.PerformLayout()
        Me.iconsGroupBox.ResumeLayout(False)
        Me.iconsGroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents abortRetryIgnoreRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents displayButton As System.Windows.Forms.Button
    Friend WithEvents authorLabel As System.Windows.Forms.Label
    Friend WithEvents messageInfoGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents titleLabel As System.Windows.Forms.Label
    Friend WithEvents titleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents messageLabel As System.Windows.Forms.Label
    Friend WithEvents messageTextBox As System.Windows.Forms.TextBox
    Friend WithEvents criticalRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents buttonsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents okRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents okCancelRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents yesNoRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents yesNoCancelRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents retryCancelRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents warningRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents defaultButtonGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents defaultButton1RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents defaultButton2RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents defaultButton3RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents clearButton As System.Windows.Forms.Button
    Friend WithEvents exitButton As System.Windows.Forms.Button
    Friend WithEvents headingLabel As System.Windows.Forms.Label
    Friend WithEvents questionRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents informationRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents iconsGroupBox As System.Windows.Forms.GroupBox

End Class
