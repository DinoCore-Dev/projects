﻿Public Class Form1

    Private n1 As Integer
    Private n2 As Integer
    Private n3 As Integer
    Private sum As Integer
    Private diff As Integer
    Private quot As Integer
    Private product As Integer
    Private average As Integer

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtn1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtn1.TextChanged

    End Sub

    Private Sub txtn2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtn2.TextChanged

    End Sub

    Private Sub txtn3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtn3.TextChanged

    End Sub

    Private Sub txtsum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsum.TextChanged

    End Sub

    Private Sub txtdiff_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdiff.TextChanged

    End Sub

    Private Sub txtprod_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtprod.TextChanged

    End Sub

    Private Sub txtquot_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtquot.TextChanged
        
    End Sub

    Private Sub txtave_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtave.TextChanged

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        Try
            n1 = Convert.ToInt32(txtn1.Text())
            n2 = Convert.ToInt32(txtn2.Text())
            n3 = Convert.ToInt32(txtn3.Text())

            sum = n1 + n2 + n3
            txtsum.Text() = sum.ToString()
            

        Catch ex As Exception
            txtsum.Text = "Error: Maybe Invalid Number..."
        End Try

    End Sub

    Private Sub btnSubtract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubtract.Click
        Try
            n1 = Convert.ToInt32(txtn1.Text())
            n2 = Convert.ToInt32(txtn2.Text())
            n3 = Convert.ToInt32(txtn3.Text())

            diff = n1 - n2 - n3
            txtdiff.Text() = diff.ToString()


        Catch ex As Exception
            txtdiff.Text = "Error: Maybe Invalid Number..."
        End Try
    End Sub

    Private Sub btnMultiply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMultiply.Click
        Try
            n1 = Convert.ToInt32(txtn1.Text())
            n2 = Convert.ToInt32(txtn2.Text())
            n3 = Convert.ToInt32(txtn3.Text())

            quot = n1 * n2 * n3
            txtquot.Text() = quot.ToString()

        Catch ex As Exception
            txtquot.Text = "Error: Maybe Invalid Number..."
        End Try
    End Sub

    Private Sub btnDivide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDivide.Click
        Try
            n1 = Convert.ToInt32(txtn1.Text())
            n2 = Convert.ToInt32(txtn2.Text())
            n3 = Convert.ToInt32(txtn3.Text())

            product = n1 / n2 / n3
            txtprod.Text() = product.ToString()


        Catch ex As Exception
            txtprod.Text = "Error: Maybe Invalid Number..."
        End Try
    End Sub

    Private Sub btnAverage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAverage.Click
        Try
            n1 = Convert.ToInt32(txtn1.Text())
            n2 = Convert.ToInt32(txtn2.Text())
            n3 = Convert.ToInt32(txtn3.Text())

            average = (n1 + n2 + n3) / 3
            txtave.Text() = average.ToString()


        Catch ex As Exception
            txtave.Text = "Error: Maybe Invalid Number..."
        End Try
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtn1.Clear()
        txtn2.Clear()
        txtn3.Clear()
        txtsum.Clear()
        txtdiff.Clear()
        txtprod.Clear()
        txtquot.Clear()
        txtave.Clear()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
End Class
