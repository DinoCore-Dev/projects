Option Strict On
Option Explicit On

Imports System.IO
Imports System.Text

Public Class Form1
    Private currentPath As String = ""
    Private history As New List(Of String)()
    Private historyPosition As Integer = -1
    Private changingFolder As Boolean = False
    Private splittersLocked As Boolean = False
    Private previewHost As Panel
    Private cutPaths As New List(Of String)()

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            txtSearch.Text = ""
            cboShowMode.Items.Clear()
            cboShowMode.Items.Add("Details")
            cboShowMode.Items.Add("Preview")
            cboShowMode.Items.Add("Details + Preview")
            cboShowMode.SelectedIndex = 2
            SetSafeSplitterDistance(splitMain, 220)
            SetSafeSplitterDistance(splitContent, CInt(splitContent.Width * 0.64))
            LoadFolderTree()
            Dim startFolder As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
            If Not Directory.Exists(startFolder) Then startFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
            If Not Directory.Exists(startFolder) Then startFolder = Environment.CurrentDirectory
            NavigateTo(startFolder, True)
            UpdateFileToolState()
        Catch ex As Exception
            lblStatus.Text = "The explorer could not finish loading: " & ex.Message
        End Try
    End Sub

    Private Sub LoadFolderTree()
        tvFolders.Nodes.Clear()
        AddRootNode("Desktop", Environment.GetFolderPath(Environment.SpecialFolder.Desktop))
        AddRootNode("Documents", Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments))
        AddRootNode("Pictures", Environment.GetFolderPath(Environment.SpecialFolder.MyPictures))
        AddRootNode("Computer", "")
        Dim computer As TreeNode = tvFolders.Nodes(tvFolders.Nodes.Count - 1)
        For Each drive As DriveInfo In DriveInfo.GetDrives()
            Dim node As New TreeNode(drive.Name)
            node.Tag = drive.RootDirectory.FullName
            node.Nodes.Add(New TreeNode("Loading"))
            computer.Nodes.Add(node)
        Next
        computer.Expand()
    End Sub

    Private Sub AddRootNode(ByVal title As String, ByVal folderPath As String)
        If folderPath = "" OrElse Not Directory.Exists(folderPath) Then Return
        Dim node As New TreeNode(title)
        node.Tag = folderPath
        node.Nodes.Add(New TreeNode("Loading"))
        tvFolders.Nodes.Add(node)
    End Sub

    Private Sub tvFolders_BeforeExpand(ByVal sender As Object, ByVal e As TreeViewCancelEventArgs) Handles tvFolders.BeforeExpand
        If e.Node.Tag Is Nothing Then Return
        If e.Node.Nodes.Count = 1 AndAlso e.Node.Nodes(0).Tag Is Nothing Then
            e.Node.Nodes.Clear()
            Try
                For Each folder As String In Directory.GetDirectories(CStr(e.Node.Tag))
                    Dim info As New DirectoryInfo(folder)
                    If (info.Attributes And FileAttributes.Hidden) = 0 Then
                        Dim child As New TreeNode(info.Name)
                        child.Tag = info.FullName
                        child.Nodes.Add(New TreeNode("Loading"))
                        e.Node.Nodes.Add(child)
                    End If
                Next
            Catch
            End Try
        End If
    End Sub

    Private Sub tvFolders_AfterSelect(ByVal sender As Object, ByVal e As TreeViewEventArgs) Handles tvFolders.AfterSelect
        If changingFolder OrElse e.Node.Tag Is Nothing Then Return
        NavigateTo(CStr(e.Node.Tag), True)
    End Sub

    Private Sub NavigateTo(ByVal folderPath As String, ByVal addToHistory As Boolean)
        If folderPath = "" OrElse Not Directory.Exists(folderPath) Then
            lblStatus.Text = "Folder not found."
            Return
        End If
        Try
            currentPath = folderPath
            txtAddress.Text = folderPath
            lblFiles.Text = IO.Path.GetFileName(folderPath)
            If lblFiles.Text = "" Then lblFiles.Text = folderPath
            If addToHistory Then
                If historyPosition < history.Count - 1 Then
                    history.RemoveRange(historyPosition + 1, history.Count - historyPosition - 1)
                End If
                If history.Count = 0 OrElse history(history.Count - 1) <> folderPath Then
                    history.Add(folderPath)
                    historyPosition = history.Count - 1
                End If
            End If
            FillFileList(txtSearch.Text.Trim())
            SelectTreePath(folderPath)
            ClearPreview("Select a file or folder to preview it.")
        Catch ex As Exception
            lblStatus.Text = ex.Message
        End Try
    End Sub

    Private Sub SelectTreePath(ByVal folderPath As String)
        changingFolder = True
        Try
            Dim found As TreeNode = FindNode(tvFolders.Nodes, folderPath)
            If found IsNot Nothing Then tvFolders.SelectedNode = found
        Finally
            changingFolder = False
        End Try
    End Sub

    Private Function FindNode(ByVal nodes As TreeNodeCollection, ByVal folderPath As String) As TreeNode
        For Each node As TreeNode In nodes
            If node.Tag IsNot Nothing AndAlso String.Equals(CStr(node.Tag), folderPath, StringComparison.OrdinalIgnoreCase) Then Return node
            If node.IsExpanded Then
                Dim found As TreeNode = FindNode(node.Nodes, folderPath)
                If found IsNot Nothing Then Return found
            End If
        Next
        Return Nothing
    End Function

    Private Sub FillFileList(ByVal filter As String)
        lvFiles.BeginUpdate()
        lvFiles.Items.Clear()
        Try
            For Each folder As String In Directory.GetDirectories(currentPath)
                Dim info As New DirectoryInfo(folder)
                If (info.Attributes And FileAttributes.Hidden) = 0 AndAlso MatchesFilter(info.Name, filter) Then
                    Dim item As New ListViewItem(info.Name)
                    item.SubItems.Add("File folder")
                    item.SubItems.Add("")
                    item.SubItems.Add(info.LastWriteTime.ToString("g"))
                    item.Tag = info.FullName
                    lvFiles.Items.Add(item)
                End If
            Next
            For Each fileName As String In Directory.GetFiles(currentPath)
                Dim info As New FileInfo(fileName)
                If MatchesFilter(info.Name, filter) Then
                    Dim item As New ListViewItem(info.Name)
                    Dim extension As String = info.Extension.ToUpperInvariant()
                    If extension = "" Then extension = "File"
                    item.SubItems.Add(extension & " file")
                    item.SubItems.Add(FormatSize(info.Length))
                    item.SubItems.Add(info.LastWriteTime.ToString("g"))
                    item.Tag = info.FullName
                    lvFiles.Items.Add(item)
                End If
            Next
            lblStatus.Text = lvFiles.Items.Count.ToString() & " items   |   " & currentPath
        Catch ex As Exception
            lblStatus.Text = "Cannot open folder: " & ex.Message
        Finally
            lvFiles.EndUpdate()
        End Try
    End Sub

    Private Function MatchesFilter(ByVal itemName As String, ByVal filter As String) As Boolean
        If filter = "" Then Return True
        Return itemName.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0
    End Function

    Private Function FormatSize(ByVal value As Long) As String
        If value >= 1073741824 Then Return (value / 1073741824.0).ToString("0.00") & " GB"
        If value >= 1048576 Then Return (value / 1048576.0).ToString("0.00") & " MB"
        If value >= 1024 Then Return (value / 1024.0).ToString("0.00") & " KB"
        Return value.ToString() & " bytes"
    End Function

    Private Sub lvFiles_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles lvFiles.SelectedIndexChanged
        UpdateFileToolState()
        If lvFiles.SelectedItems.Count = 0 Then
            ClearPreview("Select a file or folder to preview it.")
            Return
        End If
        ShowPreview(CStr(lvFiles.SelectedItems(0).Tag))
    End Sub

    Private Sub lvFiles_DoubleClick(ByVal sender As Object, ByVal e As EventArgs) Handles lvFiles.DoubleClick
        If lvFiles.SelectedItems.Count = 0 Then Return
        Dim selectedPath As String = CStr(lvFiles.SelectedItems(0).Tag)
        If Directory.Exists(selectedPath) Then
            NavigateTo(selectedPath, True)
        Else
            Try
                Process.Start(selectedPath)
            Catch ex As Exception
                lblStatus.Text = ex.Message
            End Try
        End If
    End Sub

    Private Sub ShowPreview(ByVal selectedPath As String)
        ClearPreview("")
        previewHost = New Panel()
        previewHost.Dock = DockStyle.Fill
        previewHost.AutoScroll = True
        previewHost.BackColor = Color.White
        previewHost.TabStop = True
        pnlPreviewContent.Controls.Add(previewHost)
        lblPreviewTitle.Text = IO.Path.GetFileName(selectedPath)

        If Directory.Exists(selectedPath) Then
            Try
                Dim info As New DirectoryInfo(selectedPath)
                Dim folderCount As Integer = 0
                Dim fileCount As Integer = 0
                Try
                    folderCount = Directory.GetDirectories(selectedPath).Length
                    fileCount = Directory.GetFiles(selectedPath).Length
                Catch
                End Try
                Dim parentLocation As String = info.FullName
                If info.Parent IsNot Nothing Then parentLocation = info.Parent.FullName
                txtPreviewDetails.Text = "Type: File folder" & vbCrLf & _
                                         "Location: " & parentLocation & vbCrLf & _
                                         "Modified: " & info.LastWriteTime.ToString("g") & vbCrLf & _
                                         "Contains: " & folderCount.ToString() & " folders, " & fileCount.ToString() & " files"
                Dim text As New StringBuilder()
                text.AppendLine(info.FullName)
                text.AppendLine()
                Try
                    For Each folder As String In Directory.GetDirectories(selectedPath)
                        text.AppendLine("[Folder]  " & IO.Path.GetFileName(folder))
                        If text.Length > 100000 Then Exit For
                    Next
                    For Each fileName As String In Directory.GetFiles(selectedPath)
                        Dim child As New FileInfo(fileName)
                        text.AppendLine("          " & child.Name & "   " & FormatSize(child.Length))
                        If text.Length > 200000 Then Exit For
                    Next
                Catch ex As Exception
                    text.AppendLine(ex.Message)
                End Try
                AddTextPreview(text.ToString(), False)
            Catch ex As Exception
                AddTextPreview("Folder preview is not available." & vbCrLf & ex.Message, True)
            End Try
            Return
        End If

        Try
            If Not File.Exists(selectedPath) Then
                ClearPreview("The selected file no longer exists.")
                Return
            End If

            Dim info As New FileInfo(selectedPath)
            Dim extension As String = info.Extension.ToLowerInvariant()
            txtPreviewDetails.Text = "Type: " & If(extension = "", "File", extension.ToUpperInvariant() & " file") & vbCrLf & _
                                     "Size: " & FormatSize(info.Length) & vbCrLf & _
                                     "Created: " & info.CreationTime.ToString("g") & vbCrLf & _
                                     "Modified: " & info.LastWriteTime.ToString("g") & vbCrLf & _
                                     "Attributes: " & info.Attributes.ToString()

            Select Case extension
                Case ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".ico", ".tif", ".tiff", ".wmf", ".emf"
                    If info.Length > 52428800 Then
                        AddTextPreview("This image is larger than 50 MB. Open it normally to avoid using too much memory.", True)
                        Return
                    End If
                    Dim data As Byte() = File.ReadAllBytes(selectedPath)
                    Using stream As New MemoryStream(data)
                        Using source As Image = Image.FromStream(stream)
                            Dim picture As New PictureBox()
                            picture.Dock = DockStyle.Fill
                            picture.SizeMode = PictureBoxSizeMode.Zoom
                            picture.Image = New Bitmap(source)
                            previewHost.Controls.Add(picture)
                            txtPreviewDetails.Text &= vbCrLf & "Dimensions: " & source.Width.ToString() & " x " & source.Height.ToString()
                        End Using
                    End Using

                Case ".rtf"
                    AddRtfPreview(selectedPath)

                Case ".htm", ".html", ".mht", ".mhtml", ".xhtml", ".svg"
                    AddWebPreview(selectedPath)

                Case ".pdf"
                    AddTextPreview(PreviewEngine.GetPdfText(selectedPath), True)

                Case ".docx", ".docm", ".dotx"
                    AddTextPreview(PreviewEngine.GetDocxText(selectedPath), True)

                Case ".xlsx", ".xltx"
                    AddTextPreview(PreviewEngine.GetXlsxText(selectedPath), False)

                Case ".pptx", ".ppsx", ".potx"
                    AddTextPreview(PreviewEngine.GetPptxText(selectedPath), True)

                Case ".doc", ".dot", ".xls", ".xlsm", ".xlsb", ".ppt", ".pps"
                    Dim officeText As String = PreviewEngine.GetLegacyOfficeText(selectedPath)
                    If String.IsNullOrEmpty(officeText) Then
                        officeText = "Microsoft Office is not available for a full preview." & vbCrLf & vbCrLf & PreviewEngine.ScrapeText(selectedPath, 1048576)
                    End If
                    AddTextPreview(officeText, True)

                Case ".csv"
                    AddTextPreview(PreviewEngine.FormatDelimited(ReadText(selectedPath), ","c), False)

                Case ".tsv"
                    AddTextPreview(PreviewEngine.FormatDelimited(ReadText(selectedPath), CChar(vbTab)), False)

                Case ".zip", ".jar", ".apk", ".vsix", ".nupkg", ".epub"
                    AddTextPreview(PreviewEngine.GetZipListing(selectedPath), False)

                Case ".exe", ".dll", ".ocx", ".sys"
                    AddTextPreview(PreviewEngine.GetVersionText(selectedPath) & vbCrLf & GetHexPreview(selectedPath, 512), False)

                Case ".mp3", ".wav", ".wma", ".m4a", ".flac", ".ogg", ".aac", ".mp4", ".avi", ".mkv", ".wmv", ".mov", ".flv", ".3gp", ".webm"
                    AddTextPreview(PreviewEngine.GetMediaText(selectedPath), True)

                Case ".txt", ".log", ".ini", ".xml", ".vb", ".cs", ".cpp", ".c", ".h", ".json", ".sql", ".bat", ".cmd", ".ps1", ".py", ".java", ".js", ".css", ".config", ".md"
                    AddTextPreview(ReadText(selectedPath), False)

                Case Else
                    If LooksLikeText(selectedPath) Then
                        AddTextPreview(ReadText(selectedPath), False)
                    Else
                        AddTextPreview("This format has no visual preview. The first bytes are shown below." & vbCrLf & vbCrLf & GetHexPreview(selectedPath, 2048), False)
                    End If
            End Select

            previewHost.Focus()
            pnlPreviewContent.Refresh()
        Catch ex As OutOfMemoryException
            AddTextPreview("The file is too large or damaged to preview safely.", True)
        Catch ex As UnauthorizedAccessException
            AddTextPreview("Access to this file was denied.", True)
        Catch ex As IOException
            AddTextPreview("The file is unavailable or is being used by another program." & vbCrLf & ex.Message, True)
        Catch ex As Exception
            AddTextPreview("Preview is not available." & vbCrLf & vbCrLf & ex.Message, True)
        End Try
    End Sub

    Private Sub AddRtfPreview(ByVal fileName As String)
        Dim box As New RichTextBox()
        box.BackColor = Color.White
        box.BorderStyle = BorderStyle.None
        box.Dock = DockStyle.Fill
        box.ReadOnly = True
        box.ScrollBars = RichTextBoxScrollBars.Both
        box.LoadFile(fileName)
        previewHost.Controls.Add(box)
    End Sub

    Private Sub AddWebPreview(ByVal fileName As String)
        Dim browser As New WebBrowser()
        browser.AllowWebBrowserDrop = False
        browser.Dock = DockStyle.Fill
        browser.IsWebBrowserContextMenuEnabled = False
        browser.ScriptErrorsSuppressed = True
        previewHost.Controls.Add(browser)
        browser.Navigate(New Uri(fileName))
    End Sub

    Private Function LooksLikeText(ByVal fileName As String) As Boolean
        Try
            Using stream As New FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
                Dim size As Integer = CInt(Math.Min(stream.Length, 1024))
                If size = 0 Then Return True
                Dim data(size - 1) As Byte
                stream.Read(data, 0, size)
                Dim unusual As Integer = 0
                For Each value As Byte In data
                    If value = 0 Then Return False
                    If value < 9 OrElse (value > 13 AndAlso value < 32) Then unusual += 1
                Next
                Return unusual * 100 \ size < 5
            End Using
        Catch
            Return False
        End Try
    End Function

    Private Function GetHexPreview(ByVal fileName As String, ByVal maximum As Integer) As String
        Dim data() As Byte
        Using stream As New FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
            Dim size As Integer = CInt(Math.Min(stream.Length, maximum))
            If size = 0 Then Return "Empty file"
            ReDim data(size - 1)
            stream.Read(data, 0, size)
        End Using
        Dim result As New StringBuilder()
        Dim offset As Integer = 0
        While offset < data.Length
            Dim hexText As New StringBuilder()
            Dim normalText As New StringBuilder()
            For column As Integer = 0 To 15
                If offset + column < data.Length Then
                    Dim value As Byte = data(offset + column)
                    hexText.Append(value.ToString("X2") & " ")
                    If value >= 32 AndAlso value <= 126 Then
                        normalText.Append(Chr(value))
                    Else
                        normalText.Append("."c)
                    End If
                Else
                    hexText.Append("   ")
                End If
            Next
            result.AppendLine(offset.ToString("X8") & "  " & hexText.ToString() & " " & normalText.ToString())
            offset += 16
        End While
        Return result.ToString()
    End Function

    Private Function ReadText(ByVal fileName As String) As String
        Using stream As New FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
            Dim size As Integer = CInt(Math.Min(stream.Length, 262144))
            If size = 0 Then Return ""
            Dim data(size - 1) As Byte
            stream.Read(data, 0, size)
            Dim text As String = Encoding.Default.GetString(data)
            If stream.Length > size Then text &= vbCrLf & vbCrLf & "Preview shortened."
            Return text
        End Using
    End Function

    Private Sub AddTextPreview(ByVal value As String, ByVal wrapText As Boolean)
        Dim box As New TextBox()
        box.BackColor = Color.White
        box.BorderStyle = BorderStyle.None
        box.Dock = DockStyle.Fill
        box.Font = New Font("Consolas", 9.0!)
        box.Multiline = True
        box.ReadOnly = True
        box.ScrollBars = ScrollBars.Both
        box.WordWrap = wrapText
        box.Text = value
        previewHost.Controls.Add(box)
    End Sub

    Private Sub ClearPreview(ByVal message As String)
        If previewHost IsNot Nothing Then
            If pnlPreviewContent.Contains(previewHost) Then pnlPreviewContent.Controls.Remove(previewHost)
            previewHost.Dispose()
            previewHost = Nothing
        End If
        lblPreviewTitle.Text = "Preview"
        txtPreviewDetails.Text = If(message = "", "", "No file selected")
        If message <> "" Then
            previewHost = New Panel()
            previewHost.Dock = DockStyle.Fill
            previewHost.BackColor = Color.White
            pnlPreviewContent.Controls.Add(previewHost)
            Dim label As New Label()
            label.Dock = DockStyle.Fill
            label.ForeColor = SystemColors.GrayText
            label.Text = message
            label.TextAlign = ContentAlignment.MiddleCenter
            previewHost.Controls.Add(label)
        End If
    End Sub

    Private Function GetSelectedPath() As String
        If lvFiles.SelectedItems.Count = 0 Then Return ""
        Return CStr(lvFiles.SelectedItems(0).Tag)
    End Function

    Private Sub UpdateFileToolState()
        Dim hasSelection As Boolean = lvFiles.SelectedItems.Count > 0
        toolCut.Enabled = hasSelection
        toolCopy.Enabled = hasSelection
        toolRename.Enabled = hasSelection
        toolDelete.Enabled = hasSelection
        Try
            toolPaste.Enabled = Clipboard.ContainsFileDropList()
        Catch
            toolPaste.Enabled = False
        End Try
    End Sub

    Private Sub toolNewFolder_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolNewFolder.Click
        Try
            Dim folderName As String = GetUniqueDestination(currentPath, "New folder")
            Directory.CreateDirectory(folderName)
            FillFileList(txtSearch.Text.Trim())
            For Each item As ListViewItem In lvFiles.Items
                If String.Equals(CStr(item.Tag), folderName, StringComparison.OrdinalIgnoreCase) Then
                    item.Selected = True
                    item.BeginEdit()
                    Exit For
                End If
            Next
            lblStatus.Text = "A new folder was created."
        Catch ex As Exception
            MessageBox.Show(ex.Message, "New Folder", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub toolCopy_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolCopy.Click
        CopySelection(False)
    End Sub

    Private Sub toolCut_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolCut.Click
        CopySelection(True)
    End Sub

    Private Sub CopySelection(ByVal cut As Boolean)
        Dim selectedPath As String = GetSelectedPath()
        If selectedPath = "" Then Return
        Try
            Dim files As New System.Collections.Specialized.StringCollection()
            files.Add(selectedPath)
            Clipboard.SetFileDropList(files)
            cutPaths.Clear()
            If cut Then cutPaths.Add(selectedPath)
            toolPaste.Enabled = True
            lblStatus.Text = If(cut, "Item ready to move.", "Item copied to the Clipboard.")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Clipboard", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub toolPaste_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolPaste.Click
        If currentPath = "" Then Return
        Try
            If Not Clipboard.ContainsFileDropList() Then Return
            Dim clipboardItems As System.Collections.Specialized.StringCollection = Clipboard.GetFileDropList()
            For Each source As String In clipboardItems
                If Not File.Exists(source) AndAlso Not Directory.Exists(source) Then Continue For
                If Directory.Exists(source) AndAlso currentPath.StartsWith(source.TrimEnd(IO.Path.DirectorySeparatorChar) & IO.Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) Then
                    Throw New IOException("A folder cannot be pasted inside itself.")
                End If
                Dim destination As String = GetUniqueDestination(currentPath, IO.Path.GetFileName(source.TrimEnd(IO.Path.DirectorySeparatorChar)))
                Dim moveItem As Boolean = cutPaths.Exists(Function(value As String) String.Equals(value, source, StringComparison.OrdinalIgnoreCase))
                If moveItem Then
                    If Directory.Exists(source) Then
                        Directory.Move(source, destination)
                    Else
                        File.Move(source, destination)
                    End If
                ElseIf Directory.Exists(source) Then
                    CopyDirectory(source, destination)
                Else
                    File.Copy(source, destination, False)
                End If
            Next
            cutPaths.Clear()
            FillFileList(txtSearch.Text.Trim())
            lblStatus.Text = "Paste completed."
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Paste", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        UpdateFileToolState()
    End Sub

    Private Sub CopyDirectory(ByVal source As String, ByVal destination As String)
        Directory.CreateDirectory(destination)
        For Each fileName As String In Directory.GetFiles(source)
            File.Copy(fileName, IO.Path.Combine(destination, IO.Path.GetFileName(fileName)), False)
        Next
        For Each folder As String In Directory.GetDirectories(source)
            CopyDirectory(folder, IO.Path.Combine(destination, IO.Path.GetFileName(folder)))
        Next
    End Sub

    Private Function GetUniqueDestination(ByVal parentFolder As String, ByVal itemName As String) As String
        Dim destination As String = IO.Path.Combine(parentFolder, itemName)
        If Not File.Exists(destination) AndAlso Not Directory.Exists(destination) Then Return destination
        Dim baseName As String = IO.Path.GetFileNameWithoutExtension(itemName)
        Dim extension As String = IO.Path.GetExtension(itemName)
        Dim number As Integer = 2
        Do
            destination = IO.Path.Combine(parentFolder, baseName & " (" & number.ToString() & ")" & extension)
            number += 1
        Loop While File.Exists(destination) OrElse Directory.Exists(destination)
        Return destination
    End Function

    Private Sub toolRename_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolRename.Click
        If lvFiles.SelectedItems.Count > 0 Then lvFiles.SelectedItems(0).BeginEdit()
    End Sub

    Private Sub lvFiles_AfterLabelEdit(ByVal sender As Object, ByVal e As LabelEditEventArgs) Handles lvFiles.AfterLabelEdit
        If e.Label Is Nothing Then Return
        If e.Label.Trim() = "" OrElse e.Label.IndexOfAny(IO.Path.GetInvalidFileNameChars()) >= 0 Then
            e.CancelEdit = True
            MessageBox.Show("Enter a valid name.", "Rename", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        Dim source As String = CStr(lvFiles.Items(e.Item).Tag)
        Dim destination As String = IO.Path.Combine(IO.Path.GetDirectoryName(source), e.Label.Trim())
        Try
            If File.Exists(destination) OrElse Directory.Exists(destination) Then Throw New IOException("An item with that name already exists.")
            If Directory.Exists(source) Then
                Directory.Move(source, destination)
            Else
                File.Move(source, destination)
            End If
            lvFiles.Items(e.Item).Tag = destination
            lblStatus.Text = "Item renamed."
        Catch ex As Exception
            e.CancelEdit = True
            MessageBox.Show(ex.Message, "Rename", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub toolDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolDelete.Click
        Dim selectedPath As String = GetSelectedPath()
        If selectedPath = "" Then Return
        If MessageBox.Show("Delete " & IO.Path.GetFileName(selectedPath) & "?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) <> DialogResult.Yes Then Return
        Try
            ClearPreview("Select a file or folder to preview it.")
            If Directory.Exists(selectedPath) Then
                Directory.Delete(selectedPath, True)
            Else
                File.Delete(selectedPath)
            End If
            FillFileList(txtSearch.Text.Trim())
            lblStatus.Text = "Item deleted."
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Sort_Click(ByVal sender As Object, ByVal e As EventArgs) Handles sortName.Click, sortDate.Click, sortType.Click, sortSize.Click
        Dim mode As Integer = 0
        If sender Is sortDate Then mode = 1
        If sender Is sortType Then mode = 2
        If sender Is sortSize Then mode = 3
        lvFiles.ListViewItemSorter = New ExplorerItemComparer(mode)
        lvFiles.Sort()
        lblStatus.Text = "Items sorted by " & DirectCast(sender, ToolStripMenuItem).Text & "."
    End Sub

    Private Class ExplorerItemComparer
        Implements System.Collections.IComparer
        Private mode As Integer

        Public Sub New(ByVal sortMode As Integer)
            mode = sortMode
        End Sub

        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Dim first As ListViewItem = DirectCast(x, ListViewItem)
            Dim second As ListViewItem = DirectCast(y, ListViewItem)
            Dim firstPath As String = CStr(first.Tag)
            Dim secondPath As String = CStr(second.Tag)
            Dim firstFolder As Boolean = Directory.Exists(firstPath)
            Dim secondFolder As Boolean = Directory.Exists(secondPath)
            If firstFolder AndAlso Not secondFolder Then Return -1
            If secondFolder AndAlso Not firstFolder Then Return 1
            Try
                Select Case mode
                    Case 1
                        Return DateTime.Compare(File.GetLastWriteTime(firstPath), File.GetLastWriteTime(secondPath))
                    Case 2
                        Return String.Compare(IO.Path.GetExtension(firstPath), IO.Path.GetExtension(secondPath), True)
                    Case 3
                        Dim firstSize As Long = If(firstFolder, 0, New FileInfo(firstPath).Length)
                        Dim secondSize As Long = If(secondFolder, 0, New FileInfo(secondPath).Length)
                        Return firstSize.CompareTo(secondSize)
                    Case Else
                        Return String.Compare(first.Text, second.Text, True)
                End Select
            Catch
                Return String.Compare(first.Text, second.Text, True)
            End Try
        End Function
    End Class

    Private Sub viewDetails_Click(ByVal sender As Object, ByVal e As EventArgs) Handles viewDetails.Click
        lvFiles.View = View.Details
    End Sub

    Private Sub viewList_Click(ByVal sender As Object, ByVal e As EventArgs) Handles viewList.Click
        lvFiles.View = View.List
    End Sub

    Private Sub viewLarge_Click(ByVal sender As Object, ByVal e As EventArgs) Handles viewLarge.Click
        lvFiles.View = View.LargeIcon
    End Sub

    Private Sub toolDetailsPane_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolDetailsPane.Click
        If toolDetailsPane.Checked Then
            ExpandPanel(splitContent)
            pnlPreview.Visible = True
            btnPreview.Text = "Hide Preview"
        Else
            pnlPreview.Visible = False
            CollapsePanel(splitContent, 2)
            btnPreview.Text = "Show Preview"
        End If
    End Sub

    Private Sub btnBack_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnBack.Click
        If historyPosition > 0 Then
            historyPosition -= 1
            NavigateTo(history(historyPosition), False)
        End If
    End Sub

    Private Sub btnUp_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUp.Click
        If currentPath = "" Then Return
        Dim parent As DirectoryInfo = Directory.GetParent(currentPath)
        If parent IsNot Nothing Then NavigateTo(parent.FullName, True)
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRefresh.Click
        FillFileList(txtSearch.Text.Trim())
        pnlFiles.Refresh()
        splitContent.Refresh()
        lblStatus.Text = "Refresh() updated the folder and repainted the panels."
    End Sub

    Private Sub txtAddress_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles txtAddress.KeyDown
        If e.KeyCode = Keys.Enter Then
            NavigateTo(txtAddress.Text.Trim(), True)
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged
        If currentPath <> "" Then FillFileList(txtSearch.Text.Trim())
    End Sub

    Private Sub cboShowMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cboShowMode.SelectedIndexChanged
        ApplyPreviewMode()
        If Me.Visible AndAlso splitContent.Panel2Collapsed Then
            ExpandPanel(splitContent)
            pnlPreview.Visible = True
            btnPreview.Text = "Hide Preview"
        End If
    End Sub

    Private Sub ApplyPreviewMode()
        Select Case cboShowMode.SelectedIndex
            Case 0
                txtPreviewDetails.Visible = True
                txtPreviewDetails.Dock = DockStyle.Fill
                pnlPreviewContent.Visible = False
                lblStatus.Text = "The right pane is showing file details."
            Case 1
                txtPreviewDetails.Visible = False
                pnlPreviewContent.Visible = True
                pnlPreviewContent.Dock = DockStyle.Fill
                lblStatus.Text = "The right pane is showing the file preview."
            Case Else
                txtPreviewDetails.Dock = DockStyle.Top
                txtPreviewDetails.Height = 112
                txtPreviewDetails.Visible = True
                pnlPreviewContent.Visible = True
                pnlPreviewContent.Dock = DockStyle.Fill
                lblStatus.Text = "The right pane is showing details and preview."
        End Select
        pnlPreview.PerformLayout()
        pnlPreview.Invalidate(True)
    End Sub

    Private Sub btnFolders_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFolders.Click
        If splitMain.Panel1Collapsed Then
            ExpandPanel(splitMain)
            pnlFolders.Visible = True
            btnFolders.Text = "Hide Folders"
            lblStatus.Text = "ExpandPanel() displayed the folder panel."
        Else
            pnlFolders.Visible = False
            CollapsePanel(splitMain, 1)
            btnFolders.Text = "Show Folders"
            lblStatus.Text = "CollapsePanel() hid the folder panel."
        End If
    End Sub

    Private Sub btnPreview_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnPreview.Click
        If splitContent.Panel2Collapsed Then
            ExpandPanel(splitContent)
            pnlPreview.Visible = True
            btnPreview.Text = "Hide Preview"
            toolDetailsPane.Checked = True
            lblStatus.Text = "ExpandPanel() displayed the preview panel."
        Else
            pnlPreview.Visible = False
            CollapsePanel(splitContent, 2)
            btnPreview.Text = "Show Preview"
            toolDetailsPane.Checked = False
            lblStatus.Text = "CollapsePanel() hid the preview panel."
        End If
    End Sub

    Private Sub btnOrientation_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnOrientation.Click
        Try
            splitContent.Panel1MinSize = 60
            splitContent.Panel2MinSize = 60
            SetSafeSplitterDistance(splitContent, 180)
            If splitContent.Orientation = Orientation.Vertical Then
                splitContent.Orientation = Orientation.Horizontal
                splitContent.Panel1MinSize = 100
                splitContent.Panel2MinSize = 100
                SetSafeSplitterDistance(splitContent, CInt(splitContent.Height * 0.62))
                btnOrientation.Text = "Preview Right"
                lblStatus.Text = "Orientation changed to horizontal."
            Else
                splitContent.Orientation = Orientation.Vertical
                splitContent.Panel1MinSize = 220
                splitContent.Panel2MinSize = 180
                SetSafeSplitterDistance(splitContent, CInt(splitContent.Width * 0.64))
                btnOrientation.Text = "Preview Below"
                lblStatus.Text = "Orientation changed to vertical."
            End If
        Catch ex As Exception
            lblStatus.Text = "The preview direction could not be changed: " & ex.Message
        End Try
    End Sub

    Private Sub SetSafeSplitterDistance(ByVal target As SplitContainer, ByVal requested As Integer)
        Dim available As Integer
        If target.Orientation = Orientation.Vertical Then
            available = target.ClientSize.Width
        Else
            available = target.ClientSize.Height
        End If
        Dim lowest As Integer = target.Panel1MinSize
        Dim highest As Integer = available - target.Panel2MinSize - target.SplitterWidth
        If highest < lowest Then Return
        target.SplitterDistance = Math.Max(lowest, Math.Min(requested, highest))
    End Sub

    Private Sub btnLock_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLock.Click
        splittersLocked = Not splittersLocked
        splitMain.IsSplitterFixed = splittersLocked
        splitContent.IsSplitterFixed = splittersLocked
        btnLock.Text = If(splittersLocked, "Unlock Panes", "Lock Panes")
        lblStatus.Text = "IsSplitterFixed = " & splittersLocked.ToString()
    End Sub

    Private Sub btnCheck_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCheck.Click
        Dim containsList As Boolean = pnlFiles.Contains(lvFiles)
        Dim focused As Boolean = pnlFiles.Focus()
        lblStatus.Text = "Contains(ListView) = " & containsList.ToString() & "   Focus() = " & focused.ToString()
    End Sub

    Private Sub btnRedraw_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRedraw.Click
        pnlFolders.Invalidate(True)
        pnlFiles.Invalidate(True)
        pnlPreview.Invalidate(True)
        splitMain.Invalidate(True)
        splitContent.Invalidate(True)
        lblStatus.Text = "Invalidate() requested a redraw of all panels."
    End Sub

    Private Sub CollapsePanel(ByVal target As SplitContainer, ByVal panelNumber As Integer)
        If panelNumber = 1 Then
            target.Panel1Collapsed = True
        Else
            target.Panel2Collapsed = True
        End If
    End Sub

    Private Sub ExpandPanel(ByVal target As SplitContainer)
        target.Panel1Collapsed = False
        target.Panel2Collapsed = False
    End Sub

    Private Sub splitMain_SplitterMoved(ByVal sender As Object, ByVal e As SplitterEventArgs) Handles splitMain.SplitterMoved
        lblStatus.Text = "Folder pane width: " & splitMain.SplitterDistance.ToString() & " pixels"
    End Sub

    Private Sub splitContent_SplitterMoved(ByVal sender As Object, ByVal e As SplitterEventArgs) Handles splitContent.SplitterMoved
        lblStatus.Text = "SplitterDistance: " & splitContent.SplitterDistance.ToString() & " pixels"
    End Sub

    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles MyBase.FormClosed
        Try
            If previewHost IsNot Nothing Then
                previewHost.Dispose()
                previewHost = Nothing
            End If
            splitContent.Dispose()
            splitMain.Dispose()
        Catch
        End Try
    End Sub
End Class
