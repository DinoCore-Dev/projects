<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then components.Dispose()
        MyBase.Dispose(disposing)
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents pnlHeader As Panel
    Friend WithEvents lblTitle As Label
    Friend WithEvents pnlAddress As Panel
    Friend WithEvents btnBack As Button
    Friend WithEvents btnUp As Button
    Friend WithEvents btnRefresh As Button
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents toolFiles As ToolStrip
    Friend WithEvents toolNewFolder As ToolStripButton
    Friend WithEvents toolCut As ToolStripButton
    Friend WithEvents toolCopy As ToolStripButton
    Friend WithEvents toolPaste As ToolStripButton
    Friend WithEvents toolRename As ToolStripButton
    Friend WithEvents toolDelete As ToolStripButton
    Friend WithEvents toolSort As ToolStripDropDownButton
    Friend WithEvents sortName As ToolStripMenuItem
    Friend WithEvents sortDate As ToolStripMenuItem
    Friend WithEvents sortType As ToolStripMenuItem
    Friend WithEvents sortSize As ToolStripMenuItem
    Friend WithEvents toolView As ToolStripDropDownButton
    Friend WithEvents viewDetails As ToolStripMenuItem
    Friend WithEvents viewList As ToolStripMenuItem
    Friend WithEvents viewLarge As ToolStripMenuItem
    Friend WithEvents toolDetailsPane As ToolStripButton
    Friend WithEvents pnlCommands As Panel
    Friend WithEvents btnFolders As Button
    Friend WithEvents btnPreview As Button
    Friend WithEvents btnOrientation As Button
    Friend WithEvents btnLock As Button
    Friend WithEvents btnCheck As Button
    Friend WithEvents btnRedraw As Button
    Friend WithEvents lblShowMode As Label
    Friend WithEvents cboShowMode As ComboBox
    Friend WithEvents splitMain As SplitContainer
    Friend WithEvents pnlFolders As Panel
    Friend WithEvents lblFolders As Label
    Friend WithEvents tvFolders As TreeView
    Friend WithEvents splitContent As SplitContainer
    Friend WithEvents pnlFiles As Panel
    Friend WithEvents lblFiles As Label
    Friend WithEvents lvFiles As ListView
    Friend WithEvents colName As ColumnHeader
    Friend WithEvents colType As ColumnHeader
    Friend WithEvents colSize As ColumnHeader
    Friend WithEvents colModified As ColumnHeader
    Friend WithEvents pnlPreview As Panel
    Friend WithEvents lblPreviewTitle As Label
    Friend WithEvents txtPreviewDetails As TextBox
    Friend WithEvents pnlPreviewContent As Panel
    Friend WithEvents pnlStatus As Panel
    Friend WithEvents lblStatus As Label

    Private Sub InitializeComponent()
        Me.pnlHeader = New Panel()
        Me.lblTitle = New Label()
        Me.pnlAddress = New Panel()
        Me.btnBack = New Button()
        Me.btnUp = New Button()
        Me.btnRefresh = New Button()
        Me.txtAddress = New TextBox()
        Me.txtSearch = New TextBox()
        Me.toolFiles = New ToolStrip()
        Me.toolNewFolder = New ToolStripButton()
        Me.toolCut = New ToolStripButton()
        Me.toolCopy = New ToolStripButton()
        Me.toolPaste = New ToolStripButton()
        Me.toolRename = New ToolStripButton()
        Me.toolDelete = New ToolStripButton()
        Me.toolSort = New ToolStripDropDownButton()
        Me.sortName = New ToolStripMenuItem()
        Me.sortDate = New ToolStripMenuItem()
        Me.sortType = New ToolStripMenuItem()
        Me.sortSize = New ToolStripMenuItem()
        Me.toolView = New ToolStripDropDownButton()
        Me.viewDetails = New ToolStripMenuItem()
        Me.viewList = New ToolStripMenuItem()
        Me.viewLarge = New ToolStripMenuItem()
        Me.toolDetailsPane = New ToolStripButton()
        Me.pnlCommands = New Panel()
        Me.btnFolders = New Button()
        Me.btnPreview = New Button()
        Me.btnOrientation = New Button()
        Me.btnLock = New Button()
        Me.btnCheck = New Button()
        Me.btnRedraw = New Button()
        Me.lblShowMode = New Label()
        Me.cboShowMode = New ComboBox()
        Me.splitMain = New SplitContainer()
        Me.pnlFolders = New Panel()
        Me.lblFolders = New Label()
        Me.tvFolders = New TreeView()
        Me.splitContent = New SplitContainer()
        Me.pnlFiles = New Panel()
        Me.lblFiles = New Label()
        Me.lvFiles = New ListView()
        Me.colName = New ColumnHeader()
        Me.colType = New ColumnHeader()
        Me.colSize = New ColumnHeader()
        Me.colModified = New ColumnHeader()
        Me.pnlPreview = New Panel()
        Me.lblPreviewTitle = New Label()
        Me.txtPreviewDetails = New TextBox()
        Me.pnlPreviewContent = New Panel()
        Me.pnlStatus = New Panel()
        Me.lblStatus = New Label()
        Me.pnlHeader.SuspendLayout()
        Me.pnlAddress.SuspendLayout()
        Me.toolFiles.SuspendLayout()
        Me.pnlCommands.SuspendLayout()
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.splitMain.Panel1.SuspendLayout()
        Me.splitMain.Panel2.SuspendLayout()
        Me.splitMain.SuspendLayout()
        Me.pnlFolders.SuspendLayout()
        CType(Me.splitContent, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.splitContent.Panel1.SuspendLayout()
        Me.splitContent.Panel2.SuspendLayout()
        Me.splitContent.SuspendLayout()
        Me.pnlFiles.SuspendLayout()
        Me.pnlPreview.SuspendLayout()
        Me.pnlStatus.SuspendLayout()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = Color.SteelBlue
        Me.pnlHeader.Controls.Add(Me.lblTitle)
        Me.pnlHeader.Dock = DockStyle.Top
        Me.pnlHeader.Size = New Size(1080, 48)
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New Font("Segoe UI", 15.0!, FontStyle.Bold)
        Me.lblTitle.ForeColor = Color.White
        Me.lblTitle.Location = New Point(14, 9)
        Me.lblTitle.Text = "Folder Explorer"
        Me.pnlAddress.BackColor = SystemColors.Control
        Me.pnlAddress.BorderStyle = BorderStyle.FixedSingle
        Me.pnlAddress.Controls.Add(Me.btnBack)
        Me.pnlAddress.Controls.Add(Me.btnUp)
        Me.pnlAddress.Controls.Add(Me.btnRefresh)
        Me.pnlAddress.Controls.Add(Me.txtAddress)
        Me.pnlAddress.Controls.Add(Me.txtSearch)
        Me.pnlAddress.Dock = DockStyle.Top
        Me.pnlAddress.Size = New Size(1080, 42)
        Me.btnBack.Location = New Point(8, 7)
        Me.btnBack.Size = New Size(55, 27)
        Me.btnBack.Text = "Back"
        Me.btnUp.Location = New Point(68, 7)
        Me.btnUp.Size = New Size(45, 27)
        Me.btnUp.Text = "Up"
        Me.btnRefresh.Location = New Point(118, 7)
        Me.btnRefresh.Size = New Size(65, 27)
        Me.btnRefresh.Text = "Refresh"
        Me.txtAddress.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Me.txtAddress.Location = New Point(190, 9)
        Me.txtAddress.Size = New Size(625, 20)
        Me.txtSearch.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Me.txtSearch.Location = New Point(823, 9)
        Me.txtSearch.Size = New Size(245, 20)
        Me.toolFiles.BackColor = Color.WhiteSmoke
        Me.toolFiles.GripStyle = ToolStripGripStyle.Hidden
        Me.toolFiles.Items.AddRange(New ToolStripItem() {Me.toolNewFolder, New ToolStripSeparator(), Me.toolCut, Me.toolCopy, Me.toolPaste, New ToolStripSeparator(), Me.toolRename, Me.toolDelete, New ToolStripSeparator(), Me.toolSort, Me.toolView, New ToolStripSeparator(), Me.toolDetailsPane})
        Me.toolFiles.Dock = DockStyle.Top
        Me.toolFiles.Font = New Font("Segoe UI", 9.0!)
        Me.toolFiles.Padding = New Padding(8, 2, 0, 2)
        Me.toolFiles.Size = New Size(1080, 35)
        Me.toolNewFolder.Text = "New Folder"
        Me.toolNewFolder.ToolTipText = "Create a new folder"
        Me.toolCut.Text = "Cut"
        Me.toolCopy.Text = "Copy"
        Me.toolPaste.Text = "Paste"
        Me.toolRename.Text = "Rename"
        Me.toolDelete.Text = "Delete"
        Me.toolSort.DropDownItems.AddRange(New ToolStripItem() {Me.sortName, Me.sortDate, Me.sortType, Me.sortSize})
        Me.toolSort.Text = "Sort"
        Me.sortName.Text = "Name"
        Me.sortDate.Text = "Date modified"
        Me.sortType.Text = "Type"
        Me.sortSize.Text = "Size"
        Me.toolView.DropDownItems.AddRange(New ToolStripItem() {Me.viewDetails, Me.viewList, Me.viewLarge})
        Me.toolView.Text = "View"
        Me.viewDetails.Text = "Details"
        Me.viewList.Text = "List"
        Me.viewLarge.Text = "Large icons"
        Me.toolDetailsPane.CheckOnClick = True
        Me.toolDetailsPane.Checked = True
        Me.toolDetailsPane.Text = "Details pane"
        Me.pnlCommands.BackColor = Color.WhiteSmoke
        Me.pnlCommands.BorderStyle = BorderStyle.FixedSingle
        Me.pnlCommands.Controls.Add(Me.btnFolders)
        Me.pnlCommands.Controls.Add(Me.btnPreview)
        Me.pnlCommands.Controls.Add(Me.btnOrientation)
        Me.pnlCommands.Controls.Add(Me.btnLock)
        Me.pnlCommands.Controls.Add(Me.btnCheck)
        Me.pnlCommands.Controls.Add(Me.btnRedraw)
        Me.pnlCommands.Controls.Add(Me.lblShowMode)
        Me.pnlCommands.Controls.Add(Me.cboShowMode)
        Me.pnlCommands.Dock = DockStyle.Top
        Me.pnlCommands.Size = New Size(1080, 43)
        Me.btnFolders.Location = New Point(8, 7)
        Me.btnFolders.Size = New Size(92, 27)
        Me.btnFolders.Text = "Hide Folders"
        Me.btnPreview.Location = New Point(105, 7)
        Me.btnPreview.Size = New Size(92, 27)
        Me.btnPreview.Text = "Hide Preview"
        Me.btnOrientation.Location = New Point(202, 7)
        Me.btnOrientation.Size = New Size(118, 27)
        Me.btnOrientation.Text = "Preview Below"
        Me.btnLock.Location = New Point(325, 7)
        Me.btnLock.Size = New Size(92, 27)
        Me.btnLock.Text = "Lock Panes"
        Me.btnCheck.Location = New Point(422, 7)
        Me.btnCheck.Size = New Size(102, 27)
        Me.btnCheck.Text = "Check Layout"
        Me.btnRedraw.Location = New Point(529, 7)
        Me.btnRedraw.Size = New Size(88, 27)
        Me.btnRedraw.Text = "Redraw"
        Me.lblShowMode.AutoSize = True
        Me.lblShowMode.Location = New Point(635, 13)
        Me.lblShowMode.Text = "Show:"
        Me.cboShowMode.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cboShowMode.FormattingEnabled = True
        Me.cboShowMode.Location = New Point(680, 9)
        Me.cboShowMode.Size = New Size(145, 21)
        Me.splitMain.Dock = DockStyle.Fill
        Me.splitMain.FixedPanel = FixedPanel.Panel1
        Me.splitMain.IsSplitterFixed = False
        Me.splitMain.Location = New Point(0, 133)
        Me.splitMain.Orientation = Orientation.Vertical
        Me.splitMain.Size = New Size(1080, 488)
        Me.splitMain.Panel1MinSize = 130
        Me.splitMain.Panel2MinSize = 350
        Me.splitMain.SplitterWidth = 7
        Me.splitMain.Panel1.Controls.Add(Me.pnlFolders)
        Me.splitMain.Panel2.Controls.Add(Me.splitContent)
        Me.pnlFolders.AutoScroll = True
        Me.pnlFolders.BackColor = Color.WhiteSmoke
        Me.pnlFolders.BorderStyle = BorderStyle.Fixed3D
        Me.pnlFolders.Controls.Add(Me.tvFolders)
        Me.pnlFolders.Controls.Add(Me.lblFolders)
        Me.pnlFolders.Dock = DockStyle.Fill
        Me.pnlFolders.Visible = True
        Me.lblFolders.Dock = DockStyle.Top
        Me.lblFolders.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        Me.lblFolders.Padding = New Padding(8, 7, 0, 0)
        Me.lblFolders.Size = New Size(220, 34)
        Me.lblFolders.Text = "Folders"
        Me.tvFolders.BorderStyle = BorderStyle.None
        Me.tvFolders.Dock = DockStyle.Fill
        Me.tvFolders.HideSelection = False
        Me.tvFolders.Location = New Point(0, 34)
        Me.tvFolders.Name = "tvFolders"
        Me.tvFolders.Scrollable = True
        Me.splitContent.Dock = DockStyle.Fill
        Me.splitContent.FixedPanel = FixedPanel.None
        Me.splitContent.IsSplitterFixed = False
        Me.splitContent.Orientation = Orientation.Vertical
        Me.splitContent.Size = New Size(853, 488)
        Me.splitContent.Panel1MinSize = 220
        Me.splitContent.Panel2MinSize = 180
        Me.splitContent.SplitterWidth = 7
        Me.splitContent.Panel1.Controls.Add(Me.pnlFiles)
        Me.splitContent.Panel2.Controls.Add(Me.pnlPreview)
        Me.pnlFiles.AutoScroll = True
        Me.pnlFiles.BackColor = Color.White
        Me.pnlFiles.BorderStyle = BorderStyle.FixedSingle
        Me.pnlFiles.Controls.Add(Me.lvFiles)
        Me.pnlFiles.Controls.Add(Me.lblFiles)
        Me.pnlFiles.Dock = DockStyle.Fill
        Me.pnlFiles.TabStop = True
        Me.lblFiles.Dock = DockStyle.Top
        Me.lblFiles.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        Me.lblFiles.Padding = New Padding(8, 7, 0, 0)
        Me.lblFiles.Size = New Size(520, 34)
        Me.lblFiles.Text = "Files"
        Me.lvFiles.Columns.AddRange(New ColumnHeader() {Me.colName, Me.colType, Me.colSize, Me.colModified})
        Me.lvFiles.Dock = DockStyle.Fill
        Me.lvFiles.FullRowSelect = True
        Me.lvFiles.GridLines = True
        Me.lvFiles.HideSelection = False
        Me.lvFiles.MultiSelect = False
        Me.lvFiles.LabelEdit = True
        Me.lvFiles.Scrollable = True
        Me.lvFiles.View = View.Details
        Me.colName.Text = "Name"
        Me.colName.Width = 220
        Me.colType.Text = "Type"
        Me.colType.Width = 110
        Me.colSize.Text = "Size"
        Me.colSize.TextAlign = HorizontalAlignment.Right
        Me.colSize.Width = 85
        Me.colModified.Text = "Date modified"
        Me.colModified.Width = 130
        Me.pnlPreview.AutoScroll = True
        Me.pnlPreview.BackColor = SystemColors.Control
        Me.pnlPreview.BorderStyle = BorderStyle.Fixed3D
        Me.pnlPreview.Controls.Add(Me.pnlPreviewContent)
        Me.pnlPreview.Controls.Add(Me.txtPreviewDetails)
        Me.pnlPreview.Controls.Add(Me.lblPreviewTitle)
        Me.pnlPreview.Dock = DockStyle.Fill
        Me.pnlPreview.Visible = True
        Me.lblPreviewTitle.Dock = DockStyle.Top
        Me.lblPreviewTitle.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        Me.lblPreviewTitle.Padding = New Padding(8, 7, 0, 0)
        Me.lblPreviewTitle.Size = New Size(326, 34)
        Me.lblPreviewTitle.Text = "Preview"
        Me.txtPreviewDetails.BackColor = Color.WhiteSmoke
        Me.txtPreviewDetails.BorderStyle = BorderStyle.FixedSingle
        Me.txtPreviewDetails.Dock = DockStyle.Top
        Me.txtPreviewDetails.Font = New Font("Segoe UI", 8.25!)
        Me.txtPreviewDetails.Multiline = True
        Me.txtPreviewDetails.ReadOnly = True
        Me.txtPreviewDetails.ScrollBars = ScrollBars.Vertical
        Me.txtPreviewDetails.Size = New Size(326, 112)
        Me.txtPreviewDetails.TabStop = False
        Me.txtPreviewDetails.Text = "No file selected"
        Me.pnlPreviewContent.AutoScroll = True
        Me.pnlPreviewContent.BackColor = Color.White
        Me.pnlPreviewContent.Dock = DockStyle.Fill
        Me.pnlPreviewContent.TabStop = True
        Me.pnlStatus.BackColor = SystemColors.ControlLight
        Me.pnlStatus.BorderStyle = BorderStyle.FixedSingle
        Me.pnlStatus.Controls.Add(Me.lblStatus)
        Me.pnlStatus.Dock = DockStyle.Bottom
        Me.pnlStatus.Size = New Size(1080, 29)
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New Point(9, 7)
        Me.lblStatus.Text = "Ready"
        Me.AutoScaleDimensions = New SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = AutoScaleMode.Font
        Me.ClientSize = New Size(1080, 650)
        Me.Controls.Add(Me.splitMain)
        Me.Controls.Add(Me.pnlStatus)
        Me.Controls.Add(Me.pnlCommands)
        Me.Controls.Add(Me.toolFiles)
        Me.Controls.Add(Me.pnlAddress)
        Me.Controls.Add(Me.pnlHeader)
        Me.MinimumSize = New Size(760, 500)
        Me.Name = "Form1"
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.Text = "Folder Explorer - Panel and SplitPanel Demo"
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.pnlAddress.ResumeLayout(False)
        Me.pnlAddress.PerformLayout()
        Me.toolFiles.ResumeLayout(False)
        Me.toolFiles.PerformLayout()
        Me.pnlCommands.ResumeLayout(False)
        Me.splitMain.Panel1.ResumeLayout(False)
        Me.splitMain.Panel2.ResumeLayout(False)
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.splitMain.ResumeLayout(False)
        Me.pnlFolders.ResumeLayout(False)
        Me.splitContent.Panel1.ResumeLayout(False)
        Me.splitContent.Panel2.ResumeLayout(False)
        CType(Me.splitContent, System.ComponentModel.ISupportInitialize).EndInit()
        Me.splitContent.ResumeLayout(False)
        Me.pnlFiles.ResumeLayout(False)
        Me.pnlPreview.ResumeLayout(False)
        Me.pnlStatus.ResumeLayout(False)
        Me.pnlStatus.PerformLayout()
        Me.ResumeLayout(False)
    End Sub
End Class
