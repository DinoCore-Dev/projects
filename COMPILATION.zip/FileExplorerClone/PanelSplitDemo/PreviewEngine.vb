Option Strict Off
Option Explicit On
Imports System.IO
Imports System.IO.Compression
Imports System.Text
Imports System.Text.RegularExpressions
Public Module PreviewEngine
#Region "Word"
    Public Function GetDocxText(ByVal file As String) As String
        Try
            Using pkg As Packaging.Package = Packaging.Package.Open(file, FileMode.Open, FileAccess.Read)
                Dim uri As New Uri("/word/document.xml", UriKind.Relative)
                If Not pkg.PartExists(uri) Then Return "(No readable document part inside this file.)"
                Dim xml As String
                Using sr As New StreamReader(pkg.GetPart(uri).GetStream())
                    xml = sr.ReadToEnd()
                End Using
                xml = xml.Replace("<w:br/>", vbCrLf).Replace("<w:br />", vbCrLf)
                xml = xml.Replace("<w:tab/>", vbTab).Replace("<w:tab />", vbTab)
                xml = xml.Replace("</w:p>", vbCrLf)
                xml = xml.Replace("</w:tc>", vbTab)
                xml = xml.Replace("</w:tr>", vbCrLf)
                Return CleanXmlText(xml)
            End Using
        Catch ex As Exception
            Return "Cannot read this Word document." & vbCrLf & ex.Message
        End Try
    End Function
#End Region
#Region "Excel"
    Public Function GetXlsxText(ByVal file As String) As String
        Try
            Using pkg As Packaging.Package = Packaging.Package.Open(file, FileMode.Open, FileAccess.Read)
                Dim shared_ As New List(Of String)
                Dim ssUri As New Uri("/xl/sharedStrings.xml", UriKind.Relative)
                If pkg.PartExists(ssUri) Then
                    Dim xml As String
                    Using sr As New StreamReader(pkg.GetPart(ssUri).GetStream())
                        xml = sr.ReadToEnd()
                    End Using
                    For Each m As Match In Regex.Matches(xml, "<si>(.*?)</si>", RegexOptions.Singleline)
                        shared_.Add(CleanXmlText(m.Groups(1).Value).Replace(vbCrLf, " ").Trim())
                    Next
                End If
                Dim sb As New StringBuilder()
                Dim sheet As Integer = 0
                For Each part As Packaging.PackagePart In pkg.GetParts()
                    If Not part.Uri.ToString().StartsWith("/xl/worksheets/sheet") Then Continue For
                    sheet += 1
                    sb.AppendLine("=== Sheet " & sheet & " (" & IO.Path.GetFileName(part.Uri.ToString()) & ") ===")
                    sb.AppendLine()
                    Dim xml As String
                    Using sr As New StreamReader(part.GetStream())
                        xml = sr.ReadToEnd()
                    End Using
                    Dim rows As Integer = 0
                    For Each rm As Match In Regex.Matches(xml, "<row[^>]*>(.*?)</row>", RegexOptions.Singleline)
                        Dim line As New StringBuilder()
                        For Each cm As Match In Regex.Matches(rm.Groups(1).Value, "<c([^>]*)>(.*?)</c>", RegexOptions.Singleline)
                            Dim attrs As String = cm.Groups(1).Value
                            Dim inner As String = cm.Groups(2).Value
                            Dim vm As Match = Regex.Match(inner, "<v>(.*?)</v>", RegexOptions.Singleline)
                            Dim val As String = ""
                            If vm.Success Then
                                val = vm.Groups(1).Value
                                If attrs.Contains("t=""s""") Then
                                    Dim idx As Integer
                                    If Integer.TryParse(val, idx) AndAlso idx >= 0 AndAlso idx < shared_.Count Then
                                        val = shared_(idx)
                                    End If
                                End If
                            Else
                                val = CleanXmlText(inner).Trim()
                            End If
                            line.Append(PadCell(val))
                        Next
                        If line.ToString().Trim() <> "" Then
                            sb.AppendLine(line.ToString().TrimEnd())
                            rows += 1
                        End If
                        If rows >= 400 Then
                            sb.AppendLine("... (only the first 400 rows are previewed) ...")
                            Exit For
                        End If
                    Next
                    sb.AppendLine()
                Next
                If sb.Length = 0 Then Return "(This workbook has no readable sheet.)"
                Return sb.ToString()
            End Using
        Catch ex As Exception
            Return "Cannot read this Excel workbook." & vbCrLf & ex.Message
        End Try
    End Function
    Private Function PadCell(ByVal v As String) As String
        If v Is Nothing Then v = ""
        If v.Length > 16 Then v = v.Substring(0, 15) & Chr(133)
        Return v.PadRight(18)
    End Function
#End Region
#Region "PowerPoint"
    Public Function GetPptxText(ByVal file As String) As String
        Try
            Using pkg As Packaging.Package = Packaging.Package.Open(file, FileMode.Open, FileAccess.Read)
                Dim slides As New List(Of String)
                For Each part As Packaging.PackagePart In pkg.GetParts()
                    Dim u As String = part.Uri.ToString()
                    If Regex.IsMatch(u, "^/ppt/slides/slide\d+\.xml$") Then slides.Add(u)
                Next
                slides.Sort(New SlideComparer())
                Dim sb As New StringBuilder()
                Dim n As Integer = 0
                For Each u As String In slides
                    n += 1
                    Dim xml As String
                    Using sr As New StreamReader(pkg.GetPart(New Uri(u, UriKind.Relative)).GetStream())
                        xml = sr.ReadToEnd()
                    End Using
                    xml = xml.Replace("</a:p>", vbCrLf).Replace("<a:br/>", vbCrLf)
                    sb.AppendLine("----- Slide " & n & " -----")
                    sb.AppendLine(CleanXmlText(xml).Trim())
                    sb.AppendLine()
                Next
                If n = 0 Then Return "(No slides found in this presentation.)"
                Return sb.ToString()
            End Using
        Catch ex As Exception
            Return "Cannot read this PowerPoint file." & vbCrLf & ex.Message
        End Try
    End Function
    Private Class SlideComparer
        Implements IComparer(Of String)
        Public Function Compare(ByVal a As String, ByVal b As String) As Integer _
                Implements IComparer(Of String).Compare
            Return Num(a).CompareTo(Num(b))
        End Function
        Private Function Num(ByVal s As String) As Integer
            Dim m As Match = Regex.Match(s, "(\d+)")
            If m.Success Then Return CInt(m.Groups(1).Value)
            Return 0
        End Function
    End Class
#End Region
#Region "Legacy Office (.doc .xls .ppt) - late bound automation + fallback"
    Public Function GetLegacyOfficeText(ByVal file As String) As String
        Dim ext As String = IO.Path.GetExtension(file).ToLowerInvariant()
        Dim app As Object = Nothing
        Try
            Select Case ext
                Case ".doc", ".dot", ".rtf"
                    app = CreateObject("Word.Application")
                    app.Visible = False
                    Dim doc As Object = app.Documents.Open(file, , True)
                    Dim t As String = doc.Content.Text
                    doc.Close(False)
                    Return t
                Case ".xls", ".xlsm", ".xlsb"
                    app = CreateObject("Excel.Application")
                    app.Visible = False
                    Dim wb As Object = app.Workbooks.Open(file, , True)
                    Dim sb As New StringBuilder()
                    For s As Integer = 1 To wb.Sheets.Count
                        Dim ws As Object = wb.Sheets(s)
                        sb.AppendLine("=== " & ws.Name & " ===")
                        Dim used As Object = ws.UsedRange
                        Dim rows As Integer = Math.Min(CInt(used.Rows.Count), 200)
                        Dim cols As Integer = Math.Min(CInt(used.Columns.Count), 20)
                        For r As Integer = 1 To rows
                            Dim line As New StringBuilder()
                            For c As Integer = 1 To cols
                                Dim v As Object = used.Cells(r, c).Text
                                line.Append(PadCell(CStr(v)))
                            Next
                            sb.AppendLine(line.ToString().TrimEnd())
                        Next
                        sb.AppendLine()
                    Next
                    wb.Close(False)
                    Return sb.ToString()
                Case ".ppt"
                    app = CreateObject("PowerPoint.Application")
                    Dim pres As Object = app.Presentations.Open(file, True, False, False)
                    Dim sb As New StringBuilder()
                    For i As Integer = 1 To pres.Slides.Count
                        sb.AppendLine("----- Slide " & i & " -----")
                        For Each shp As Object In pres.Slides(i).Shapes
                            Try
                                If shp.HasTextFrame Then
                                    If shp.TextFrame.HasText Then sb.AppendLine(shp.TextFrame.TextRange.Text)
                                End If
                            Catch
                            End Try
                        Next
                        sb.AppendLine()
                    Next
                    pres.Close()
                    Return sb.ToString()
            End Select
        Catch
            Return Nothing
        Finally
            Try
                If app IsNot Nothing Then
                    app.Quit()
                    Runtime.InteropServices.Marshal.ReleaseComObject(app)
                End If
            Catch
            End Try
        End Try
        Return Nothing
    End Function
    Public Function ScrapeText(ByVal file As String, ByVal maxBytes As Integer) As String
        Dim buf() As Byte
        Using fs As New FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
            Dim take As Integer = CInt(Math.Min(fs.Length, maxBytes))
            ReDim buf(Math.Max(take - 1, 0))
            fs.Read(buf, 0, take)
        End Using
        Dim sb As New StringBuilder()
        Dim run As New StringBuilder()
        Dim i As Integer = 0
        While i < buf.Length
            Dim b As Byte = buf(i)
            Dim isUni As Boolean = (i + 1 < buf.Length AndAlso buf(i + 1) = 0 AndAlso b >= 32 AndAlso b <= 126)
            If b >= 32 AndAlso b <= 126 Then
                run.Append(Chr(b))
                i += IIf(isUni, 2, 1)
            ElseIf b = 13 OrElse b = 10 Then
                run.Append(vbLf) : i += 1
            Else
                If run.Length >= 4 Then sb.AppendLine(run.ToString().Trim())
                run.Length = 0
                i += 1
            End If
        End While
        If run.Length >= 4 Then sb.AppendLine(run.ToString().Trim())
        Dim res As String = Regex.Replace(sb.ToString(), "(\r?\n){3,}", vbCrLf & vbCrLf)
        If res.Trim() = "" Then Return "(No readable text found in this file.)"
        Return res
    End Function
#End Region
#Region "PDF"
    Public Function GetPdfText(ByVal file As String) As String
        Try
            Dim data As Byte() = IO.File.ReadAllBytes(file)
            Dim latin As Encoding = Encoding.GetEncoding(28591)
            Dim raw As String = latin.GetString(data)
            If raw.IndexOf("/Encrypt") >= 0 Then
                Return "This PDF is encrypted / password protected, text cannot be previewed."
            End If
            Dim text As New StringBuilder()
            Dim pos As Integer = 0
            Dim streams As Integer = 0
            While True
                Dim s As Integer = raw.IndexOf("stream", pos, StringComparison.Ordinal)
                If s < 0 Then Exit While
                Dim e As Integer = raw.IndexOf("endstream", s, StringComparison.Ordinal)
                If e < 0 Then Exit While
                Dim start As Integer = s + 6
                If start < raw.Length AndAlso raw(start) = vbCr Then start += 1
                If start < raw.Length AndAlso raw(start) = vbLf Then start += 1
                Dim len As Integer = e - start
                If len > 0 Then
                    Dim chunk(len - 1) As Byte
                    Array.Copy(data, start, chunk, 0, len)
                    Dim plain As String = Inflate(chunk)
                    If plain IsNot Nothing Then
                        text.Append(ExtractPdfOperators(plain))
                        streams += 1
                    End If
                End If
                pos = e + 9
                If streams > 400 Then Exit While
            End While
            Dim result As String = text.ToString()
            result = Regex.Replace(result, "[ \t]{2,}", " ")
            result = Regex.Replace(result, "(\r?\n){3,}", vbCrLf & vbCrLf)
            If result.Trim() = "" Then
                Return "No extractable text in this PDF (it is probably a scanned image)." & vbCrLf & _
                       "Double-click the file to open it in your PDF reader."
            End If
            Return result.Trim()
        Catch ex As Exception
            Return "Cannot read this PDF." & vbCrLf & ex.Message
        End Try
    End Function
    Private Function Inflate(ByVal data As Byte()) As String
        Try
            If data.Length < 3 Then Return Nothing
            Dim skip As Integer = 0
            If data(0) = &H78 Then skip = 2
            Using ms As New MemoryStream(data, skip, data.Length - skip)
                Using ds As New DeflateStream(ms, CompressionMode.Decompress)
                    Using outMs As New MemoryStream()
                        Dim buf(8191) As Byte
                        Dim n As Integer = ds.Read(buf, 0, buf.Length)
                        While n > 0
                            outMs.Write(buf, 0, n)
                            If outMs.Length > 4 * 1024 * 1024 Then Exit While
                            n = ds.Read(buf, 0, buf.Length)
                        End While
                        Return Encoding.GetEncoding(28591).GetString(outMs.ToArray())
                    End Using
                End Using
            End Using
        Catch
            Return Nothing
        End Try
    End Function
    Private Function ExtractPdfOperators(ByVal content As String) As String
        Dim sb As New StringBuilder()
        For Each m As Match In Regex.Matches(content, "\((?:\\.|[^\\()])*\)\s*(Tj|TJ|')|\[(?:[^\[\]]*)\]\s*TJ", _
                                             RegexOptions.Singleline)
            Dim piece As String = m.Value
            For Each sm As Match In Regex.Matches(piece, "\((?:\\.|[^\\()])*\)", RegexOptions.Singleline)
                Dim t As String = sm.Value.Substring(1, sm.Value.Length - 2)
                t = t.Replace("\(", "(").Replace("\)", ")").Replace("\\", "\")
                t = t.Replace("\n", vbLf).Replace("\r", vbCr).Replace("\t", vbTab)
                sb.Append(t)
            Next
            If piece.TrimEnd().EndsWith("'") OrElse piece.TrimEnd().EndsWith("TJ") Then sb.Append(" ")
        Next
        If Regex.IsMatch(content, "\bTD\b|\bTd\b|\bT\*\b") Then sb.AppendLine()
        Return sb.ToString()
    End Function
#End Region
#Region "ZIP archives"
    Public Function GetZipListing(ByVal file As String) As String
        Try
            Dim d As Byte() = IO.File.ReadAllBytes(file)
            Dim eocd As Integer = -1
            For i As Integer = d.Length - 22 To Math.Max(0, d.Length - 65557) Step -1
                If i < 0 Then Exit For
                If d(i) = &H50 AndAlso d(i + 1) = &H4B AndAlso d(i + 2) = 5 AndAlso d(i + 3) = 6 Then
                    eocd = i : Exit For
                End If
            Next
            If eocd < 0 Then Return "(Not a readable ZIP archive.)"
            Dim count As Integer = BitConverter.ToUInt16(d, eocd + 10)
            Dim cdOff As Integer = CInt(BitConverter.ToUInt32(d, eocd + 16))
            Dim sb As New StringBuilder()
            sb.AppendLine("Archive contents - " & count & " entries")
            sb.AppendLine(New String("-"c, 70))
            sb.AppendLine("Size".PadLeft(12) & "  " & "Packed".PadLeft(12) & "  Name")
            Dim p As Integer = cdOff
            Dim shown As Integer = 0
            While shown < count AndAlso p + 46 <= d.Length
                If Not (d(p) = &H50 AndAlso d(p + 1) = &H4B AndAlso d(p + 2) = 1 AndAlso d(p + 3) = 2) Then Exit While
                Dim comp As UInteger = BitConverter.ToUInt32(d, p + 20)
                Dim uncomp As UInteger = BitConverter.ToUInt32(d, p + 24)
                Dim nameLen As Integer = BitConverter.ToUInt16(d, p + 28)
                Dim extraLen As Integer = BitConverter.ToUInt16(d, p + 30)
                Dim cmtLen As Integer = BitConverter.ToUInt16(d, p + 32)
                Dim name As String = Encoding.UTF8.GetString(d, p + 46, nameLen)
                sb.AppendLine(Format(uncomp, "#,##0").PadLeft(12) & "  " & _
                              Format(comp, "#,##0").PadLeft(12) & "  " & name)
                p += 46 + nameLen + extraLen + cmtLen
                shown += 1
                If shown >= 500 Then
                    sb.AppendLine("... (only the first 500 entries are listed) ...")
                    Exit While
                End If
            End While
            Return sb.ToString()
        Catch ex As Exception
            Return "Cannot read this archive." & vbCrLf & ex.Message
        End Try
    End Function
#End Region
#Region "Helpers"
    Public Function CleanXmlText(ByVal xml As String) As String
        Dim t As String = Regex.Replace(xml, "<[^>]+>", "")
        t = t.Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">")
        t = t.Replace("&quot;", """").Replace("&apos;", "'").Replace("&#10;", vbCrLf)
        t = Regex.Replace(t, "(\r?\n){3,}", vbCrLf & vbCrLf)
        Return t
    End Function
    Public Function FormatDelimited(ByVal text As String, ByVal sep As Char) As String
        Dim lines() As String = text.Replace(vbCrLf, vbLf).Split(CChar(vbLf))
        Dim sb As New StringBuilder()
        Dim max As Integer = Math.Min(lines.Length, 500)
        For i As Integer = 0 To max - 1
            Dim cells() As String = lines(i).Split(sep)
            Dim line As New StringBuilder()
            For Each c As String In cells
                line.Append(PadCell(c.Trim(""""c)))
            Next
            sb.AppendLine(line.ToString().TrimEnd())
            If i = 0 Then sb.AppendLine(New String("-"c, Math.Min(line.Length, 100)))
        Next
        If lines.Length > max Then sb.AppendLine("... (" & (lines.Length - max) & " more rows) ...")
        Return sb.ToString()
    End Function
    Public Function GetVersionText(ByVal file As String) As String
        Try
            Dim fv As FileVersionInfo = FileVersionInfo.GetVersionInfo(file)
            Dim sb As New StringBuilder()
            sb.AppendLine("Program information")
            sb.AppendLine(New String("-"c, 40))
            sb.AppendLine("Product name   : " & fv.ProductName)
            sb.AppendLine("Description    : " & fv.FileDescription)
            sb.AppendLine("Company        : " & fv.CompanyName)
            sb.AppendLine("File version   : " & fv.FileVersion)
            sb.AppendLine("Product version: " & fv.ProductVersion)
            sb.AppendLine("Copyright      : " & fv.LegalCopyright)
            sb.AppendLine("Language       : " & fv.Language)
            Return sb.ToString()
        Catch ex As Exception
            Return "No version information available."
        End Try
    End Function
    Public Function GetMediaText(ByVal file As String) As String
        Dim fi As New FileInfo(file)
        Dim sb As New StringBuilder()
        sb.AppendLine("Media file")
        sb.AppendLine(New String("-"c, 40))
        sb.AppendLine("Name     : " & fi.Name)
        sb.AppendLine("Type     : " & IO.Path.GetExtension(file).ToUpperInvariant() & " file")
        sb.AppendLine("Size     : " & Format(fi.Length / 1048576.0, "#,##0.00") & " MB")
        sb.AppendLine("Created  : " & fi.CreationTime.ToString("g"))
        sb.AppendLine("Modified : " & fi.LastWriteTime.ToString("g"))
        sb.AppendLine()
        sb.AppendLine("Double-click the file to play it in your default player.")
        Return sb.ToString()
    End Function
#End Region
End Module
