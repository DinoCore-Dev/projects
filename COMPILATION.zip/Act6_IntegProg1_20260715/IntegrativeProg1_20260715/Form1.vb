﻿Public Class Form1

    Dim g1, g2, g3, sum, ave As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub txtG1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtG2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtG3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtAve_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtRemarks1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtRemarks2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtRemarks3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub btnDisplay_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub btnClear_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub btnExit_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Application.Exit()

    End Sub

    Private Sub btnDisplay_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        Try

            'convert to double first
            g1 = Convert.ToInt32(txtG1.Text())
            g2 = Convert.ToInt32(txtG2.Text())
            g3 = Convert.ToInt32(txtG3.Text())

            'get the sum and average of the 3 numbers
            sum = g1 + g2 + g3
            ave = sum / 3.0

            'get the value of txtave then convert to string
            txtAve.Text = ave.ToString()

            'decisions
            'remarks 1
            Select Case ave
                Case Is >= 75
                    txtRemarks1.Text = "Passed!"
                Case 74 To 70
                    txtRemarks1.Text = "Conditional!"
                Case Is < 70
                    txtRemarks1.Text = "Failed!"
                Case Else
                    txtRemarks1.Text = "Invalid Grade..."
            End Select

            'remarks 2
            Select Case ave
                Case 95 To 100
                    txtRemarks2.Text = "A"
                Case 89 To 94
                    txtRemarks2.Text = "B"
                Case 80 To 88
                    txtRemarks2.Text = "C"
                Case 75 To 79
                    txtRemarks2.Text = "D"
                Case 70 To 74
                    txtRemarks2.Text = "E"
                Case Is < 70
                    txtRemarks2.Text = "F"
                Case Else
                    txtRemarks2.Text = "Invalid Grade..."
            End Select

            'remarks 3
            Select Case ave
                Case 98 To 100
                    txtRemarks3.Text = "1.00"
                Case 95 To 97
                    txtRemarks3.Text = "1.25"
                Case 92 To 94
                    txtRemarks3.Text = "1.50"
                Case 89 To 91
                    txtRemarks3.Text = "1.75"
                Case 86 To 88
                    txtRemarks3.Text = "2.00"
                Case 83 To 85
                    txtRemarks3.Text = "2.25"
                Case 80 To 82
                    txtRemarks3.Text = "2.50"
                Case 77 To 79
                    txtRemarks3.Text = "2.75"
                Case 75 To 76
                    txtRemarks3.Text = "3.00"
                Case 70 To 74
                    txtRemarks3.Text = "4.00"
                Case Is < 70
                    txtRemarks3.Text = "5.00"
                Case Else
                    txtRemarks3.Text = "Invalid Grade..."
            End Select


            'errror handling
        Catch ex As Exception
            txtRemarks1.Text = "Theres something wrong with your code.."
            txtRemarks2.Text = "Make sure to enter the right grade number"
            txtRemarks3.Text = "Enter only number or decimal number"
        End Try
    End Sub

    Private Sub btnExit_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        'exits the application
        Application.Exit()
    End Sub

    Private Sub btnClear_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ' Clear all grade inputs and outputs
        txtG1.Clear()
        txtG2.Clear()
        txtG3.Clear()
        txtAve.Clear()
        txtRemarks1.Clear()
        txtRemarks2.Clear()
        txtRemarks3.Clear()
    End Sub
End Class
