Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices



<Assembly: AssemblyTitle("QR-Based Library Management System")>
<Assembly: AssemblyDescription("QR Code (USB scanner) based Library Management System - VB.NET Windows Forms, Visual Studio 2010, SQL Server Compact (.sdf)")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("QRLibrarySystem")>
<Assembly: AssemblyCopyright("Copyright (c) 2026")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

<Assembly: Guid("f85b7b67-0baf-4d1a-a87d-b2f01455f780")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
