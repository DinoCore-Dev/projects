<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCategories
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.grpCategoryInfo = New System.Windows.Forms.GroupBox()
        Me.txtShelfLocation = New System.Windows.Forms.TextBox()
        Me.lblShelfLocation = New System.Windows.Forms.Label()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.txtCategoryName = New System.Windows.Forms.TextBox()
        Me.lblCategoryName = New System.Windows.Forms.Label()
        Me.txtCategoryCode = New System.Windows.Forms.TextBox()
        Me.lblCategoryCode = New System.Windows.Forms.Label()
        Me.txtCategoryID = New System.Windows.Forms.TextBox()
        Me.lblCategoryID = New System.Windows.Forms.Label()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dgvCategories = New System.Windows.Forms.DataGridView()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.grpCategoryInfo.SuspendLayout()
        CType(Me.dgvCategories, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1100, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(700, 46)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "Categories"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpCategoryInfo.Controls.Add(Me.txtShelfLocation)
        Me.grpCategoryInfo.Controls.Add(Me.lblShelfLocation)
        Me.grpCategoryInfo.Controls.Add(Me.txtDescription)
        Me.grpCategoryInfo.Controls.Add(Me.lblDescription)
        Me.grpCategoryInfo.Controls.Add(Me.txtCategoryName)
        Me.grpCategoryInfo.Controls.Add(Me.lblCategoryName)
        Me.grpCategoryInfo.Controls.Add(Me.txtCategoryCode)
        Me.grpCategoryInfo.Controls.Add(Me.lblCategoryCode)
        Me.grpCategoryInfo.Controls.Add(Me.txtCategoryID)
        Me.grpCategoryInfo.Controls.Add(Me.lblCategoryID)
        Me.grpCategoryInfo.Location = New System.Drawing.Point(12, 58)
        Me.grpCategoryInfo.Name = "grpCategoryInfo"
        Me.grpCategoryInfo.Size = New System.Drawing.Size(365, 300)
        Me.grpCategoryInfo.TabIndex = 1
        Me.grpCategoryInfo.TabStop = False
        Me.grpCategoryInfo.Text = "Category"
        Me.txtShelfLocation.Location = New System.Drawing.Point(125, 240)
        Me.txtShelfLocation.Name = "txtShelfLocation"
        Me.txtShelfLocation.Size = New System.Drawing.Size(220, 20)
        Me.txtShelfLocation.TabIndex = 9
        Me.lblShelfLocation.AutoSize = False
        Me.lblShelfLocation.Location = New System.Drawing.Point(18, 240)
        Me.lblShelfLocation.Name = "lblShelfLocation"
        Me.lblShelfLocation.Size = New System.Drawing.Size(100, 20)
        Me.lblShelfLocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblShelfLocation.TabIndex = 8
        Me.lblShelfLocation.Text = "Shelf Location :"
        Me.txtDescription.Location = New System.Drawing.Point(125, 145)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(220, 80)
        Me.txtDescription.TabIndex = 7
        Me.lblDescription.AutoSize = False
        Me.lblDescription.Location = New System.Drawing.Point(18, 148)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(100, 13)
        Me.lblDescription.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.lblDescription.TabIndex = 6
        Me.lblDescription.Text = "Description :"
        Me.txtCategoryName.Location = New System.Drawing.Point(125, 110)
        Me.txtCategoryName.Name = "txtCategoryName"
        Me.txtCategoryName.Size = New System.Drawing.Size(220, 20)
        Me.txtCategoryName.TabIndex = 5
        Me.lblCategoryName.AutoSize = False
        Me.lblCategoryName.Location = New System.Drawing.Point(18, 110)
        Me.lblCategoryName.Name = "lblCategoryName"
        Me.lblCategoryName.Size = New System.Drawing.Size(100, 20)
        Me.lblCategoryName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblCategoryName.TabIndex = 4
        Me.lblCategoryName.Text = "Category Name :"
        Me.txtCategoryCode.Location = New System.Drawing.Point(125, 75)
        Me.txtCategoryCode.Name = "txtCategoryCode"
        Me.txtCategoryCode.Size = New System.Drawing.Size(220, 20)
        Me.txtCategoryCode.TabIndex = 3
        Me.lblCategoryCode.AutoSize = False
        Me.lblCategoryCode.Location = New System.Drawing.Point(18, 75)
        Me.lblCategoryCode.Name = "lblCategoryCode"
        Me.lblCategoryCode.Size = New System.Drawing.Size(100, 20)
        Me.lblCategoryCode.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblCategoryCode.TabIndex = 2
        Me.lblCategoryCode.Text = "Category Code :"
        Me.txtCategoryID.Location = New System.Drawing.Point(125, 40)
        Me.txtCategoryID.Name = "txtCategoryID"
        Me.txtCategoryID.ReadOnly = True
        Me.txtCategoryID.Size = New System.Drawing.Size(100, 20)
        Me.txtCategoryID.TabIndex = 1
        Me.lblCategoryID.AutoSize = False
        Me.lblCategoryID.Location = New System.Drawing.Point(18, 40)
        Me.lblCategoryID.Name = "lblCategoryID"
        Me.lblCategoryID.Size = New System.Drawing.Size(100, 20)
        Me.lblCategoryID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblCategoryID.TabIndex = 0
        Me.lblCategoryID.Text = "Category ID :"
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Location = New System.Drawing.Point(397, 68)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Size = New System.Drawing.Size(47, 13)
        Me.lblSearch.TabIndex = 2
        Me.lblSearch.Text = "Search"
        Me.txtSearch.Location = New System.Drawing.Point(450, 65)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(511, 20)
        Me.txtSearch.TabIndex = 3
        Me.btnSearch.Location = New System.Drawing.Point(971, 58)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(110, 32)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "&Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        Me.dgvCategories.AllowUserToAddRows = False
        Me.dgvCategories.AllowUserToDeleteRows = False
        Me.dgvCategories.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCategories.Location = New System.Drawing.Point(397, 100)
        Me.dgvCategories.MultiSelect = False
        Me.dgvCategories.Name = "dgvCategories"
        Me.dgvCategories.ReadOnly = True
        Me.dgvCategories.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvCategories.Size = New System.Drawing.Size(684, 330)
        Me.dgvCategories.TabIndex = 5
        Me.lblCount.AutoSize = True
        Me.lblCount.Location = New System.Drawing.Point(397, 440)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(102, 13)
        Me.lblCount.TabIndex = 6
        Me.lblCount.Text = "Records: 0"
        Me.btnNew.Location = New System.Drawing.Point(12, 475)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(95, 34)
        Me.btnNew.TabIndex = 7
        Me.btnNew.Text = "&New"
        Me.btnNew.UseVisualStyleBackColor = True
        Me.btnSave.Location = New System.Drawing.Point(115, 475)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(95, 34)
        Me.btnSave.TabIndex = 8
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        Me.btnUpdate.Location = New System.Drawing.Point(218, 475)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(95, 34)
        Me.btnUpdate.TabIndex = 9
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        Me.btnDelete.Location = New System.Drawing.Point(321, 475)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(95, 34)
        Me.btnDelete.TabIndex = 10
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        Me.btnClear.Location = New System.Drawing.Point(424, 475)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(95, 34)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        Me.btnClose.Location = New System.Drawing.Point(971, 475)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(110, 34)
        Me.btnClose.TabIndex = 12
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1100, 521)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.dgvCategories)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.lblSearch)
        Me.Controls.Add(Me.grpCategoryInfo)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmCategories"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Categories"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.grpCategoryInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpCategoryInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpCategoryInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpCategoryInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblCategoryID.BackColor = System.Drawing.Color.Transparent
        Me.lblCategoryID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtCategoryID.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.txtCategoryID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtCategoryID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCategoryID.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblCategoryCode.BackColor = System.Drawing.Color.Transparent
        Me.lblCategoryCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtCategoryCode.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtCategoryCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtCategoryCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCategoryCode.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblCategoryName.BackColor = System.Drawing.Color.Transparent
        Me.lblCategoryName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtCategoryName.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtCategoryName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtCategoryName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCategoryName.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDescription.BackColor = System.Drawing.Color.Transparent
        Me.lblDescription.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtDescription.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtDescription.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblShelfLocation.BackColor = System.Drawing.Color.Transparent
        Me.lblShelfLocation.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtShelfLocation.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtShelfLocation.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtShelfLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShelfLocation.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblSearch.BackColor = System.Drawing.Color.Transparent
        Me.lblSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.FlatAppearance.BorderSize = 1
        Me.btnSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSearch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnSearch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSearch.UseVisualStyleBackColor = False
        Me.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvCategories.EnableHeadersVisualStyles = False
        Me.dgvCategories.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvCategories.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvCategories.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvCategories.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvCategories.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvCategories.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvCategories.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvCategories.ColumnHeadersHeight = 32
        Me.dgvCategories.RowTemplate.Height = 24
        Me.dgvCategories.RowHeadersVisible = False
        Me.dgvCategories.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvCategories.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvCategories.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvCategories.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvCategories.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvCategories.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvCategories.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvCategories.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvCategories.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvCategories.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvCategories.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvCategories.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvCategories.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvCategories.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvCategories.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvCategories.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvCategories.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvCategories.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvCategories.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblCount.BackColor = System.Drawing.Color.Transparent
        Me.lblCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNew.FlatAppearance.BorderSize = 1
        Me.btnNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnNew.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnNew.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnNew.UseVisualStyleBackColor = False
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.FlatAppearance.BorderSize = 2
        Me.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSave.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSave.UseVisualStyleBackColor = False
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.FlatAppearance.BorderSize = 1
        Me.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUpdate.UseVisualStyleBackColor = False
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.FlatAppearance.BorderSize = 1
        Me.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.btnDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnDelete.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnDelete.UseVisualStyleBackColor = False
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.FlatAppearance.BorderSize = 1
        Me.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.pnlHeader.ResumeLayout(False)
        Me.grpCategoryInfo.ResumeLayout(False)
        Me.grpCategoryInfo.PerformLayout()
        CType(Me.dgvCategories, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents grpCategoryInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblCategoryID As System.Windows.Forms.Label
    Friend WithEvents txtCategoryID As System.Windows.Forms.TextBox
    Friend WithEvents lblCategoryCode As System.Windows.Forms.Label
    Friend WithEvents txtCategoryCode As System.Windows.Forms.TextBox
    Friend WithEvents lblCategoryName As System.Windows.Forms.Label
    Friend WithEvents txtCategoryName As System.Windows.Forms.TextBox
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents lblShelfLocation As System.Windows.Forms.Label
    Friend WithEvents txtShelfLocation As System.Windows.Forms.TextBox
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents dgvCategories As System.Windows.Forms.DataGridView
    Friend WithEvents lblCount As System.Windows.Forms.Label
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
