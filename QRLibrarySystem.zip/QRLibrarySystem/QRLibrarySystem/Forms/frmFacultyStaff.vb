Imports MessagingToolkit.QRCode.Codec
Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO
Public Class frmFacultyStaff

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Try
            Dim value As Object = GetScalar(sql, pars)
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
            Return Convert.ToString(row(col))
        Catch
            Return ""
        End Try
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
            Return Convert.ToInt32(row(col))
        Catch
            Return 0
        End Try
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
            Return Convert.ToDecimal(row(col))
        Catch
            Return 0D
        End Try
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
            Dim value As Date = Convert.ToDateTime(row(col))
            If value < New Date(1900, 1, 1) OrElse value > New Date(9998, 12, 31) Then Return Date.Today
            Return value
        Catch
            Return Date.Today
        End Try
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        Try
            If gridRow Is Nothing Then Return ""
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return ""
            Return Convert.ToString(value)
        Catch
            Return ""
        End Try
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        Try
            If gridRow Is Nothing Then Return 0
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        Try
            If gridRow Is Nothing Then Return Date.Today
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
            Dim result As Date = Convert.ToDateTime(value)
            If result < New Date(1900, 1, 1) OrElse result > New Date(9998, 12, 31) Then Return Date.Today
            Return result
        Catch
            Return Date.Today
        End Try
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        Dim message As String = ex.Message
        If TypeOf ex Is SqlCeException OrElse TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then message = FriendlyDatabaseError(ex, "complete the operation")
        MessageBox.Show(title & ": " & message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region

    Private Function CleanText(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Dim result As String = ""
        Dim lastWasSpace As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsWhiteSpace(ch) Then
                If result.Length > 0 AndAlso Not lastWasSpace Then result &= " "c
                lastWasSpace = True
            Else
                result &= ch
                lastWasSpace = False
            End If
        Next
        Return result.Trim()
    End Function

    Private Function HasBadControl(ByVal value As String, ByVal allowMultiline As Boolean) As Boolean
        If value Is Nothing Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsControl(ch) Then
                If allowMultiline AndAlso (ch = ControlChars.Cr OrElse ch = ControlChars.Lf OrElse ch = ControlChars.Tab) Then Continue For
                Return True
            End If
        Next
        Return False
    End Function

    Private Function FailValidation(ByVal target As Control, ByVal message As String) As Boolean
        MessageBox.Show(message, "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        If target IsNot Nothing Then
            Try
                target.Focus()
                Dim textBox As TextBox = TryCast(target, TextBox)
                If textBox IsNot Nothing Then textBox.SelectAll()
                Dim comboBox As ComboBox = TryCast(target, ComboBox)
                If comboBox IsNot Nothing Then comboBox.SelectAll()
            Catch
            End Try
        End If
        Return False
    End Function

    Private Function CheckTextBox(ByVal target As TextBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Function CheckComboText(ByVal target As ComboBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Sub NormalizeComboText(ByVal target As ComboBox)
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return
            End If
        Next
        target.Text = value
    End Sub

    Private Function RequireListValue(ByVal target As ComboBox, ByVal label As String) As Boolean
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return True
            End If
        Next
        Return FailValidation(target, "Please select a valid " & label & " from the list.")
    End Function

    Private Function IdentifierOK(ByVal value As String, ByVal minLength As Integer) As Boolean
        If value Is Nothing OrElse value.Length < minLength Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(0)) Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(value.Length - 1)) Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c AndAlso ch <> "_"c AndAlso ch <> "."c AndAlso ch <> "/"c Then Return False
        Next
        Return True
    End Function

    Private Function PersonNameOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 Then Return False
        Dim hasLetter As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsLetter(ch) Then
                hasLetter = True
            ElseIf ch = " "c OrElse ch = "'"c OrElse ch = "-"c OrElse ch = "."c Then
            Else
                Return False
            End If
        Next
        Return hasLetter
    End Function

    Private Function EmailOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length < 5 OrElse value.Length > 100 Then Return False
        If HasBadControl(value, False) OrElse value.IndexOf(" "c) >= 0 Then Return False
        Dim at As Integer = value.IndexOf("@"c)
        If at < 1 OrElse at <> value.LastIndexOf("@"c) OrElse at >= value.Length - 3 Then Return False
        Dim localPart As String = value.Substring(0, at)
        Dim domain As String = value.Substring(at + 1)
        If localPart.StartsWith(".") OrElse localPart.EndsWith(".") OrElse localPart.Contains("..") Then Return False
        If domain.StartsWith(".") OrElse domain.EndsWith(".") OrElse domain.StartsWith("-") OrElse domain.EndsWith("-") OrElse domain.Contains("..") Then Return False
        Dim labels() As String = domain.Split("."c)
        If labels.Length < 2 Then Return False
        Dim i As Integer
        For i = 0 To localPart.Length - 1
            Dim ch As Char = localPart.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "."c AndAlso ch <> "_"c AndAlso ch <> "%"c AndAlso ch <> "+"c AndAlso ch <> "-"c Then Return False
        Next
        For i = 0 To labels.Length - 1
            If labels(i).Length = 0 OrElse labels(i).StartsWith("-") OrElse labels(i).EndsWith("-") Then Return False
            Dim j As Integer
            For j = 0 To labels(i).Length - 1
                Dim ch As Char = labels(i).Chars(j)
                If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c Then Return False
            Next
        Next
        If labels(labels.Length - 1).Length < 2 Then Return False
        Return True
    End Function

    Private Function PhoneOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 OrElse value.Length > 20 Then Return False
        Dim digits As Integer = 0
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsDigit(ch) Then
                digits += 1
            ElseIf ch = " "c OrElse ch = "-"c OrElse ch = "("c OrElse ch = ")"c OrElse (ch = "+"c AndAlso i = 0) Then
            Else
                Return False
            End If
        Next
        Return digits >= 7 AndAlso digits <= 15
    End Function

    Private Function TrySelectedId(ByVal target As TextBox, ByRef recordId As Integer) As Boolean
        recordId = 0
        If Not Integer.TryParse(CleanText(target.Text), recordId) Then Return False
        Return recordId > 0
    End Function

    Private Function EscapeLike(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Return value.Trim().Replace("[", "[[]").Replace("%", "[%]").Replace("_", "[_]")
    End Function

    Private Function SafePickerDate(ByVal value As Date, ByVal minimumYear As Integer) As Date
        If value < New Date(minimumYear, 1, 1) Then Return New Date(minimumYear, 1, 1)
        If value.Date > Date.Today Then Return Date.Today
        Return value.Date
    End Function

    Private Function FriendlyDatabaseError(ByVal ex As Exception, ByVal action As String) As String
        Dim message As String = ""
        If ex IsNot Nothing AndAlso ex.Message IsNot Nothing Then message = ex.Message
        Dim lower As String = message.ToLowerInvariant()
        If TypeOf ex Is SqlCeException Then
            If lower.Contains("unique") OrElse lower.Contains("duplicate") Then Return "Could not " & action & " because another record already uses the same unique value."
            If lower.Contains("foreign key") OrElse lower.Contains("constraint") OrElse lower.Contains("related") Then Return "Could not " & action & " because the record is connected to other records. Check related records and try again."
            If lower.Contains("locked") OrElse lower.Contains("being used") OrElse lower.Contains("in use") Then Return "Could not " & action & " because the database is busy or locked. Wait a moment and try again."
            If lower.Contains("could not find") OrElse lower.Contains("does not exist") OrElse lower.Contains("file") Then Return "Could not " & action & " because the database file could not be opened. Close the system and run it again."
            Return "Could not " & action & ". Database error: " & message
        End If
        If TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then Return "Could not " & action & " because a required file could not be accessed. Close other programs using the system and try again."
        Return "Could not " & action & ": " & message
    End Function

    Private Function ConfirmAction(ByVal message As String, ByVal title As String) As Boolean
        Return MessageBox.Show(message, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes
    End Function


    Private _busy As Boolean = False
    Private _savedSignature As String = ""

    Private Sub ConfigureInputLimits()
        txtFacultyStaffID.MaxLength = 10
        txtEmployeeNumber.MaxLength = 20
        txtFirstName.MaxLength = 50
        txtMiddleName.MaxLength = 50
        txtLastName.MaxLength = 50
        cboDepartment.MaxLength = 100
        txtPosition.MaxLength = 50
        txtEmail.MaxLength = 100
        txtContactNumber.MaxLength = 20
        txtQRCode.MaxLength = 100
        txtSearch.MaxLength = 100
        dtpDateRegistered.MinDate = New Date(1950, 1, 1)
        dtpDateRegistered.MaxDate = Date.Today
    End Sub

    Private Function CurrentSignature() As String
        Return String.Join("|", New String() {CleanText(txtFacultyStaffID.Text), CleanText(txtEmployeeNumber.Text), CleanText(txtFirstName.Text), CleanText(txtMiddleName.Text), CleanText(txtLastName.Text), CleanText(cboDepartment.Text), CleanText(cboEmploymentType.Text), CleanText(txtPosition.Text), CleanText(txtEmail.Text), CleanText(txtContactNumber.Text), CleanText(cboStatus.Text), dtpDateRegistered.Value.Date.ToString("yyyy-MM-dd")})
    End Function

    Private Sub RememberSavedState()
        _savedSignature = CurrentSignature()
    End Sub

    Private Function ConfirmDiscardChanges() As Boolean
        If _savedSignature = "" OrElse _savedSignature = CurrentSignature() Then Return True
        Return ConfirmAction("Discard unsaved faculty/staff changes?", "Unsaved Changes")
    End Function

    Private Sub frmFacultyStaff_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If e.CloseReason = CloseReason.UserClosing AndAlso Not ConfirmDiscardChanges() Then e.Cancel = True
    End Sub

    Private Sub NormalizeInput()
        txtEmployeeNumber.Text = CleanText(txtEmployeeNumber.Text).ToUpperInvariant()
        txtFirstName.Text = CleanText(txtFirstName.Text)
        txtMiddleName.Text = CleanText(txtMiddleName.Text)
        txtLastName.Text = CleanText(txtLastName.Text)
        NormalizeComboText(cboDepartment)
        txtPosition.Text = CleanText(txtPosition.Text)
        txtEmail.Text = CleanText(txtEmail.Text).ToLowerInvariant()
        txtContactNumber.Text = CleanText(txtContactNumber.Text)
    End Sub

    Private Sub PerformSearch()
        Dim scanned As String = CleanText(txtSearch.Text).ToUpperInvariant()
        If scanned.StartsWith("BOOK-") OrElse scanned.StartsWith("STU-") Then
            MessageBox.Show("Wrong QR type. This search accepts a Faculty QR (FAC-...).", "Search", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSearch.Clear()
            txtSearch.Focus()
            Exit Sub
        End If
        txtSearch.Text = CleanText(txtSearch.Text)
        LoadFaculty(txtSearch.Text)
    End Sub

    Private Sub frmFacultyStaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ConfigureInputLimits()
            ClearFields()
            LoadFaculty("")
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatFacultyGrid()
        Try
            HideAllGridColumns(dgvFaculty)
            Dim i As Integer = 0
            ShowGridColumn(dgvFaculty, "facultystaffid", "ID", 45, i)
            ShowGridColumn(dgvFaculty, "employee_number", "Employee No.", 110, i)
            ShowGridColumn(dgvFaculty, "last_name", "Last Name", 110, i)
            ShowGridColumn(dgvFaculty, "first_name", "First Name", 105, i)
            ShowGridColumn(dgvFaculty, "department", "Department", 150, i)
            ShowGridColumn(dgvFaculty, "employment_type", "Emp. Type", 80, i)
            ShowGridColumn(dgvFaculty, "status", "Status", 65, i)
        Catch
        End Try
    End Sub

    Private Sub LoadFaculty(ByVal keyword As String)
        Try
            Dim key As String = CleanText(keyword)
            If key.Length > 100 Then key = key.Substring(0, 100)
            Dim sql As String = "SELECT * FROM FACULTY_STAFF"
            Dim dt As DataTable
            If key = "" Then
                dt = GetTable(sql & " ORDER BY last_name, first_name")
            Else
                Dim likeValue As String = "%" & EscapeLike(key) & "%"
                sql &= " WHERE employee_number LIKE @q1 OR qr_code LIKE @q2 OR first_name LIKE @q3 OR last_name LIKE @q4 OR department LIKE @q5 ORDER BY last_name, first_name"
                dt = GetTable(sql, P("@q1", likeValue), P("@q2", likeValue), P("@q3", likeValue), P("@q4", likeValue), P("@q5", likeValue))
            End If
            dgvFaculty.DataSource = dt
            FormatFacultyGrid()
            lblCount.Text = "Records: " & dt.Rows.Count
            If dgvFaculty.Columns.Contains("facultystaffid") Then dgvFaculty.Columns("facultystaffid").HeaderText = "ID"
        Catch ex As Exception
            dgvFaculty.DataSource = Nothing
            lblCount.Text = "Records: 0"
            MessageBox.Show(FriendlyDatabaseError(ex, "load faculty/staffs"), "Faculty and Staff", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub ClearFields()
        txtFacultyStaffID.Clear()
        txtEmployeeNumber.Clear()
        txtFirstName.Clear()
        txtMiddleName.Clear()
        txtLastName.Clear()
        cboDepartment.Text = ""
        If cboEmploymentType.Items.Count > 0 Then cboEmploymentType.SelectedIndex = 0
        txtPosition.Clear()
        txtEmail.Clear()
        txtContactNumber.Clear()
        cboStatus.Text = "Active"
        dtpDateRegistered.Value = Date.Today
        txtQRCode.Clear()
        Dim oldImage As System.Drawing.Image = picQR.Image
        picQR.Image = Nothing
        If oldImage IsNot Nothing Then oldImage.Dispose()
        RememberSavedState()
        txtEmployeeNumber.Focus()
    End Sub
    Private Function IsValid() As Boolean
        If Not CheckTextBox(txtEmployeeNumber, "Employee Number", 20, True) Then Return False
        If Not IdentifierOK(txtEmployeeNumber.Text, 3) Then Return FailValidation(txtEmployeeNumber, "Employee Number must be at least 3 characters and use only letters, numbers, hyphen, underscore, dot, or slash. Do not include spaces.")
        If Not CheckTextBox(txtFirstName, "First Name", 50, True) Then Return False
        If Not PersonNameOK(txtFirstName.Text) Then Return FailValidation(txtFirstName, "First Name must contain letters and may use spaces, apostrophes, hyphens, and periods only.")
        If Not CheckTextBox(txtMiddleName, "Middle Name", 50, False) Then Return False
        If txtMiddleName.Text <> "" AndAlso Not PersonNameOK(txtMiddleName.Text) Then Return FailValidation(txtMiddleName, "Middle Name must contain letters and may use spaces, apostrophes, hyphens, and periods only.")
        If Not CheckTextBox(txtLastName, "Last Name", 50, True) Then Return False
        If Not PersonNameOK(txtLastName.Text) Then Return FailValidation(txtLastName, "Last Name must contain letters and may use spaces, apostrophes, hyphens, and periods only.")
        If Not CheckComboText(cboDepartment, "Department", 100, True) Then Return False
        If Not RequireListValue(cboEmploymentType, "Employment Type") Then Return False
        If Not CheckTextBox(txtPosition, "Position", 50, False) Then Return False
        Dim i As Integer
        For i = 0 To txtPosition.Text.Length - 1
            Dim ch As Char = txtPosition.Text.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> " "c AndAlso ch <> "-"c AndAlso ch <> "."c AndAlso ch <> "/"c Then Return FailValidation(txtPosition, "Position may use letters, numbers, spaces, hyphens, periods, and slashes only.")
        Next
        If Not CheckTextBox(txtEmail, "Email", 100, False) Then Return False
        If txtEmail.Text <> "" AndAlso Not EmailOK(txtEmail.Text) Then Return FailValidation(txtEmail, "Enter a valid email address, or leave Email blank.")
        If Not CheckTextBox(txtContactNumber, "Contact Number", 20, False) Then Return False
        If txtContactNumber.Text <> "" AndAlso Not PhoneOK(txtContactNumber.Text) Then Return FailValidation(txtContactNumber, "Enter a valid contact number with 7 to 15 digits, or leave it blank.")
        If Not RequireListValue(cboStatus, "Status") Then Return False
        If dtpDateRegistered.Value.Date > Date.Today OrElse dtpDateRegistered.Value.Date < New Date(1950, 1, 1) Then Return FailValidation(dtpDateRegistered, "Date Registered must be between January 1, 1950 and today.")
        Return True
    End Function
    Private Sub btnGenerateQR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerateQR.Click
        Try
            txtEmployeeNumber.Text = CleanText(txtEmployeeNumber.Text).ToUpperInvariant()
            If Not IdentifierOK(txtEmployeeNumber.Text, 3) Then
                FailValidation(txtEmployeeNumber, "Enter a valid Employee Number first. It must not contain spaces.")
                Exit Sub
            End If
            txtQRCode.Text = FacultyQRValue(txtEmployeeNumber.Text)
            ShowQRCodeInPictureBox(picQR, txtQRCode.Text)
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        If Not ConfirmDiscardChanges() Then Exit Sub
        ClearFields()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        If Not ConfirmDiscardChanges() Then Exit Sub
        ClearFields()
        txtSearch.Clear()
        LoadFaculty("")
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If _busy Then Exit Sub
        NormalizeInput()
        If CleanText(txtFacultyStaffID.Text) <> "" Then
            MessageBox.Show("This record already exists. Use UPDATE, or click NEW for a new faculty/staff.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        If Not IsValid() Then Exit Sub
        _busy = True
        Try
            Dim employeeNumber As String = CleanText(txtEmployeeNumber.Text).ToUpperInvariant()
            Dim qrValue As String = FacultyQRValue(employeeNumber)
            If GetCount("SELECT COUNT(*) FROM FACULTY_STAFF WHERE UPPER(employee_number) = @n OR UPPER(qr_code) = @q", P("@n", employeeNumber), P("@q", qrValue.ToUpperInvariant())) > 0 Then
                FailValidation(txtEmployeeNumber, "Employee Number or its QR code already exists.")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM FACULTY_STAFF WHERE UPPER(first_name) = @f AND UPPER(last_name) = @l AND UPPER(department) = @c", P("@f", txtFirstName.Text.ToUpperInvariant()), P("@l", txtLastName.Text.ToUpperInvariant()), P("@c", cboDepartment.Text.ToUpperInvariant())) > 0 Then
                If Not ConfirmAction("A faculty/staff with the same first name, last name, and department already exists. Continue saving a separate record?", "Possible Duplicate") Then Exit Sub
            End If
            txtQRCode.Text = qrValue
            Dim qrTest As System.Drawing.Bitmap = GenerateQRCodeImage(qrValue)
            If qrTest Is Nothing Then
                MessageBox.Show("The faculty/staff QR code could not be generated, so the record was not saved.", "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            qrTest.Dispose()
            Dim affected As Integer = RunNonQuery("INSERT INTO FACULTY_STAFF (employee_number, qr_code, first_name, middle_name, last_name, department, employment_type, position, email, contact_number, status, date_registered) VALUES (@num,@qr,@fn,@mn,@ln,@department,@emptype,@pos,@email,@contact,@status,@date)", P("@num", employeeNumber), P("@qr", qrValue), P("@fn", txtFirstName.Text.Trim()), P("@mn", txtMiddleName.Text.Trim()), P("@ln", txtLastName.Text.Trim()), P("@department", cboDepartment.Text.Trim()), P("@emptype", cboEmploymentType.Text), P("@pos", txtPosition.Text.Trim()), P("@email", txtEmail.Text.Trim()), P("@contact", txtContactNumber.Text.Trim()), P("@status", cboStatus.Text), P("@date", dtpDateRegistered.Value.Date))
            If affected <> 1 Then Throw New Exception("The faculty/staff record was not inserted.")
            Dim newId As Integer = 0
            Dim newIdValue As Object = GetScalar("SELECT facultystaffid FROM FACULTY_STAFF WHERE UPPER(employee_number) = @n", P("@n", employeeNumber))
            If newIdValue IsNot Nothing AndAlso Not IsDBNull(newIdValue) Then Integer.TryParse(Convert.ToString(newIdValue), newId)
            If newId > 0 Then txtFacultyStaffID.Text = CStr(newId)
            ShowQRCodeInPictureBox(picQR, qrValue)
            WriteUserLog("Insert", "Faculty Staff Management", "FACULTY_STAFF", newId, "Registered faculty/staff " & employeeNumber)
            MessageBox.Show("Faculty/Staff saved successfully. QR Code: " & qrValue, "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSearch.Clear()
            LoadFaculty("")
            RememberSavedState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmFacultyStaff.Save", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "save the faculty/staff"), "Save", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If _busy Then Exit Sub
        Dim facultyId As Integer = 0
        If Not TrySelectedId(txtFacultyStaffID, facultyId) Then
            MessageBox.Show("Select a valid faculty/staff from the list first.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        NormalizeInput()
        If Not IsValid() Then Exit Sub
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT employee_number, status FROM FACULTY_STAFF WHERE facultystaffid = @id", P("@id", facultyId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This faculty/staff no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadFaculty("")
                Exit Sub
            End If
            Dim oldNumber As String = DbStr(existing.Rows(0), "employee_number")
            Dim employeeNumber As String = CleanText(txtEmployeeNumber.Text).ToUpperInvariant()
            Dim qrValue As String = FacultyQRValue(employeeNumber)
            If GetCount("SELECT COUNT(*) FROM FACULTY_STAFF WHERE (UPPER(employee_number) = @n OR UPPER(qr_code) = @q) AND facultystaffid <> @id", P("@n", employeeNumber), P("@q", qrValue.ToUpperInvariant()), P("@id", facultyId)) > 0 Then
                FailValidation(txtEmployeeNumber, "Employee Number or its QR code is already used by another faculty/staff.")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM FACULTY_STAFF WHERE UPPER(first_name) = @f AND UPPER(last_name) = @l AND UPPER(department) = @c AND facultystaffid <> @id", P("@f", txtFirstName.Text.ToUpperInvariant()), P("@l", txtLastName.Text.ToUpperInvariant()), P("@c", cboDepartment.Text.ToUpperInvariant()), P("@id", facultyId)) > 0 Then
                If Not ConfirmAction("Another faculty/staff with the same first name, last name, and department already exists. Continue updating this separate record?", "Possible Duplicate") Then Exit Sub
            End If
            If Not String.Equals(oldNumber, employeeNumber, StringComparison.OrdinalIgnoreCase) Then
                If Not ConfirmAction("Changing the Employee Number will change the QR code. Previously printed QR IDs will stop working. Continue?", "Change Employee Number") Then Exit Sub
            End If
            If cboStatus.Text <> "Active" Then
                Dim openVisitCount As Integer = GetCount("SELECT COUNT(*) FROM VISITORS_LOG WHERE facultystaffid = @id AND time_out IS NULL", P("@id", facultyId))
                Dim openBorrowCount As Integer = GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE facultystaffid = @id AND return_date IS NULL", P("@id", facultyId))
                If openVisitCount > 0 OrElse openBorrowCount > 0 Then
                    FailValidation(cboStatus, "This faculty/staff cannot be made inactive yet. Open visit records: " & openVisitCount & ". Borrowed books not returned: " & openBorrowCount & ". Complete those records first.")
                    Exit Sub
                End If
            End If
            txtQRCode.Text = qrValue
            Dim qrTest As System.Drawing.Bitmap = GenerateQRCodeImage(qrValue)
            If qrTest Is Nothing Then
                MessageBox.Show("The faculty/staff QR code could not be generated, so the record was not saved.", "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            qrTest.Dispose()
            Dim affected As Integer = RunNonQuery("UPDATE FACULTY_STAFF SET employee_number=@num, qr_code=@qr, first_name=@fn, middle_name=@mn, last_name=@ln, department=@department, employment_type=@emptype, position=@pos, email=@email, contact_number=@contact, status=@status, date_registered=@date WHERE facultystaffid=@id", P("@num", employeeNumber), P("@qr", qrValue), P("@fn", txtFirstName.Text.Trim()), P("@mn", txtMiddleName.Text.Trim()), P("@ln", txtLastName.Text.Trim()), P("@department", cboDepartment.Text.Trim()), P("@emptype", cboEmploymentType.Text), P("@pos", txtPosition.Text.Trim()), P("@email", txtEmail.Text.Trim()), P("@contact", txtContactNumber.Text.Trim()), P("@status", cboStatus.Text), P("@date", dtpDateRegistered.Value.Date), P("@id", facultyId))
            If affected <> 1 Then
                MessageBox.Show("This faculty/staff no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadFaculty("")
                Exit Sub
            End If
            ShowQRCodeInPictureBox(picQR, qrValue)
            WriteUserLog("Update", "Faculty Staff Management", "FACULTY_STAFF", facultyId, "Updated faculty/staff " & employeeNumber)
            MessageBox.Show("Faculty/Staff updated successfully.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSearch.Clear()
            LoadFaculty("")
            RememberSavedState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmFacultyStaff.Update", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "update the faculty/staff"), "Update", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If _busy Then Exit Sub
        Dim facultyId As Integer = 0
        If Not TrySelectedId(txtFacultyStaffID, facultyId) Then
            MessageBox.Show("Select a valid faculty/staff from the list first.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT employee_number, first_name, last_name FROM FACULTY_STAFF WHERE facultystaffid = @id", P("@id", facultyId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This faculty/staff no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadFaculty("")
                Exit Sub
            End If
            Dim borrowCount As Integer = GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE facultystaffid = @id", P("@id", facultyId))
            Dim visitCount As Integer = GetCount("SELECT COUNT(*) FROM VISITORS_LOG WHERE facultystaffid = @id", P("@id", facultyId))
            If borrowCount > 0 OrElse visitCount > 0 Then
                MessageBox.Show("This faculty/staff cannot be deleted because history must be kept. Borrow records: " & borrowCount & ". Visitor records: " & visitCount & ". Set Status to Inactive or Graduated instead.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim displayName As String = CleanText(DbStr(existing.Rows(0), "last_name") & ", " & DbStr(existing.Rows(0), "first_name") & " (" & DbStr(existing.Rows(0), "employee_number") & ")")
            If Not ConfirmAction("Delete faculty/staff " & displayName & "? This cannot be undone.", "Delete") Then Exit Sub
            Dim affected As Integer = RunNonQuery("DELETE FROM FACULTY_STAFF WHERE facultystaffid=@id", P("@id", facultyId))
            If affected <> 1 Then
                MessageBox.Show("This faculty/staff no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadFaculty("")
                Exit Sub
            End If
            WriteUserLog("Delete", "Faculty Staff Management", "FACULTY_STAFF", facultyId, "Deleted faculty/staff " & displayName)
            MessageBox.Show("Faculty/Staff deleted successfully.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearFields()
            txtSearch.Clear()
            LoadFaculty("")
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmFacultyStaff.Delete", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "delete the faculty/staff"), "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        PerformSearch()
    End Sub
    Private Sub txtSearch_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter OrElse e.KeyCode = Keys.Tab Then
            e.SuppressKeyPress = True
            PerformSearch()
        End If
    End Sub
    Private Sub dgvFaculty_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvFaculty.CellClick
        Try
            If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then Exit Sub
            Dim r As DataGridViewRow = dgvFaculty.Rows(e.RowIndex)
            If r Is Nothing OrElse r.IsNewRow Then Exit Sub
            If CellInt(r, "facultystaffid") <= 0 Then
                MessageBox.Show("This row does not contain a valid faculty/staff record.", "Faculty and Staff", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If Not ConfirmDiscardChanges() Then Exit Sub
            txtFacultyStaffID.Text = CStr(CellInt(r, "facultystaffid"))
            txtEmployeeNumber.Text = CellStr(r, "employee_number")
            txtFirstName.Text = CellStr(r, "first_name")
            txtMiddleName.Text = CellStr(r, "middle_name")
            txtLastName.Text = CellStr(r, "last_name")
            cboDepartment.Text = CellStr(r, "department")
            cboEmploymentType.Text = CellStr(r, "employment_type")
            txtPosition.Text = CellStr(r, "position")
            txtEmail.Text = CellStr(r, "email")
            txtContactNumber.Text = CellStr(r, "contact_number")
            cboStatus.Text = CellStr(r, "status")
            dtpDateRegistered.Value = SafePickerDate(CellDate(r, "date_registered"), 1950)
            txtQRCode.Text = CellStr(r, "qr_code")
            If txtQRCode.Text.Trim() = "" AndAlso txtEmployeeNumber.Text.Trim() <> "" Then txtQRCode.Text = FacultyQRValue(txtEmployeeNumber.Text)
            ShowQRCodeInPictureBox(picQR, txtQRCode.Text)
            RememberSavedState()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnPrintQR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrintQR.Click
        Try
            Dim facultyId As Integer = 0
            If Not TrySelectedId(txtFacultyStaffID, facultyId) Then
                MessageBox.Show("Save or select a saved faculty/staff before printing a QR ID.", "Print QR", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim dt As DataTable = GetTable("SELECT * FROM FACULTY_STAFF WHERE facultystaffid = @id", P("@id", facultyId))
            If dt.Rows.Count = 0 Then
                MessageBox.Show("This faculty/staff no longer exists. The list will be refreshed.", "Print QR", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadFaculty("")
                Exit Sub
            End If
            Dim savedNumber As String = DbStr(dt.Rows(0), "employee_number")
            If Not String.Equals(savedNumber, CleanText(txtEmployeeNumber.Text), StringComparison.OrdinalIgnoreCase) Then
                MessageBox.Show("The Employee Number was changed but not updated. Click UPDATE before printing the new QR ID.", "Print QR", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtEmployeeNumber.Focus()
                Exit Sub
            End If
            Dim qrValue As String = FacultyQRValue(savedNumber)
            txtQRCode.Text = qrValue
            ShowQRCodeInPictureBox(picQR, qrValue)
            If picQR.Image Is Nothing Then Exit Sub
            Using f As New frmQRPreview()
                f.FormTitle = "FACULTY / STAFF LIBRARY QR ID"
                f.QRText = qrValue
                f.DisplayName = CleanText(DbStr(dt.Rows(0), "last_name") & ", " & DbStr(dt.Rows(0), "first_name") & " " & DbStr(dt.Rows(0), "middle_name"))
                f.Detail1 = CleanText(DbStr(dt.Rows(0), "department") & " - " & DbStr(dt.Rows(0), "employment_type") & " - " & DbStr(dt.Rows(0), "position"))
                f.Detail2 = "Employee No.: " & savedNumber
                f.ShowDialog()
            End Using
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


#Region "Form-local QR code generation (NO MODULES / NO HELPER CLASS)"
    Private Function GenerateQRCodeImage(ByVal content As String) As System.Drawing.Bitmap
        If content Is Nothing OrElse content.Trim() = "" Then Return Nothing
        Dim encoder As New QRCodeEncoder()
        encoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE
        encoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M
        encoder.QRCodeScale = 6
        encoder.QRCodeVersion = 7
        encoder.QRCodeBackgroundColor = System.Drawing.Color.FromArgb(240, 253, 244)
        encoder.QRCodeForegroundColor = System.Drawing.Color.FromArgb(20, 83, 45)
        Dim qrOnly As System.Drawing.Bitmap = encoder.Encode(content.Trim())
        Dim margin As Integer = encoder.QRCodeScale * 4
        Dim result As New System.Drawing.Bitmap(qrOnly.Width + (margin * 2), qrOnly.Height + (margin * 2))
        Dim g As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(result)
        Try
            g.Clear(System.Drawing.Color.FromArgb(240, 253, 244))
            g.DrawImage(qrOnly, margin, margin)
        Finally
            g.Dispose()
            qrOnly.Dispose()
        End Try
        Return result
    End Function

    Private Sub ShowQRCodeInPictureBox(ByVal pic As System.Windows.Forms.PictureBox, ByVal content As String)
        Try
            If content Is Nothing OrElse content.Trim() = "" Then
                pic.Image = Nothing
                Exit Sub
            End If
            Dim oldImage As System.Drawing.Image = pic.Image
            pic.Image = GenerateQRCodeImage(content.Trim())
            pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            If oldImage IsNot Nothing Then oldImage.Dispose()
            If pic.Image Is Nothing Then
                MessageBox.Show("The QR code could not be generated. Please check the QR value.", _
                                "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            pic.Image = Nothing
            MessageBox.Show("QR code generation failed: " & ex.Message & vbCrLf & _
                            "Check that MessagingToolkit.QRCode.dll is beside the EXE in bin\Debug.", _
                            "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region


    Private Function FacultyQRValue(ByVal employeeNumber As String) As String
        If employeeNumber Is Nothing Then Return "FAC-"
        Return "FAC-" & employeeNumber.Trim()
    End Function

End Class
