Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO
Public Class frmVisitorLog

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim value As Object = GetScalar(sql, pars)
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
        Return CStr(row(col))
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
        Return CInt(row(col))
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
        Return CDec(row(col))
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
        Return CDate(row(col))
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        If gridRow Is Nothing Then Return ""
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return ""
        Return CStr(value)
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        If gridRow Is Nothing Then Return 0
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        If gridRow Is Nothing Then Return Date.Today
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
        Return CDate(value)
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        MessageBox.Show(title & ": " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region

    Private _scanBusy As Boolean = False
    Private _lastScanCode As String = ""
    Private _lastScanAt As DateTime = DateTime.MinValue

    Private Sub frmVisitorLog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
        If cboPurpose.Items.Count > 0 Then cboPurpose.SelectedIndex = 0
        LoadTodayVisitors()
        txtScanQR.Focus()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub frmVisitorLog_Shown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Shown
        Try
            txtScanQR.Focus()
        Catch ex As Exception
            ShowError("Scanner focus", ex)
        End Try
    End Sub

    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatVisitorsGrid()
        Try
            HideAllGridColumns(dgvTodayVisitors)
            Dim i As Integer = 0
            ShowGridColumn(dgvTodayVisitors, "Log ID", "Log ID", 40, i)
            ShowGridColumn(dgvTodayVisitors, "Visitor Name", "Visitor Name", 155, i)
            ShowGridColumn(dgvTodayVisitors, "Type", "Type", 65, i)
            ShowGridColumn(dgvTodayVisitors, "Purpose", "Purpose", 110, i)
            ShowGridColumn(dgvTodayVisitors, "Time In", "Time In", 100, i)
            ShowGridColumn(dgvTodayVisitors, "Time Out", "Time Out", 100, i)
            ShowGridColumn(dgvTodayVisitors, "Minutes", "Minutes", 50, i)
        Catch
        End Try
    End Sub

    Private Sub LoadTodayVisitors()
        Try
            Dim sql As String = "SELECT v.visitorlogid AS [Log ID], " & _
                "CASE WHEN v.visitor_type = 'Student' THEN (s.last_name + ', ' + s.first_name) " & _
                "ELSE (f.last_name + ', ' + f.first_name) END AS [Visitor Name], " & _
                "v.visitor_type AS [Type], v.purpose_of_visit AS [Purpose], " & _
                "v.time_in AS [Time In], v.time_out AS [Time Out], v.duration_minutes AS [Minutes] " & _
                "FROM VISITORS_LOG v " & _
                "LEFT JOIN STUDENTS s ON v.studentid = s.studentid " & _
                "LEFT JOIN FACULTY_STAFF f ON v.facultystaffid = f.facultystaffid " & _
                "WHERE v.visit_date >= @d1 AND v.visit_date < @d2 ORDER BY v.time_in DESC"
            Dim dt As DataTable = GetTable(sql, P("@d1", Date.Today), P("@d2", Date.Today.AddDays(1)))
            dgvTodayVisitors.DataSource = dt
            FormatVisitorsGrid()
            lblTodayCount.Text = "Visitors today: " & dt.Rows.Count
        Catch ex As Exception
            WriteSystemLog("Visitor Logging", "Error", "frmVisitorLog.LoadToday", ex.Message)
        End Try
    End Sub

    Private Sub txtScanQR_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtScanQR.KeyDown
        If e.KeyCode = Keys.Enter OrElse e.KeyCode = Keys.Tab Then
            e.SuppressKeyPress = True
            ProcessScan()
        End If
    End Sub

    Private Sub btnProcessScan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcessScan.Click
        ProcessScan()
    End Sub

    Private Function ScannedQRType(ByVal code As String) As String
        Dim u As String = code.Trim().ToUpper()
        If u.StartsWith("STU-") Then Return "Student"
        If u.StartsWith("FAC-") Then Return "Faculty"
        If u.StartsWith("BOOK-") Then Return "Book"
        Return "Unknown"
    End Function

    Private Sub RejectScan(ByVal message As String, ByVal code As String)
        System.Media.SystemSounds.Exclamation.Play()
        lblResult.BackColor = Color.FromArgb(153, 27, 27)
        lblResult.ForeColor = Color.FromArgb(240, 253, 244)
        lblResult.Text = message
        ClearVisitorInfo()
        WriteSystemLog("Visitor Logging", "Warning", "frmVisitorLog", message & " [" & code & "]")
        txtScanQR.Clear()
        txtScanQR.Focus()
    End Sub

    Private Sub ProcessScan()
        If _scanBusy Then Exit Sub

        Dim code As String = txtScanQR.Text.Trim()
        If code = "" Then
            txtScanQR.Focus()
            Exit Sub
        End If

        Dim upperCode As String = code.ToUpper()
        If upperCode = _lastScanCode AndAlso (DateTime.Now - _lastScanAt).TotalSeconds < 2 Then
            lblResult.BackColor = Color.FromArgb(202, 138, 4)
            lblResult.ForeColor = Color.FromArgb(63, 42, 0)
            lblResult.Text = "DUPLICATE SCAN IGNORED"
            txtScanQR.Clear()
            txtScanQR.Focus()
            Exit Sub
        End If
        _lastScanCode = upperCode
        _lastScanAt = DateTime.Now

        Dim scannedType As String = ScannedQRType(code)
        If scannedType = "Book" Then
            RejectScan("WRONG QR: BOOK QR SCANNED. Scan a Student/Faculty ID.", code)
            Exit Sub
        End If

        _scanBusy = True
        Try
            Dim visitorType As String = ""
            Dim studentId As Integer = 0
            Dim facultyId As Integer = 0
            Dim fullName As String = ""
            Dim idNumber As String = ""
            Dim courseDept As String = ""
            Dim status As String = ""

            If scannedType <> "Faculty" Then
                Dim dtS As DataTable = GetTable("SELECT * FROM STUDENTS WHERE qr_code = @q1 OR student_number = @q2", _
                                                P("@q1", code), P("@q2", code))
                If dtS.Rows.Count > 0 Then
                    Dim r As DataRow = dtS.Rows(0)
                    visitorType = "Student"
                    studentId = DbInt(r, "studentid")
                    fullName = DbStr(r, "last_name") & ", " & DbStr(r, "first_name") & " " & DbStr(r, "middle_name")
                    idNumber = DbStr(r, "student_number")
                    courseDept = DbStr(r, "course") & " - " & DbStr(r, "year_level") & " - " & DbStr(r, "section")
                    status = DbStr(r, "status")
                End If
            End If

            If visitorType = "" AndAlso scannedType <> "Student" Then
                Dim dtF As DataTable = GetTable("SELECT * FROM FACULTY_STAFF WHERE qr_code = @q1 OR employee_number = @q2", _
                                                P("@q1", code), P("@q2", code))
                If dtF.Rows.Count > 0 Then
                    Dim r As DataRow = dtF.Rows(0)
                    visitorType = "Faculty/Staff"
                    facultyId = DbInt(r, "facultystaffid")
                    fullName = DbStr(r, "last_name") & ", " & DbStr(r, "first_name") & " " & DbStr(r, "middle_name")
                    idNumber = DbStr(r, "employee_number")
                    courseDept = DbStr(r, "department") & " - " & DbStr(r, "position")
                    status = DbStr(r, "status")
                End If
            End If

            If visitorType = "" Then
                System.Media.SystemSounds.Exclamation.Play()
                lblResult.BackColor = Color.FromArgb(153, 27, 27)
                lblResult.ForeColor = Color.FromArgb(240, 253, 244)
                lblResult.Text = "QR NOT FOUND: " & code
                ClearVisitorInfo()
                WriteSystemLog("Visitor Logging", "Warning", "frmVisitorLog", "Unknown QR scanned: " & code)
                Exit Sub
            End If

            If status <> "Active" Then
                System.Media.SystemSounds.Exclamation.Play()
                lblResult.BackColor = Color.FromArgb(153, 27, 27)
                lblResult.ForeColor = Color.FromArgb(240, 253, 244)
                lblResult.Text = "INACTIVE RECORD - ENTRY NOT RECORDED"
                ShowVisitorInfo(fullName, visitorType, idNumber, courseDept, "-")
                Exit Sub
            End If

            Dim openSql As String
            Dim dtOpen As DataTable
            If visitorType = "Student" Then
                openSql = "SELECT TOP (1) * FROM VISITORS_LOG WHERE studentid = @id AND time_out IS NULL ORDER BY time_in DESC"
                dtOpen = GetTable(openSql, P("@id", studentId))
            Else
                openSql = "SELECT TOP (1) * FROM VISITORS_LOG WHERE facultystaffid = @id AND time_out IS NULL ORDER BY time_in DESC"
                dtOpen = GetTable(openSql, P("@id", facultyId))
            End If

            If dtOpen.Rows.Count > 0 Then
                Dim logId As Integer = DbInt(dtOpen.Rows(0), "visitorlogid")
                Dim timeIn As DateTime = DbDate(dtOpen.Rows(0), "time_in")
                Dim mins As Integer = CInt(DateDiff(DateInterval.Minute, timeIn, DateTime.Now))
                If mins < 0 Then mins = 0

                RunNonQuery("UPDATE VISITORS_LOG SET time_out = @out, duration_minutes = @mins WHERE visitorlogid = @id", _
                            P("@out", DateTime.Now), P("@mins", mins), P("@id", logId))

                lblResult.BackColor = Color.FromArgb(202, 138, 4)
                lblResult.ForeColor = Color.FromArgb(63, 42, 0)
                lblResult.Text = "TIME OUT RECORDED - Thank you!"
                ShowVisitorInfo(fullName, visitorType, idNumber, courseDept, _
                                "Out: " & DateTime.Now.ToString("hh:mm tt") & "  |  Duration: " & mins & " minute(s)")
                WriteUserLog("Time Out", "Visitor Logging", "VISITORS_LOG", logId, _
                             fullName & " timed out. Duration " & mins & " minute(s).")
            Else
                Dim sidValue As Object = DBNull.Value
                Dim fidValue As Object = DBNull.Value
                If visitorType = "Student" Then sidValue = studentId
                If visitorType = "Faculty/Staff" Then fidValue = facultyId

                RunNonQuery("INSERT INTO VISITORS_LOG (studentid, facultystaffid, visitor_type, purpose_of_visit, visit_date, time_in, time_out, duration_minutes) " & _
                            "VALUES (@sid,@fid,@type,@purpose,@vdate,@tin,@tout,@dur)", _
                            P("@sid", sidValue), P("@fid", fidValue), P("@type", visitorType), _
                            P("@purpose", cboPurpose.Text), P("@vdate", Date.Today), _
                            P("@tin", DateTime.Now), P("@tout", DBNull.Value), P("@dur", DBNull.Value))

                lblResult.BackColor = Color.FromArgb(20, 83, 45)
                lblResult.ForeColor = Color.FromArgb(240, 253, 244)
                lblResult.Text = "TIME IN RECORDED"
                ShowVisitorInfo(fullName, visitorType, idNumber, courseDept, _
                                "In: " & DateTime.Now.ToString("hh:mm tt") & "  |  Purpose: " & cboPurpose.Text)
                WriteUserLog("Time In", "Visitor Logging", "VISITORS_LOG", 0, _
                             fullName & " timed in. Purpose: " & cboPurpose.Text)
            End If

            System.Media.SystemSounds.Beep.Play()
            LoadTodayVisitors()

        Catch ex As Exception
            WriteSystemLog("Visitor Logging", "Error", "frmVisitorLog.ProcessScan", ex.Message)
            MessageBox.Show("Error processing scan: " & ex.Message, "Visitor Log", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _scanBusy = False
            txtScanQR.Clear()
            txtScanQR.Focus()
        End Try
    End Sub

    Private Sub ShowVisitorInfo(ByVal fullName As String, ByVal visitorType As String, _
                                ByVal idNumber As String, ByVal courseDept As String, ByVal timeInfo As String)
        lblVisitorName.Text = "Name : " & fullName.Trim()
        lblVisitorType.Text = "Type : " & visitorType
        lblVisitorIDNo.Text = "ID No. : " & idNumber
        lblVisitorCourseDept.Text = "Course/Dept : " & courseDept
        lblTimeInfo.Text = "Time : " & timeInfo
    End Sub

    Private Sub ClearVisitorInfo()
        lblVisitorName.Text = "Name : -"
        lblVisitorType.Text = "Type : -"
        lblVisitorIDNo.Text = "ID No. : -"
        lblVisitorCourseDept.Text = "Course/Dept : -"
        lblTimeInfo.Text = "Time : -"
    End Sub

    Private Sub btnClearScan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearScan.Click
        txtScanQR.Clear()
        ClearVisitorInfo()
        lblResult.BackColor = Color.FromArgb(185, 216, 190)
        lblResult.ForeColor = Color.FromArgb(20, 83, 45)
        lblResult.Text = "Waiting for scan..."
        txtScanQR.Focus()
    End Sub

    Private Sub cboPurpose_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPurpose.SelectedIndexChanged
        Try
        If txtScanQR.CanFocus Then txtScanQR.Focus()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        LoadTodayVisitors()
        txtScanQR.Focus()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
