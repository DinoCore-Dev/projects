Imports MessagingToolkit.QRCode.Codec
Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO
Public Class frmBooks
    Public ReadOnlyMode As Boolean = False

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Try
            Dim value As Object = GetScalar(sql, pars)
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
            Return Convert.ToString(row(col))
        Catch
            Return ""
        End Try
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
            Return Convert.ToInt32(row(col))
        Catch
            Return 0
        End Try
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
            Return Convert.ToDecimal(row(col))
        Catch
            Return 0D
        End Try
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
            Dim value As Date = Convert.ToDateTime(row(col))
            If value < New Date(1900, 1, 1) OrElse value > New Date(9998, 12, 31) Then Return Date.Today
            Return value
        Catch
            Return Date.Today
        End Try
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        Try
            If gridRow Is Nothing Then Return ""
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return ""
            Return Convert.ToString(value)
        Catch
            Return ""
        End Try
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        Try
            If gridRow Is Nothing Then Return 0
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        Try
            If gridRow Is Nothing Then Return Date.Today
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
            Dim result As Date = Convert.ToDateTime(value)
            If result < New Date(1900, 1, 1) OrElse result > New Date(9998, 12, 31) Then Return Date.Today
            Return result
        Catch
            Return Date.Today
        End Try
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        Dim message As String = ex.Message
        If TypeOf ex Is SqlCeException OrElse TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then message = FriendlyDatabaseError(ex, "complete the operation")
        MessageBox.Show(title & ": " & message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region

    Private Function CleanText(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Dim result As String = ""
        Dim lastWasSpace As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsWhiteSpace(ch) Then
                If result.Length > 0 AndAlso Not lastWasSpace Then result &= " "c
                lastWasSpace = True
            Else
                result &= ch
                lastWasSpace = False
            End If
        Next
        Return result.Trim()
    End Function

    Private Function HasBadControl(ByVal value As String, ByVal allowMultiline As Boolean) As Boolean
        If value Is Nothing Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsControl(ch) Then
                If allowMultiline AndAlso (ch = ControlChars.Cr OrElse ch = ControlChars.Lf OrElse ch = ControlChars.Tab) Then Continue For
                Return True
            End If
        Next
        Return False
    End Function

    Private Function FailValidation(ByVal target As Control, ByVal message As String) As Boolean
        MessageBox.Show(message, "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        If target IsNot Nothing Then
            Try
                target.Focus()
                Dim textBox As TextBox = TryCast(target, TextBox)
                If textBox IsNot Nothing Then textBox.SelectAll()
                Dim comboBox As ComboBox = TryCast(target, ComboBox)
                If comboBox IsNot Nothing Then comboBox.SelectAll()
            Catch
            End Try
        End If
        Return False
    End Function

    Private Function CheckTextBox(ByVal target As TextBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Function CheckComboText(ByVal target As ComboBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Sub NormalizeComboText(ByVal target As ComboBox)
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return
            End If
        Next
        target.Text = value
    End Sub

    Private Function RequireListValue(ByVal target As ComboBox, ByVal label As String) As Boolean
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return True
            End If
        Next
        Return FailValidation(target, "Please select a valid " & label & " from the list.")
    End Function

    Private Function IdentifierOK(ByVal value As String, ByVal minLength As Integer) As Boolean
        If value Is Nothing OrElse value.Length < minLength Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(0)) Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(value.Length - 1)) Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c AndAlso ch <> "_"c AndAlso ch <> "."c AndAlso ch <> "/"c Then Return False
        Next
        Return True
    End Function

    Private Function PersonNameOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 Then Return False
        Dim hasLetter As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsLetter(ch) Then
                hasLetter = True
            ElseIf ch = " "c OrElse ch = "'"c OrElse ch = "-"c OrElse ch = "."c Then
            Else
                Return False
            End If
        Next
        Return hasLetter
    End Function

    Private Function EmailOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length < 5 OrElse value.Length > 100 Then Return False
        If HasBadControl(value, False) OrElse value.IndexOf(" "c) >= 0 Then Return False
        Dim at As Integer = value.IndexOf("@"c)
        If at < 1 OrElse at <> value.LastIndexOf("@"c) OrElse at >= value.Length - 3 Then Return False
        Dim localPart As String = value.Substring(0, at)
        Dim domain As String = value.Substring(at + 1)
        If localPart.StartsWith(".") OrElse localPart.EndsWith(".") OrElse localPart.Contains("..") Then Return False
        If domain.StartsWith(".") OrElse domain.EndsWith(".") OrElse domain.StartsWith("-") OrElse domain.EndsWith("-") OrElse domain.Contains("..") Then Return False
        Dim labels() As String = domain.Split("."c)
        If labels.Length < 2 Then Return False
        Dim i As Integer
        For i = 0 To localPart.Length - 1
            Dim ch As Char = localPart.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "."c AndAlso ch <> "_"c AndAlso ch <> "%"c AndAlso ch <> "+"c AndAlso ch <> "-"c Then Return False
        Next
        For i = 0 To labels.Length - 1
            If labels(i).Length = 0 OrElse labels(i).StartsWith("-") OrElse labels(i).EndsWith("-") Then Return False
            Dim j As Integer
            For j = 0 To labels(i).Length - 1
                Dim ch As Char = labels(i).Chars(j)
                If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c Then Return False
            Next
        Next
        If labels(labels.Length - 1).Length < 2 Then Return False
        Return True
    End Function

    Private Function PhoneOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 OrElse value.Length > 20 Then Return False
        Dim digits As Integer = 0
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsDigit(ch) Then
                digits += 1
            ElseIf ch = " "c OrElse ch = "-"c OrElse ch = "("c OrElse ch = ")"c OrElse (ch = "+"c AndAlso i = 0) Then
            Else
                Return False
            End If
        Next
        Return digits >= 7 AndAlso digits <= 15
    End Function

    Private Function TrySelectedId(ByVal target As TextBox, ByRef recordId As Integer) As Boolean
        recordId = 0
        If Not Integer.TryParse(CleanText(target.Text), recordId) Then Return False
        Return recordId > 0
    End Function

    Private Function EscapeLike(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Return value.Trim().Replace("[", "[[]").Replace("%", "[%]").Replace("_", "[_]")
    End Function

    Private Function SafePickerDate(ByVal value As Date, ByVal minimumYear As Integer) As Date
        If value < New Date(minimumYear, 1, 1) Then Return New Date(minimumYear, 1, 1)
        If value.Date > Date.Today Then Return Date.Today
        Return value.Date
    End Function

    Private Function FriendlyDatabaseError(ByVal ex As Exception, ByVal action As String) As String
        Dim message As String = ""
        If ex IsNot Nothing AndAlso ex.Message IsNot Nothing Then message = ex.Message
        Dim lower As String = message.ToLowerInvariant()
        If TypeOf ex Is SqlCeException Then
            If lower.Contains("unique") OrElse lower.Contains("duplicate") Then Return "Could not " & action & " because another record already uses the same unique value."
            If lower.Contains("foreign key") OrElse lower.Contains("constraint") OrElse lower.Contains("related") Then Return "Could not " & action & " because the record is connected to other records. Check related records and try again."
            If lower.Contains("locked") OrElse lower.Contains("being used") OrElse lower.Contains("in use") Then Return "Could not " & action & " because the database is busy or locked. Wait a moment and try again."
            If lower.Contains("could not find") OrElse lower.Contains("does not exist") OrElse lower.Contains("file") Then Return "Could not " & action & " because the database file could not be opened. Close the system and run it again."
            Return "Could not " & action & ". Database error: " & message
        End If
        If TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then Return "Could not " & action & " because a required file could not be accessed. Close other programs using the system and try again."
        Return "Could not " & action & ": " & message
    End Function

    Private Function ConfirmAction(ByVal message As String, ByVal title As String) As Boolean
        Return MessageBox.Show(message, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes
    End Function


    Private _busy As Boolean = False
    Private _savedSignature As String = ""

    Private Sub ConfigureInputLimits()
        txtBookID.MaxLength = 10
        txtAccessionNo.MaxLength = 30
        txtTitle.MaxLength = 200
        txtAuthor.MaxLength = 150
        txtPublisher.MaxLength = 150
        txtPublicationYear.MaxLength = 4
        txtEdition.MaxLength = 30
        txtISBN.MaxLength = 20
        txtShelfLocation.MaxLength = 50
        txtQRCode.MaxLength = 100
        txtSearch.MaxLength = 100
        dtpDateAcquired.MinDate = New Date(1950, 1, 1)
        dtpDateAcquired.MaxDate = Date.Today
    End Sub

    Private Function CurrentSignature() As String
        Return String.Join("|", New String() {CleanText(txtBookID.Text), CleanText(txtAccessionNo.Text), CleanText(txtTitle.Text), CleanText(txtAuthor.Text), CleanText(txtPublisher.Text), CleanText(txtPublicationYear.Text), CleanText(txtEdition.Text), CleanText(txtISBN.Text), CleanText(Convert.ToString(cboCategory.SelectedValue)), CleanText(cboCategory.Text), CleanText(txtShelfLocation.Text), CStr(CInt(nudTotalCopies.Value)), CStr(CInt(nudAvailableCopies.Value)), CleanText(cboStatus.Text), dtpDateAcquired.Value.Date.ToString("yyyy-MM-dd")})
    End Function

    Private Sub RememberSavedState()
        _savedSignature = CurrentSignature()
    End Sub

    Private Function ConfirmDiscardChanges() As Boolean
        If ReadOnlyMode Then Return True
        If _savedSignature = "" OrElse _savedSignature = CurrentSignature() Then Return True
        Return ConfirmAction("Discard unsaved book changes?", "Unsaved Changes")
    End Function

    Private Sub frmBooks_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If e.CloseReason = CloseReason.UserClosing AndAlso Not ConfirmDiscardChanges() Then e.Cancel = True
    End Sub

    Private Function IsbnText() As String
        Return CleanText(txtISBN.Text).Replace("-", "").Replace(" ", "").ToUpperInvariant()
    End Function

    Private Function IsbnChecksumOK(ByVal value As String) As Boolean
        Dim i As Integer
        Dim total As Integer = 0
        If value.Length = 10 Then
            For i = 0 To 8
                Dim ch As Char = value.Chars(i)
                If Not Char.IsDigit(ch) Then Return False
                total += (10 - i) * CInt(ch.ToString())
            Next
            Dim last As Char = value.Chars(9)
            If Char.IsDigit(last) Then
                total += CInt(last.ToString())
            ElseIf last = "X"c Then
                total += 10
            Else
                Return False
            End If
            Return total Mod 11 = 0
        End If
        If value.Length = 13 Then
            If Not value.StartsWith("978") AndAlso Not value.StartsWith("979") Then Return False
            For i = 0 To 12
                Dim ch As Char = value.Chars(i)
                If Not Char.IsDigit(ch) Then Return False
                Dim digit As Integer = CInt(ch.ToString())
                If i < 12 Then
                    If i Mod 2 = 0 Then total += digit Else total += digit * 3
                Else
                    total += digit
                End If
            Next
            Return total Mod 10 = 0
        End If
        Return False
    End Function

    Private Function IsbnFormatOK(ByVal value As String) As Boolean
        Dim i As Integer
        If value.Length = 10 Then
            For i = 0 To 8
                If Not Char.IsDigit(value.Chars(i)) Then Return False
            Next
            Return Char.IsDigit(value.Chars(9)) OrElse value.Chars(9) = "X"c
        End If
        If value.Length = 13 Then
            If Not value.StartsWith("978") AndAlso Not value.StartsWith("979") Then Return False
            For i = 0 To 12
                If Not Char.IsDigit(value.Chars(i)) Then Return False
            Next
            Return True
        End If
        Return False
    End Function

    Private Function SelectedCategoryId(ByRef categoryId As Integer) As Boolean
        categoryId = 0
        If cboCategory.DataSource Is Nothing OrElse cboCategory.SelectedValue Is Nothing OrElse IsDBNull(cboCategory.SelectedValue) Then Return False
        Return Integer.TryParse(Convert.ToString(cboCategory.SelectedValue), categoryId) AndAlso categoryId > 0
    End Function

    Private Sub NormalizeInput()
        txtAccessionNo.Text = CleanText(txtAccessionNo.Text).ToUpperInvariant()
        txtTitle.Text = CleanText(txtTitle.Text)
        txtAuthor.Text = CleanText(txtAuthor.Text)
        txtPublisher.Text = CleanText(txtPublisher.Text)
        txtPublicationYear.Text = CleanText(txtPublicationYear.Text)
        txtEdition.Text = CleanText(txtEdition.Text)
        txtISBN.Text = IsbnText()
        txtShelfLocation.Text = CleanText(txtShelfLocation.Text)
    End Sub

    Private Sub PerformSearch()
        Dim scanned As String = CleanText(txtSearch.Text).ToUpperInvariant()
        If scanned.StartsWith("STU-") OrElse scanned.StartsWith("FAC-") Then
            MessageBox.Show("Wrong QR type. This search accepts a Book QR (BOOK-...).", "Search", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSearch.Clear()
            txtSearch.Focus()
            Exit Sub
        End If
        txtSearch.Text = CleanText(txtSearch.Text)
        LoadBooks(txtSearch.Text)
    End Sub

    Private Sub frmBooks_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ConfigureInputLimits()
            LoadCategoryCombo()
            ClearFields()
            LoadBooks("")
            ApplyReadOnlyMode()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub LoadCategoryCombo()
        Try
            Dim dt As DataTable = GetTable("SELECT categoryid, category_name FROM CATEGORIES ORDER BY category_name")
            cboCategory.DataSource = dt
            cboCategory.DisplayMember = "category_name"
            cboCategory.ValueMember = "categoryid"
            If dt.Rows.Count = 0 Then
                MessageBox.Show("No categories found. Add a category first in Book Categories before saving a book.", "Books", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            cboCategory.DataSource = Nothing
            MessageBox.Show(FriendlyDatabaseError(ex, "load book categories"), "Books", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatBooksGrid()
        Try
            HideAllGridColumns(dgvBooks)
            Dim i As Integer = 0
            ShowGridColumn(dgvBooks, "accession_no", "Accession No.", 95, i)
            ShowGridColumn(dgvBooks, "title", "Title", 200, i)
            ShowGridColumn(dgvBooks, "author", "Author", 125, i)
            ShowGridColumn(dgvBooks, "category_name", "Category", 105, i)
            ShowGridColumn(dgvBooks, "total_copies", "Total", 45, i)
            ShowGridColumn(dgvBooks, "available_copies", "Available", 50, i)
            ShowGridColumn(dgvBooks, "status", "Status", 70, i)
        Catch
        End Try
    End Sub

    Private Sub LoadBooks(ByVal keyword As String)
        Try
            Dim key As String = CleanText(keyword)
            If key.Length > 100 Then key = key.Substring(0, 100)
            Dim sql As String = "SELECT b.bookid, b.categoryid, b.accession_no, b.title, b.author, b.publisher, b.publication_year, b.edition, b.isbn, b.qr_code, b.shelf_location, b.total_copies, b.available_copies, b.status, b.date_acquired, c.category_name FROM BOOKS b LEFT JOIN CATEGORIES c ON b.categoryid = c.categoryid"
            Dim dt As DataTable
            If key = "" Then
                dt = GetTable(sql & " ORDER BY b.title")
            Else
                Dim likeValue As String = "%" & EscapeLike(key) & "%"
                sql &= " WHERE b.accession_no LIKE @q1 OR b.qr_code LIKE @q2 OR b.title LIKE @q3 OR b.author LIKE @q4 OR b.isbn LIKE @q5 OR c.category_name LIKE @q6 ORDER BY b.title"
                dt = GetTable(sql, P("@q1", likeValue), P("@q2", likeValue), P("@q3", likeValue), P("@q4", likeValue), P("@q5", likeValue), P("@q6", likeValue))
            End If
            dgvBooks.DataSource = dt
            FormatBooksGrid()
            lblCount.Text = "Records: " & dt.Rows.Count
        Catch ex As Exception
            dgvBooks.DataSource = Nothing
            lblCount.Text = "Records: 0"
            MessageBox.Show(FriendlyDatabaseError(ex, "load books"), "Books", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub ClearFields()
        txtBookID.Clear()
        txtAccessionNo.Clear()
        txtTitle.Clear()
        txtAuthor.Clear()
        txtPublisher.Clear()
        txtPublicationYear.Clear()
        txtEdition.Clear()
        txtISBN.Clear()
        If cboCategory.Items.Count > 0 Then cboCategory.SelectedIndex = 0
        txtShelfLocation.Clear()
        nudTotalCopies.Value = 1
        nudAvailableCopies.Value = 1
        cboStatus.Text = "Available"
        dtpDateAcquired.Value = Date.Today
        txtQRCode.Clear()
        Dim oldImage As System.Drawing.Image = picQR.Image
        picQR.Image = Nothing
        If oldImage IsNot Nothing Then oldImage.Dispose()
        RememberSavedState()
        txtAccessionNo.Focus()
    End Sub
    Private Function IsValid() As Boolean
        If Not CheckTextBox(txtAccessionNo, "Accession No.", 30, True) Then Return False
        If Not IdentifierOK(txtAccessionNo.Text, 3) Then Return FailValidation(txtAccessionNo, "Accession No. must be at least 3 characters and use only letters, numbers, hyphen, underscore, dot, or slash. Do not include spaces.")
        If Not CheckTextBox(txtTitle, "Book Title", 200, True) Then Return False
        If Not CheckTextBox(txtAuthor, "Author", 150, False) Then Return False
        If Not CheckTextBox(txtPublisher, "Publisher", 150, False) Then Return False
        If Not CheckTextBox(txtPublicationYear, "Year Published", 4, False) Then Return False
        If txtPublicationYear.Text <> "" Then
            Dim yearValue As Integer = 0
            If txtPublicationYear.Text.Length <> 4 OrElse Not Integer.TryParse(txtPublicationYear.Text, yearValue) OrElse yearValue < 1450 OrElse yearValue > Date.Today.Year + 1 Then Return FailValidation(txtPublicationYear, "Year Published must be a four-digit year from 1450 to " & CStr(Date.Today.Year + 1) & ", or leave it blank.")
        End If
        If Not CheckTextBox(txtEdition, "Edition", 30, False) Then Return False
        If Not CheckTextBox(txtISBN, "ISBN", 20, False) Then Return False
        If txtISBN.Text <> "" AndAlso Not IsbnFormatOK(txtISBN.Text) Then Return FailValidation(txtISBN, "ISBN must be a valid ISBN-10 or ISBN-13 format. Correct it, or leave ISBN blank if the book has none.")
        Dim categoryId As Integer = 0
        If Not SelectedCategoryId(categoryId) Then
            MessageBox.Show("Please select a Category (add one first if the list is empty).", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboCategory.Focus()
            Return False
        End If
        If Not CheckTextBox(txtShelfLocation, "Shelf Location", 50, False) Then Return False
        If nudTotalCopies.Value < 1 OrElse nudTotalCopies.Value > 1000 Then
            MessageBox.Show("Total Copies must be between 1 and 1000.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            nudTotalCopies.Focus()
            Return False
        End If
        If nudAvailableCopies.Value < 0 OrElse nudAvailableCopies.Value > nudTotalCopies.Value Then
            MessageBox.Show("Available Copies must be between 0 and Total Copies.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            nudAvailableCopies.Focus()
            Return False
        End If
        If Not RequireListValue(cboStatus, "Status") Then Return False
        If cboStatus.Text = "Available" AndAlso nudAvailableCopies.Value = 0 Then
            MessageBox.Show("A book with 0 available copies cannot have Status = Available. Use Checked Out, Lost, or Damaged.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboStatus.Focus()
            Return False
        End If
        If cboStatus.Text = "Checked Out" AndAlso nudAvailableCopies.Value > 0 Then
            MessageBox.Show("Use Checked Out only when Available Copies is 0. If at least one copy is on the shelf, use Available or Reserved.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cboStatus.Focus()
            Return False
        End If
        If dtpDateAcquired.Value.Date > Date.Today OrElse dtpDateAcquired.Value.Date < New Date(1950, 1, 1) Then Return FailValidation(dtpDateAcquired, "Date Acquired must be between January 1, 1950 and today.")
        Return True
    End Function
    Private Function PublicationYearValue() As Object
        Dim yearValue As Integer = 0
        If Not Integer.TryParse(CleanText(txtPublicationYear.Text), yearValue) Then Return DBNull.Value
        Return yearValue
    End Function
    Private Sub btnGenerateQR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerateQR.Click
        Try
            txtAccessionNo.Text = CleanText(txtAccessionNo.Text).ToUpperInvariant()
            If Not IdentifierOK(txtAccessionNo.Text, 3) Then
                FailValidation(txtAccessionNo, "Enter a valid Accession No. first. It must not contain spaces.")
                Exit Sub
            End If
            txtQRCode.Text = BookQRValue(txtAccessionNo.Text)
            ShowQRCodeInPictureBox(picQR, txtQRCode.Text)
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        If Not ConfirmDiscardChanges() Then Exit Sub
        ClearFields()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        If Not ConfirmDiscardChanges() Then Exit Sub
        ClearFields()
        txtSearch.Clear()
        LoadBooks("")
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If _busy Then Exit Sub
        If ReadOnlyMode Then
            MessageBox.Show("This Staff account can only view this form.", "View Only", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        NormalizeInput()
        If CleanText(txtBookID.Text) <> "" Then
            MessageBox.Show("This record already exists. Use UPDATE, or click NEW for a new book.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        If Not IsValid() Then Exit Sub
        _busy = True
        Try
            Dim categoryId As Integer = 0
            If Not SelectedCategoryId(categoryId) Then
                MessageBox.Show("Please select a valid Category.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM CATEGORIES WHERE categoryid = @id", P("@id", categoryId)) = 0 Then
                MessageBox.Show("The selected category no longer exists. The category list will be refreshed.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                LoadCategoryCombo()
                Exit Sub
            End If
            Dim accessionNo As String = CleanText(txtAccessionNo.Text).ToUpperInvariant()
            Dim qrValue As String = BookQRValue(accessionNo)
            If GetCount("SELECT COUNT(*) FROM BOOKS WHERE UPPER(accession_no) = @a OR UPPER(qr_code) = @q", P("@a", accessionNo), P("@q", qrValue.ToUpperInvariant())) > 0 Then
                FailValidation(txtAccessionNo, "Accession No. or its QR code already exists.")
                Exit Sub
            End If
            If txtISBN.Text <> "" AndAlso Not IsbnChecksumOK(txtISBN.Text) Then
                If Not ConfirmAction("The ISBN check digit does not match. It may have been mistyped, or this may be an old/demo record. Save it anyway?", "Check ISBN") Then
                    txtISBN.Focus()
                    txtISBN.SelectAll()
                    Exit Sub
                End If
            End If
            If txtISBN.Text <> "" AndAlso GetCount("SELECT COUNT(*) FROM BOOKS WHERE UPPER(isbn) = @i", P("@i", txtISBN.Text.ToUpperInvariant())) > 0 Then
                If Not ConfirmAction("Another book record already uses this ISBN. Different copies or volumes can share an ISBN. Continue saving this separate record?", "Same ISBN") Then
                    txtISBN.Focus()
                    Exit Sub
                End If
            End If
            If GetCount("SELECT COUNT(*) FROM BOOKS WHERE UPPER(title) = @t AND UPPER(author) = @a", P("@t", txtTitle.Text.ToUpperInvariant()), P("@a", txtAuthor.Text.ToUpperInvariant())) > 0 Then
                If Not ConfirmAction("A book with the same title and author already exists. Continue saving a separate record or another copy group?", "Possible Duplicate") Then Exit Sub
            End If
            txtQRCode.Text = qrValue
            Dim qrTest As System.Drawing.Bitmap = GenerateQRCodeImage(qrValue)
            If qrTest Is Nothing Then
                MessageBox.Show("The book QR code could not be generated, so the book was not saved.", "Book QR Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            qrTest.Dispose()
            Dim affected As Integer = RunNonQuery("INSERT INTO BOOKS (categoryid, accession_no, title, author, publisher, publication_year, edition, isbn, qr_code, shelf_location, total_copies, available_copies, status, date_acquired) VALUES (@cat,@acc,@title,@author,@pub,@year,@ed,@isbn,@qr,@shelf,@total,@avail,@status,@date)", P("@cat", categoryId), P("@acc", accessionNo), P("@title", txtTitle.Text.Trim()), P("@author", txtAuthor.Text.Trim()), P("@pub", txtPublisher.Text.Trim()), P("@year", PublicationYearValue()), P("@ed", txtEdition.Text.Trim()), P("@isbn", txtISBN.Text.Trim()), P("@qr", qrValue), P("@shelf", txtShelfLocation.Text.Trim()), P("@total", CInt(nudTotalCopies.Value)), P("@avail", CInt(nudAvailableCopies.Value)), P("@status", cboStatus.Text), P("@date", dtpDateAcquired.Value.Date))
            If affected <> 1 Then Throw New Exception("The book record was not inserted.")
            Dim newId As Integer = 0
            Dim newIdValue As Object = GetScalar("SELECT bookid FROM BOOKS WHERE UPPER(accession_no) = @a", P("@a", accessionNo))
            If newIdValue IsNot Nothing AndAlso Not IsDBNull(newIdValue) Then Integer.TryParse(Convert.ToString(newIdValue), newId)
            If newId > 0 Then txtBookID.Text = CStr(newId)
            ShowQRCodeInPictureBox(picQR, qrValue)
            WriteUserLog("Insert", "Book & Category Management", "BOOKS", newId, "Added book " & accessionNo & " - " & txtTitle.Text.Trim())
            MessageBox.Show("Book saved successfully. QR Code: " & qrValue, "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSearch.Clear()
            LoadBooks("")
            RememberSavedState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmBooks.Save", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "save the book"), "Save", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If _busy Then Exit Sub
        If ReadOnlyMode Then
            MessageBox.Show("This Staff account can only view this form.", "View Only", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        Dim bookId As Integer = 0
        If Not TrySelectedId(txtBookID, bookId) Then
            MessageBox.Show("Select a valid book from the list first.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        NormalizeInput()
        If Not IsValid() Then Exit Sub
        _busy = True
        Try
            Dim categoryId As Integer = 0
            If Not SelectedCategoryId(categoryId) Then
                MessageBox.Show("Please select a valid Category.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim existing As DataTable = GetTable("SELECT accession_no, total_copies, available_copies, status FROM BOOKS WHERE bookid = @id", P("@id", bookId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This book no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadBooks("")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM CATEGORIES WHERE categoryid = @id", P("@id", categoryId)) = 0 Then
                MessageBox.Show("The selected category no longer exists. The category list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                LoadCategoryCombo()
                Exit Sub
            End If
            Dim oldAccession As String = DbStr(existing.Rows(0), "accession_no")
            Dim accessionNo As String = CleanText(txtAccessionNo.Text).ToUpperInvariant()
            Dim qrValue As String = BookQRValue(accessionNo)
            If GetCount("SELECT COUNT(*) FROM BOOKS WHERE (UPPER(accession_no) = @a OR UPPER(qr_code) = @q) AND bookid <> @id", P("@a", accessionNo), P("@q", qrValue.ToUpperInvariant()), P("@id", bookId)) > 0 Then
                FailValidation(txtAccessionNo, "Accession No. or its QR code is already used by another book.")
                Exit Sub
            End If
            If txtISBN.Text <> "" AndAlso Not IsbnChecksumOK(txtISBN.Text) Then
                If Not ConfirmAction("The ISBN check digit does not match. It may have been mistyped, or this may be an old/demo record. Save it anyway?", "Check ISBN") Then
                    txtISBN.Focus()
                    txtISBN.SelectAll()
                    Exit Sub
                End If
            End If
            If txtISBN.Text <> "" AndAlso GetCount("SELECT COUNT(*) FROM BOOKS WHERE UPPER(isbn) = @i AND bookid <> @id", P("@i", txtISBN.Text.ToUpperInvariant()), P("@id", bookId)) > 0 Then
                If Not ConfirmAction("Another book record already uses this ISBN. Different copies or volumes can share an ISBN. Continue updating?", "Same ISBN") Then
                    txtISBN.Focus()
                    Exit Sub
                End If
            End If
            If GetCount("SELECT COUNT(*) FROM BOOKS WHERE UPPER(title) = @t AND UPPER(author) = @a AND bookid <> @id", P("@t", txtTitle.Text.ToUpperInvariant()), P("@a", txtAuthor.Text.ToUpperInvariant()), P("@id", bookId)) > 0 Then
                If Not ConfirmAction("Another book with the same title and author already exists. Continue updating this separate record?", "Possible Duplicate") Then Exit Sub
            End If
            If Not String.Equals(oldAccession, accessionNo, StringComparison.OrdinalIgnoreCase) Then
                If Not ConfirmAction("Changing the Accession No. will change the QR code. Previously printed book QR labels will stop working. Continue?", "Change Accession No.") Then Exit Sub
            End If
            Dim openBorrowCount As Integer = GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE bookid = @id AND return_date IS NULL", P("@id", bookId))
            Dim newTotal As Integer = CInt(nudTotalCopies.Value)
            Dim newAvailable As Integer = CInt(nudAvailableCopies.Value)
            If openBorrowCount > 0 Then
                Dim expectedAvailable As Integer = newTotal - openBorrowCount
                If expectedAvailable < 0 Then
                    MessageBox.Show("Total Copies cannot be less than the " & openBorrowCount & " copie(s) currently borrowed. Increase Total Copies or wait for the books to be returned.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    nudTotalCopies.Focus()
                    Exit Sub
                End If
                If newAvailable <> expectedAvailable Then
                    MessageBox.Show("This book has " & openBorrowCount & " borrowed copie(s). With Total Copies = " & newTotal & ", Available Copies must be " & expectedAvailable & ". The value was corrected for you.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    nudAvailableCopies.Value = expectedAvailable
                    newAvailable = expectedAvailable
                End If
                If newAvailable = 0 AndAlso cboStatus.Text = "Available" Then cboStatus.Text = "Checked Out"
                If newAvailable > 0 AndAlso cboStatus.Text = "Checked Out" Then cboStatus.Text = "Available"
                If cboStatus.Text = "Lost" OrElse cboStatus.Text = "Damaged" Then
                    If Not ConfirmAction("This book still has borrowed copies. Marking it " & cboStatus.Text & " will block new borrowing, but returns can still be processed. Continue?", "Borrowed Copies") Then Exit Sub
                End If
            End If
            txtQRCode.Text = qrValue
            Dim qrTest As System.Drawing.Bitmap = GenerateQRCodeImage(qrValue)
            If qrTest Is Nothing Then
                MessageBox.Show("The book QR code could not be generated, so the book was not saved.", "Book QR Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            qrTest.Dispose()
            Dim affected As Integer = RunNonQuery("UPDATE BOOKS SET categoryid=@cat, accession_no=@acc, title=@title, author=@author, publisher=@pub, publication_year=@year, edition=@ed, isbn=@isbn, qr_code=@qr, shelf_location=@shelf, total_copies=@total, available_copies=@avail, status=@status, date_acquired=@date WHERE bookid=@id", P("@cat", categoryId), P("@acc", accessionNo), P("@title", txtTitle.Text.Trim()), P("@author", txtAuthor.Text.Trim()), P("@pub", txtPublisher.Text.Trim()), P("@year", PublicationYearValue()), P("@ed", txtEdition.Text.Trim()), P("@isbn", txtISBN.Text.Trim()), P("@qr", qrValue), P("@shelf", txtShelfLocation.Text.Trim()), P("@total", newTotal), P("@avail", newAvailable), P("@status", cboStatus.Text), P("@date", dtpDateAcquired.Value.Date), P("@id", bookId))
            If affected <> 1 Then
                MessageBox.Show("This book no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadBooks("")
                Exit Sub
            End If
            ShowQRCodeInPictureBox(picQR, qrValue)
            WriteUserLog("Update", "Book & Category Management", "BOOKS", bookId, "Updated book " & accessionNo)
            MessageBox.Show("Book updated successfully.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSearch.Clear()
            LoadBooks("")
            RememberSavedState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmBooks.Update", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "update the book"), "Update", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If _busy Then Exit Sub
        If ReadOnlyMode Then
            MessageBox.Show("This Staff account can only view this form.", "View Only", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        Dim bookId As Integer = 0
        If Not TrySelectedId(txtBookID, bookId) Then
            MessageBox.Show("Select a valid book from the list first.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT accession_no, title FROM BOOKS WHERE bookid = @id", P("@id", bookId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This book no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadBooks("")
                Exit Sub
            End If
            Dim borrowCount As Integer = GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE bookid = @id", P("@id", bookId))
            If borrowCount > 0 Then
                MessageBox.Show("This book cannot be deleted because it has " & borrowCount & " borrow record(s). Keep the record and set Status to Lost or Damaged if it should no longer be borrowed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim displayName As String = CleanText(DbStr(existing.Rows(0), "accession_no") & " - " & DbStr(existing.Rows(0), "title"))
            If Not ConfirmAction("Delete book " & displayName & "? This cannot be undone.", "Delete") Then Exit Sub
            Dim affected As Integer = RunNonQuery("DELETE FROM BOOKS WHERE bookid=@id", P("@id", bookId))
            If affected <> 1 Then
                MessageBox.Show("This book no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadBooks("")
                Exit Sub
            End If
            WriteUserLog("Delete", "Book & Category Management", "BOOKS", bookId, "Deleted book " & displayName)
            MessageBox.Show("Book deleted successfully.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearFields()
            txtSearch.Clear()
            LoadBooks("")
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmBooks.Delete", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "delete the book"), "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        PerformSearch()
    End Sub
    Private Sub txtSearch_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter OrElse e.KeyCode = Keys.Tab Then
            e.SuppressKeyPress = True
            PerformSearch()
        End If
    End Sub
    Private Sub dgvBooks_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvBooks.CellClick
        Try
            If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then Exit Sub
            Dim r As DataGridViewRow = dgvBooks.Rows(e.RowIndex)
            If r Is Nothing OrElse r.IsNewRow Then Exit Sub
            If CellInt(r, "bookid") <= 0 Then
                MessageBox.Show("This row does not contain a valid book record.", "Books", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If Not ConfirmDiscardChanges() Then Exit Sub
            txtBookID.Text = CStr(CellInt(r, "bookid"))
            txtAccessionNo.Text = CellStr(r, "accession_no")
            txtTitle.Text = CellStr(r, "title")
            txtAuthor.Text = CellStr(r, "author")
            txtPublisher.Text = CellStr(r, "publisher")
            Dim yr As Integer = CellInt(r, "publication_year")
            txtPublicationYear.Text = IIf(yr = 0, "", CStr(yr))
            txtEdition.Text = CellStr(r, "edition")
            txtISBN.Text = CellStr(r, "isbn")
            Dim catId As Integer = CellInt(r, "categoryid")
            If catId > 0 Then
                Try
                    cboCategory.SelectedValue = catId
                Catch
                    cboCategory.SelectedIndex = -1
                End Try
            Else
                cboCategory.SelectedIndex = -1
            End If
            txtShelfLocation.Text = CellStr(r, "shelf_location")
            Dim tot As Integer = CellInt(r, "total_copies")
            Dim av As Integer = CellInt(r, "available_copies")
            If tot < 1 Then tot = 1
            If tot > 1000 Then tot = 1000
            If av < 0 Then av = 0
            If av > tot Then av = tot
            nudTotalCopies.Value = tot
            nudAvailableCopies.Value = av
            cboStatus.Text = CellStr(r, "status")
            dtpDateAcquired.Value = SafePickerDate(CellDate(r, "date_acquired"), 1950)
            txtQRCode.Text = CellStr(r, "qr_code")
            If txtQRCode.Text.Trim() = "" AndAlso txtAccessionNo.Text.Trim() <> "" Then txtQRCode.Text = BookQRValue(txtAccessionNo.Text)
            ShowQRCodeInPictureBox(picQR, txtQRCode.Text)
            RememberSavedState()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnPrintQR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrintQR.Click
        Try
            Dim bookId As Integer = 0
            If Not TrySelectedId(txtBookID, bookId) Then
                MessageBox.Show("Save or select a saved book before printing a QR label.", "Print QR", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim dt As DataTable = GetTable("SELECT * FROM BOOKS WHERE bookid = @id", P("@id", bookId))
            If dt.Rows.Count = 0 Then
                MessageBox.Show("This book no longer exists. The list will be refreshed.", "Print QR", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadBooks("")
                Exit Sub
            End If
            Dim savedAccession As String = DbStr(dt.Rows(0), "accession_no")
            If Not String.Equals(savedAccession, CleanText(txtAccessionNo.Text), StringComparison.OrdinalIgnoreCase) Then
                MessageBox.Show("The Accession No. was changed but not updated. Click UPDATE before printing the new QR label.", "Print QR", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtAccessionNo.Focus()
                Exit Sub
            End If
            Dim qrValue As String = BookQRValue(savedAccession)
            txtQRCode.Text = qrValue
            ShowQRCodeInPictureBox(picQR, qrValue)
            If picQR.Image Is Nothing Then Exit Sub
            Using f As New frmQRPreview()
                f.FormTitle = "BOOK QR LABEL"
                f.QRText = qrValue
                f.DisplayName = DbStr(dt.Rows(0), "title")
                f.Detail1 = DbStr(dt.Rows(0), "author")
                f.Detail2 = "Accession No.: " & savedAccession & "  |  Shelf: " & DbStr(dt.Rows(0), "shelf_location")
                f.ShowDialog()
            End Using
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub



    Private Sub ApplyReadOnlyMode()
        Try
            If Not ReadOnlyMode Then Exit Sub

            Me.Text = "Books (View Only)"
            lblFormTitle.Text = "Books"
            grpBookInfo.Visible = False
            btnNew.Visible = False
            btnSave.Visible = False
            btnUpdate.Visible = False
            btnDelete.Visible = False
            btnClear.Visible = False
            btnSave.Enabled = False
            btnUpdate.Enabled = False
            btnDelete.Enabled = False

            Dim w As Integer = Me.ClientSize.Width
            lblSearch.Location = New System.Drawing.Point(14, 68)
            txtSearch.Location = New System.Drawing.Point(72, 65)
            txtSearch.Width = Math.Max(200, w - 72 - 143)
            btnSearch.Location = New System.Drawing.Point(w - 129, 58)
            dgvBooks.Location = New System.Drawing.Point(14, 100)
            dgvBooks.Width = Math.Max(200, w - 28)
            lblCount.Location = New System.Drawing.Point(14, 585)
            btnPrintQR.Location = New System.Drawing.Point(14, 615)
            btnClose.Location = New System.Drawing.Point(w - btnClose.Width - 14, 615)
            txtSearch.Focus()
        Catch ex As Exception
            ShowError("Read-only mode", ex)
        End Try
    End Sub

#Region "Form-local QR code generation (NO MODULES / NO HELPER CLASS)"
    Private Function GenerateQRCodeImage(ByVal content As String) As System.Drawing.Bitmap
        If content Is Nothing OrElse content.Trim() = "" Then Return Nothing
        Dim encoder As New QRCodeEncoder()
        encoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE
        encoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M
        encoder.QRCodeScale = 6
        encoder.QRCodeVersion = 7
        encoder.QRCodeBackgroundColor = System.Drawing.Color.FromArgb(240, 253, 244)
        encoder.QRCodeForegroundColor = System.Drawing.Color.FromArgb(20, 83, 45)
        Dim qrOnly As System.Drawing.Bitmap = encoder.Encode(content.Trim())
        Dim margin As Integer = encoder.QRCodeScale * 4
        Dim result As New System.Drawing.Bitmap(qrOnly.Width + (margin * 2), qrOnly.Height + (margin * 2))
        Dim g As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(result)
        Try
            g.Clear(System.Drawing.Color.FromArgb(240, 253, 244))
            g.DrawImage(qrOnly, margin, margin)
        Finally
            g.Dispose()
            qrOnly.Dispose()
        End Try
        Return result
    End Function

    Private Sub ShowQRCodeInPictureBox(ByVal pic As System.Windows.Forms.PictureBox, ByVal content As String)
        Try
            If content Is Nothing OrElse content.Trim() = "" Then
                pic.Image = Nothing
                Exit Sub
            End If
            Dim oldImage As System.Drawing.Image = pic.Image
            pic.Image = GenerateQRCodeImage(content.Trim())
            pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            If oldImage IsNot Nothing Then oldImage.Dispose()
            If pic.Image Is Nothing Then
                MessageBox.Show("The QR code could not be generated. Please check the QR value.", _
                                "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            pic.Image = Nothing
            MessageBox.Show("QR code generation failed: " & ex.Message & vbCrLf & _
                            "Check that MessagingToolkit.QRCode.dll is beside the EXE in bin\Debug.", _
                            "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region


    Private Function BookQRValue(ByVal accessionNo As String) As String
        If accessionNo Is Nothing Then Return "BOOK-"
        Return "BOOK-" & accessionNo.Trim()
    End Function

End Class
