<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVisitorLog
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.grpScan = New System.Windows.Forms.GroupBox()
        Me.btnClearScan = New System.Windows.Forms.Button()
        Me.btnProcessScan = New System.Windows.Forms.Button()
        Me.cboPurpose = New System.Windows.Forms.ComboBox()
        Me.lblPurpose = New System.Windows.Forms.Label()
        Me.lblScannerStatus = New System.Windows.Forms.Label()
        Me.txtScanQR = New System.Windows.Forms.TextBox()
        Me.lblScanQR = New System.Windows.Forms.Label()
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.grpVisitorInfo = New System.Windows.Forms.GroupBox()
        Me.lblTimeInfo = New System.Windows.Forms.Label()
        Me.lblVisitorCourseDept = New System.Windows.Forms.Label()
        Me.lblVisitorIDNo = New System.Windows.Forms.Label()
        Me.lblVisitorType = New System.Windows.Forms.Label()
        Me.lblVisitorName = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.lblTodayTitle = New System.Windows.Forms.Label()
        Me.dgvTodayVisitors = New System.Windows.Forms.DataGridView()
        Me.lblTodayCount = New System.Windows.Forms.Label()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.grpScan.SuspendLayout()
        Me.grpVisitorInfo.SuspendLayout()
        CType(Me.dgvTodayVisitors, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1200, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(900, 46)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "Visitor Log"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpScan.Controls.Add(Me.btnClearScan)
        Me.grpScan.Controls.Add(Me.btnProcessScan)
        Me.grpScan.Controls.Add(Me.cboPurpose)
        Me.grpScan.Controls.Add(Me.lblPurpose)
        Me.grpScan.Controls.Add(Me.lblScannerStatus)
        Me.grpScan.Controls.Add(Me.txtScanQR)
        Me.grpScan.Controls.Add(Me.lblScanQR)
        Me.grpScan.Controls.Add(Me.lblInstruction)
        Me.grpScan.Location = New System.Drawing.Point(12, 58)
        Me.grpScan.Name = "grpScan"
        Me.grpScan.Size = New System.Drawing.Size(480, 305)
        Me.grpScan.TabIndex = 1
        Me.grpScan.TabStop = False
        Me.grpScan.Text = "Scanner"
        Me.btnClearScan.Location = New System.Drawing.Point(250, 245)
        Me.btnClearScan.Name = "btnClearScan"
        Me.btnClearScan.Size = New System.Drawing.Size(190, 38)
        Me.btnClearScan.TabIndex = 7
        Me.btnClearScan.Text = "&Clear"
        Me.btnClearScan.UseVisualStyleBackColor = True
        Me.btnProcessScan.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProcessScan.Location = New System.Drawing.Point(20, 245)
        Me.btnProcessScan.Name = "btnProcessScan"
        Me.btnProcessScan.Size = New System.Drawing.Size(220, 38)
        Me.btnProcessScan.TabIndex = 6
        Me.btnProcessScan.Text = "&Process"
        Me.btnProcessScan.UseVisualStyleBackColor = True
        Me.cboPurpose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPurpose.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPurpose.FormattingEnabled = True
        Me.cboPurpose.Items.AddRange(New Object() {"Reading / Studying", "Research", "Borrow / Return Book", "Computer / Internet Use", "Group Study", "Others"})
        Me.cboPurpose.Location = New System.Drawing.Point(20, 200)
        Me.cboPurpose.Name = "cboPurpose"
        Me.cboPurpose.Size = New System.Drawing.Size(420, 24)
        Me.cboPurpose.TabIndex = 5
        Me.lblPurpose.AutoSize = True
        Me.lblPurpose.Location = New System.Drawing.Point(20, 180)
        Me.lblPurpose.Name = "lblPurpose"
        Me.lblPurpose.Size = New System.Drawing.Size(223, 13)
        Me.lblPurpose.TabIndex = 4
        Me.lblPurpose.Text = "Purpose"
        Me.lblScannerStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScannerStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblScannerStatus.Location = New System.Drawing.Point(20, 145)
        Me.lblScannerStatus.Name = "lblScannerStatus"
        Me.lblScannerStatus.Size = New System.Drawing.Size(420, 20)
        Me.lblScannerStatus.TabIndex = 3
        Me.lblScannerStatus.Text = "Scanner ready"
        Me.txtScanQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanQR.Font = New System.Drawing.Font("Segoe UI Semibold", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtScanQR.Location = New System.Drawing.Point(20, 100)
        Me.txtScanQR.Name = "txtScanQR"
        Me.txtScanQR.Size = New System.Drawing.Size(420, 30)
        Me.txtScanQR.TabIndex = 2
        Me.txtScanQR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.lblScanQR.AutoSize = True
        Me.lblScanQR.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScanQR.Location = New System.Drawing.Point(20, 80)
        Me.lblScanQR.Name = "lblScanQR"
        Me.lblScanQR.Size = New System.Drawing.Size(252, 15)
        Me.lblScanQR.TabIndex = 1
        Me.lblScanQR.Text = "Scan Student/Faculty QR"
        Me.lblInstruction.Location = New System.Drawing.Point(20, 22)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(440, 50)
        Me.lblInstruction.TabIndex = 0
        Me.lblInstruction.Text = "Scan once: Time In. Scan again: Time Out."
        Me.grpVisitorInfo.Controls.Add(Me.lblTimeInfo)
        Me.grpVisitorInfo.Controls.Add(Me.lblVisitorCourseDept)
        Me.grpVisitorInfo.Controls.Add(Me.lblVisitorIDNo)
        Me.grpVisitorInfo.Controls.Add(Me.lblVisitorType)
        Me.grpVisitorInfo.Controls.Add(Me.lblVisitorName)
        Me.grpVisitorInfo.Location = New System.Drawing.Point(12, 375)
        Me.grpVisitorInfo.Name = "grpVisitorInfo"
        Me.grpVisitorInfo.Size = New System.Drawing.Size(480, 185)
        Me.grpVisitorInfo.TabIndex = 2
        Me.grpVisitorInfo.TabStop = False
        Me.grpVisitorInfo.Text = "Visitor"
        Me.lblTimeInfo.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeInfo.Location = New System.Drawing.Point(20, 142)
        Me.lblTimeInfo.Name = "lblTimeInfo"
        Me.lblTimeInfo.Size = New System.Drawing.Size(440, 22)
        Me.lblTimeInfo.TabIndex = 4
        Me.lblTimeInfo.Text = "Time : -"
        Me.lblVisitorCourseDept.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVisitorCourseDept.Location = New System.Drawing.Point(20, 112)
        Me.lblVisitorCourseDept.Name = "lblVisitorCourseDept"
        Me.lblVisitorCourseDept.Size = New System.Drawing.Size(440, 22)
        Me.lblVisitorCourseDept.TabIndex = 3
        Me.lblVisitorCourseDept.Text = "Course/Dept : -"
        Me.lblVisitorIDNo.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVisitorIDNo.Location = New System.Drawing.Point(20, 82)
        Me.lblVisitorIDNo.Name = "lblVisitorIDNo"
        Me.lblVisitorIDNo.Size = New System.Drawing.Size(440, 22)
        Me.lblVisitorIDNo.TabIndex = 2
        Me.lblVisitorIDNo.Text = "ID No. : -"
        Me.lblVisitorType.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVisitorType.Location = New System.Drawing.Point(20, 55)
        Me.lblVisitorType.Name = "lblVisitorType"
        Me.lblVisitorType.Size = New System.Drawing.Size(440, 22)
        Me.lblVisitorType.TabIndex = 1
        Me.lblVisitorType.Text = "Type : -"
        Me.lblVisitorName.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVisitorName.Location = New System.Drawing.Point(20, 25)
        Me.lblVisitorName.Name = "lblVisitorName"
        Me.lblVisitorName.Size = New System.Drawing.Size(440, 25)
        Me.lblVisitorName.TabIndex = 0
        Me.lblVisitorName.Text = "Name : -"
        Me.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblResult.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(12, 572)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(480, 45)
        Me.lblResult.TabIndex = 3
        Me.lblResult.Text = "Waiting for scan..."
        Me.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblTodayTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTodayTitle.Location = New System.Drawing.Point(510, 62)
        Me.lblTodayTitle.Name = "lblTodayTitle"
        Me.lblTodayTitle.Size = New System.Drawing.Size(300, 20)
        Me.lblTodayTitle.TabIndex = 4
        Me.lblTodayTitle.Text = "Today"
        Me.dgvTodayVisitors.AllowUserToAddRows = False
        Me.dgvTodayVisitors.AllowUserToDeleteRows = False
        Me.dgvTodayVisitors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTodayVisitors.Location = New System.Drawing.Point(510, 90)
        Me.dgvTodayVisitors.MultiSelect = False
        Me.dgvTodayVisitors.Name = "dgvTodayVisitors"
        Me.dgvTodayVisitors.ReadOnly = True
        Me.dgvTodayVisitors.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvTodayVisitors.Size = New System.Drawing.Size(666, 500)
        Me.dgvTodayVisitors.TabIndex = 5
        Me.lblTodayCount.AutoSize = True
        Me.lblTodayCount.Location = New System.Drawing.Point(510, 598)
        Me.lblTodayCount.Name = "lblTodayCount"
        Me.lblTodayCount.Size = New System.Drawing.Size(119, 13)
        Me.lblTodayCount.TabIndex = 6
        Me.lblTodayCount.Text = "Visitors today: 0"
        Me.btnRefresh.Location = New System.Drawing.Point(941, 630)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 34)
        Me.btnRefresh.TabIndex = 7
        Me.btnRefresh.Text = "&Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        Me.btnClose.Location = New System.Drawing.Point(1061, 630)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(115, 34)
        Me.btnClose.TabIndex = 8
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 676)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.lblTodayCount)
        Me.Controls.Add(Me.dgvTodayVisitors)
        Me.Controls.Add(Me.lblTodayTitle)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.grpVisitorInfo)
        Me.Controls.Add(Me.grpScan)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmVisitorLog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Visitor Log"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.grpScan.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpScan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpScan.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpScan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblInstruction.BackColor = System.Drawing.Color.Transparent
        Me.lblInstruction.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblScanQR.BackColor = System.Drawing.Color.Transparent
        Me.lblScanQR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanQR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblScannerStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.lblScannerStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblScannerStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPurpose.BackColor = System.Drawing.Color.Transparent
        Me.lblPurpose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboPurpose.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboPurpose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboPurpose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboPurpose.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnProcessScan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProcessScan.FlatAppearance.BorderSize = 2
        Me.btnProcessScan.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnProcessScan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnProcessScan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnProcessScan.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnProcessScan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnProcessScan.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnProcessScan.UseVisualStyleBackColor = False
        Me.btnProcessScan.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClearScan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearScan.FlatAppearance.BorderSize = 1
        Me.btnClearScan.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClearScan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClearScan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClearScan.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClearScan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClearScan.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClearScan.UseVisualStyleBackColor = False
        Me.btnClearScan.Cursor = System.Windows.Forms.Cursors.Hand

        Me.grpVisitorInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpVisitorInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpVisitorInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpVisitorInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblVisitorName.BackColor = System.Drawing.Color.Transparent
        Me.lblVisitorName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblVisitorType.BackColor = System.Drawing.Color.Transparent
        Me.lblVisitorType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblVisitorIDNo.BackColor = System.Drawing.Color.Transparent
        Me.lblVisitorIDNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblVisitorCourseDept.BackColor = System.Drawing.Color.Transparent
        Me.lblVisitorCourseDept.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblTimeInfo.BackColor = System.Drawing.Color.Transparent
        Me.lblTimeInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblResult.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.lblResult.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblResult.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular)
        Me.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTodayTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTodayTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblTodayTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvTodayVisitors.EnableHeadersVisualStyles = False
        Me.dgvTodayVisitors.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvTodayVisitors.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvTodayVisitors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvTodayVisitors.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvTodayVisitors.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvTodayVisitors.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvTodayVisitors.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvTodayVisitors.ColumnHeadersHeight = 32
        Me.dgvTodayVisitors.RowTemplate.Height = 24
        Me.dgvTodayVisitors.RowHeadersVisible = False
        Me.dgvTodayVisitors.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvTodayVisitors.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvTodayVisitors.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvTodayVisitors.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvTodayVisitors.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvTodayVisitors.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvTodayVisitors.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvTodayVisitors.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvTodayVisitors.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvTodayVisitors.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvTodayVisitors.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvTodayVisitors.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvTodayVisitors.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvTodayVisitors.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvTodayVisitors.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvTodayVisitors.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvTodayVisitors.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvTodayVisitors.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvTodayVisitors.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblTodayCount.BackColor = System.Drawing.Color.Transparent
        Me.lblTodayCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.FlatAppearance.BorderSize = 1
        Me.btnRefresh.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnRefresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnRefresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRefresh.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnRefresh.UseVisualStyleBackColor = False
        Me.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.pnlHeader.ResumeLayout(False)
        Me.grpScan.ResumeLayout(False)
        Me.grpScan.PerformLayout()
        Me.grpVisitorInfo.ResumeLayout(False)
        CType(Me.dgvTodayVisitors, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents grpScan As System.Windows.Forms.GroupBox
    Friend WithEvents lblInstruction As System.Windows.Forms.Label
    Friend WithEvents lblScanQR As System.Windows.Forms.Label
    Friend WithEvents txtScanQR As System.Windows.Forms.TextBox
    Friend WithEvents lblScannerStatus As System.Windows.Forms.Label
    Friend WithEvents lblPurpose As System.Windows.Forms.Label
    Friend WithEvents cboPurpose As System.Windows.Forms.ComboBox
    Friend WithEvents btnProcessScan As System.Windows.Forms.Button
    Friend WithEvents btnClearScan As System.Windows.Forms.Button
    Friend WithEvents grpVisitorInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblVisitorName As System.Windows.Forms.Label
    Friend WithEvents lblVisitorType As System.Windows.Forms.Label
    Friend WithEvents lblVisitorIDNo As System.Windows.Forms.Label
    Friend WithEvents lblVisitorCourseDept As System.Windows.Forms.Label
    Friend WithEvents lblTimeInfo As System.Windows.Forms.Label
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents lblTodayTitle As System.Windows.Forms.Label
    Friend WithEvents dgvTodayVisitors As System.Windows.Forms.DataGridView
    Friend WithEvents lblTodayCount As System.Windows.Forms.Label
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
