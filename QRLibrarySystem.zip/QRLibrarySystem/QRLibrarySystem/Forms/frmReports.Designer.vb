<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReports
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.grpFilter = New System.Windows.Forms.GroupBox()
        Me.lblReportType = New System.Windows.Forms.Label()
        Me.cboReportType = New System.Windows.Forms.ComboBox()
        Me.lblDateFrom = New System.Windows.Forms.Label()
        Me.dtpFrom = New System.Windows.Forms.DateTimePicker()
        Me.lblDateTo = New System.Windows.Forms.Label()
        Me.dtpTo = New System.Windows.Forms.DateTimePicker()
        Me.btnGenerate = New System.Windows.Forms.Button()
        Me.lblNote = New System.Windows.Forms.Label()
        Me.dgvReport = New System.Windows.Forms.DataGridView()
        Me.lblTotalRecords = New System.Windows.Forms.Label()
        Me.lblSummary = New System.Windows.Forms.Label()
        Me.btnExportCSV = New System.Windows.Forms.Button()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.prnReport = New System.Drawing.Printing.PrintDocument()
        Me.ppdReport = New System.Windows.Forms.PrintPreviewDialog()
        Me.pnlHeader.SuspendLayout()
        Me.grpFilter.SuspendLayout()
        CType(Me.dgvReport, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1024, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(800, 46)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "Reports"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpFilter.Controls.Add(Me.lblReportType)
        Me.grpFilter.Controls.Add(Me.cboReportType)
        Me.grpFilter.Controls.Add(Me.lblDateFrom)
        Me.grpFilter.Controls.Add(Me.dtpFrom)
        Me.grpFilter.Controls.Add(Me.lblDateTo)
        Me.grpFilter.Controls.Add(Me.dtpTo)
        Me.grpFilter.Controls.Add(Me.btnGenerate)
        Me.grpFilter.Controls.Add(Me.lblNote)
        Me.grpFilter.Location = New System.Drawing.Point(12, 58)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(1000, 110)
        Me.grpFilter.TabIndex = 1
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Filter"
        Me.lblReportType.AutoSize = True
        Me.lblReportType.Location = New System.Drawing.Point(18, 35)
        Me.lblReportType.Name = "lblReportType"
        Me.lblReportType.TabIndex = 0
        Me.lblReportType.Text = "Report Type :"
        Me.cboReportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboReportType.FormattingEnabled = True
        Me.cboReportType.Items.AddRange(New Object() {"Visitor Report", "Circulation Report", "Book Inventory Report", "Overdue Report"})
        Me.cboReportType.Location = New System.Drawing.Point(105, 32)
        Me.cboReportType.Name = "cboReportType"
        Me.cboReportType.Size = New System.Drawing.Size(230, 21)
        Me.cboReportType.TabIndex = 1
        Me.lblDateFrom.AutoSize = True
        Me.lblDateFrom.Location = New System.Drawing.Point(360, 35)
        Me.lblDateFrom.Name = "lblDateFrom"
        Me.lblDateFrom.TabIndex = 2
        Me.lblDateFrom.Text = "Date From :"
        Me.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpFrom.Location = New System.Drawing.Point(435, 32)
        Me.dtpFrom.Name = "dtpFrom"
        Me.dtpFrom.Size = New System.Drawing.Size(140, 20)
        Me.dtpFrom.TabIndex = 3
        Me.lblDateTo.AutoSize = True
        Me.lblDateTo.Location = New System.Drawing.Point(595, 35)
        Me.lblDateTo.Name = "lblDateTo"
        Me.lblDateTo.TabIndex = 4
        Me.lblDateTo.Text = "Date To :"
        Me.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpTo.Location = New System.Drawing.Point(655, 32)
        Me.dtpTo.Name = "dtpTo"
        Me.dtpTo.Size = New System.Drawing.Size(140, 20)
        Me.dtpTo.TabIndex = 5
        Me.btnGenerate.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnGenerate.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGenerate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnGenerate.Location = New System.Drawing.Point(820, 22)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(160, 40)
        Me.btnGenerate.TabIndex = 6
        Me.btnGenerate.Text = "&Generate"
        Me.btnGenerate.UseVisualStyleBackColor = False
        Me.lblNote.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblNote.Location = New System.Drawing.Point(18, 72)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(900, 20)
        Me.lblNote.TabIndex = 7
        Me.lblNote.Text = "Inventory ignores dates."
        Me.dgvReport.AllowUserToAddRows = False
        Me.dgvReport.AllowUserToDeleteRows = False
        Me.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvReport.Location = New System.Drawing.Point(12, 180)
        Me.dgvReport.MultiSelect = False
        Me.dgvReport.Name = "dgvReport"
        Me.dgvReport.ReadOnly = True
        Me.dgvReport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvReport.Size = New System.Drawing.Size(1000, 400)
        Me.dgvReport.TabIndex = 2
        Me.lblTotalRecords.AutoSize = True
        Me.lblTotalRecords.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalRecords.Location = New System.Drawing.Point(12, 592)
        Me.lblTotalRecords.Name = "lblTotalRecords"
        Me.lblTotalRecords.TabIndex = 3
        Me.lblTotalRecords.Text = "Records: 0"
        Me.lblSummary.Location = New System.Drawing.Point(12, 618)
        Me.lblSummary.Name = "lblSummary"
        Me.lblSummary.Size = New System.Drawing.Size(700, 40)
        Me.lblSummary.TabIndex = 4
        Me.lblSummary.Text = "Summary : -"
        Me.btnExportCSV.Location = New System.Drawing.Point(730, 600)
        Me.btnExportCSV.Name = "btnExportCSV"
        Me.btnExportCSV.Size = New System.Drawing.Size(130, 38)
        Me.btnExportCSV.TabIndex = 5
        Me.btnExportCSV.Text = "&CSV"
        Me.btnExportCSV.UseVisualStyleBackColor = True
        Me.btnPrint.Location = New System.Drawing.Point(870, 600)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(130, 38)
        Me.btnPrint.TabIndex = 6
        Me.btnPrint.Text = "&Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        Me.btnClose.Location = New System.Drawing.Point(870, 645)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(130, 34)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.ppdReport.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.ppdReport.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.ppdReport.ClientSize = New System.Drawing.Size(400, 300)
        Me.ppdReport.Enabled = True
        Me.ppdReport.Name = "ppdReport"
        Me.ppdReport.Visible = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1024, 691)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.btnExportCSV)
        Me.Controls.Add(Me.lblSummary)
        Me.Controls.Add(Me.lblTotalRecords)
        Me.Controls.Add(Me.dgvReport)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmReports"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Reports"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.grpFilter.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpFilter.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpFilter.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblReportType.BackColor = System.Drawing.Color.Transparent
        Me.lblReportType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboReportType.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboReportType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboReportType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboReportType.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDateFrom.BackColor = System.Drawing.Color.Transparent
        Me.lblDateFrom.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpFrom.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.dtpFrom.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpFrom.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dtpFrom.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpFrom.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dtpFrom.CalendarTitleBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpFrom.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dtpFrom.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblDateTo.BackColor = System.Drawing.Color.Transparent
        Me.lblDateTo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpTo.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.dtpTo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpTo.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dtpTo.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpTo.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dtpTo.CalendarTitleBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpTo.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dtpTo.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGenerate.FlatAppearance.BorderSize = 2
        Me.btnGenerate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnGenerate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnGenerate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnGenerate.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnGenerate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnGenerate.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnGenerate.UseVisualStyleBackColor = False
        Me.btnGenerate.Cursor = System.Windows.Forms.Cursors.Hand

        Me.lblNote.BackColor = System.Drawing.Color.Transparent
        Me.lblNote.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.dgvReport.EnableHeadersVisualStyles = False
        Me.dgvReport.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvReport.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvReport.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvReport.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvReport.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvReport.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvReport.ColumnHeadersHeight = 32
        Me.dgvReport.RowTemplate.Height = 24
        Me.dgvReport.RowHeadersVisible = False
        Me.dgvReport.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvReport.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvReport.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvReport.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvReport.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvReport.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvReport.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvReport.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvReport.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvReport.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvReport.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvReport.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvReport.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvReport.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvReport.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvReport.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvReport.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvReport.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvReport.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblTotalRecords.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalRecords.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblSummary.BackColor = System.Drawing.Color.Transparent
        Me.lblSummary.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnExportCSV.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExportCSV.FlatAppearance.BorderSize = 1
        Me.btnExportCSV.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnExportCSV.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnExportCSV.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnExportCSV.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnExportCSV.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnExportCSV.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnExportCSV.UseVisualStyleBackColor = False
        Me.btnExportCSV.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPrint.FlatAppearance.BorderSize = 1
        Me.btnPrint.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnPrint.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnPrint.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPrint.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnPrint.UseVisualStyleBackColor = False
        Me.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.ppdReport.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.ppdReport.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.pnlHeader.ResumeLayout(False)
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        CType(Me.dgvReport, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
    Friend WithEvents lblReportType As System.Windows.Forms.Label
    Friend WithEvents cboReportType As System.Windows.Forms.ComboBox
    Friend WithEvents lblDateFrom As System.Windows.Forms.Label
    Friend WithEvents dtpFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDateTo As System.Windows.Forms.Label
    Friend WithEvents dtpTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnGenerate As System.Windows.Forms.Button
    Friend WithEvents lblNote As System.Windows.Forms.Label
    Friend WithEvents dgvReport As System.Windows.Forms.DataGridView
    Friend WithEvents lblTotalRecords As System.Windows.Forms.Label
    Friend WithEvents lblSummary As System.Windows.Forms.Label
    Friend WithEvents btnExportCSV As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents prnReport As System.Drawing.Printing.PrintDocument
    Friend WithEvents ppdReport As System.Windows.Forms.PrintPreviewDialog
End Class
