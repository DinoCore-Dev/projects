Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO
Public Class frmCategories

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Try
            Dim value As Object = GetScalar(sql, pars)
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
            Return Convert.ToString(row(col))
        Catch
            Return ""
        End Try
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
            Return Convert.ToInt32(row(col))
        Catch
            Return 0
        End Try
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
            Return Convert.ToDecimal(row(col))
        Catch
            Return 0D
        End Try
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
            Dim value As Date = Convert.ToDateTime(row(col))
            If value < New Date(1900, 1, 1) OrElse value > New Date(9998, 12, 31) Then Return Date.Today
            Return value
        Catch
            Return Date.Today
        End Try
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        Try
            If gridRow Is Nothing Then Return ""
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return ""
            Return Convert.ToString(value)
        Catch
            Return ""
        End Try
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        Try
            If gridRow Is Nothing Then Return 0
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        Try
            If gridRow Is Nothing Then Return Date.Today
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
            Dim result As Date = Convert.ToDateTime(value)
            If result < New Date(1900, 1, 1) OrElse result > New Date(9998, 12, 31) Then Return Date.Today
            Return result
        Catch
            Return Date.Today
        End Try
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        Dim message As String = ex.Message
        If TypeOf ex Is SqlCeException OrElse TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then message = FriendlyDatabaseError(ex, "complete the operation")
        MessageBox.Show(title & ": " & message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region

    Private Function CleanText(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Dim result As String = ""
        Dim lastWasSpace As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsWhiteSpace(ch) Then
                If result.Length > 0 AndAlso Not lastWasSpace Then result &= " "c
                lastWasSpace = True
            Else
                result &= ch
                lastWasSpace = False
            End If
        Next
        Return result.Trim()
    End Function

    Private Function HasBadControl(ByVal value As String, ByVal allowMultiline As Boolean) As Boolean
        If value Is Nothing Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsControl(ch) Then
                If allowMultiline AndAlso (ch = ControlChars.Cr OrElse ch = ControlChars.Lf OrElse ch = ControlChars.Tab) Then Continue For
                Return True
            End If
        Next
        Return False
    End Function

    Private Function FailValidation(ByVal target As Control, ByVal message As String) As Boolean
        MessageBox.Show(message, "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        If target IsNot Nothing Then
            Try
                target.Focus()
                Dim textBox As TextBox = TryCast(target, TextBox)
                If textBox IsNot Nothing Then textBox.SelectAll()
                Dim comboBox As ComboBox = TryCast(target, ComboBox)
                If comboBox IsNot Nothing Then comboBox.SelectAll()
            Catch
            End Try
        End If
        Return False
    End Function

    Private Function CheckTextBox(ByVal target As TextBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Function CheckComboText(ByVal target As ComboBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Sub NormalizeComboText(ByVal target As ComboBox)
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return
            End If
        Next
        target.Text = value
    End Sub

    Private Function RequireListValue(ByVal target As ComboBox, ByVal label As String) As Boolean
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return True
            End If
        Next
        Return FailValidation(target, "Please select a valid " & label & " from the list.")
    End Function

    Private Function IdentifierOK(ByVal value As String, ByVal minLength As Integer) As Boolean
        If value Is Nothing OrElse value.Length < minLength Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(0)) Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(value.Length - 1)) Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c AndAlso ch <> "_"c AndAlso ch <> "."c AndAlso ch <> "/"c Then Return False
        Next
        Return True
    End Function

    Private Function PersonNameOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 Then Return False
        Dim hasLetter As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsLetter(ch) Then
                hasLetter = True
            ElseIf ch = " "c OrElse ch = "'"c OrElse ch = "-"c OrElse ch = "."c Then
            Else
                Return False
            End If
        Next
        Return hasLetter
    End Function

    Private Function EmailOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length < 5 OrElse value.Length > 100 Then Return False
        If HasBadControl(value, False) OrElse value.IndexOf(" "c) >= 0 Then Return False
        Dim at As Integer = value.IndexOf("@"c)
        If at < 1 OrElse at <> value.LastIndexOf("@"c) OrElse at >= value.Length - 3 Then Return False
        Dim localPart As String = value.Substring(0, at)
        Dim domain As String = value.Substring(at + 1)
        If localPart.StartsWith(".") OrElse localPart.EndsWith(".") OrElse localPart.Contains("..") Then Return False
        If domain.StartsWith(".") OrElse domain.EndsWith(".") OrElse domain.StartsWith("-") OrElse domain.EndsWith("-") OrElse domain.Contains("..") Then Return False
        Dim labels() As String = domain.Split("."c)
        If labels.Length < 2 Then Return False
        Dim i As Integer
        For i = 0 To localPart.Length - 1
            Dim ch As Char = localPart.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "."c AndAlso ch <> "_"c AndAlso ch <> "%"c AndAlso ch <> "+"c AndAlso ch <> "-"c Then Return False
        Next
        For i = 0 To labels.Length - 1
            If labels(i).Length = 0 OrElse labels(i).StartsWith("-") OrElse labels(i).EndsWith("-") Then Return False
            Dim j As Integer
            For j = 0 To labels(i).Length - 1
                Dim ch As Char = labels(i).Chars(j)
                If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c Then Return False
            Next
        Next
        If labels(labels.Length - 1).Length < 2 Then Return False
        Return True
    End Function

    Private Function PhoneOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 OrElse value.Length > 20 Then Return False
        Dim digits As Integer = 0
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsDigit(ch) Then
                digits += 1
            ElseIf ch = " "c OrElse ch = "-"c OrElse ch = "("c OrElse ch = ")"c OrElse (ch = "+"c AndAlso i = 0) Then
            Else
                Return False
            End If
        Next
        Return digits >= 7 AndAlso digits <= 15
    End Function

    Private Function TrySelectedId(ByVal target As TextBox, ByRef recordId As Integer) As Boolean
        recordId = 0
        If Not Integer.TryParse(CleanText(target.Text), recordId) Then Return False
        Return recordId > 0
    End Function

    Private Function EscapeLike(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Return value.Trim().Replace("[", "[[]").Replace("%", "[%]").Replace("_", "[_]")
    End Function

    Private Function SafePickerDate(ByVal value As Date, ByVal minimumYear As Integer) As Date
        If value < New Date(minimumYear, 1, 1) Then Return New Date(minimumYear, 1, 1)
        If value.Date > Date.Today Then Return Date.Today
        Return value.Date
    End Function

    Private Function FriendlyDatabaseError(ByVal ex As Exception, ByVal action As String) As String
        Dim message As String = ""
        If ex IsNot Nothing AndAlso ex.Message IsNot Nothing Then message = ex.Message
        Dim lower As String = message.ToLowerInvariant()
        If TypeOf ex Is SqlCeException Then
            If lower.Contains("unique") OrElse lower.Contains("duplicate") Then Return "Could not " & action & " because another record already uses the same unique value."
            If lower.Contains("foreign key") OrElse lower.Contains("constraint") OrElse lower.Contains("related") Then Return "Could not " & action & " because the record is connected to other records. Check related records and try again."
            If lower.Contains("locked") OrElse lower.Contains("being used") OrElse lower.Contains("in use") Then Return "Could not " & action & " because the database is busy or locked. Wait a moment and try again."
            If lower.Contains("could not find") OrElse lower.Contains("does not exist") OrElse lower.Contains("file") Then Return "Could not " & action & " because the database file could not be opened. Close the system and run it again."
            Return "Could not " & action & ". Database error: " & message
        End If
        If TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then Return "Could not " & action & " because a required file could not be accessed. Close other programs using the system and try again."
        Return "Could not " & action & ": " & message
    End Function

    Private Function ConfirmAction(ByVal message As String, ByVal title As String) As Boolean
        Return MessageBox.Show(message, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes
    End Function


    Private _busy As Boolean = False
    Private _savedSignature As String = ""

    Private Sub ConfigureInputLimits()
        txtCategoryID.MaxLength = 10
        txtCategoryCode.MaxLength = 20
        txtCategoryName.MaxLength = 100
        txtDescription.MaxLength = 32767
        txtShelfLocation.MaxLength = 50
        txtSearch.MaxLength = 100
    End Sub

    Private Function CleanDescription(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Dim normalized As String = value.Replace(vbCrLf, vbLf).Replace(vbCr, vbLf)
        Dim sb As New System.Text.StringBuilder()
        Dim i As Integer
        For i = 0 To normalized.Length - 1
            Dim ch As Char = normalized.Chars(i)
            If ch = vbLf Then
                sb.Append(Environment.NewLine)
            ElseIf ch = vbTab OrElse Not Char.IsControl(ch) Then
                sb.Append(ch)
            End If
        Next
        Return sb.ToString().Trim()
    End Function

    Private Function CurrentSignature() As String
        Return String.Join("|", New String() {CleanText(txtCategoryID.Text), CleanText(txtCategoryCode.Text), CleanText(txtCategoryName.Text), CleanText(txtDescription.Text), CleanText(txtShelfLocation.Text)})
    End Function

    Private Sub RememberSavedState()
        _savedSignature = CurrentSignature()
    End Sub

    Private Function ConfirmDiscardChanges() As Boolean
        If _savedSignature = "" OrElse _savedSignature = CurrentSignature() Then Return True
        Return ConfirmAction("Discard unsaved category changes?", "Unsaved Changes")
    End Function

    Private Sub frmCategories_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If e.CloseReason = CloseReason.UserClosing AndAlso Not ConfirmDiscardChanges() Then e.Cancel = True
    End Sub

    Private Sub NormalizeInput()
        txtCategoryCode.Text = CleanText(txtCategoryCode.Text).ToUpperInvariant()
        txtCategoryName.Text = CleanText(txtCategoryName.Text)
        txtDescription.Text = CleanDescription(txtDescription.Text)
        txtShelfLocation.Text = CleanText(txtShelfLocation.Text)
    End Sub

    Private Sub PerformSearch()
        txtSearch.Text = CleanText(txtSearch.Text)
        LoadCategories(txtSearch.Text)
    End Sub

    Private Sub frmCategories_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ConfigureInputLimits()
            ClearFields()
            LoadCategories("")
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatCategoriesGrid()
        Try
            HideAllGridColumns(dgvCategories)
            Dim i As Integer = 0
            ShowGridColumn(dgvCategories, "category_code", "Code", 90, i)
            ShowGridColumn(dgvCategories, "category_name", "Category Name", 180, i)
            ShowGridColumn(dgvCategories, "description", "Description", 230, i)
            ShowGridColumn(dgvCategories, "shelf_location", "Shelf Location", 110, i)
        Catch
        End Try
    End Sub

    Private Sub LoadCategories(ByVal keyword As String)
        Try
            Dim key As String = CleanText(keyword)
            If key.Length > 100 Then key = key.Substring(0, 100)
            Dim sql As String = "SELECT * FROM CATEGORIES"
            Dim dt As DataTable
            If key = "" Then
                dt = GetTable(sql & " ORDER BY category_name")
            Else
                Dim likeValue As String = "%" & EscapeLike(key) & "%"
                sql &= " WHERE category_code LIKE @q1 OR category_name LIKE @q2 OR shelf_location LIKE @q3 ORDER BY category_name"
                dt = GetTable(sql, P("@q1", likeValue), P("@q2", likeValue), P("@q3", likeValue))
            End If
            dgvCategories.DataSource = dt
            FormatCategoriesGrid()
            lblCount.Text = "Records: " & dt.Rows.Count
            If dgvCategories.Columns.Contains("categoryid") Then dgvCategories.Columns("categoryid").HeaderText = "ID"
        Catch ex As Exception
            dgvCategories.DataSource = Nothing
            lblCount.Text = "Records: 0"
            MessageBox.Show(FriendlyDatabaseError(ex, "load categories"), "Categories", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub ClearFields()
        txtCategoryID.Clear()
        txtCategoryCode.Clear()
        txtCategoryName.Clear()
        txtDescription.Clear()
        txtShelfLocation.Clear()
        RememberSavedState()
        txtCategoryCode.Focus()
    End Sub
    Private Function IsValid() As Boolean
        If Not CheckTextBox(txtCategoryCode, "Category Code", 20, True) Then Return False
        If Not IdentifierOK(txtCategoryCode.Text, 2) Then Return FailValidation(txtCategoryCode, "Category Code must be at least 2 characters and use only letters, numbers, hyphen, underscore, dot, or slash. Do not include spaces.")
        If Not CheckTextBox(txtCategoryName, "Category Name", 100, True) Then Return False
        If CleanText(txtCategoryName.Text).Length < 2 Then Return FailValidation(txtCategoryName, "Category Name must contain at least 2 characters.")
        If txtDescription.Text.Length > 32767 Then Return FailValidation(txtDescription, "Description must not exceed 32767 characters.")
        If HasBadControl(txtDescription.Text, True) Then Return FailValidation(txtDescription, "Description contains unsupported characters. Remove pasted symbols or control characters and try again.")
        If Not CheckTextBox(txtShelfLocation, "Shelf Location", 50, False) Then Return False
        Return True
    End Function
    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        If Not ConfirmDiscardChanges() Then Exit Sub
        ClearFields()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        If Not ConfirmDiscardChanges() Then Exit Sub
        ClearFields()
        txtSearch.Clear()
        LoadCategories("")
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If _busy Then Exit Sub
        NormalizeInput()
        If CleanText(txtCategoryID.Text) <> "" Then
            MessageBox.Show("This record already exists. Use UPDATE, or click NEW for a new category.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        If Not IsValid() Then Exit Sub
        _busy = True
        Try
            Dim code As String = CleanText(txtCategoryCode.Text).ToUpperInvariant()
            If GetCount("SELECT COUNT(*) FROM CATEGORIES WHERE UPPER(category_code) = @c", P("@c", code)) > 0 Then
                FailValidation(txtCategoryCode, "Category Code already exists.")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM CATEGORIES WHERE UPPER(category_name) = @n", P("@n", txtCategoryName.Text.ToUpperInvariant())) > 0 Then
                FailValidation(txtCategoryName, "Category Name already exists. Use the existing category or enter a different name.")
                Exit Sub
            End If
            Dim affected As Integer = RunNonQuery("INSERT INTO CATEGORIES (category_code, category_name, description, shelf_location, created_at) VALUES (@code,@name,@desc,@shelf,@created)", P("@code", code), P("@name", txtCategoryName.Text.Trim()), P("@desc", txtDescription.Text.Trim()), P("@shelf", txtShelfLocation.Text.Trim()), P("@created", DateTime.Now))
            If affected <> 1 Then Throw New Exception("The category record was not inserted.")
            Dim newId As Integer = 0
            Dim newIdValue As Object = GetScalar("SELECT categoryid FROM CATEGORIES WHERE UPPER(category_code) = @c", P("@c", code))
            If newIdValue IsNot Nothing AndAlso Not IsDBNull(newIdValue) Then Integer.TryParse(Convert.ToString(newIdValue), newId)
            If newId > 0 Then txtCategoryID.Text = CStr(newId)
            WriteUserLog("Insert", "Book & Category Management", "CATEGORIES", newId, "Added category " & code)
            MessageBox.Show("Category saved successfully.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSearch.Clear()
            LoadCategories("")
            RememberSavedState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmCategories.Save", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "save the category"), "Save", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If _busy Then Exit Sub
        Dim categoryId As Integer = 0
        If Not TrySelectedId(txtCategoryID, categoryId) Then
            MessageBox.Show("Select a valid category from the list first.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        NormalizeInput()
        If Not IsValid() Then Exit Sub
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT category_code, category_name FROM CATEGORIES WHERE categoryid = @id", P("@id", categoryId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This category no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadCategories("")
                Exit Sub
            End If
            Dim code As String = CleanText(txtCategoryCode.Text).ToUpperInvariant()
            If GetCount("SELECT COUNT(*) FROM CATEGORIES WHERE UPPER(category_code) = @c AND categoryid <> @id", P("@c", code), P("@id", categoryId)) > 0 Then
                FailValidation(txtCategoryCode, "Category Code is already used by another category.")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM CATEGORIES WHERE UPPER(category_name) = @n AND categoryid <> @id", P("@n", txtCategoryName.Text.ToUpperInvariant()), P("@id", categoryId)) > 0 Then
                FailValidation(txtCategoryName, "Category Name is already used by another category.")
                Exit Sub
            End If
            Dim bookCount As Integer = GetCount("SELECT COUNT(*) FROM BOOKS WHERE categoryid = @id", P("@id", categoryId))
            Dim codeChanged As Boolean = Not String.Equals(DbStr(existing.Rows(0), "category_code"), code, StringComparison.OrdinalIgnoreCase)
            Dim nameChanged As Boolean = Not String.Equals(DbStr(existing.Rows(0), "category_name"), txtCategoryName.Text.Trim(), StringComparison.OrdinalIgnoreCase)
            If bookCount > 0 AndAlso (codeChanged OrElse nameChanged) Then
                If Not ConfirmAction("This category is used by " & bookCount & " book record(s). Changing its code or name will change how those books are grouped and displayed. Continue?", "Category In Use") Then Exit Sub
            End If
            Dim affected As Integer = RunNonQuery("UPDATE CATEGORIES SET category_code=@code, category_name=@name, description=@desc, shelf_location=@shelf WHERE categoryid=@id", P("@code", code), P("@name", txtCategoryName.Text.Trim()), P("@desc", txtDescription.Text.Trim()), P("@shelf", txtShelfLocation.Text.Trim()), P("@id", categoryId))
            If affected <> 1 Then
                MessageBox.Show("This category no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadCategories("")
                Exit Sub
            End If
            WriteUserLog("Update", "Book & Category Management", "CATEGORIES", categoryId, "Updated category " & code)
            MessageBox.Show("Category updated successfully.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSearch.Clear()
            LoadCategories("")
            RememberSavedState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmCategories.Update", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "update the category"), "Update", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If _busy Then Exit Sub
        Dim categoryId As Integer = 0
        If Not TrySelectedId(txtCategoryID, categoryId) Then
            MessageBox.Show("Select a valid category from the list first.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT category_code, category_name FROM CATEGORIES WHERE categoryid = @id", P("@id", categoryId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This category no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadCategories("")
                Exit Sub
            End If
            Dim bookCount As Integer = GetCount("SELECT COUNT(*) FROM BOOKS WHERE categoryid = @id", P("@id", categoryId))
            If bookCount > 0 Then
                MessageBox.Show("This category cannot be deleted because " & bookCount & " book record(s) use it. Move those books to another category first.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim totalCategories As Integer = GetCount("SELECT COUNT(*) FROM CATEGORIES")
            If totalCategories <= 1 Then
                MessageBox.Show("At least one category must remain so books can be encoded. Add another category before deleting this last category.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim displayName As String = CleanText(DbStr(existing.Rows(0), "category_code") & " - " & DbStr(existing.Rows(0), "category_name"))
            If Not ConfirmAction("Delete category " & displayName & "? This cannot be undone.", "Delete") Then Exit Sub
            Dim affected As Integer = RunNonQuery("DELETE FROM CATEGORIES WHERE categoryid=@id", P("@id", categoryId))
            If affected <> 1 Then
                MessageBox.Show("This category no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearFields()
                LoadCategories("")
                Exit Sub
            End If
            WriteUserLog("Delete", "Book & Category Management", "CATEGORIES", categoryId, "Deleted category " & displayName)
            MessageBox.Show("Category deleted successfully.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearFields()
            txtSearch.Clear()
            LoadCategories("")
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmCategories.Delete", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "delete the category"), "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        PerformSearch()
    End Sub
    Private Sub txtSearch_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            PerformSearch()
        End If
    End Sub
    Private Sub dgvCategories_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvCategories.CellClick
        Try
            If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then Exit Sub
            Dim r As DataGridViewRow = dgvCategories.Rows(e.RowIndex)
            If r Is Nothing OrElse r.IsNewRow Then Exit Sub
            If CellInt(r, "categoryid") <= 0 Then
                MessageBox.Show("This row does not contain a valid category record.", "Categories", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If Not ConfirmDiscardChanges() Then Exit Sub
            txtCategoryID.Text = CStr(CellInt(r, "categoryid"))
            txtCategoryCode.Text = CellStr(r, "category_code")
            txtCategoryName.Text = CellStr(r, "category_name")
            txtDescription.Text = CellStr(r, "description")
            If txtDescription.Text.Length > 32767 Then txtDescription.Text = txtDescription.Text.Substring(0, 32767)
            txtShelfLocation.Text = CellStr(r, "shelf_location")
            RememberSavedState()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
