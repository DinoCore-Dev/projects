Imports System.Data
Imports System.IO
Imports System.Data.SqlServerCe

Public Class frmBorrowReturn

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim value As Object = GetScalar(sql, pars)
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
        Return CStr(row(col))
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
        Return CInt(row(col))
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
        Return CDec(row(col))
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
        Return CDate(row(col))
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        If gridRow Is Nothing Then Return ""
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return ""
        Return CStr(value)
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        If gridRow Is Nothing Then Return 0
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        If gridRow Is Nothing Then Return Date.Today
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
        Return CDate(value)
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        MessageBox.Show(title & ": " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region


    Private Const STUDENT_LIMIT As Integer = 3
    Private Const FACULTY_LIMIT As Integer = 5
    Private Const STUDENT_DAYS As Integer = 3
    Private Const FACULTY_DAYS As Integer = 7
    Private Const FINE_PER_DAY As Decimal = 5D

    Private _borrowerType As String = ""
    Private _studentId As Integer = 0
    Private _facultyId As Integer = 0
    Private _borrowerLimit As Integer = 3
    Private _borrowerName As String = ""

    Private _bookId As Integer = 0
    Private _bookTitle As String = ""

    Private _returnBorrowId As Integer = 0
    Private _returnBookId As Integer = 0
    Private _daysOverdue As Integer = 0
    Private _fineAmount As Decimal = 0D

    Private Function ScannedQRType(ByVal code As String) As String
        Dim u As String = code.Trim().ToUpper()
        If u.StartsWith("STU-") Then Return "Student"
        If u.StartsWith("FAC-") Then Return "Faculty"
        If u.StartsWith("BOOK-") Then Return "Book"
        Return "Unknown"
    End Function

    Private Sub frmBorrowReturn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
        dtpBorrowDate.Value = Date.Today
        UpdateDueDate()
        cboTransStatus.Text = "All"
        LoadTransactions()
        txtScanBorrower.Focus()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub frmBorrowReturn_Shown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Shown
        Try
            If tabMain.SelectedTab Is tabReturn Then
                txtScanReturnBook.Focus()
            Else
                txtScanBorrower.Focus()
            End If
        Catch ex As Exception
            ShowError("Scanner focus", ex)
        End Try
    End Sub

    Private Sub tabMain_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tabMain.SelectedIndexChanged
        Try
        If tabMain.SelectedTab Is tabBorrow Then
            txtScanBorrower.Focus()
        ElseIf tabMain.SelectedTab Is tabReturn Then
            txtScanReturnBook.Focus()
        Else
            LoadTransactions()
        End If
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub UpdateDueDate()
        dtpDueDate.Value = dtpBorrowDate.Value.Date.AddDays(CInt(nudLoanDays.Value))
    End Sub

    Private Sub dtpBorrowDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpBorrowDate.ValueChanged
        UpdateDueDate()
    End Sub

    Private Sub nudLoanDays_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nudLoanDays.ValueChanged
        UpdateDueDate()
    End Sub

    Private Sub txtScanBorrower_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtScanBorrower.KeyDown
        If e.KeyCode = Keys.Enter OrElse e.KeyCode = Keys.Tab Then
            e.SuppressKeyPress = True
            FindBorrower()
        End If
    End Sub

    Private Sub FindBorrower()
        Dim code As String = txtScanBorrower.Text.Trim()
        If code = "" Then Exit Sub
        _borrowerType = ""
        _studentId = 0
        _facultyId = 0
        _borrowerName = ""
        lblBorrowerName.Text = "Name : -"
        lblBorrowerType.Text = "Type : -"
        lblBorrowerIDNo.Text = "ID No. : -"
        lblBorrowerDetail.Text = "Course/Dept : -"
        lblBorrowerBorrowedCount.Text = "Borrowed : -"

        Dim scannedType As String = ScannedQRType(code)
        If scannedType = "Book" Then
            BorrowerNotAllowed("WRONG QR: BOOK QR. Scan the Student/Faculty ID first.")
            Exit Sub
        End If

        Try
            Dim dtS As DataTable = Nothing
            If scannedType <> "Faculty" Then
                dtS = GetTable("SELECT * FROM STUDENTS WHERE qr_code = @q1 OR student_number = @q2", _
                               P("@q1", code), P("@q2", code))
            End If
            If dtS IsNot Nothing AndAlso dtS.Rows.Count > 0 Then
                Dim r As DataRow = dtS.Rows(0)
                If DbStr(r, "status") <> "Active" Then
                    BorrowerNotAllowed("Student record is INACTIVE - cannot borrow.")
                    Exit Sub
                End If
                _borrowerType = "Student"
                _studentId = DbInt(r, "studentid")
                _borrowerLimit = STUDENT_LIMIT
                _borrowerName = (DbStr(r, "last_name") & ", " & DbStr(r, "first_name") & " " & DbStr(r, "middle_name")).Trim()
                lblBorrowerName.Text = "Name : " & _borrowerName
                lblBorrowerType.Text = "Type : Student"
                lblBorrowerIDNo.Text = "ID No. : " & DbStr(r, "student_number")
                lblBorrowerDetail.Text = "Course/Dept : " & DbStr(r, "course") & " - " & DbStr(r, "year_level") & " - " & DbStr(r, "section")
                nudLoanDays.Value = STUDENT_DAYS
            ElseIf scannedType <> "Student" Then
                Dim dtF As DataTable = GetTable("SELECT * FROM FACULTY_STAFF WHERE qr_code = @q1 OR employee_number = @q2", _
                                                P("@q1", code), P("@q2", code))
                If dtF.Rows.Count > 0 Then
                    Dim r As DataRow = dtF.Rows(0)
                    If DbStr(r, "status") <> "Active" Then
                        BorrowerNotAllowed("Faculty/Staff record is INACTIVE - cannot borrow.")
                        Exit Sub
                    End If
                    _borrowerType = "Faculty/Staff"
                    _facultyId = DbInt(r, "facultystaffid")
                    _borrowerLimit = FACULTY_LIMIT
                    _borrowerName = (DbStr(r, "last_name") & ", " & DbStr(r, "first_name") & " " & DbStr(r, "middle_name")).Trim()
                    lblBorrowerName.Text = "Name : " & _borrowerName
                    lblBorrowerType.Text = "Type : Faculty/Staff"
                    lblBorrowerIDNo.Text = "ID No. : " & DbStr(r, "employee_number")
                    lblBorrowerDetail.Text = "Course/Dept : " & DbStr(r, "department") & " - " & DbStr(r, "position")
                    nudLoanDays.Value = FACULTY_DAYS
                End If
            End If

            If _borrowerType = "" Then
                BorrowerNotAllowed("BORROWER QR NOT FOUND: " & code)
                Exit Sub
            End If

            Dim borrowed As Integer = CurrentBorrowedCount()
            lblBorrowerBorrowedCount.Text = "Borrowed : " & borrowed & " of " & _borrowerLimit
            If borrowed >= _borrowerLimit Then
                BorrowerNotAllowed("Borrower already reached the limit of " & _borrowerLimit & " book(s).")
                Exit Sub
            End If

            lblBorrowerStatus.ForeColor = Color.FromArgb(20, 83, 45)
            lblBorrowerStatus.Text = "Borrower OK. Scan the book."
            UpdateDueDate()
            System.Media.SystemSounds.Beep.Play()
            txtScanBook.Focus()

        Catch ex As Exception
            WriteSystemLog("Borrowing", "Error", "frmBorrowReturn.FindBorrower", ex.Message)
            MessageBox.Show("Error finding borrower: " & ex.Message, "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BorrowerNotAllowed(ByVal msg As String)
        System.Media.SystemSounds.Exclamation.Play()
        lblBorrowerStatus.ForeColor = Color.FromArgb(153, 27, 27)
        lblBorrowerStatus.Text = msg
        _borrowerType = ""
        _studentId = 0
        _facultyId = 0
        txtScanBorrower.SelectAll()
        txtScanBorrower.Focus()
    End Sub

    Private Function CurrentBorrowedCount() As Integer
        If _borrowerType = "Student" Then
            Return GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE studentid = @id AND return_date IS NULL AND (status = 'Borrowed' OR status = 'Overdue')", _
                            P("@id", _studentId))
        ElseIf _borrowerType = "Faculty/Staff" Then
            Return GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE facultystaffid = @id AND return_date IS NULL AND (status = 'Borrowed' OR status = 'Overdue')", _
                            P("@id", _facultyId))
        End If
        Return 0
    End Function

    Private Sub txtScanBook_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtScanBook.KeyDown
        If e.KeyCode = Keys.Enter OrElse e.KeyCode = Keys.Tab Then
            e.SuppressKeyPress = True
            FindBook()
        End If
    End Sub

    Private Sub FindBook()
        Dim code As String = txtScanBook.Text.Trim()
        If code = "" Then Exit Sub
        _bookId = 0
        _bookTitle = ""
        lblBookTitle.Text = "Title : -"
        lblBookAccession.Text = "Accession : -"
        lblBookAuthor.Text = "Author : -"
        lblBookAvailable.Text = "Available : -"

        Dim scannedType As String = ScannedQRType(code)
        If scannedType = "Student" OrElse scannedType = "Faculty" Then
            BookNotAllowed("WRONG QR: PERSON ID. Scan the Book QR here.")
            Exit Sub
        End If
        If _borrowerType = "" Then
            BookNotAllowed("Scan the borrower first (Step 1).")
            txtScanBorrower.Focus()
            Exit Sub
        End If

        Try
            Dim dt As DataTable = GetTable("SELECT * FROM BOOKS WHERE qr_code = @q1 OR accession_no = @q2", _
                                           P("@q1", code), P("@q2", code))
            If dt.Rows.Count = 0 Then
                BookNotAllowed("BOOK QR NOT FOUND: " & code)
                Exit Sub
            End If

            Dim r As DataRow = dt.Rows(0)
            Dim avail As Integer = DbInt(r, "available_copies")
            Dim bstatus As String = DbStr(r, "status")
            lblBookTitle.Text = "Title : " & DbStr(r, "title")
            lblBookAccession.Text = "Accession No. : " & DbStr(r, "accession_no")
            lblBookAuthor.Text = "Author : " & DbStr(r, "author")
            lblBookAvailable.Text = "Available : " & avail & " of " & DbInt(r, "total_copies") & "   (Status: " & bstatus & ")"

            If bstatus = "Lost" OrElse bstatus = "Damaged" Then
                BookNotAllowed("This book is marked " & bstatus & " - cannot be borrowed.")
                Exit Sub
            End If
            If avail <= 0 Then
                BookNotAllowed("No available copy of this book.")
                Exit Sub
            End If

            _bookId = DbInt(r, "bookid")
            _bookTitle = DbStr(r, "title")
            lblBookStatus.ForeColor = Color.FromArgb(20, 83, 45)
            lblBookStatus.Text = "Book OK. Click Borrow."
            System.Media.SystemSounds.Beep.Play()
            btnBorrowBook.Focus()

        Catch ex As Exception
            WriteSystemLog("Borrowing", "Error", "frmBorrowReturn.FindBook", ex.Message)
            MessageBox.Show("Error finding book: " & ex.Message, "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BookNotAllowed(ByVal msg As String)
        System.Media.SystemSounds.Exclamation.Play()
        lblBookStatus.ForeColor = Color.FromArgb(153, 27, 27)
        lblBookStatus.Text = msg
        _bookId = 0
        txtScanBook.SelectAll()
        txtScanBook.Focus()
    End Sub

    Private Sub btnBorrowBook_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrowBook.Click
        If _borrowerType = "" Then
            MessageBox.Show("Scan a valid borrower QR first (STEP 1).", "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtScanBorrower.Focus()
            Exit Sub
        End If
        If _bookId = 0 Then
            MessageBox.Show("Scan a valid book QR first (STEP 2).", "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtScanBook.Focus()
            Exit Sub
        End If

        Try
            If CurrentBorrowedCount() >= _borrowerLimit Then
                MessageBox.Show("Borrower already reached the limit of " & _borrowerLimit & " book(s).", "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            Dim dupSql As String
            Dim dupCount As Integer
            If _borrowerType = "Student" Then
                dupSql = "SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE bookid=@b AND studentid=@id AND return_date IS NULL"
                dupCount = GetCount(dupSql, P("@b", _bookId), P("@id", _studentId))
            Else
                dupSql = "SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE bookid=@b AND facultystaffid=@id AND return_date IS NULL"
                dupCount = GetCount(dupSql, P("@b", _bookId), P("@id", _facultyId))
            End If
            If dupCount > 0 Then
                MessageBox.Show("This borrower already has an unreturned copy of this book.", "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            Dim dtB As DataTable = GetTable("SELECT available_copies, total_copies FROM BOOKS WHERE bookid=@id", P("@id", _bookId))
            If dtB.Rows.Count = 0 Then Exit Sub
            Dim avail As Integer = DbInt(dtB.Rows(0), "available_copies")
            If avail <= 0 Then
                MessageBox.Show("No available copy of this book.", "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            Dim transCode As String = "TRX-" & DateTime.Now.ToString("yyyyMMddHHmmss")
            Dim sidValue As Object = DBNull.Value
            Dim fidValue As Object = DBNull.Value
            If _borrowerType = "Student" Then sidValue = _studentId
            If _borrowerType = "Faculty/Staff" Then fidValue = _facultyId
            Dim libValue As Object = DBNull.Value
            If CurrentLibraryStaffID > 0 Then libValue = CurrentLibraryStaffID

            RunNonQuery("INSERT INTO BORROW_TRANSACTIONS (bookid, studentid, facultystaffid, librarystaffid, transaction_code, " & _
                        "borrower_type, borrow_date, due_date, return_date, days_overdue, fine_amount, status) " & _
                        "VALUES (@book,@sid,@fid,@lib,@code,@type,@bdate,@ddate,@rdate,@days,@fine,@status)", _
                        P("@book", _bookId), P("@sid", sidValue), P("@fid", fidValue), P("@lib", libValue), _
                        P("@code", transCode), P("@type", _borrowerType), _
                        P("@bdate", dtpBorrowDate.Value.Date), P("@ddate", dtpDueDate.Value.Date), _
                        P("@rdate", DBNull.Value), P("@days", 0), P("@fine", 0D), P("@status", "Borrowed"))

            Dim newAvail As Integer = avail - 1
            Dim newStatus As String = "Available"
            If newAvail <= 0 Then newStatus = "Borrowed"
            RunNonQuery("UPDATE BOOKS SET available_copies=@avail, status=@status WHERE bookid=@id", _
                        P("@avail", newAvail), P("@status", newStatus), P("@id", _bookId))

            WriteUserLog("Borrow", "Borrowing & Returning", "BORROW_TRANSACTIONS", 0, _
                         transCode & " | " & _borrowerName & " borrowed '" & _bookTitle & "', due " & dtpDueDate.Value.ToString("yyyy-MM-dd"))

            lblBorrowResult.BackColor = Color.FromArgb(20, 83, 45)
            lblBorrowResult.ForeColor = Color.FromArgb(240, 253, 244)
            lblBorrowResult.Text = "Borrowed! " & transCode & "  |  Due: " & dtpDueDate.Value.ToString("MMMM dd, yyyy")

            MessageBox.Show("Borrowing successful! (Receipt)" & vbCrLf & vbCrLf & _
                            "Transaction : " & transCode & vbCrLf & _
                            "Borrower         : " & _borrowerName & " (" & _borrowerType & ")" & vbCrLf & _
                            "Book             : " & _bookTitle & vbCrLf & _
                            "Borrow Date      : " & dtpBorrowDate.Value.ToString("MMMM dd, yyyy") & vbCrLf & _
                            "Due Date         : " & dtpDueDate.Value.ToString("MMMM dd, yyyy"), _
                            "Borrow Book", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ClearBorrowFields()
            LoadTransactions()

        Catch ex As Exception
            WriteSystemLog("Borrowing", "Error", "frmBorrowReturn.Borrow", ex.Message)
            MessageBox.Show("Error borrowing book: " & ex.Message, "Borrow", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ClearBorrowFields()
        _borrowerType = ""
        _studentId = 0
        _facultyId = 0
        _borrowerName = ""
        _bookId = 0
        _bookTitle = ""
        txtScanBorrower.Clear()
        txtScanBook.Clear()
        lblBorrowerStatus.ForeColor = Color.FromArgb(20, 83, 45)
        lblBorrowerStatus.Text = "Waiting for borrower scan..."
        lblBorrowerName.Text = "Name : -"
        lblBorrowerType.Text = "Type : -"
        lblBorrowerIDNo.Text = "ID No. : -"
        lblBorrowerDetail.Text = "Course/Dept : -"
        lblBorrowerBorrowedCount.Text = "Borrowed : -"
        lblBookStatus.ForeColor = Color.FromArgb(20, 83, 45)
        lblBookStatus.Text = "Waiting for book scan..."
        lblBookTitle.Text = "Title : -"
        lblBookAccession.Text = "Accession No. : -"
        lblBookAuthor.Text = "Author : -"
        lblBookAvailable.Text = "Available : -"
        dtpBorrowDate.Value = Date.Today
        nudLoanDays.Value = STUDENT_DAYS
        UpdateDueDate()
        txtScanBorrower.Focus()
    End Sub

    Private Sub btnClearBorrow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearBorrow.Click
        lblBorrowResult.BackColor = Color.FromArgb(185, 216, 190)
        lblBorrowResult.ForeColor = Color.FromArgb(20, 83, 45)
        lblBorrowResult.Text = "Waiting for scans..."
        ClearBorrowFields()
    End Sub

    Private Sub txtScanReturnBook_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtScanReturnBook.KeyDown
        If e.KeyCode = Keys.Enter OrElse e.KeyCode = Keys.Tab Then
            e.SuppressKeyPress = True
            FindBorrowRecord()
        End If
    End Sub

    Private Sub btnFindBorrowed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFindBorrowed.Click
        FindBorrowRecord()
    End Sub

    Private Sub RejectReturnScan(ByVal message As String, ByVal isOrange As Boolean)
        System.Media.SystemSounds.Exclamation.Play()
        If isOrange Then
            lblReturnResult.BackColor = Color.FromArgb(202, 138, 4)
            lblReturnResult.ForeColor = Color.FromArgb(63, 42, 0)
        Else
            lblReturnResult.BackColor = Color.FromArgb(153, 27, 27)
            lblReturnResult.ForeColor = Color.FromArgb(240, 253, 244)
        End If
        lblReturnResult.Text = message
        ClearReturnInfo()
        txtScanReturnBook.SelectAll()
        txtScanReturnBook.Focus()
    End Sub

    Private Sub FindBorrowRecord()
        Dim code As String = txtScanReturnBook.Text.Trim()
        If code = "" Then Exit Sub
        _returnBorrowId = 0
        _returnBookId = 0
        _daysOverdue = 0
        _fineAmount = 0D
        ClearReturnInfo()

        Dim scannedType As String = ScannedQRType(code)
        If scannedType = "Student" OrElse scannedType = "Faculty" Then
            RejectReturnScan("WRONG QR: PERSON ID. Scan the Book QR to return.", False)
            Exit Sub
        End If

        Try
            Dim dtB As DataTable = GetTable("SELECT bookid, title FROM BOOKS WHERE qr_code = @q1 OR accession_no = @q2", _
                                            P("@q1", code), P("@q2", code))
            If dtB.Rows.Count = 0 Then
                RejectReturnScan("BOOK QR NOT FOUND: " & code, False)
                Exit Sub
            End If
            _returnBookId = DbInt(dtB.Rows(0), "bookid")

            Dim sql As String = "SELECT TOP (1) t.*, b.title AS book_title, " & _
                "CASE WHEN t.borrower_type = 'Student' THEN (s.last_name + ', ' + s.first_name) " & _
                "ELSE (f.last_name + ', ' + f.first_name) END AS borrower_name " & _
                "FROM BORROW_TRANSACTIONS t " & _
                "LEFT JOIN BOOKS b ON t.bookid = b.bookid " & _
                "LEFT JOIN STUDENTS s ON t.studentid = s.studentid " & _
                "LEFT JOIN FACULTY_STAFF f ON t.facultystaffid = f.facultystaffid " & _
                "WHERE t.bookid = @book AND t.return_date IS NULL ORDER BY t.borrow_date"
            Dim dt As DataTable = GetTable(sql, P("@book", _returnBookId))
            If dt.Rows.Count = 0 Then
                RejectReturnScan("No open borrow record for this book (already returned?).", True)
                Exit Sub
            End If

            Dim openCount As Integer = GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE bookid=@book AND return_date IS NULL", _
                                                P("@book", _returnBookId))
            Dim r As DataRow = dt.Rows(0)
            _returnBorrowId = DbInt(r, "borrowid")
            Dim dueDate As Date = DbDate(r, "due_date").Date
            If Date.Today > dueDate Then
                _daysOverdue = CInt(DateDiff(DateInterval.Day, dueDate, Date.Today))
            Else
                _daysOverdue = 0
            End If
            _fineAmount = _daysOverdue * FINE_PER_DAY

            lblReturnTransCode.Text = "Transaction : " & DbStr(r, "transaction_code") & _
                                      "   (Status: " & DbStr(r, "status") & ")"
            lblReturnBookTitle.Text = "Book : " & DbStr(r, "book_title")
            lblReturnBorrower.Text = "Borrower : " & DbStr(r, "borrower_name") & " (" & DbStr(r, "borrower_type") & ")"
            lblReturnBorrowDate.Text = "Borrow Date : " & DbDate(r, "borrow_date").ToString("MMMM dd, yyyy")
            lblReturnDueDate.Text = "Due Date : " & dueDate.ToString("MMMM dd, yyyy")
            lblDaysOverdue.Text = "Days Overdue : " & _daysOverdue
            lblFineAmount.Text = "Fine Amount : Php " & _fineAmount.ToString("N2")

            lblReturnResult.BackColor = Color.FromArgb(20, 83, 45)
            lblReturnResult.ForeColor = Color.FromArgb(240, 253, 244)
            If openCount > 1 Then
                lblReturnResult.Text = "VERIFY BORROWER ABOVE: oldest of " & openCount & " open records for this book."
            Else
                lblReturnResult.Text = "Borrow record found - click RETURN."
            End If
            System.Media.SystemSounds.Beep.Play()
            btnProcessReturn.Focus()

        Catch ex As Exception
            WriteSystemLog("Returning", "Error", "frmBorrowReturn.FindBorrowRecord", ex.Message)
            MessageBox.Show("Error finding borrow record: " & ex.Message, "Return", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnProcessReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcessReturn.Click
        If _returnBorrowId = 0 Then
            MessageBox.Show("Scan a borrowed book QR first.", "Return", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtScanReturnBook.Focus()
            Exit Sub
        End If

        Dim msg As String = "Process this return?"
        If _fineAmount > 0 Then
            msg &= vbCrLf & vbCrLf & "Days Overdue: " & _daysOverdue & vbCrLf & _
                   "FINE TO COLLECT: Php " & _fineAmount.ToString("N2")
        End If
        If MessageBox.Show(msg, "Process Return", MessageBoxButtons.YesNo, MessageBoxIcon.Question) <> DialogResult.Yes Then Exit Sub

        Try
            RunNonQuery("UPDATE BORROW_TRANSACTIONS SET return_date=@rdate, days_overdue=@days, fine_amount=@fine, status='Returned' WHERE borrowid=@id", _
                        P("@rdate", Date.Today), P("@days", _daysOverdue), P("@fine", _fineAmount), P("@id", _returnBorrowId))

            Dim dtB As DataTable = GetTable("SELECT available_copies, total_copies FROM BOOKS WHERE bookid=@id", P("@id", _returnBookId))
            If dtB.Rows.Count > 0 Then
                Dim avail As Integer = DbInt(dtB.Rows(0), "available_copies")
                Dim total As Integer = DbInt(dtB.Rows(0), "total_copies")
                Dim newAvail As Integer = avail + 1
                If newAvail > total Then newAvail = total
                RunNonQuery("UPDATE BOOKS SET available_copies=@avail, status='Available' WHERE bookid=@id", _
                            P("@avail", newAvail), P("@id", _returnBookId))
            End If

            WriteUserLog("Return", "Borrowing & Returning", "BORROW_TRANSACTIONS", _returnBorrowId, _
                         "Book returned. Days overdue: " & _daysOverdue & ", Fine: Php " & _fineAmount.ToString("N2"))

            lblReturnResult.BackColor = Color.FromArgb(20, 83, 45)
            lblReturnResult.ForeColor = Color.FromArgb(240, 253, 244)
            lblReturnResult.Text = "RETURN PROCESSED! Fine: Php " & _fineAmount.ToString("N2")
            MessageBox.Show("Book returned successfully." & vbCrLf & _
                            "Days Overdue: " & _daysOverdue & vbCrLf & _
                            "Fine Amount : Php " & _fineAmount.ToString("N2"), _
                            "Process Return", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ClearReturnFields()
            LoadTransactions()

        Catch ex As Exception
            WriteSystemLog("Returning", "Error", "frmBorrowReturn.ProcessReturn", ex.Message)
            MessageBox.Show("Error processing return: " & ex.Message, "Return", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ClearReturnInfo()
        lblReturnTransCode.Text = "Transaction : -"
        lblReturnBookTitle.Text = "Book : -"
        lblReturnBorrower.Text = "Borrower : -"
        lblReturnBorrowDate.Text = "Borrow Date : -"
        lblReturnDueDate.Text = "Due Date : -"
        lblDaysOverdue.Text = "Days Overdue : 0"
        lblFineAmount.Text = "Fine Amount : Php 0.00"
    End Sub

    Private Sub ClearReturnFields()
        _returnBorrowId = 0
        _returnBookId = 0
        _daysOverdue = 0
        _fineAmount = 0D
        txtScanReturnBook.Clear()
        ClearReturnInfo()
        txtScanReturnBook.Focus()
    End Sub

    Private Sub btnClearReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearReturn.Click
        lblReturnResult.BackColor = Color.FromArgb(185, 216, 190)
        lblReturnResult.ForeColor = Color.FromArgb(20, 83, 45)
        lblReturnResult.Text = "Waiting for book scan..."
        ClearReturnFields()
    End Sub

    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatTransactionsGrid()
        Try
            HideAllGridColumns(dgvTransactions)
            Dim i As Integer = 0
            ShowGridColumn(dgvTransactions, "Transaction Code", "Transaction Code", 100, i)
            ShowGridColumn(dgvTransactions, "Book Title", "Book Title", 170, i)
            ShowGridColumn(dgvTransactions, "Borrower", "Borrower", 135, i)
            ShowGridColumn(dgvTransactions, "Type", "Type", 60, i)
            ShowGridColumn(dgvTransactions, "Borrow Date", "Borrow Date", 85, i)
            ShowGridColumn(dgvTransactions, "Due Date", "Due Date", 85, i)
            ShowGridColumn(dgvTransactions, "Return Date", "Return Date", 85, i)
            ShowGridColumn(dgvTransactions, "Days Overdue", "Days Overdue", 65, i)
            ShowGridColumn(dgvTransactions, "Fine", "Fine", 50, i)
            ShowGridColumn(dgvTransactions, "Status", "Status", 70, i)
        Catch
        End Try
    End Sub

    Private Sub LoadTransactions()
        Try
            Dim sql As String = "SELECT t.borrowid AS [ID], t.transaction_code AS [Transaction Code], " & _
                "b.title AS [Book Title], " & _
                "CASE WHEN t.borrower_type = 'Student' THEN (s.last_name + ', ' + s.first_name) " & _
                "ELSE (f.last_name + ', ' + f.first_name) END AS [Borrower], " & _
                "t.borrower_type AS [Type], t.borrow_date AS [Borrow Date], t.due_date AS [Due Date], " & _
                "t.return_date AS [Return Date], t.days_overdue AS [Days Overdue], " & _
                "t.fine_amount AS [Fine], t.status AS [Status] " & _
                "FROM BORROW_TRANSACTIONS t " & _
                "LEFT JOIN BOOKS b ON t.bookid = b.bookid " & _
                "LEFT JOIN STUDENTS s ON t.studentid = s.studentid " & _
                "LEFT JOIN FACULTY_STAFF f ON t.facultystaffid = f.facultystaffid " & _
                "WHERE 1 = 1"

            Dim pars As New System.Collections.Generic.List(Of SqlCeParameter)()
            If txtSearchTrans.Text.Trim() <> "" Then
                sql &= " AND (t.transaction_code LIKE @q1 OR b.title LIKE @q2 OR s.last_name LIKE @q3 OR f.last_name LIKE @q4)"
                pars.Add(P("@q1", "%" & txtSearchTrans.Text.Trim() & "%"))
                pars.Add(P("@q2", "%" & txtSearchTrans.Text.Trim() & "%"))
                pars.Add(P("@q3", "%" & txtSearchTrans.Text.Trim() & "%"))
                pars.Add(P("@q4", "%" & txtSearchTrans.Text.Trim() & "%"))
            End If
            If cboTransStatus.Text <> "" AndAlso cboTransStatus.Text <> "All" Then
                sql &= " AND t.status = @st"
                pars.Add(P("@st", cboTransStatus.Text))
            End If
            sql &= " ORDER BY t.borrow_date DESC"

            Dim arr() As SqlCeParameter = pars.ToArray()
            Dim dt As DataTable = GetTable(sql, arr)
            dgvTransactions.DataSource = dt
            FormatTransactionsGrid()
            lblTransCount.Text = "Records: " & dt.Rows.Count
        Catch ex As Exception
            WriteSystemLog("Borrowing", "Error", "frmBorrowReturn.LoadTransactions", ex.Message)
        End Try
    End Sub

    Private Sub btnSearchTrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchTrans.Click
        LoadTransactions()
    End Sub

    Private Sub btnFlagOverdue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFlagOverdue.Click
        Try
            Dim affected As Integer = RunNonQuery( _
                "UPDATE BORROW_TRANSACTIONS SET status='Overdue' WHERE return_date IS NULL AND status='Borrowed' AND due_date < @today", _
                P("@today", Date.Today))
            WriteUserLog("Flag Overdue", "Borrowing & Returning", "BORROW_TRANSACTIONS", 0, _
                         affected & " transaction(s) flagged Overdue.")
            MessageBox.Show(affected & " borrowed book(s) flagged as Overdue." & vbCrLf & _
                            "(Days overdue and fine are computed when the book is returned.)", _
                            "Flag Overdue", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadTransactions()
        Catch ex As Exception
            MessageBox.Show("Error flagging overdue: " & ex.Message, "Flag Overdue", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
