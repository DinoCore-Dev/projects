Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO
Imports System.Security.Cryptography
Public Class frmStaffUsers

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Try
            Dim value As Object = GetScalar(sql, pars)
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
            Return Convert.ToString(row(col))
        Catch
            Return ""
        End Try
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
            Return Convert.ToInt32(row(col))
        Catch
            Return 0
        End Try
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
            Return Convert.ToDecimal(row(col))
        Catch
            Return 0D
        End Try
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        Try
            If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
            Dim value As Date = Convert.ToDateTime(row(col))
            If value < New Date(1900, 1, 1) OrElse value > New Date(9998, 12, 31) Then Return Date.Today
            Return value
        Catch
            Return Date.Today
        End Try
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        Try
            If gridRow Is Nothing Then Return ""
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return ""
            Return Convert.ToString(value)
        Catch
            Return ""
        End Try
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        Try
            If gridRow Is Nothing Then Return 0
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return 0
            Return Convert.ToInt32(value)
        Catch
            Return 0
        End Try
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        Try
            If gridRow Is Nothing Then Return Date.Today
            Dim value As Object = gridRow.Cells(col).Value
            If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
            Dim result As Date = Convert.ToDateTime(value)
            If result < New Date(1900, 1, 1) OrElse result > New Date(9998, 12, 31) Then Return Date.Today
            Return result
        Catch
            Return Date.Today
        End Try
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        Dim message As String = ex.Message
        If TypeOf ex Is SqlCeException OrElse TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then message = FriendlyDatabaseError(ex, "complete the operation")
        MessageBox.Show(title & ": " & message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region

    Private Function CleanText(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Dim result As String = ""
        Dim lastWasSpace As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsWhiteSpace(ch) Then
                If result.Length > 0 AndAlso Not lastWasSpace Then result &= " "c
                lastWasSpace = True
            Else
                result &= ch
                lastWasSpace = False
            End If
        Next
        Return result.Trim()
    End Function

    Private Function HasBadControl(ByVal value As String, ByVal allowMultiline As Boolean) As Boolean
        If value Is Nothing Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsControl(ch) Then
                If allowMultiline AndAlso (ch = ControlChars.Cr OrElse ch = ControlChars.Lf OrElse ch = ControlChars.Tab) Then Continue For
                Return True
            End If
        Next
        Return False
    End Function

    Private Function FailValidation(ByVal target As Control, ByVal message As String) As Boolean
        MessageBox.Show(message, "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        If target IsNot Nothing Then
            Try
                target.Focus()
                Dim textBox As TextBox = TryCast(target, TextBox)
                If textBox IsNot Nothing Then textBox.SelectAll()
                Dim comboBox As ComboBox = TryCast(target, ComboBox)
                If comboBox IsNot Nothing Then comboBox.SelectAll()
            Catch
            End Try
        End If
        Return False
    End Function

    Private Function CheckTextBox(ByVal target As TextBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Function CheckComboText(ByVal target As ComboBox, ByVal label As String, ByVal maxLength As Integer, ByVal required As Boolean) As Boolean
        Dim value As String = CleanText(target.Text)
        target.Text = value
        If required AndAlso value = "" Then Return FailValidation(target, label & " is required.")
        If value.Length > maxLength Then Return FailValidation(target, label & " must not exceed " & maxLength & " characters.")
        If HasBadControl(value, False) Then Return FailValidation(target, label & " contains an unsupported character.")
        Return True
    End Function

    Private Sub NormalizeComboText(ByVal target As ComboBox)
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return
            End If
        Next
        target.Text = value
    End Sub

    Private Function RequireListValue(ByVal target As ComboBox, ByVal label As String) As Boolean
        Dim value As String = CleanText(target.Text)
        Dim i As Integer
        For i = 0 To target.Items.Count - 1
            Dim itemText As String = Convert.ToString(target.Items(i))
            If String.Equals(itemText, value, StringComparison.OrdinalIgnoreCase) Then
                target.SelectedIndex = i
                Return True
            End If
        Next
        Return FailValidation(target, "Please select a valid " & label & " from the list.")
    End Function

    Private Function IdentifierOK(ByVal value As String, ByVal minLength As Integer) As Boolean
        If value Is Nothing OrElse value.Length < minLength Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(0)) Then Return False
        If Not Char.IsLetterOrDigit(value.Chars(value.Length - 1)) Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c AndAlso ch <> "_"c AndAlso ch <> "."c AndAlso ch <> "/"c Then Return False
        Next
        Return True
    End Function

    Private Function PersonNameOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 Then Return False
        Dim hasLetter As Boolean = False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsLetter(ch) Then
                hasLetter = True
            ElseIf ch = " "c OrElse ch = "'"c OrElse ch = "-"c OrElse ch = "."c Then
            Else
                Return False
            End If
        Next
        Return hasLetter
    End Function

    Private Function EmailOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length < 5 OrElse value.Length > 100 Then Return False
        If HasBadControl(value, False) OrElse value.IndexOf(" "c) >= 0 Then Return False
        Dim at As Integer = value.IndexOf("@"c)
        If at < 1 OrElse at <> value.LastIndexOf("@"c) OrElse at >= value.Length - 3 Then Return False
        Dim localPart As String = value.Substring(0, at)
        Dim domain As String = value.Substring(at + 1)
        If localPart.StartsWith(".") OrElse localPart.EndsWith(".") OrElse localPart.Contains("..") Then Return False
        If domain.StartsWith(".") OrElse domain.EndsWith(".") OrElse domain.StartsWith("-") OrElse domain.EndsWith("-") OrElse domain.Contains("..") Then Return False
        Dim labels() As String = domain.Split("."c)
        If labels.Length < 2 Then Return False
        Dim i As Integer
        For i = 0 To localPart.Length - 1
            Dim ch As Char = localPart.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "."c AndAlso ch <> "_"c AndAlso ch <> "%"c AndAlso ch <> "+"c AndAlso ch <> "-"c Then Return False
        Next
        For i = 0 To labels.Length - 1
            If labels(i).Length = 0 OrElse labels(i).StartsWith("-") OrElse labels(i).EndsWith("-") Then Return False
            Dim j As Integer
            For j = 0 To labels(i).Length - 1
                Dim ch As Char = labels(i).Chars(j)
                If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "-"c Then Return False
            Next
        Next
        If labels(labels.Length - 1).Length < 2 Then Return False
        Return True
    End Function

    Private Function PhoneOK(ByVal value As String) As Boolean
        If value Is Nothing OrElse value.Length = 0 OrElse value.Length > 20 Then Return False
        Dim digits As Integer = 0
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Char.IsDigit(ch) Then
                digits += 1
            ElseIf ch = " "c OrElse ch = "-"c OrElse ch = "("c OrElse ch = ")"c OrElse (ch = "+"c AndAlso i = 0) Then
            Else
                Return False
            End If
        Next
        Return digits >= 7 AndAlso digits <= 15
    End Function

    Private Function TrySelectedId(ByVal target As TextBox, ByRef recordId As Integer) As Boolean
        recordId = 0
        If Not Integer.TryParse(CleanText(target.Text), recordId) Then Return False
        Return recordId > 0
    End Function

    Private Function EscapeLike(ByVal value As String) As String
        If value Is Nothing Then Return ""
        Return value.Trim().Replace("[", "[[]").Replace("%", "[%]").Replace("_", "[_]")
    End Function

    Private Function SafePickerDate(ByVal value As Date, ByVal minimumYear As Integer) As Date
        If value < New Date(minimumYear, 1, 1) Then Return New Date(minimumYear, 1, 1)
        If value.Date > Date.Today Then Return Date.Today
        Return value.Date
    End Function

    Private Function FriendlyDatabaseError(ByVal ex As Exception, ByVal action As String) As String
        Dim message As String = ""
        If ex IsNot Nothing AndAlso ex.Message IsNot Nothing Then message = ex.Message
        Dim lower As String = message.ToLowerInvariant()
        If TypeOf ex Is SqlCeException Then
            If lower.Contains("unique") OrElse lower.Contains("duplicate") Then Return "Could not " & action & " because another record already uses the same unique value."
            If lower.Contains("foreign key") OrElse lower.Contains("constraint") OrElse lower.Contains("related") Then Return "Could not " & action & " because the record is connected to other records. Check related records and try again."
            If lower.Contains("locked") OrElse lower.Contains("being used") OrElse lower.Contains("in use") Then Return "Could not " & action & " because the database is busy or locked. Wait a moment and try again."
            If lower.Contains("could not find") OrElse lower.Contains("does not exist") OrElse lower.Contains("file") Then Return "Could not " & action & " because the database file could not be opened. Close the system and run it again."
            Return "Could not " & action & ". Database error: " & message
        End If
        If TypeOf ex Is System.IO.IOException OrElse TypeOf ex Is UnauthorizedAccessException Then Return "Could not " & action & " because a required file could not be accessed. Close other programs using the system and try again."
        Return "Could not " & action & ": " & message
    End Function

    Private Function ConfirmAction(ByVal message As String, ByVal title As String) As Boolean
        Return MessageBox.Show(message, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes
    End Function


    Private _busy As Boolean = False
    Private _savedStaffSignature As String = ""
    Private _savedUserSignature As String = ""

    Private Sub ConfigureInputLimits()
        txtStaffID.MaxLength = 10
        txtEmployeeNo.MaxLength = 20
        txtFullName.MaxLength = 100
        txtStaffEmail.MaxLength = 100
        txtStaffContact.MaxLength = 20
        txtUserID.MaxLength = 10
        txtUsername.MaxLength = 50
        txtUserPassword.MaxLength = 255
        txtConfirmPassword.MaxLength = 255
    End Sub

    Private Function CurrentStaffSignature() As String
        Return String.Join("|", New String() {CleanText(txtStaffID.Text), CleanText(txtEmployeeNo.Text), CleanText(txtFullName.Text), CleanText(cboRole.Text), CleanText(txtStaffEmail.Text), CleanText(txtStaffContact.Text), CleanText(cboStaffStatus.Text)})
    End Function

    Private Sub RememberStaffState()
        _savedStaffSignature = CurrentStaffSignature()
    End Sub

    Private Function ConfirmDiscardStaffChanges() As Boolean
        If _savedStaffSignature = "" OrElse _savedStaffSignature = CurrentStaffSignature() Then Return True
        Return ConfirmAction("Discard unsaved Library Staff changes?", "Unsaved Changes")
    End Function

    Private Function CurrentUserSignature() As String
        Return String.Join("|", New String() {CleanText(txtUserID.Text), CleanText(txtUsername.Text), txtUserPassword.Text, txtConfirmPassword.Text, CleanText(cboUserLevel.Text), CleanText(cboUserStatus.Text)})
    End Function

    Private Sub RememberUserState()
        _savedUserSignature = CurrentUserSignature()
    End Sub

    Private Function ConfirmDiscardUserChanges() As Boolean
        If _savedUserSignature = "" OrElse _savedUserSignature = CurrentUserSignature() Then Return True
        Return ConfirmAction("Discard unsaved User Account changes?", "Unsaved Changes")
    End Function

    Private Sub frmStaffUsers_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If e.CloseReason = CloseReason.UserClosing Then
            If Not ConfirmDiscardStaffChanges() OrElse Not ConfirmDiscardUserChanges() Then e.Cancel = True
        End If
    End Sub

    Private Sub NormalizeStaffInput()
        txtEmployeeNo.Text = CleanText(txtEmployeeNo.Text).ToUpperInvariant()
        txtFullName.Text = CleanText(txtFullName.Text)
        txtStaffEmail.Text = CleanText(txtStaffEmail.Text).ToLowerInvariant()
        txtStaffContact.Text = CleanText(txtStaffContact.Text)
    End Sub

    Private Sub NormalizeUserInput()
        txtUsername.Text = CleanText(txtUsername.Text).ToLowerInvariant()
    End Sub

    Private Function UsernameOK(ByVal value As String) As Boolean
        If value.Length < 4 OrElse value.Length > 50 Then Return False
        If Not Char.IsLetter(value.Chars(0)) Then Return False
        Dim i As Integer
        For i = 0 To value.Length - 1
            Dim ch As Char = value.Chars(i)
            If Not Char.IsLetterOrDigit(ch) AndAlso ch <> "."c AndAlso ch <> "_"c AndAlso ch <> "-"c Then Return False
        Next
        Return True
    End Function

    Private Function RoleMatchesLevel(ByVal staffPosition As String, ByVal userLevel As String) As Boolean
        Dim position As String = CleanText(staffPosition).ToUpperInvariant()
        Dim level As String = CleanText(userLevel).ToUpperInvariant()
        If level = "LIBRARY STAFF" Then level = "STAFF"
        If position = "" OrElse level = "" Then Return True
        If level = "ADMINISTRATOR" Then Return position = "ADMINISTRATOR" OrElse position = "HEAD LIBRARIAN"
        If level = "LIBRARIAN" Then Return position = "LIBRARIAN" OrElse position = "HEAD LIBRARIAN"
        If level = "STAFF" Then Return position = "STAFF" OrElse position = "LIBRARY STAFF" OrElse position = "LIBRARY ASSISTANT" OrElse position = "ASSISTANT"
        Return position = level
    End Function
    Private Function SystemRoleToDb(ByVal displayRole As String) As String
        If String.Equals(CleanText(displayRole), "Library Staff", StringComparison.OrdinalIgnoreCase) Then Return "Staff"
        Return CleanText(displayRole)
    End Function

    Private Function SystemRoleDisplay(ByVal dbRole As String) As String
        If String.Equals(CleanText(dbRole), "Staff", StringComparison.OrdinalIgnoreCase) Then Return "Library Staff"
        Return CleanText(dbRole)
    End Function

    Private Function HashPassword(ByVal plainPassword As String) As String
        If plainPassword Is Nothing Then plainPassword = ""
        Dim salt(15) As Byte
        Dim rng As New RNGCryptoServiceProvider()
        rng.GetBytes(salt)
        Dim hash As Byte()
        Using derive As New Rfc2898DeriveBytes(plainPassword, salt, 20000)
            hash = derive.GetBytes(32)
        End Using
        Return "PBKDF2$20000$" & Convert.ToBase64String(salt) & "$" & Convert.ToBase64String(hash)
    End Function

    Private Function VerifyPassword(ByVal plainPassword As String, ByVal storedPassword As String) As Boolean
        If plainPassword Is Nothing Then plainPassword = ""
        If storedPassword Is Nothing Then storedPassword = ""
        If Not storedPassword.StartsWith("PBKDF2$") Then Return String.Equals(plainPassword, storedPassword, StringComparison.Ordinal)
        Try
            Dim parts() As String = storedPassword.Split("$"c)
            If parts.Length <> 4 Then Return False
            Dim iterations As Integer = 0
            If Not Integer.TryParse(parts(1), iterations) OrElse iterations < 1000 OrElse iterations > 200000 Then Return False
            Dim salt As Byte() = Convert.FromBase64String(parts(2))
            Dim expected As Byte() = Convert.FromBase64String(parts(3))
            If salt.Length < 8 OrElse expected.Length < 16 Then Return False
            Dim computed As Byte()
            Using derive As New Rfc2898DeriveBytes(plainPassword, salt, iterations)
                computed = derive.GetBytes(expected.Length)
            End Using
            Dim difference As Integer = 0
            Dim i As Integer
            For i = 0 To expected.Length - 1
                difference = difference Or (expected(i) Xor computed(i))
            Next
            Return difference = 0
        Catch
            Return False
        End Try
    End Function

    Private Function RequireAdministrator() As Boolean
        If IsAdministrator() Then Return True
        MessageBox.Show("Only a signed-in Administrator can manage Library Staff records and login accounts.", "Administrator Only", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Return False
    End Function

    Private Function PromptForPassword(ByVal promptText As String, ByRef enteredPassword As String) As Boolean
        enteredPassword = ""
        Using promptForm As New Form()
            promptForm.Text = "Password Verification"
            promptForm.StartPosition = FormStartPosition.CenterParent
            promptForm.FormBorderStyle = FormBorderStyle.FixedDialog
            promptForm.MinimizeBox = False
            promptForm.MaximizeBox = False
            promptForm.ShowInTaskbar = False
            promptForm.ClientSize = New System.Drawing.Size(390, 168)
            promptForm.BackColor = System.Drawing.Color.FromArgb(240, 253, 244)
            Dim lblPrompt As New Label()
            lblPrompt.Location = New System.Drawing.Point(15, 14)
            lblPrompt.Size = New System.Drawing.Size(360, 44)
            lblPrompt.Text = promptText
            lblPrompt.ForeColor = System.Drawing.Color.FromArgb(20, 83, 45)
            Dim txtVerify As New TextBox()
            txtVerify.Location = New System.Drawing.Point(15, 66)
            txtVerify.Size = New System.Drawing.Size(360, 23)
            txtVerify.UseSystemPasswordChar = True
            txtVerify.MaxLength = 255
            txtVerify.BackColor = System.Drawing.Color.FromArgb(221, 238, 223)
            Dim btnVerify As New Button()
            btnVerify.Text = "Verify"
            btnVerify.Location = New System.Drawing.Point(195, 108)
            btnVerify.Size = New System.Drawing.Size(85, 34)
            btnVerify.DialogResult = DialogResult.OK
            btnVerify.BackColor = System.Drawing.Color.FromArgb(20, 83, 45)
            btnVerify.ForeColor = System.Drawing.Color.FromArgb(240, 253, 244)
            btnVerify.FlatStyle = FlatStyle.Flat
            btnVerify.UseVisualStyleBackColor = False
            Dim btnCancel As New Button()
            btnCancel.Text = "Cancel"
            btnCancel.Location = New System.Drawing.Point(290, 108)
            btnCancel.Size = New System.Drawing.Size(85, 34)
            btnCancel.DialogResult = DialogResult.Cancel
            btnCancel.BackColor = System.Drawing.Color.FromArgb(169, 205, 176)
            btnCancel.ForeColor = System.Drawing.Color.FromArgb(20, 83, 45)
            btnCancel.FlatStyle = FlatStyle.Flat
            btnCancel.UseVisualStyleBackColor = False
            promptForm.Controls.Add(lblPrompt)
            promptForm.Controls.Add(txtVerify)
            promptForm.Controls.Add(btnVerify)
            promptForm.Controls.Add(btnCancel)
            promptForm.AcceptButton = btnVerify
            promptForm.CancelButton = btnCancel
            promptForm.ActiveControl = txtVerify
            If promptForm.ShowDialog(Me) <> DialogResult.OK Then Return False
            enteredPassword = txtVerify.Text
            txtVerify.Clear()
            Return True
        End Using
    End Function

    Private Function VerifyStoredPasswordWithPrompt(ByVal storedPassword As String, ByVal promptText As String, ByVal failureDescription As String) As Boolean
        If storedPassword Is Nothing OrElse storedPassword = "" Then
            MessageBox.Show("This action cannot be verified because no password is stored for the required account. The operation was cancelled.", "Password Verification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If
        Dim attempts As Integer = 0
        Do While attempts < 3
            Dim enteredPassword As String = ""
            If Not PromptForPassword(promptText, enteredPassword) Then Return False
            attempts += 1
            If enteredPassword <> "" AndAlso VerifyPassword(enteredPassword, storedPassword) Then
                enteredPassword = ""
                Return True
            End If
            enteredPassword = ""
            If attempts < 3 Then MessageBox.Show("The password entered is incorrect. Attempts remaining: " & CStr(3 - attempts) & ".", "Password Verification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Loop
        WriteSystemLog("Authentication", "Warning", "frmStaffUsers", failureDescription)
        MessageBox.Show("Password verification failed three times. The operation was cancelled and no changes were saved.", "Password Verification", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Return False
    End Function

    Private Function VerifyCurrentAdministrator(ByVal actionText As String) As Boolean
        If Not RequireAdministrator() Then Return False
        If CurrentUserID <= 0 Then
            MessageBox.Show("Your signed-in Administrator account could not be identified, so this action cannot be verified.", "Password Verification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If
        Dim storedValue As Object = GetScalar("SELECT password FROM USER_TABLE WHERE userid = @id", P("@id", CurrentUserID))
        If storedValue Is Nothing OrElse IsDBNull(storedValue) Then
            MessageBox.Show("Your signed-in Administrator account was not found, so this action cannot be verified.", "Password Verification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If
        Return VerifyStoredPasswordWithPrompt(Convert.ToString(storedValue), "To " & actionText & ", enter YOUR current Administrator password. It will not be displayed.", "Administrator verification failed while trying to " & actionText & ".")
    End Function

    Private Function VerifyAccountOwnerPassword(ByVal storedPassword As String, ByVal username As String) As Boolean
        Return VerifyStoredPasswordWithPrompt(storedPassword, "The owner of account '" & username & "' must type that account's CURRENT password before the password can be changed. It will not be displayed.", "Account-owner password verification failed for account '" & username & "'.")
    End Function

    Private Function OtherUsableAdministratorExists(ByVal excludedUserId As Integer) As Boolean
        Return GetCount("SELECT COUNT(*) FROM USER_TABLE u LEFT JOIN LIBRARY_STAFF s ON u.librarystaffid = s.librarystaffid WHERE UPPER(u.user_level) = 'ADMINISTRATOR' AND UPPER(u.status) = 'ACTIVE' AND (u.librarystaffid IS NULL OR UPPER(s.status) = 'ACTIVE') AND u.userid <> @id", P("@id", excludedUserId)) > 0
    End Function

    Private Function OtherUsableAdministratorForStaff(ByVal excludedStaffId As Integer) As Boolean
        Return GetCount("SELECT COUNT(*) FROM USER_TABLE u LEFT JOIN LIBRARY_STAFF s ON u.librarystaffid = s.librarystaffid WHERE UPPER(u.user_level) = 'ADMINISTRATOR' AND UPPER(u.status) = 'ACTIVE' AND (u.librarystaffid IS NULL OR (u.librarystaffid <> @id AND UPPER(s.status) = 'ACTIVE'))", P("@id", excludedStaffId)) > 0
    End Function

    Private Sub frmStaffUsers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ConfigureInputLimits()
            ClearStaffFields()
            LoadStaff()
            ClearUserFields()
            LoadUsers()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatStaffGrid()
        Try
            HideAllGridColumns(dgvStaff)
            Dim i As Integer = 0
            ShowGridColumn(dgvStaff, "employee_no", "Employee No.", 90, i)
            ShowGridColumn(dgvStaff, "full_name", "Full Name", 150, i)
            ShowGridColumn(dgvStaff, "role", "Position", 100, i)
            ShowGridColumn(dgvStaff, "email", "Email", 165, i)
            ShowGridColumn(dgvStaff, "contact_number", "Contact Number", 110, i)
            ShowGridColumn(dgvStaff, "status", "Status", 60, i)
        Catch
        End Try
    End Sub

    Private Sub FormatUsersGrid()
        Try
            HideAllGridColumns(dgvUsers)
            Dim i As Integer = 0
            ShowGridColumn(dgvUsers, "username", "Username", 170, i)
            ShowGridColumn(dgvUsers, "user_level", "System Role", 150, i)
            ShowGridColumn(dgvUsers, "status", "Status", 90, i)
            ShowGridColumn(dgvUsers, "last_login", "Last Login", 190, i)
        Catch
        End Try
    End Sub
    Private Sub LoadStaff()
        Try
            Dim dt As DataTable = GetTable("SELECT * FROM LIBRARY_STAFF ORDER BY full_name")
            dgvStaff.DataSource = dt
            FormatStaffGrid()
            lblStaffCount.Text = "Records: " & dt.Rows.Count
        Catch ex As Exception
            dgvStaff.DataSource = Nothing
            lblStaffCount.Text = "Records: 0"
            MessageBox.Show(FriendlyDatabaseError(ex, "load library staff"), "Library Staff", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub ClearStaffFields()
        txtStaffID.Clear()
        txtEmployeeNo.Clear()
        txtFullName.Clear()
        cboRole.Text = "Librarian"
        txtStaffEmail.Clear()
        txtStaffContact.Clear()
        cboStaffStatus.Text = "Active"
        RememberStaffState()
    End Sub
    Private Function IsStaffValid() As Boolean
        If Not CheckTextBox(txtEmployeeNo, "Employee No.", 20, True) Then Return False
        If Not IdentifierOK(txtEmployeeNo.Text, 3) Then Return FailValidation(txtEmployeeNo, "Employee No. must be at least 3 characters and use only letters, numbers, hyphen, underscore, dot, or slash. Do not include spaces.")
        If Not CheckTextBox(txtFullName, "Full Name", 100, True) Then Return False
        If Not PersonNameOK(txtFullName.Text) Then Return FailValidation(txtFullName, "Full Name must contain letters and may use spaces, apostrophes, hyphens, and periods only.")
        If Not RequireListValue(cboRole, "Position") Then Return False
        If Not CheckTextBox(txtStaffEmail, "Email", 100, False) Then Return False
        If txtStaffEmail.Text <> "" AndAlso Not EmailOK(txtStaffEmail.Text) Then Return FailValidation(txtStaffEmail, "Enter a valid email address, or leave Email blank.")
        If Not CheckTextBox(txtStaffContact, "Contact Number", 20, False) Then Return False
        If txtStaffContact.Text <> "" AndAlso Not PhoneOK(txtStaffContact.Text) Then Return FailValidation(txtStaffContact, "Enter a valid contact number with 7 to 15 digits, or leave it blank.")
        If Not RequireListValue(cboStaffStatus, "Status") Then Return False
        Return True
    End Function
    Private Sub btnStaffNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStaffNew.Click
        If Not ConfirmDiscardStaffChanges() Then Exit Sub
        ClearStaffFields()
        txtEmployeeNo.Focus()
    End Sub
    Private Sub btnStaffClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStaffClear.Click
        If Not ConfirmDiscardStaffChanges() Then Exit Sub
        ClearStaffFields()
        LoadStaff()
    End Sub
    Private Sub btnStaffSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStaffSave.Click
        If _busy Then Exit Sub
        If Not RequireAdministrator() Then Exit Sub
        NormalizeStaffInput()
        If CleanText(txtStaffID.Text) <> "" Then
            MessageBox.Show("This record already exists. Use UPDATE, or click NEW for a new Library Staff record.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        If Not IsStaffValid() Then Exit Sub
        _busy = True
        Try
            Dim employeeNo As String = CleanText(txtEmployeeNo.Text).ToUpperInvariant()
            If GetCount("SELECT COUNT(*) FROM LIBRARY_STAFF WHERE UPPER(employee_no) = @n", P("@n", employeeNo)) > 0 Then
                FailValidation(txtEmployeeNo, "Employee No. already exists.")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM LIBRARY_STAFF WHERE UPPER(full_name) = @n", P("@n", txtFullName.Text.ToUpperInvariant())) > 0 Then
                If Not ConfirmAction("Another Library Staff record has the same full name. Continue saving a separate record?", "Possible Duplicate") Then
                    txtFullName.Focus()
                    Exit Sub
                End If
            End If
            Dim affected As Integer = RunNonQuery("INSERT INTO LIBRARY_STAFF (employee_no, full_name, role, email, contact_number, status, created_at, updated_at) VALUES (@eno,@name,@role,@email,@contact,@status,@created,@updated)", P("@eno", employeeNo), P("@name", txtFullName.Text.Trim()), P("@role", cboRole.Text), P("@email", txtStaffEmail.Text.Trim()), P("@contact", txtStaffContact.Text.Trim()), P("@status", cboStaffStatus.Text), P("@created", DateTime.Now), P("@updated", DateTime.Now))
            If affected <> 1 Then Throw New Exception("The Library Staff record was not inserted.")
            Dim newId As Integer = 0
            Dim newIdValue As Object = GetScalar("SELECT librarystaffid FROM LIBRARY_STAFF WHERE UPPER(employee_no) = @n", P("@n", employeeNo))
            If newIdValue IsNot Nothing AndAlso Not IsDBNull(newIdValue) Then Integer.TryParse(Convert.ToString(newIdValue), newId)
            If newId > 0 Then txtStaffID.Text = CStr(newId)
            WriteUserLog("Insert", "User Authentication", "LIBRARY_STAFF", newId, "Added library staff " & employeeNo)
            MessageBox.Show("Library staff saved successfully.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadStaff()
            RememberStaffState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmStaffUsers.StaffSave", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "save the Library Staff record"), "Save", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnStaffUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStaffUpdate.Click
        If _busy Then Exit Sub
        If Not RequireAdministrator() Then Exit Sub
        Dim staffId As Integer = 0
        If Not TrySelectedId(txtStaffID, staffId) Then
            MessageBox.Show("Select a valid staff record from the list first.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        NormalizeStaffInput()
        If Not IsStaffValid() Then Exit Sub
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT employee_no, full_name, role, status FROM LIBRARY_STAFF WHERE librarystaffid = @id", P("@id", staffId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This Library Staff record no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearStaffFields()
                LoadStaff()
                Exit Sub
            End If
            Dim employeeNo As String = CleanText(txtEmployeeNo.Text).ToUpperInvariant()
            If GetCount("SELECT COUNT(*) FROM LIBRARY_STAFF WHERE UPPER(employee_no) = @n AND librarystaffid <> @id", P("@n", employeeNo), P("@id", staffId)) > 0 Then
                FailValidation(txtEmployeeNo, "Employee No. is already used by another Library Staff record.")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM LIBRARY_STAFF WHERE UPPER(full_name) = @n AND librarystaffid <> @id", P("@n", txtFullName.Text.ToUpperInvariant()), P("@id", staffId)) > 0 Then
                If Not ConfirmAction("Another Library Staff record has the same full name. Continue updating this separate record?", "Possible Duplicate") Then
                    txtFullName.Focus()
                    Exit Sub
                End If
            End If
            If staffId = CurrentLibraryStaffID AndAlso cboStaffStatus.Text <> "Active" Then
                FailValidation(cboStaffStatus, "You cannot make your own Library Staff record inactive while you are logged in.")
                Exit Sub
            End If
            Dim linkedAccountCount As Integer = GetCount("SELECT COUNT(*) FROM USER_TABLE WHERE librarystaffid = @id", P("@id", staffId))
            Dim activeLinkedAccountCount As Integer = GetCount("SELECT COUNT(*) FROM USER_TABLE WHERE librarystaffid = @id AND UPPER(status) = 'ACTIVE'", P("@id", staffId))
            If cboStaffStatus.Text <> "Active" AndAlso activeLinkedAccountCount > 0 Then
                Dim linkedUsableAdminCount As Integer = GetCount("SELECT COUNT(*) FROM USER_TABLE WHERE librarystaffid = @id AND UPPER(user_level) = 'ADMINISTRATOR' AND UPPER(status) = 'ACTIVE'", P("@id", staffId))
                If linkedUsableAdminCount > 0 AndAlso Not OtherUsableAdministratorForStaff(staffId) Then
                    FailValidation(cboStaffStatus, "This staff record owns the last usable active Administrator account. Create or activate another Administrator first.")
                    Exit Sub
                End If
                If Not ConfirmAction("Making this staff record inactive will also prevent its " & activeLinkedAccountCount & " active login account(s) from signing in until the staff record is reactivated. Continue?", "Deactivate Staff") Then Exit Sub
                If linkedUsableAdminCount > 0 AndAlso Not VerifyCurrentAdministrator("deactivate a staff record linked to an Administrator account") Then Exit Sub
            End If
            If linkedAccountCount > 0 Then
                Dim linkedLevels As DataTable = GetTable("SELECT user_level FROM USER_TABLE WHERE librarystaffid = @id", P("@id", staffId))
                Dim mismatchedAccounts As Integer = 0
                Dim linkedLevelRow As DataRow
                For Each linkedLevelRow In linkedLevels.Rows
                    If Not RoleMatchesLevel(cboRole.Text, DbStr(linkedLevelRow, "user_level")) Then mismatchedAccounts += 1
                Next
                If mismatchedAccounts > 0 Then
                    If Not ConfirmAction("The selected Position (" & cboRole.Text & ") does not match " & mismatchedAccounts & " linked login System Role(s). The System Role in User Accounts controls access; Position is only the personnel record. Continue anyway?", "Position / System Role") Then
                        cboRole.Focus()
                        Exit Sub
                    End If
                End If
            End If
            Dim affected As Integer = RunNonQuery("UPDATE LIBRARY_STAFF SET employee_no=@eno, full_name=@name, role=@role, email=@email, contact_number=@contact, status=@status, updated_at=@updated WHERE librarystaffid=@id", P("@eno", employeeNo), P("@name", txtFullName.Text.Trim()), P("@role", cboRole.Text), P("@email", txtStaffEmail.Text.Trim()), P("@contact", txtStaffContact.Text.Trim()), P("@status", cboStaffStatus.Text), P("@updated", DateTime.Now), P("@id", staffId))
            If affected <> 1 Then
                MessageBox.Show("This Library Staff record no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearStaffFields()
                LoadStaff()
                Exit Sub
            End If
            WriteUserLog("Update", "User Authentication", "LIBRARY_STAFF", staffId, "Updated library staff " & employeeNo)
            MessageBox.Show("Library staff updated successfully.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadStaff()
            RememberStaffState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmStaffUsers.StaffUpdate", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "update the Library Staff record"), "Update", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnStaffDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStaffDelete.Click
        If _busy Then Exit Sub
        If Not RequireAdministrator() Then Exit Sub
        Dim staffId As Integer = 0
        If Not TrySelectedId(txtStaffID, staffId) Then
            MessageBox.Show("Select a valid staff record from the list first.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        If staffId = CurrentLibraryStaffID Then
            MessageBox.Show("You cannot delete your own staff record while logged in.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT employee_no, full_name FROM LIBRARY_STAFF WHERE librarystaffid = @id", P("@id", staffId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This Library Staff record no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearStaffFields()
                LoadStaff()
                Exit Sub
            End If
            Dim linkedAccountCount As Integer = GetCount("SELECT COUNT(*) FROM USER_TABLE WHERE librarystaffid = @id", P("@id", staffId))
            Dim processedBorrowCount As Integer = GetCount("SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE librarystaffid = @id", P("@id", staffId))
            If linkedAccountCount > 0 OrElse processedBorrowCount > 0 Then
                MessageBox.Show("This Library Staff record cannot be deleted because history must be kept. Linked login accounts: " & linkedAccountCount & ". Processed borrow transactions: " & processedBorrowCount & ". Set Status to Inactive instead.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim totalStaff As Integer = GetCount("SELECT COUNT(*) FROM LIBRARY_STAFF")
            If totalStaff <= 1 Then
                MessageBox.Show("At least one Library Staff record must remain.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim displayName As String = CleanText(DbStr(existing.Rows(0), "full_name") & " (" & DbStr(existing.Rows(0), "employee_no") & ")")
            If Not ConfirmAction("Delete Library Staff record " & displayName & "? This cannot be undone.", "Delete") Then Exit Sub
            Dim affected As Integer = RunNonQuery("DELETE FROM LIBRARY_STAFF WHERE librarystaffid=@id", P("@id", staffId))
            If affected <> 1 Then
                MessageBox.Show("This Library Staff record no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearStaffFields()
                LoadStaff()
                Exit Sub
            End If
            WriteUserLog("Delete", "User Authentication", "LIBRARY_STAFF", staffId, "Deleted library staff " & displayName)
            MessageBox.Show("Library staff deleted successfully.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearStaffFields()
            LoadStaff()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmStaffUsers.StaffDelete", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "delete the Library Staff record"), "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub dgvStaff_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvStaff.CellClick
        Try
            If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then Exit Sub
            Dim r As DataGridViewRow = dgvStaff.Rows(e.RowIndex)
            If r Is Nothing OrElse r.IsNewRow Then Exit Sub
            If CellInt(r, "librarystaffid") <= 0 Then
                MessageBox.Show("This row does not contain a valid Library Staff record.", "Library Staff", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If Not ConfirmDiscardStaffChanges() Then Exit Sub
            txtStaffID.Text = CStr(CellInt(r, "librarystaffid"))
            txtEmployeeNo.Text = CellStr(r, "employee_no")
            txtFullName.Text = CellStr(r, "full_name")
            cboRole.Text = CellStr(r, "role")
            txtStaffEmail.Text = CellStr(r, "email")
            txtStaffContact.Text = CellStr(r, "contact_number")
            cboStaffStatus.Text = CellStr(r, "status")
            RememberStaffState()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub LoadUsers()
        Try
            Dim dt As DataTable = GetTable("SELECT userid, username, CASE WHEN user_level = 'Staff' THEN 'Library Staff' ELSE user_level END AS user_level, status, last_login, created_at FROM USER_TABLE ORDER BY username")
            dgvUsers.DataSource = dt
            FormatUsersGrid()
            lblUserCount.Text = "Records: " & dt.Rows.Count
        Catch ex As Exception
            dgvUsers.DataSource = Nothing
            lblUserCount.Text = "Records: 0"
            MessageBox.Show(FriendlyDatabaseError(ex, "load user accounts"), "Users", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub ClearUserFields()
        txtUserID.Clear()
        txtUsername.Clear()
        txtUserPassword.Clear()
        txtConfirmPassword.Clear()
        cboUserLevel.Text = "Library Staff"
        cboUserStatus.Text = "Active"
        RememberUserState()
    End Sub
    Private Function IsUserValid(ByVal passwordRequired As Boolean) As Boolean
        If Not CheckTextBox(txtUsername, "Username", 50, True) Then Return False
        If Not UsernameOK(txtUsername.Text) Then Return FailValidation(txtUsername, "Username must start with a letter, contain at least 4 characters, and use only letters, numbers, periods, underscores, or hyphens.")
        Dim hasNewPassword As Boolean = txtUserPassword.Text <> ""
        Dim hasConfirmPassword As Boolean = txtConfirmPassword.Text <> ""
        If passwordRequired AndAlso Not hasNewPassword Then Return FailValidation(txtUserPassword, "New Password is required for a new login account.")
        If hasNewPassword <> hasConfirmPassword Then
            If passwordRequired Then Return FailValidation(txtConfirmPassword, "Enter the same password in both New Password and Confirm Password.")
            Return FailValidation(txtConfirmPassword, "To change the password, fill in both New Password and Confirm Password. To keep the current password, leave both blank.")
        End If
        If hasNewPassword Then
            If txtUserPassword.Text.Length < 8 OrElse txtUserPassword.Text.Length > 255 Then Return FailValidation(txtUserPassword, "New Password must contain at least 8 characters.")
            If txtUserPassword.Text <> CleanText(txtUserPassword.Text) Then Return FailValidation(txtUserPassword, "New Password must not contain spaces or unsupported characters.")
            If txtConfirmPassword.Text <> CleanText(txtConfirmPassword.Text) Then Return FailValidation(txtConfirmPassword, "Confirm Password must not contain spaces or unsupported characters.")
            Dim hasLetter As Boolean = False
            Dim hasDigit As Boolean = False
            Dim i As Integer
            For i = 0 To txtUserPassword.Text.Length - 1
                Dim ch As Char = txtUserPassword.Text.Chars(i)
                If Char.IsLetter(ch) Then hasLetter = True
                If Char.IsDigit(ch) Then hasDigit = True
            Next
            If Not hasLetter OrElse Not hasDigit Then Return FailValidation(txtUserPassword, "New Password must contain at least one letter and one number.")
            If String.Equals(txtUsername.Text, txtUserPassword.Text, StringComparison.OrdinalIgnoreCase) Then Return FailValidation(txtUserPassword, "New Password must not be the same as the Username.")
            If Not String.Equals(txtUserPassword.Text, txtConfirmPassword.Text, StringComparison.Ordinal) Then Return FailValidation(txtConfirmPassword, "New Password and Confirm Password do not match. Passwords are case-sensitive; please retype them carefully.")
        End If
        If Not RequireListValue(cboUserLevel, "System Role") Then Return False
        If Not RequireListValue(cboUserStatus, "Status") Then Return False
        Return True
    End Function
    Private Sub btnUserNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserNew.Click
        If Not ConfirmDiscardUserChanges() Then Exit Sub
        ClearUserFields()
        txtUsername.Focus()
    End Sub
    Private Sub btnUserClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserClear.Click
        If Not ConfirmDiscardUserChanges() Then Exit Sub
        ClearUserFields()
        LoadUsers()
    End Sub
    Private Sub btnUserSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserSave.Click
        If _busy Then Exit Sub
        If Not RequireAdministrator() Then Exit Sub
        NormalizeUserInput()
        If CleanText(txtUserID.Text) <> "" Then
            MessageBox.Show("This account already exists. Use UPDATE, or click NEW for a new account.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        If Not IsUserValid(True) Then Exit Sub
        _busy = True
        Try
            Dim username As String = CleanText(txtUsername.Text).ToLowerInvariant()
            If GetCount("SELECT COUNT(*) FROM USER_TABLE WHERE UPPER(username) = @u", P("@u", username.ToUpperInvariant())) > 0 Then
                FailValidation(txtUsername, "Username already exists.")
                Exit Sub
            End If
            Dim systemRole As String = SystemRoleToDb(cboUserLevel.Text)
            Dim systemRoleName As String = SystemRoleDisplay(systemRole)
            If systemRole = "Administrator" Then
                If Not VerifyCurrentAdministrator("create a new Administrator account '" & username & "'") Then Exit Sub
            End If
            Dim affected As Integer = RunNonQuery("INSERT INTO USER_TABLE (username, password, user_level, status, created_at) VALUES (@user,@pass,@level,@status,@created)", P("@user", username), P("@pass", HashPassword(txtUserPassword.Text)), P("@level", systemRole), P("@status", cboUserStatus.Text), P("@created", DateTime.Now))
            If affected <> 1 Then Throw New Exception("The user account was not inserted.")
            Dim newId As Integer = 0
            Dim newIdValue As Object = GetScalar("SELECT userid FROM USER_TABLE WHERE UPPER(username) = @u", P("@u", username.ToUpperInvariant()))
            If newIdValue IsNot Nothing AndAlso Not IsDBNull(newIdValue) Then Integer.TryParse(Convert.ToString(newIdValue), newId)
            If newId > 0 Then txtUserID.Text = CStr(newId)
            txtUserPassword.Clear()
            txtConfirmPassword.Clear()
            WriteUserLog("Insert", "User Authentication", "USER_TABLE", newId, "Created user account '" & username & "' (" & systemRoleName & ") with an encrypted password.")
            MessageBox.Show("User account saved successfully. The password was encrypted and cannot be viewed later.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadUsers()
            RememberUserState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmStaffUsers.UserSave", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "save the user account"), "Save", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnUserUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserUpdate.Click
        If _busy Then Exit Sub
        If Not RequireAdministrator() Then Exit Sub
        Dim userId As Integer = 0
        If Not TrySelectedId(txtUserID, userId) Then
            MessageBox.Show("Select a valid user account from the list first.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        NormalizeUserInput()
        If Not IsUserValid(False) Then Exit Sub
        If _savedUserSignature <> "" AndAlso String.Equals(CurrentUserSignature(), _savedUserSignature, StringComparison.Ordinal) Then
            MessageBox.Show("No changes were made to this user account. Change a field first, or enter and confirm a New Password if you only want to change the password.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT username, password, user_level, status FROM USER_TABLE WHERE userid = @id", P("@id", userId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This user account no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearUserFields()
                LoadUsers()
                Exit Sub
            End If
            Dim oldUsername As String = DbStr(existing.Rows(0), "username")
            Dim oldStoredPassword As String = DbStr(existing.Rows(0), "password")
            Dim oldLevel As String = DbStr(existing.Rows(0), "user_level")
            Dim oldStatus As String = DbStr(existing.Rows(0), "status")
            Dim username As String = CleanText(txtUsername.Text).ToLowerInvariant()
            Dim systemRole As String = SystemRoleToDb(cboUserLevel.Text)
            Dim systemRoleName As String = SystemRoleDisplay(systemRole)
            Dim passwordChangeRequested As Boolean = txtUserPassword.Text <> ""
            If oldStoredPassword = "" AndAlso Not passwordChangeRequested Then
                FailValidation(txtUserPassword, "This account has no stored password and cannot log in. Enter and confirm a New Password to repair it.")
                Exit Sub
            End If
            If passwordChangeRequested AndAlso VerifyPassword(txtUserPassword.Text, oldStoredPassword) Then
                FailValidation(txtUserPassword, "The New Password must be different from the current password.")
                Exit Sub
            End If
            If GetCount("SELECT COUNT(*) FROM USER_TABLE WHERE UPPER(username) = @u AND userid <> @id", P("@u", username.ToUpperInvariant()), P("@id", userId)) > 0 Then
                FailValidation(txtUsername, "Username is already used by another account.")
                Exit Sub
            End If
            If userId = CurrentUserID Then
                If cboUserStatus.Text <> "Active" Then
                    FailValidation(cboUserStatus, "You cannot deactivate the account you are currently using.")
                    Exit Sub
                End If
                If Not String.Equals(systemRole, oldLevel, StringComparison.OrdinalIgnoreCase) Then
                    FailValidation(cboUserLevel, "You cannot change the System Role of the account you are currently using.")
                    Exit Sub
                End If
            End If
            Dim oldUsableAdmin As Boolean = String.Equals(oldLevel, "Administrator", StringComparison.OrdinalIgnoreCase) AndAlso String.Equals(oldStatus, "Active", StringComparison.OrdinalIgnoreCase)
            Dim newUsableAdmin As Boolean = String.Equals(systemRole, "Administrator", StringComparison.OrdinalIgnoreCase) AndAlso String.Equals(cboUserStatus.Text, "Active", StringComparison.OrdinalIgnoreCase)
            If oldUsableAdmin AndAlso Not newUsableAdmin AndAlso Not OtherUsableAdministratorExists(userId) Then
                MessageBox.Show("This is the last usable active Administrator account. Create or activate another Administrator before deactivating or demoting this account.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If Not String.Equals(username, oldUsername, StringComparison.OrdinalIgnoreCase) AndAlso userId <> CurrentUserID Then
                If Not ConfirmAction("Changing the username will change how this person logs in. Continue?", "Change Username") Then
                    txtUsername.Focus()
                    Exit Sub
                End If
            End If
            Dim verified As Boolean = False
            If passwordChangeRequested Then
                verified = VerifyAccountOwnerPassword(oldStoredPassword, oldUsername)
                If Not verified Then Exit Sub
            End If
            Dim sensitiveAdminChange As Boolean = (String.Equals(oldLevel, "Administrator", StringComparison.OrdinalIgnoreCase) OrElse String.Equals(systemRole, "Administrator", StringComparison.OrdinalIgnoreCase)) AndAlso (Not String.Equals(username, oldUsername, StringComparison.OrdinalIgnoreCase) OrElse Not String.Equals(systemRole, oldLevel, StringComparison.OrdinalIgnoreCase) OrElse Not String.Equals(cboUserStatus.Text, oldStatus, StringComparison.OrdinalIgnoreCase))
            If sensitiveAdminChange AndAlso Not verified Then
                If Not VerifyCurrentAdministrator("change Administrator account '" & oldUsername & "'") Then Exit Sub
                verified = True
            End If
            If userId = CurrentUserID AndAlso (Not String.Equals(username, oldUsername, StringComparison.OrdinalIgnoreCase) OrElse passwordChangeRequested) Then
                If Not ConfirmAction("You are changing your own username or password. You will stay logged in now, but the new credentials will be required at the next login. Continue?", "Change Your Credentials") Then Exit Sub
            End If
            Dim passwordToSave As String = oldStoredPassword
            If passwordChangeRequested Then
                passwordToSave = HashPassword(txtUserPassword.Text)
            ElseIf Not oldStoredPassword.StartsWith("PBKDF2$") Then
                passwordToSave = HashPassword(oldStoredPassword)
            End If
            Dim affected As Integer = RunNonQuery("UPDATE USER_TABLE SET username=@user, password=@pass, user_level=@level, status=@status WHERE userid=@id", P("@user", username), P("@pass", passwordToSave), P("@level", systemRole), P("@status", cboUserStatus.Text), P("@id", userId))
            If affected <> 1 Then
                MessageBox.Show("This user account no longer exists. The list will be refreshed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearUserFields()
                LoadUsers()
                Exit Sub
            End If
            txtUserPassword.Clear()
            txtConfirmPassword.Clear()
            Dim logDetail As String = "Updated user account '" & username & "' (" & systemRoleName & ")."
            If passwordChangeRequested Then logDetail &= " Password changed after account-owner verification."
            WriteUserLog("Update", "User Authentication", "USER_TABLE", userId, logDetail)
            If passwordChangeRequested Then
                MessageBox.Show("User account and password updated successfully. The account owner must use the new password at the next login.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("User account updated successfully. The existing password was kept and remains hidden.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            LoadUsers()
            RememberUserState()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmStaffUsers.UserUpdate", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "update the user account"), "Update", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub btnUserDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserDelete.Click
        If _busy Then Exit Sub
        If Not RequireAdministrator() Then Exit Sub
        Dim userId As Integer = 0
        If Not TrySelectedId(txtUserID, userId) Then
            MessageBox.Show("Select a valid user account from the list first.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        If userId = CurrentUserID Then
            MessageBox.Show("You cannot delete the account you are currently using.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        _busy = True
        Try
            Dim existing As DataTable = GetTable("SELECT username, user_level, status FROM USER_TABLE WHERE userid = @id", P("@id", userId))
            If existing.Rows.Count = 0 Then
                MessageBox.Show("This user account no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearUserFields()
                LoadUsers()
                Exit Sub
            End If
            Dim targetLevel As String = DbStr(existing.Rows(0), "user_level")
            Dim isUsableAdmin As Boolean = String.Equals(targetLevel, "Administrator", StringComparison.OrdinalIgnoreCase) AndAlso String.Equals(DbStr(existing.Rows(0), "status"), "Active", StringComparison.OrdinalIgnoreCase)
            If isUsableAdmin AndAlso Not OtherUsableAdministratorExists(userId) Then
                MessageBox.Show("This is the last usable active Administrator account. Create or activate another Administrator before deleting it.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim userLogCount As Integer = GetCount("SELECT COUNT(*) FROM USER_LOGS WHERE userid = @id", P("@id", userId))
            If userLogCount > 0 Then
                MessageBox.Show("This account cannot be deleted because it has " & userLogCount & " user log record(s). Set Status to Inactive instead.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim displayName As String = DbStr(existing.Rows(0), "username")
            If Not ConfirmAction("Delete user account '" & displayName & "'? This cannot be undone.", "Delete") Then Exit Sub
            If String.Equals(targetLevel, "Administrator", StringComparison.OrdinalIgnoreCase) Then
                If Not VerifyCurrentAdministrator("delete Administrator account '" & displayName & "'") Then Exit Sub
            End If
            Dim affected As Integer = RunNonQuery("DELETE FROM USER_TABLE WHERE userid=@id", P("@id", userId))
            If affected <> 1 Then
                MessageBox.Show("This user account no longer exists. The list will be refreshed.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ClearUserFields()
                LoadUsers()
                Exit Sub
            End If
            WriteUserLog("Delete", "User Authentication", "USER_TABLE", userId, "Deleted user account '" & displayName & "'")
            MessageBox.Show("User account deleted successfully.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearUserFields()
            LoadUsers()
        Catch ex As Exception
            WriteSystemLog("Database", "Error", "frmStaffUsers.UserDelete", ex.Message)
            MessageBox.Show(FriendlyDatabaseError(ex, "delete the user account"), "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            _busy = False
        End Try
    End Sub
    Private Sub dgvUsers_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvUsers.CellClick
        Try
            If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then Exit Sub
            Dim r As DataGridViewRow = dgvUsers.Rows(e.RowIndex)
            If r Is Nothing OrElse r.IsNewRow Then Exit Sub
            If CellInt(r, "userid") <= 0 Then
                MessageBox.Show("This row does not contain a valid user account.", "Users", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            If Not ConfirmDiscardUserChanges() Then Exit Sub
            txtUserID.Text = CStr(CellInt(r, "userid"))
            txtUsername.Text = CellStr(r, "username")
            txtUserPassword.Clear()
            txtConfirmPassword.Clear()
            cboUserLevel.Text = SystemRoleDisplay(CellStr(r, "user_level"))
            cboUserStatus.Text = CellStr(r, "status")
            RememberUserState()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
