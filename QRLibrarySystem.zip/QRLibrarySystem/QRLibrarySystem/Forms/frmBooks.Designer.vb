<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBooks
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.grpBookInfo = New System.Windows.Forms.GroupBox()
        Me.lblBookID = New System.Windows.Forms.Label()
        Me.txtBookID = New System.Windows.Forms.TextBox()
        Me.lblAccessionNo = New System.Windows.Forms.Label()
        Me.txtAccessionNo = New System.Windows.Forms.TextBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.lblAuthor = New System.Windows.Forms.Label()
        Me.txtAuthor = New System.Windows.Forms.TextBox()
        Me.lblPublisher = New System.Windows.Forms.Label()
        Me.txtPublisher = New System.Windows.Forms.TextBox()
        Me.lblPublicationYear = New System.Windows.Forms.Label()
        Me.txtPublicationYear = New System.Windows.Forms.TextBox()
        Me.lblEdition = New System.Windows.Forms.Label()
        Me.txtEdition = New System.Windows.Forms.TextBox()
        Me.lblISBN = New System.Windows.Forms.Label()
        Me.txtISBN = New System.Windows.Forms.TextBox()
        Me.lblCategory = New System.Windows.Forms.Label()
        Me.cboCategory = New System.Windows.Forms.ComboBox()
        Me.lblShelfLocation = New System.Windows.Forms.Label()
        Me.txtShelfLocation = New System.Windows.Forms.TextBox()
        Me.lblTotalCopies = New System.Windows.Forms.Label()
        Me.nudTotalCopies = New System.Windows.Forms.NumericUpDown()
        Me.lblAvailableCopies = New System.Windows.Forms.Label()
        Me.nudAvailableCopies = New System.Windows.Forms.NumericUpDown()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.lblDateAcquired = New System.Windows.Forms.Label()
        Me.dtpDateAcquired = New System.Windows.Forms.DateTimePicker()
        Me.lblQRCode = New System.Windows.Forms.Label()
        Me.txtQRCode = New System.Windows.Forms.TextBox()
        Me.btnGenerateQR = New System.Windows.Forms.Button()
        Me.picQR = New System.Windows.Forms.PictureBox()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dgvBooks = New System.Windows.Forms.DataGridView()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnPrintQR = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.grpBookInfo.SuspendLayout()
        CType(Me.nudTotalCopies, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudAvailableCopies, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picQR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvBooks, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1200, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(700, 46)
        Me.lblFormTitle.Text = "Books"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblFormTitle.TabIndex = 1
        Me.grpBookInfo.Controls.Add(Me.picQR)
        Me.grpBookInfo.Controls.Add(Me.btnGenerateQR)
        Me.grpBookInfo.Controls.Add(Me.txtQRCode)
        Me.grpBookInfo.Controls.Add(Me.lblQRCode)
        Me.grpBookInfo.Controls.Add(Me.dtpDateAcquired)
        Me.grpBookInfo.Controls.Add(Me.lblDateAcquired)
        Me.grpBookInfo.Controls.Add(Me.cboStatus)
        Me.grpBookInfo.Controls.Add(Me.lblStatus)
        Me.grpBookInfo.Controls.Add(Me.nudAvailableCopies)
        Me.grpBookInfo.Controls.Add(Me.lblAvailableCopies)
        Me.grpBookInfo.Controls.Add(Me.nudTotalCopies)
        Me.grpBookInfo.Controls.Add(Me.lblTotalCopies)
        Me.grpBookInfo.Controls.Add(Me.txtShelfLocation)
        Me.grpBookInfo.Controls.Add(Me.lblShelfLocation)
        Me.grpBookInfo.Controls.Add(Me.cboCategory)
        Me.grpBookInfo.Controls.Add(Me.lblCategory)
        Me.grpBookInfo.Controls.Add(Me.txtISBN)
        Me.grpBookInfo.Controls.Add(Me.lblISBN)
        Me.grpBookInfo.Controls.Add(Me.txtEdition)
        Me.grpBookInfo.Controls.Add(Me.lblEdition)
        Me.grpBookInfo.Controls.Add(Me.txtPublicationYear)
        Me.grpBookInfo.Controls.Add(Me.lblPublicationYear)
        Me.grpBookInfo.Controls.Add(Me.txtPublisher)
        Me.grpBookInfo.Controls.Add(Me.lblPublisher)
        Me.grpBookInfo.Controls.Add(Me.txtAuthor)
        Me.grpBookInfo.Controls.Add(Me.lblAuthor)
        Me.grpBookInfo.Controls.Add(Me.txtTitle)
        Me.grpBookInfo.Controls.Add(Me.lblTitle)
        Me.grpBookInfo.Controls.Add(Me.txtAccessionNo)
        Me.grpBookInfo.Controls.Add(Me.lblAccessionNo)
        Me.grpBookInfo.Controls.Add(Me.txtBookID)
        Me.grpBookInfo.Controls.Add(Me.lblBookID)
        Me.grpBookInfo.Location = New System.Drawing.Point(12, 58)
        Me.grpBookInfo.Name = "grpBookInfo"
        Me.grpBookInfo.Size = New System.Drawing.Size(400, 530)
        Me.grpBookInfo.TabStop = False
        Me.grpBookInfo.Text = "Book"
        Me.grpBookInfo.TabIndex = 2
        Me.lblBookID.AutoSize = False
        Me.lblBookID.Location = New System.Drawing.Point(18, 30)
        Me.lblBookID.Size = New System.Drawing.Size(110, 20)
        Me.lblBookID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblBookID.Name = "lblBookID"
        Me.lblBookID.Text = "Book ID :"
        Me.lblBookID.TabIndex = 3
        Me.txtBookID.Location = New System.Drawing.Point(135, 30)
        Me.txtBookID.Name = "txtBookID"
        Me.txtBookID.Size = New System.Drawing.Size(245, 20)
        Me.txtBookID.ReadOnly = True
        Me.txtBookID.TabIndex = 4
        Me.lblAccessionNo.AutoSize = False
        Me.lblAccessionNo.Location = New System.Drawing.Point(18, 57)
        Me.lblAccessionNo.Size = New System.Drawing.Size(110, 20)
        Me.lblAccessionNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblAccessionNo.Name = "lblAccessionNo"
        Me.lblAccessionNo.Text = "Accession :"
        Me.lblAccessionNo.TabIndex = 5
        Me.txtAccessionNo.Location = New System.Drawing.Point(135, 57)
        Me.txtAccessionNo.Name = "txtAccessionNo"
        Me.txtAccessionNo.Size = New System.Drawing.Size(245, 20)
        Me.txtAccessionNo.TabIndex = 6
        Me.lblTitle.AutoSize = False
        Me.lblTitle.Location = New System.Drawing.Point(18, 84)
        Me.lblTitle.Size = New System.Drawing.Size(110, 20)
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Text = "Title :"
        Me.lblTitle.TabIndex = 7
        Me.txtTitle.Location = New System.Drawing.Point(135, 84)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(245, 20)
        Me.txtTitle.TabIndex = 8
        Me.lblAuthor.AutoSize = False
        Me.lblAuthor.Location = New System.Drawing.Point(18, 111)
        Me.lblAuthor.Size = New System.Drawing.Size(110, 20)
        Me.lblAuthor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblAuthor.Name = "lblAuthor"
        Me.lblAuthor.Text = "Author :"
        Me.lblAuthor.TabIndex = 9
        Me.txtAuthor.Location = New System.Drawing.Point(135, 111)
        Me.txtAuthor.Name = "txtAuthor"
        Me.txtAuthor.Size = New System.Drawing.Size(245, 20)
        Me.txtAuthor.TabIndex = 10
        Me.lblPublisher.AutoSize = False
        Me.lblPublisher.Location = New System.Drawing.Point(18, 138)
        Me.lblPublisher.Size = New System.Drawing.Size(110, 20)
        Me.lblPublisher.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblPublisher.Name = "lblPublisher"
        Me.lblPublisher.Text = "Publisher :"
        Me.lblPublisher.TabIndex = 11
        Me.txtPublisher.Location = New System.Drawing.Point(135, 138)
        Me.txtPublisher.Name = "txtPublisher"
        Me.txtPublisher.Size = New System.Drawing.Size(245, 20)
        Me.txtPublisher.TabIndex = 12
        Me.lblPublicationYear.AutoSize = False
        Me.lblPublicationYear.Location = New System.Drawing.Point(18, 165)
        Me.lblPublicationYear.Size = New System.Drawing.Size(110, 20)
        Me.lblPublicationYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblPublicationYear.Name = "lblPublicationYear"
        Me.lblPublicationYear.Text = "Year Published :"
        Me.lblPublicationYear.TabIndex = 13
        Me.txtPublicationYear.Location = New System.Drawing.Point(135, 165)
        Me.txtPublicationYear.Name = "txtPublicationYear"
        Me.txtPublicationYear.Size = New System.Drawing.Size(80, 20)
        Me.txtPublicationYear.TabIndex = 14
        Me.lblEdition.AutoSize = True
        Me.lblEdition.Location = New System.Drawing.Point(225, 168)
        Me.lblEdition.Name = "lblEdition"
        Me.lblEdition.Text = "Edition :"
        Me.lblEdition.TabIndex = 15
        Me.txtEdition.Location = New System.Drawing.Point(280, 165)
        Me.txtEdition.Name = "txtEdition"
        Me.txtEdition.Size = New System.Drawing.Size(100, 20)
        Me.txtEdition.TabIndex = 16
        Me.lblISBN.AutoSize = False
        Me.lblISBN.Location = New System.Drawing.Point(18, 192)
        Me.lblISBN.Size = New System.Drawing.Size(110, 20)
        Me.lblISBN.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblISBN.Name = "lblISBN"
        Me.lblISBN.Text = "ISBN :"
        Me.lblISBN.TabIndex = 17
        Me.txtISBN.Location = New System.Drawing.Point(135, 192)
        Me.txtISBN.Name = "txtISBN"
        Me.txtISBN.Size = New System.Drawing.Size(245, 20)
        Me.txtISBN.TabIndex = 18
        Me.lblCategory.AutoSize = False
        Me.lblCategory.Location = New System.Drawing.Point(18, 219)
        Me.lblCategory.Size = New System.Drawing.Size(110, 20)
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Text = "Category :"
        Me.lblCategory.TabIndex = 19
        Me.cboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(135, 219)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(245, 21)
        Me.cboCategory.TabIndex = 20
        Me.lblShelfLocation.AutoSize = False
        Me.lblShelfLocation.Location = New System.Drawing.Point(18, 246)
        Me.lblShelfLocation.Size = New System.Drawing.Size(110, 20)
        Me.lblShelfLocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblShelfLocation.Name = "lblShelfLocation"
        Me.lblShelfLocation.Text = "Shelf Location :"
        Me.lblShelfLocation.TabIndex = 21
        Me.txtShelfLocation.Location = New System.Drawing.Point(135, 246)
        Me.txtShelfLocation.Name = "txtShelfLocation"
        Me.txtShelfLocation.Size = New System.Drawing.Size(245, 20)
        Me.txtShelfLocation.TabIndex = 22
        Me.lblTotalCopies.AutoSize = False
        Me.lblTotalCopies.Location = New System.Drawing.Point(18, 273)
        Me.lblTotalCopies.Size = New System.Drawing.Size(110, 20)
        Me.lblTotalCopies.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblTotalCopies.Name = "lblTotalCopies"
        Me.lblTotalCopies.Text = "Total Copies :"
        Me.lblTotalCopies.TabIndex = 23
        Me.nudTotalCopies.Location = New System.Drawing.Point(135, 273)
        Me.nudTotalCopies.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudTotalCopies.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudTotalCopies.Name = "nudTotalCopies"
        Me.nudTotalCopies.Size = New System.Drawing.Size(70, 20)
        Me.nudTotalCopies.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudTotalCopies.TabIndex = 24
        Me.lblAvailableCopies.AutoSize = True
        Me.lblAvailableCopies.Location = New System.Drawing.Point(215, 276)
        Me.lblAvailableCopies.Name = "lblAvailableCopies"
        Me.lblAvailableCopies.Text = "Available :"
        Me.lblAvailableCopies.TabIndex = 25
        Me.nudAvailableCopies.Location = New System.Drawing.Point(285, 273)
        Me.nudAvailableCopies.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudAvailableCopies.Name = "nudAvailableCopies"
        Me.nudAvailableCopies.Size = New System.Drawing.Size(95, 20)
        Me.nudAvailableCopies.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudAvailableCopies.TabIndex = 26
        Me.lblStatus.AutoSize = False
        Me.lblStatus.Location = New System.Drawing.Point(18, 300)
        Me.lblStatus.Size = New System.Drawing.Size(110, 20)
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Text = "Status :"
        Me.lblStatus.TabIndex = 27
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Items.AddRange(New Object() {"Available", "Borrowed", "Lost", "Damaged", "Reserved"})
        Me.cboStatus.Location = New System.Drawing.Point(135, 300)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(245, 21)
        Me.cboStatus.TabIndex = 28
        Me.lblDateAcquired.AutoSize = False
        Me.lblDateAcquired.Location = New System.Drawing.Point(18, 327)
        Me.lblDateAcquired.Size = New System.Drawing.Size(110, 20)
        Me.lblDateAcquired.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblDateAcquired.Name = "lblDateAcquired"
        Me.lblDateAcquired.Text = "Date Acquired :"
        Me.lblDateAcquired.TabIndex = 29
        Me.dtpDateAcquired.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpDateAcquired.Location = New System.Drawing.Point(135, 327)
        Me.dtpDateAcquired.Name = "dtpDateAcquired"
        Me.dtpDateAcquired.Size = New System.Drawing.Size(245, 20)
        Me.dtpDateAcquired.TabIndex = 30
        Me.lblQRCode.AutoSize = False
        Me.lblQRCode.Location = New System.Drawing.Point(18, 354)
        Me.lblQRCode.Size = New System.Drawing.Size(110, 20)
        Me.lblQRCode.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblQRCode.Name = "lblQRCode"
        Me.lblQRCode.Text = "QR Code :"
        Me.lblQRCode.TabIndex = 31
        Me.txtQRCode.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtQRCode.Location = New System.Drawing.Point(135, 354)
        Me.txtQRCode.Name = "txtQRCode"
        Me.txtQRCode.Size = New System.Drawing.Size(245, 20)
        Me.txtQRCode.ReadOnly = True
        Me.txtQRCode.TabIndex = 32
        Me.btnGenerateQR.Location = New System.Drawing.Point(265, 382)
        Me.btnGenerateQR.Name = "btnGenerateQR"
        Me.btnGenerateQR.Size = New System.Drawing.Size(115, 40)
        Me.btnGenerateQR.Text = "Generate QR"
        Me.btnGenerateQR.UseVisualStyleBackColor = True
        Me.btnGenerateQR.TabIndex = 33
        Me.picQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picQR.Location = New System.Drawing.Point(135, 382)
        Me.picQR.Name = "picQR"
        Me.picQR.Size = New System.Drawing.Size(120, 120)
        Me.picQR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picQR.TabStop = False
        Me.picQR.TabIndex = 34
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Location = New System.Drawing.Point(432, 68)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Text = "Search"
        Me.lblSearch.TabIndex = 35
        Me.txtSearch.Location = New System.Drawing.Point(485, 65)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(566, 20)
        Me.txtSearch.TabIndex = 36
        Me.btnSearch.Location = New System.Drawing.Point(1061, 58)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(115, 32)
        Me.btnSearch.Text = "&Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        Me.btnSearch.TabIndex = 37
        Me.dgvBooks.AllowUserToAddRows = False
        Me.dgvBooks.AllowUserToDeleteRows = False
        Me.dgvBooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBooks.Location = New System.Drawing.Point(432, 100)
        Me.dgvBooks.MultiSelect = False
        Me.dgvBooks.Name = "dgvBooks"
        Me.dgvBooks.ReadOnly = True
        Me.dgvBooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvBooks.Size = New System.Drawing.Size(744, 475)
        Me.dgvBooks.TabIndex = 38
        Me.lblCount.AutoSize = True
        Me.lblCount.Location = New System.Drawing.Point(432, 585)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Text = "Records: 0"
        Me.lblCount.TabIndex = 39
        Me.btnNew.Location = New System.Drawing.Point(12, 615)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(85, 34)
        Me.btnNew.Text = "&New"
        Me.btnNew.UseVisualStyleBackColor = True
        Me.btnNew.TabIndex = 40
        Me.btnSave.Location = New System.Drawing.Point(105, 615)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(85, 34)
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        Me.btnSave.TabIndex = 41
        Me.btnUpdate.Location = New System.Drawing.Point(198, 615)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(85, 34)
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        Me.btnUpdate.TabIndex = 42
        Me.btnDelete.Location = New System.Drawing.Point(291, 615)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(85, 34)
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        Me.btnDelete.TabIndex = 43
        Me.btnClear.Location = New System.Drawing.Point(384, 615)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(85, 34)
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        Me.btnClear.TabIndex = 44
        Me.btnPrintQR.Location = New System.Drawing.Point(477, 615)
        Me.btnPrintQR.Name = "btnPrintQR"
        Me.btnPrintQR.Size = New System.Drawing.Size(150, 34)
        Me.btnPrintQR.Text = "&Print QR"
        Me.btnPrintQR.UseVisualStyleBackColor = True
        Me.btnPrintQR.TabIndex = 45
        Me.btnClose.Location = New System.Drawing.Point(1061, 615)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(115, 34)
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.btnClose.TabIndex = 46
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 661)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnPrintQR)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.dgvBooks)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.lblSearch)
        Me.Controls.Add(Me.grpBookInfo)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmBooks"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Books"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.grpBookInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpBookInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpBookInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpBookInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblBookID.BackColor = System.Drawing.Color.Transparent
        Me.lblBookID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtBookID.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.txtBookID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtBookID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBookID.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblAccessionNo.BackColor = System.Drawing.Color.Transparent
        Me.lblAccessionNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtAccessionNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtAccessionNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtAccessionNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAccessionNo.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTitle.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblAuthor.BackColor = System.Drawing.Color.Transparent
        Me.lblAuthor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtAuthor.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtAuthor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtAuthor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAuthor.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblPublisher.BackColor = System.Drawing.Color.Transparent
        Me.lblPublisher.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtPublisher.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtPublisher.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtPublisher.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPublisher.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblPublicationYear.BackColor = System.Drawing.Color.Transparent
        Me.lblPublicationYear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtPublicationYear.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtPublicationYear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtPublicationYear.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPublicationYear.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblEdition.BackColor = System.Drawing.Color.Transparent
        Me.lblEdition.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtEdition.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtEdition.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtEdition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEdition.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblISBN.BackColor = System.Drawing.Color.Transparent
        Me.lblISBN.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtISBN.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtISBN.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtISBN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtISBN.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblCategory.BackColor = System.Drawing.Color.Transparent
        Me.lblCategory.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboCategory.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboCategory.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboCategory.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblShelfLocation.BackColor = System.Drawing.Color.Transparent
        Me.lblShelfLocation.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtShelfLocation.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtShelfLocation.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtShelfLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShelfLocation.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblTotalCopies.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalCopies.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.nudTotalCopies.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.nudTotalCopies.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.nudTotalCopies.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nudTotalCopies.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblAvailableCopies.BackColor = System.Drawing.Color.Transparent
        Me.lblAvailableCopies.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.nudAvailableCopies.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.nudAvailableCopies.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.nudAvailableCopies.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nudAvailableCopies.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboStatus.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDateAcquired.BackColor = System.Drawing.Color.Transparent
        Me.lblDateAcquired.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpDateAcquired.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.dtpDateAcquired.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpDateAcquired.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dtpDateAcquired.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpDateAcquired.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dtpDateAcquired.CalendarTitleBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpDateAcquired.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dtpDateAcquired.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblQRCode.BackColor = System.Drawing.Color.Transparent
        Me.lblQRCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtQRCode.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtQRCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtQRCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQRCode.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnGenerateQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGenerateQR.FlatAppearance.BorderSize = 1
        Me.btnGenerateQR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnGenerateQR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnGenerateQR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnGenerateQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnGenerateQR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnGenerateQR.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnGenerateQR.UseVisualStyleBackColor = False
        Me.btnGenerateQR.Cursor = System.Windows.Forms.Cursors.Hand

        Me.picQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.picQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSearch.BackColor = System.Drawing.Color.Transparent
        Me.lblSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.FlatAppearance.BorderSize = 1
        Me.btnSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSearch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnSearch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSearch.UseVisualStyleBackColor = False
        Me.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvBooks.EnableHeadersVisualStyles = False
        Me.dgvBooks.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvBooks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvBooks.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvBooks.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvBooks.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvBooks.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvBooks.ColumnHeadersHeight = 32
        Me.dgvBooks.RowTemplate.Height = 24
        Me.dgvBooks.RowHeadersVisible = False
        Me.dgvBooks.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvBooks.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvBooks.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvBooks.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvBooks.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvBooks.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvBooks.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvBooks.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvBooks.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvBooks.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvBooks.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvBooks.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvBooks.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvBooks.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvBooks.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvBooks.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvBooks.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvBooks.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvBooks.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblCount.BackColor = System.Drawing.Color.Transparent
        Me.lblCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNew.FlatAppearance.BorderSize = 1
        Me.btnNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnNew.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnNew.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnNew.UseVisualStyleBackColor = False
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.FlatAppearance.BorderSize = 2
        Me.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSave.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSave.UseVisualStyleBackColor = False
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.FlatAppearance.BorderSize = 1
        Me.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUpdate.UseVisualStyleBackColor = False
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.FlatAppearance.BorderSize = 1
        Me.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.btnDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnDelete.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnDelete.UseVisualStyleBackColor = False
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.FlatAppearance.BorderSize = 1
        Me.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnPrintQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPrintQR.FlatAppearance.BorderSize = 1
        Me.btnPrintQR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnPrintQR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnPrintQR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnPrintQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnPrintQR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPrintQR.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnPrintQR.UseVisualStyleBackColor = False
        Me.btnPrintQR.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.pnlHeader.ResumeLayout(False)
        Me.grpBookInfo.ResumeLayout(False)
        Me.grpBookInfo.PerformLayout()
        CType(Me.nudTotalCopies, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudAvailableCopies, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picQR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvBooks, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents grpBookInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblBookID As System.Windows.Forms.Label
    Friend WithEvents txtBookID As System.Windows.Forms.TextBox
    Friend WithEvents lblAccessionNo As System.Windows.Forms.Label
    Friend WithEvents txtAccessionNo As System.Windows.Forms.TextBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents lblAuthor As System.Windows.Forms.Label
    Friend WithEvents txtAuthor As System.Windows.Forms.TextBox
    Friend WithEvents lblPublisher As System.Windows.Forms.Label
    Friend WithEvents txtPublisher As System.Windows.Forms.TextBox
    Friend WithEvents lblPublicationYear As System.Windows.Forms.Label
    Friend WithEvents txtPublicationYear As System.Windows.Forms.TextBox
    Friend WithEvents lblEdition As System.Windows.Forms.Label
    Friend WithEvents txtEdition As System.Windows.Forms.TextBox
    Friend WithEvents lblISBN As System.Windows.Forms.Label
    Friend WithEvents txtISBN As System.Windows.Forms.TextBox
    Friend WithEvents lblCategory As System.Windows.Forms.Label
    Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
    Friend WithEvents lblShelfLocation As System.Windows.Forms.Label
    Friend WithEvents txtShelfLocation As System.Windows.Forms.TextBox
    Friend WithEvents lblTotalCopies As System.Windows.Forms.Label
    Friend WithEvents nudTotalCopies As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblAvailableCopies As System.Windows.Forms.Label
    Friend WithEvents nudAvailableCopies As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblDateAcquired As System.Windows.Forms.Label
    Friend WithEvents dtpDateAcquired As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblQRCode As System.Windows.Forms.Label
    Friend WithEvents txtQRCode As System.Windows.Forms.TextBox
    Friend WithEvents btnGenerateQR As System.Windows.Forms.Button
    Friend WithEvents picQR As System.Windows.Forms.PictureBox
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents dgvBooks As System.Windows.Forms.DataGridView
    Friend WithEvents lblCount As System.Windows.Forms.Label
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnPrintQR As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
