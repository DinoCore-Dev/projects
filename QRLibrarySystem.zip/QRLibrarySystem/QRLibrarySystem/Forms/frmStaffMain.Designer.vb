<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStaffMain
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.mFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mFileLogout = New System.Windows.Forms.ToolStripMenuItem()
        Me.mFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mManagement = New System.Windows.Forms.ToolStripMenuItem()
        Me.mStudents = New System.Windows.Forms.ToolStripMenuItem()
        Me.mFaculty = New System.Windows.Forms.ToolStripMenuItem()
        Me.mBooks = New System.Windows.Forms.ToolStripMenuItem()
        Me.mCategories = New System.Windows.Forms.ToolStripMenuItem()
        Me.mStaffUsers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mTransactions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mVisitor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mBorrowReturn = New System.Windows.Forms.ToolStripMenuItem()
        Me.mReports = New System.Windows.Forms.ToolStripMenuItem()
        Me.mLogs = New System.Windows.Forms.ToolStripMenuItem()
        Me.mHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnlSide = New System.Windows.Forms.Panel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnLogs = New System.Windows.Forms.Button()
        Me.btnStaffUsers = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.btnBorrowReturn = New System.Windows.Forms.Button()
        Me.btnVisitorLog = New System.Windows.Forms.Button()
        Me.btnCategories = New System.Windows.Forms.Button()
        Me.btnBooks = New System.Windows.Forms.Button()
        Me.btnFaculty = New System.Windows.Forms.Button()
        Me.btnStudents = New System.Windows.Forms.Button()
        Me.lblSideTitle = New System.Windows.Forms.Label()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.grpStats = New System.Windows.Forms.GroupBox()
        Me.lblStatOverdue = New System.Windows.Forms.Label()
        Me.lblOverdueTitle = New System.Windows.Forms.Label()
        Me.lblStatBorrowed = New System.Windows.Forms.Label()
        Me.lblBorrowedStatTitle = New System.Windows.Forms.Label()
        Me.lblStatVisitorsToday = New System.Windows.Forms.Label()
        Me.lblVisitorsTitle = New System.Windows.Forms.Label()
        Me.lblStatFaculty = New System.Windows.Forms.Label()
        Me.lblFacultyTitle = New System.Windows.Forms.Label()
        Me.lblStatStudents = New System.Windows.Forms.Label()
        Me.lblStudentsTitle = New System.Windows.Forms.Label()
        Me.lblStatBooks = New System.Windows.Forms.Label()
        Me.lblBooksTitle = New System.Windows.Forms.Label()
        Me.lblCurrentBorrowedTitle = New System.Windows.Forms.Label()
        Me.dgvCurrentBorrowed = New System.Windows.Forms.DataGridView()
        Me.btnRefreshDashboard = New System.Windows.Forms.Button()
        Me.stsMain = New System.Windows.Forms.StatusStrip()
        Me.lblCurrentUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDateTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tmrClock = New System.Windows.Forms.Timer(Me.components)
        Me.mnuMain.SuspendLayout()
        Me.pnlSide.SuspendLayout()
        Me.grpStats.SuspendLayout()
        CType(Me.dgvCurrentBorrowed, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.stsMain.SuspendLayout()
        Me.SuspendLayout()
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mFile, Me.mManagement, Me.mTransactions, Me.mReports, Me.mLogs, Me.mHelp})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(1024, 24)
        Me.mnuMain.TabIndex = 0
        Me.mnuMain.Text = "MenuStrip1"
        Me.mFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mFileLogout, Me.mFileExit})
        Me.mFile.Name = "mFile"
        Me.mFile.Size = New System.Drawing.Size(37, 20)
        Me.mFile.Text = "&File"
        Me.mFileLogout.Name = "mFileLogout"
        Me.mFileLogout.Size = New System.Drawing.Size(112, 22)
        Me.mFileLogout.Text = "&Logout"
        Me.mFileExit.Name = "mFileExit"
        Me.mFileExit.Size = New System.Drawing.Size(112, 22)
        Me.mFileExit.Text = "E&xit"
        Me.mManagement.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mStudents, Me.mFaculty, Me.mBooks, Me.mCategories, Me.mStaffUsers})
        Me.mManagement.Name = "mManagement"
        Me.mManagement.Size = New System.Drawing.Size(90, 20)
        Me.mManagement.Text = "&Management"
        Me.mStudents.Name = "mStudents"
        Me.mStudents.Size = New System.Drawing.Size(203, 22)
        Me.mStudents.Text = "&View Students"
        Me.mFaculty.Name = "mFaculty"
        Me.mFaculty.Visible = False
        Me.mFaculty.Size = New System.Drawing.Size(203, 22)
        Me.mFaculty.Text = "&Faculty && Staff"
        Me.mBooks.Name = "mBooks"
        Me.mBooks.Size = New System.Drawing.Size(203, 22)
        Me.mBooks.Text = "&View Books"
        Me.mCategories.Name = "mCategories"
        Me.mCategories.Visible = False
        Me.mCategories.Size = New System.Drawing.Size(203, 22)
        Me.mCategories.Text = "Book &Categories"
        Me.mStaffUsers.Name = "mStaffUsers"
        Me.mStaffUsers.Visible = False
        Me.mStaffUsers.Size = New System.Drawing.Size(203, 22)
        Me.mStaffUsers.Text = "Staff && &Users"
        Me.mTransactions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mVisitor, Me.mBorrowReturn})
        Me.mTransactions.Name = "mTransactions"
        Me.mTransactions.Size = New System.Drawing.Size(86, 20)
        Me.mTransactions.Text = "&Transactions"
        Me.mVisitor.Name = "mVisitor"
        Me.mVisitor.Size = New System.Drawing.Size(228, 22)
        Me.mVisitor.Text = "&Visitor Log"
        Me.mBorrowReturn.Name = "mBorrowReturn"
        Me.mBorrowReturn.Size = New System.Drawing.Size(228, 22)
        Me.mBorrowReturn.Text = "&Borrow && Return"
        Me.mReports.Name = "mReports"
        Me.mReports.Visible = False
        Me.mReports.Size = New System.Drawing.Size(59, 20)
        Me.mReports.Text = "&Reports"
        Me.mLogs.Name = "mLogs"
        Me.mLogs.Visible = False
        Me.mLogs.Size = New System.Drawing.Size(127, 20)
        Me.mLogs.Text = "&Logs && Backup"
        Me.mHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mAbout})
        Me.mHelp.Name = "mHelp"
        Me.mHelp.Size = New System.Drawing.Size(44, 20)
        Me.mHelp.Text = "&Help"
        Me.mAbout.Name = "mAbout"
        Me.mAbout.Size = New System.Drawing.Size(107, 22)
        Me.mAbout.Text = "&About"
        Me.pnlSide.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlSide.Controls.Add(Me.btnLogout)
        Me.pnlSide.Controls.Add(Me.btnLogs)
        Me.pnlSide.Controls.Add(Me.btnStaffUsers)
        Me.pnlSide.Controls.Add(Me.btnReports)
        Me.pnlSide.Controls.Add(Me.btnBorrowReturn)
        Me.pnlSide.Controls.Add(Me.btnVisitorLog)
        Me.pnlSide.Controls.Add(Me.btnCategories)
        Me.pnlSide.Controls.Add(Me.btnBooks)
        Me.pnlSide.Controls.Add(Me.btnFaculty)
        Me.pnlSide.Controls.Add(Me.btnStudents)
        Me.pnlSide.Controls.Add(Me.lblSideTitle)
        Me.pnlSide.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlSide.Location = New System.Drawing.Point(0, 24)
        Me.pnlSide.Name = "pnlSide"
        Me.pnlSide.Size = New System.Drawing.Size(215, 654)
        Me.pnlSide.TabIndex = 1
        Me.btnLogout.Location = New System.Drawing.Point(16, 555)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(183, 38)
        Me.btnLogout.TabIndex = 10
        Me.btnLogout.Text = "Logout"
        Me.btnLogout.UseVisualStyleBackColor = True
        Me.btnLogs.Location = New System.Drawing.Point(16, 499)
        Me.btnLogs.Name = "btnLogs"
        Me.btnLogs.Visible = False
        Me.btnLogs.Size = New System.Drawing.Size(183, 38)
        Me.btnLogs.TabIndex = 9
        Me.btnLogs.Text = "Logs && Backup"
        Me.btnLogs.UseVisualStyleBackColor = True
        Me.btnStaffUsers.Location = New System.Drawing.Point(16, 453)
        Me.btnStaffUsers.Name = "btnStaffUsers"
        Me.btnStaffUsers.Visible = False
        Me.btnStaffUsers.Size = New System.Drawing.Size(183, 38)
        Me.btnStaffUsers.TabIndex = 8
        Me.btnStaffUsers.Text = "Staff && Users"
        Me.btnStaffUsers.UseVisualStyleBackColor = True
        Me.btnReports.Location = New System.Drawing.Point(16, 407)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Visible = False
        Me.btnReports.Size = New System.Drawing.Size(183, 38)
        Me.btnReports.TabIndex = 7
        Me.btnReports.Text = "Reports"
        Me.btnReports.UseVisualStyleBackColor = True
        Me.btnBorrowReturn.Location = New System.Drawing.Point(16, 269)
        Me.btnBorrowReturn.Name = "btnBorrowReturn"
        Me.btnBorrowReturn.Size = New System.Drawing.Size(183, 38)
        Me.btnBorrowReturn.TabIndex = 6
        Me.btnBorrowReturn.Text = "Borrow && Return"
        Me.btnBorrowReturn.UseVisualStyleBackColor = True
        Me.btnVisitorLog.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVisitorLog.Location = New System.Drawing.Point(16, 223)
        Me.btnVisitorLog.Name = "btnVisitorLog"
        Me.btnVisitorLog.Size = New System.Drawing.Size(183, 38)
        Me.btnVisitorLog.TabIndex = 5
        Me.btnVisitorLog.Text = "Visitor Log"
        Me.btnVisitorLog.UseVisualStyleBackColor = True
        Me.btnCategories.Location = New System.Drawing.Point(16, 269)
        Me.btnCategories.Name = "btnCategories"
        Me.btnCategories.Visible = False
        Me.btnCategories.Size = New System.Drawing.Size(183, 38)
        Me.btnCategories.TabIndex = 4
        Me.btnCategories.Text = "Categories"
        Me.btnCategories.UseVisualStyleBackColor = True
        Me.btnBooks.Location = New System.Drawing.Point(16, 177)
        Me.btnBooks.Name = "btnBooks"
        Me.btnBooks.Size = New System.Drawing.Size(183, 38)
        Me.btnBooks.TabIndex = 3
        Me.btnBooks.Text = "View Books"
        Me.btnBooks.UseVisualStyleBackColor = True
        Me.btnFaculty.Location = New System.Drawing.Point(16, 177)
        Me.btnFaculty.Name = "btnFaculty"
        Me.btnFaculty.Visible = False
        Me.btnFaculty.Size = New System.Drawing.Size(183, 38)
        Me.btnFaculty.TabIndex = 2
        Me.btnFaculty.Text = "Faculty && Staff"
        Me.btnFaculty.UseVisualStyleBackColor = True
        Me.btnStudents.Location = New System.Drawing.Point(16, 131)
        Me.btnStudents.Name = "btnStudents"
        Me.btnStudents.Size = New System.Drawing.Size(183, 38)
        Me.btnStudents.TabIndex = 1
        Me.btnStudents.Text = "View Students"
        Me.btnStudents.UseVisualStyleBackColor = True
        Me.lblSideTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSideTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblSideTitle.Location = New System.Drawing.Point(12, 15)
        Me.lblSideTitle.Name = "lblSideTitle"
        Me.lblSideTitle.Size = New System.Drawing.Size(191, 95)
        Me.lblSideTitle.TabIndex = 0
        Me.lblSideTitle.Text = "STAFF" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "QR LIBRARY"
        Me.lblSideTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblWelcome.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.Location = New System.Drawing.Point(236, 40)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(620, 30)
        Me.lblWelcome.TabIndex = 2
        Me.lblWelcome.Text = "Welcome!"
        Me.grpStats.Controls.Add(Me.lblStatOverdue)
        Me.grpStats.Controls.Add(Me.lblOverdueTitle)
        Me.grpStats.Controls.Add(Me.lblStatBorrowed)
        Me.grpStats.Controls.Add(Me.lblBorrowedStatTitle)
        Me.grpStats.Controls.Add(Me.lblStatVisitorsToday)
        Me.grpStats.Controls.Add(Me.lblVisitorsTitle)
        Me.grpStats.Controls.Add(Me.lblStatFaculty)
        Me.grpStats.Controls.Add(Me.lblFacultyTitle)
        Me.grpStats.Controls.Add(Me.lblStatStudents)
        Me.grpStats.Controls.Add(Me.lblStudentsTitle)
        Me.grpStats.Controls.Add(Me.lblStatBooks)
        Me.grpStats.Controls.Add(Me.lblBooksTitle)
        Me.grpStats.Location = New System.Drawing.Point(236, 82)
        Me.grpStats.Name = "grpStats"
        Me.grpStats.Size = New System.Drawing.Size(764, 150)
        Me.grpStats.TabIndex = 3
        Me.grpStats.TabStop = False
        Me.grpStats.Text = "Dashboard"
        Me.lblStatOverdue.Font = New System.Drawing.Font("Segoe UI Semibold", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatOverdue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.lblStatOverdue.Location = New System.Drawing.Point(625, 85)
        Me.lblStatOverdue.Name = "lblStatOverdue"
        Me.lblStatOverdue.Size = New System.Drawing.Size(120, 42)
        Me.lblStatOverdue.TabIndex = 11
        Me.lblStatOverdue.Text = "0"
        Me.lblStatOverdue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblOverdueTitle.Location = New System.Drawing.Point(625, 55)
        Me.lblOverdueTitle.Name = "lblOverdueTitle"
        Me.lblOverdueTitle.Size = New System.Drawing.Size(120, 20)
        Me.lblOverdueTitle.TabIndex = 10
        Me.lblOverdueTitle.Text = "Overdue Books"
        Me.lblOverdueTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStatBorrowed.Font = New System.Drawing.Font("Segoe UI Semibold", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatBorrowed.Location = New System.Drawing.Point(500, 85)
        Me.lblStatBorrowed.Name = "lblStatBorrowed"
        Me.lblStatBorrowed.Size = New System.Drawing.Size(120, 42)
        Me.lblStatBorrowed.TabIndex = 9
        Me.lblStatBorrowed.Text = "0"
        Me.lblStatBorrowed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblBorrowedStatTitle.Location = New System.Drawing.Point(500, 55)
        Me.lblBorrowedStatTitle.Name = "lblBorrowedStatTitle"
        Me.lblBorrowedStatTitle.Size = New System.Drawing.Size(120, 20)
        Me.lblBorrowedStatTitle.TabIndex = 8
        Me.lblBorrowedStatTitle.Text = "Borrowed"
        Me.lblBorrowedStatTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStatVisitorsToday.Font = New System.Drawing.Font("Segoe UI Semibold", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatVisitorsToday.Location = New System.Drawing.Point(375, 85)
        Me.lblStatVisitorsToday.Name = "lblStatVisitorsToday"
        Me.lblStatVisitorsToday.Size = New System.Drawing.Size(120, 42)
        Me.lblStatVisitorsToday.TabIndex = 7
        Me.lblStatVisitorsToday.Text = "0"
        Me.lblStatVisitorsToday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblVisitorsTitle.Location = New System.Drawing.Point(375, 55)
        Me.lblVisitorsTitle.Name = "lblVisitorsTitle"
        Me.lblVisitorsTitle.Size = New System.Drawing.Size(120, 20)
        Me.lblVisitorsTitle.TabIndex = 6
        Me.lblVisitorsTitle.Text = "Visitors Today"
        Me.lblVisitorsTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStatFaculty.Font = New System.Drawing.Font("Segoe UI Semibold", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatFaculty.Location = New System.Drawing.Point(250, 85)
        Me.lblStatFaculty.Name = "lblStatFaculty"
        Me.lblStatFaculty.Size = New System.Drawing.Size(120, 42)
        Me.lblStatFaculty.TabIndex = 5
        Me.lblStatFaculty.Text = "0"
        Me.lblStatFaculty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblFacultyTitle.Location = New System.Drawing.Point(250, 55)
        Me.lblFacultyTitle.Name = "lblFacultyTitle"
        Me.lblFacultyTitle.Size = New System.Drawing.Size(120, 20)
        Me.lblFacultyTitle.TabIndex = 4
        Me.lblFacultyTitle.Text = "Faculty/Staff"
        Me.lblFacultyTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStatStudents.Font = New System.Drawing.Font("Segoe UI Semibold", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatStudents.Location = New System.Drawing.Point(130, 85)
        Me.lblStatStudents.Name = "lblStatStudents"
        Me.lblStatStudents.Size = New System.Drawing.Size(115, 42)
        Me.lblStatStudents.TabIndex = 3
        Me.lblStatStudents.Text = "0"
        Me.lblStatStudents.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStudentsTitle.Location = New System.Drawing.Point(130, 55)
        Me.lblStudentsTitle.Name = "lblStudentsTitle"
        Me.lblStudentsTitle.Size = New System.Drawing.Size(115, 20)
        Me.lblStudentsTitle.TabIndex = 2
        Me.lblStudentsTitle.Text = "Students"
        Me.lblStudentsTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStatBooks.Font = New System.Drawing.Font("Segoe UI Semibold", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatBooks.Location = New System.Drawing.Point(12, 85)
        Me.lblStatBooks.Name = "lblStatBooks"
        Me.lblStatBooks.Size = New System.Drawing.Size(112, 42)
        Me.lblStatBooks.TabIndex = 1
        Me.lblStatBooks.Text = "0"
        Me.lblStatBooks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblBooksTitle.Location = New System.Drawing.Point(12, 55)
        Me.lblBooksTitle.Name = "lblBooksTitle"
        Me.lblBooksTitle.Size = New System.Drawing.Size(112, 20)
        Me.lblBooksTitle.TabIndex = 0
        Me.lblBooksTitle.Text = "Books"
        Me.lblBooksTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblCurrentBorrowedTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentBorrowedTitle.Location = New System.Drawing.Point(236, 252)
        Me.lblCurrentBorrowedTitle.Name = "lblCurrentBorrowedTitle"
        Me.lblCurrentBorrowedTitle.Size = New System.Drawing.Size(420, 20)
        Me.lblCurrentBorrowedTitle.TabIndex = 4
        Me.lblCurrentBorrowedTitle.Text = "Currently Borrowed"
        Me.dgvCurrentBorrowed.AllowUserToAddRows = False
        Me.dgvCurrentBorrowed.AllowUserToDeleteRows = False
        Me.dgvCurrentBorrowed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCurrentBorrowed.Location = New System.Drawing.Point(236, 280)
        Me.dgvCurrentBorrowed.MultiSelect = False
        Me.dgvCurrentBorrowed.Name = "dgvCurrentBorrowed"
        Me.dgvCurrentBorrowed.ReadOnly = True
        Me.dgvCurrentBorrowed.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvCurrentBorrowed.Size = New System.Drawing.Size(764, 335)
        Me.dgvCurrentBorrowed.TabIndex = 5
        Me.btnRefreshDashboard.Location = New System.Drawing.Point(880, 45)
        Me.btnRefreshDashboard.Name = "btnRefreshDashboard"
        Me.btnRefreshDashboard.Size = New System.Drawing.Size(120, 30)
        Me.btnRefreshDashboard.TabIndex = 6
        Me.btnRefreshDashboard.Text = "Refresh"
        Me.btnRefreshDashboard.UseVisualStyleBackColor = True
        Me.stsMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblCurrentUser, Me.lblDateTime})
        Me.stsMain.Location = New System.Drawing.Point(0, 678)
        Me.stsMain.Name = "stsMain"
        Me.stsMain.Size = New System.Drawing.Size(1024, 22)
        Me.stsMain.TabIndex = 7
        Me.stsMain.Text = "StatusStrip1"
        Me.lblCurrentUser.Name = "lblCurrentUser"
        Me.lblCurrentUser.Size = New System.Drawing.Size(83, 17)
        Me.lblCurrentUser.Text = ""
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(926, 17)
        Me.lblDateTime.Spring = True
        Me.lblDateTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.tmrClock.Interval = 1000
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1024, 700)
        Me.Controls.Add(Me.stsMain)
        Me.Controls.Add(Me.btnRefreshDashboard)
        Me.Controls.Add(Me.dgvCurrentBorrowed)
        Me.Controls.Add(Me.lblCurrentBorrowedTitle)
        Me.Controls.Add(Me.grpStats)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.pnlSide)
        Me.Controls.Add(Me.mnuMain)
        Me.MainMenuStrip = Me.mnuMain
        Me.MinimumSize = New System.Drawing.Size(1040, 738)
        Me.Name = "frmStaffMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Staff Dashboard"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mnuMain.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mnuMain.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.mnuMain.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.mnuMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.mnuMain.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.mFile.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mFile.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mFile.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mFileLogout.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mFileLogout.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mFileLogout.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mFileExit.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mFileExit.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mFileExit.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mManagement.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mManagement.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mManagement.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mStudents.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mStudents.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mStudents.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mFaculty.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mFaculty.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mFaculty.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mBooks.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mBooks.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mCategories.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mCategories.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mCategories.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mStaffUsers.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mStaffUsers.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mStaffUsers.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mTransactions.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mTransactions.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mTransactions.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mVisitor.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mVisitor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mVisitor.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mBorrowReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mBorrowReturn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mBorrowReturn.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mReports.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mReports.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mReports.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mLogs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mLogs.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mHelp.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mHelp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mHelp.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mAbout.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.mAbout.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.mAbout.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlSide.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlSide.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblSideTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblSideTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblSideTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Regular)
        Me.btnStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStudents.FlatAppearance.BorderSize = 1
        Me.btnStudents.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnStudents.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnStudents.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnStudents.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnStudents.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnStudents.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnStudents.UseVisualStyleBackColor = False
        Me.btnStudents.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStudents.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnStudents.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnFaculty.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFaculty.FlatAppearance.BorderSize = 1
        Me.btnFaculty.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnFaculty.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnFaculty.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnFaculty.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnFaculty.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnFaculty.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnFaculty.UseVisualStyleBackColor = False
        Me.btnFaculty.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFaculty.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnFaculty.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBooks.FlatAppearance.BorderSize = 1
        Me.btnBooks.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnBooks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnBooks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnBooks.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnBooks.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnBooks.UseVisualStyleBackColor = False
        Me.btnBooks.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBooks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBooks.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCategories.FlatAppearance.BorderSize = 1
        Me.btnCategories.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnCategories.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnCategories.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnCategories.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnCategories.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnCategories.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnCategories.UseVisualStyleBackColor = False
        Me.btnCategories.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCategories.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCategories.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnVisitorLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVisitorLog.FlatAppearance.BorderSize = 1
        Me.btnVisitorLog.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnVisitorLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnVisitorLog.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnVisitorLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnVisitorLog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnVisitorLog.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnVisitorLog.UseVisualStyleBackColor = False
        Me.btnVisitorLog.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnVisitorLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnVisitorLog.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnBorrowReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBorrowReturn.FlatAppearance.BorderSize = 1
        Me.btnBorrowReturn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnBorrowReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnBorrowReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnBorrowReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnBorrowReturn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnBorrowReturn.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnBorrowReturn.UseVisualStyleBackColor = False
        Me.btnBorrowReturn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBorrowReturn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBorrowReturn.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReports.FlatAppearance.BorderSize = 1
        Me.btnReports.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnReports.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnReports.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnReports.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnReports.UseVisualStyleBackColor = False
        Me.btnReports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReports.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnStaffUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStaffUsers.FlatAppearance.BorderSize = 1
        Me.btnStaffUsers.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnStaffUsers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnStaffUsers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnStaffUsers.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnStaffUsers.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnStaffUsers.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnStaffUsers.UseVisualStyleBackColor = False
        Me.btnStaffUsers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStaffUsers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnStaffUsers.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogs.FlatAppearance.BorderSize = 1
        Me.btnLogs.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnLogs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnLogs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnLogs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnLogs.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnLogs.UseVisualStyleBackColor = False
        Me.btnLogs.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogs.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)

        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.FlatAppearance.BorderSize = 1
        Me.btnLogout.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnLogout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnLogout.BackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnLogout.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnLogout.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnLogout.UseVisualStyleBackColor = False
        Me.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand

        Me.lblWelcome.BackColor = System.Drawing.Color.Transparent
        Me.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblWelcome.Font = New System.Drawing.Font("Segoe UI Semibold", 14.0!, System.Drawing.FontStyle.Regular)
        Me.grpStats.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpStats.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpStats.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpStats.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblBooksTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblBooksTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBooksTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.lblStatBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.lblStatBooks.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblStatBooks.Font = New System.Drawing.Font("Segoe UI Semibold", 18.0!, System.Drawing.FontStyle.Regular)
        Me.lblStatBooks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStudentsTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblStudentsTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblStudentsTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.lblStatStudents.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.lblStatStudents.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblStatStudents.Font = New System.Drawing.Font("Segoe UI Semibold", 18.0!, System.Drawing.FontStyle.Regular)
        Me.lblStatStudents.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFacultyTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFacultyTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblFacultyTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.lblStatFaculty.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.lblStatFaculty.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblStatFaculty.Font = New System.Drawing.Font("Segoe UI Semibold", 18.0!, System.Drawing.FontStyle.Regular)
        Me.lblStatFaculty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblVisitorsTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblVisitorsTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblVisitorsTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.lblStatVisitorsToday.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.lblStatVisitorsToday.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblStatVisitorsToday.Font = New System.Drawing.Font("Segoe UI Semibold", 18.0!, System.Drawing.FontStyle.Regular)
        Me.lblStatVisitorsToday.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBorrowedStatTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblBorrowedStatTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowedStatTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.lblStatBorrowed.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.lblStatBorrowed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblStatBorrowed.Font = New System.Drawing.Font("Segoe UI Semibold", 18.0!, System.Drawing.FontStyle.Regular)
        Me.lblStatBorrowed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOverdueTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblOverdueTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblOverdueTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.lblStatOverdue.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.lblStatOverdue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.lblStatOverdue.Font = New System.Drawing.Font("Segoe UI Semibold", 18.0!, System.Drawing.FontStyle.Regular)
        Me.lblStatOverdue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCurrentBorrowedTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblCurrentBorrowedTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblCurrentBorrowedTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvCurrentBorrowed.EnableHeadersVisualStyles = False
        Me.dgvCurrentBorrowed.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvCurrentBorrowed.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvCurrentBorrowed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvCurrentBorrowed.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvCurrentBorrowed.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvCurrentBorrowed.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvCurrentBorrowed.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvCurrentBorrowed.ColumnHeadersHeight = 32
        Me.dgvCurrentBorrowed.RowTemplate.Height = 24
        Me.dgvCurrentBorrowed.RowHeadersVisible = False
        Me.dgvCurrentBorrowed.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvCurrentBorrowed.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvCurrentBorrowed.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvCurrentBorrowed.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvCurrentBorrowed.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvCurrentBorrowed.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvCurrentBorrowed.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvCurrentBorrowed.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvCurrentBorrowed.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvCurrentBorrowed.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvCurrentBorrowed.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvCurrentBorrowed.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvCurrentBorrowed.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvCurrentBorrowed.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvCurrentBorrowed.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvCurrentBorrowed.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvCurrentBorrowed.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvCurrentBorrowed.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvCurrentBorrowed.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.btnRefreshDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefreshDashboard.FlatAppearance.BorderSize = 1
        Me.btnRefreshDashboard.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnRefreshDashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnRefreshDashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnRefreshDashboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnRefreshDashboard.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRefreshDashboard.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnRefreshDashboard.UseVisualStyleBackColor = False
        Me.btnRefreshDashboard.Cursor = System.Windows.Forms.Cursors.Hand

        Me.stsMain.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.stsMain.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.stsMain.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.stsMain.SizingGrip = False
        Me.stsMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.lblCurrentUser.BackColor = System.Drawing.Color.Transparent
        Me.lblCurrentUser.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblCurrentUser.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDateTime.BackColor = System.Drawing.Color.Transparent
        Me.lblDateTime.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblDateTime.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.pnlSide.ResumeLayout(False)
        Me.grpStats.ResumeLayout(False)
        CType(Me.dgvCurrentBorrowed, System.ComponentModel.ISupportInitialize).EndInit()
        Me.stsMain.ResumeLayout(False)
        Me.stsMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents mFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mFileLogout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mFileExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mManagement As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mStudents As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mFaculty As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mBooks As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mCategories As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mStaffUsers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mTransactions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mVisitor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mBorrowReturn As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mReports As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mLogs As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlSide As System.Windows.Forms.Panel
    Friend WithEvents lblSideTitle As System.Windows.Forms.Label
    Friend WithEvents btnStudents As System.Windows.Forms.Button
    Friend WithEvents btnFaculty As System.Windows.Forms.Button
    Friend WithEvents btnBooks As System.Windows.Forms.Button
    Friend WithEvents btnCategories As System.Windows.Forms.Button
    Friend WithEvents btnVisitorLog As System.Windows.Forms.Button
    Friend WithEvents btnBorrowReturn As System.Windows.Forms.Button
    Friend WithEvents btnReports As System.Windows.Forms.Button
    Friend WithEvents btnStaffUsers As System.Windows.Forms.Button
    Friend WithEvents btnLogs As System.Windows.Forms.Button
    Friend WithEvents btnLogout As System.Windows.Forms.Button
    Friend WithEvents lblWelcome As System.Windows.Forms.Label
    Friend WithEvents grpStats As System.Windows.Forms.GroupBox
    Friend WithEvents lblBooksTitle As System.Windows.Forms.Label
    Friend WithEvents lblStatBooks As System.Windows.Forms.Label
    Friend WithEvents lblStudentsTitle As System.Windows.Forms.Label
    Friend WithEvents lblStatStudents As System.Windows.Forms.Label
    Friend WithEvents lblFacultyTitle As System.Windows.Forms.Label
    Friend WithEvents lblStatFaculty As System.Windows.Forms.Label
    Friend WithEvents lblVisitorsTitle As System.Windows.Forms.Label
    Friend WithEvents lblStatVisitorsToday As System.Windows.Forms.Label
    Friend WithEvents lblBorrowedStatTitle As System.Windows.Forms.Label
    Friend WithEvents lblStatBorrowed As System.Windows.Forms.Label
    Friend WithEvents lblOverdueTitle As System.Windows.Forms.Label
    Friend WithEvents lblStatOverdue As System.Windows.Forms.Label
    Friend WithEvents lblCurrentBorrowedTitle As System.Windows.Forms.Label
    Friend WithEvents dgvCurrentBorrowed As System.Windows.Forms.DataGridView
    Friend WithEvents btnRefreshDashboard As System.Windows.Forms.Button
    Friend WithEvents stsMain As System.Windows.Forms.StatusStrip
    Friend WithEvents lblCurrentUser As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblDateTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tmrClock As System.Windows.Forms.Timer
End Class
