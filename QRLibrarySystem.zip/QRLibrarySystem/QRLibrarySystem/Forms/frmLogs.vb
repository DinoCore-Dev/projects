Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO

Public Class frmLogs

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim value As Object = GetScalar(sql, pars)
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
        Return CStr(row(col))
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
        Return CInt(row(col))
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
        Return CDec(row(col))
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
        Return CDate(row(col))
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        If gridRow Is Nothing Then Return ""
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return ""
        Return CStr(value)
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        If gridRow Is Nothing Then Return 0
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        If gridRow Is Nothing Then Return Date.Today
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
        Return CDate(value)
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        MessageBox.Show(title & ": " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region


    Private Sub frmLogs_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
        lblDbPath.Text = "Database : " & DbPath()
        cboSystemLogLevel.Text = "All"
        LoadUserLogs()
        LoadSystemLogs()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatUserLogsGrid()
        Try
            HideAllGridColumns(dgvUserLogs)
            Dim i As Integer = 0
            ShowGridColumn(dgvUserLogs, "Log ID", "Log ID", 50, i)
            ShowGridColumn(dgvUserLogs, "Username", "Username", 90, i)
            ShowGridColumn(dgvUserLogs, "Action", "Action", 75, i)
            ShowGridColumn(dgvUserLogs, "Module", "Module", 110, i)
            ShowGridColumn(dgvUserLogs, "Table", "Table", 85, i)
            ShowGridColumn(dgvUserLogs, "Record ID", "Record ID", 55, i)
            ShowGridColumn(dgvUserLogs, "Description", "Description", 245, i)
            ShowGridColumn(dgvUserLogs, "IP Address", "IP Address", 80, i)
            ShowGridColumn(dgvUserLogs, "Date / Time", "Date / Time", 115, i)
        Catch
        End Try
    End Sub

    Private Sub FormatSystemLogsGrid()
        Try
            HideAllGridColumns(dgvSystemLogs)
            Dim i As Integer = 0
            ShowGridColumn(dgvSystemLogs, "Log ID", "Log ID", 50, i)
            ShowGridColumn(dgvSystemLogs, "Log Type", "Log Type", 75, i)
            ShowGridColumn(dgvSystemLogs, "Level", "Level", 55, i)
            ShowGridColumn(dgvSystemLogs, "Event Source", "Event Source", 105, i)
            ShowGridColumn(dgvSystemLogs, "Description", "Description", 285, i)
            ShowGridColumn(dgvSystemLogs, "IP Address", "IP Address", 80, i)
            ShowGridColumn(dgvSystemLogs, "Device", "Device", 105, i)
            ShowGridColumn(dgvSystemLogs, "Date / Time", "Date / Time", 115, i)
        Catch
        End Try
    End Sub

    Private Sub LoadUserLogs()
        Try
            Dim sql As String = "SELECT l.userlogid AS [Log ID], u.username AS [Username], " & _
                                "l.action_performed AS [Action], l.module_accessed AS [Module], " & _
                                "l.table_affected AS [Table], l.record_id AS [Record ID], " & _
                                "l.description AS [Description], l.ip_address AS [IP Address], " & _
                                "l.log_timestamp AS [Date / Time] " & _
                                "FROM USER_LOGS l LEFT JOIN USER_TABLE u ON l.userid = u.userid WHERE 1 = 1"
            Dim pars As New System.Collections.Generic.List(Of SqlCeParameter)()
            If txtSearchUserLog.Text.Trim() <> "" Then
                sql &= " AND (u.username LIKE @q1 OR l.action_performed LIKE @q2 OR l.module_accessed LIKE @q3 OR l.description LIKE @q4)"
                pars.Add(P("@q1", "%" & txtSearchUserLog.Text.Trim() & "%"))
                pars.Add(P("@q2", "%" & txtSearchUserLog.Text.Trim() & "%"))
                pars.Add(P("@q3", "%" & txtSearchUserLog.Text.Trim() & "%"))
                pars.Add(P("@q4", "%" & txtSearchUserLog.Text.Trim() & "%"))
            End If
            sql &= " ORDER BY l.log_timestamp DESC"
            Dim arr() As SqlCeParameter = pars.ToArray()
            Dim dt As DataTable = GetTable(sql, arr)
            dgvUserLogs.DataSource = dt
            FormatUserLogsGrid()
            lblUserLogCount.Text = "Records: " & dt.Rows.Count
        Catch ex As Exception
            MessageBox.Show("Error loading user logs: " & ex.Message, "Logs", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnRefreshUserLogs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefreshUserLogs.Click
        LoadUserLogs()
    End Sub

    Private Sub txtSearchUserLog_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearchUserLog.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            LoadUserLogs()
        End If
    End Sub

    Private Sub LoadSystemLogs()
        Try
            Dim sql As String = "SELECT systemlogid AS [Log ID], log_type AS [Log Type], log_level AS [Level], " & _
                                "event_source AS [Event Source], description AS [Description], " & _
                                "ip_address AS [IP Address], device_info AS [Device], logged_at AS [Date / Time] " & _
                                "FROM SYSTEM_LOGS WHERE 1 = 1"
            Dim pars As New System.Collections.Generic.List(Of SqlCeParameter)()
            If txtSearchSystemLog.Text.Trim() <> "" Then
                sql &= " AND (log_type LIKE @q1 OR event_source LIKE @q2 OR description LIKE @q3)"
                pars.Add(P("@q1", "%" & txtSearchSystemLog.Text.Trim() & "%"))
                pars.Add(P("@q2", "%" & txtSearchSystemLog.Text.Trim() & "%"))
                pars.Add(P("@q3", "%" & txtSearchSystemLog.Text.Trim() & "%"))
            End If
            If cboSystemLogLevel.Text <> "" AndAlso cboSystemLogLevel.Text <> "All" Then
                sql &= " AND log_level = @lvl"
                pars.Add(P("@lvl", cboSystemLogLevel.Text))
            End If
            sql &= " ORDER BY logged_at DESC"
            Dim arr() As SqlCeParameter = pars.ToArray()
            Dim dt As DataTable = GetTable(sql, arr)
            dgvSystemLogs.DataSource = dt
            FormatSystemLogsGrid()
            lblSystemLogCount.Text = "Records: " & dt.Rows.Count
        Catch ex As Exception
            MessageBox.Show("Error loading system logs: " & ex.Message, "Logs", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnRefreshSystemLogs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefreshSystemLogs.Click
        LoadSystemLogs()
    End Sub

    Private Sub txtSearchSystemLog_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSearchSystemLog.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            LoadSystemLogs()
        End If
    End Sub

    Private Sub cboSystemLogLevel_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSystemLogLevel.SelectedIndexChanged
        Try
        LoadSystemLogs()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub btnBackup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBackup.Click
        Try
            If Not File.Exists(DbPath()) Then
                MessageBox.Show("Database file not found:" & vbCrLf & DbPath(), "Backup", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            Dim sfd As New SaveFileDialog()
            sfd.Title = "Backup Database"
            sfd.Filter = "SQL Server Compact Database (*.sdf)|*.sdf"
            sfd.FileName = "LibraryDB_Backup_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".sdf"
            If sfd.ShowDialog() <> DialogResult.OK Then Exit Sub

            File.Copy(DbPath(), sfd.FileName, True)
            WriteUserLog("Backup", "System Logs & Audit Trail", "", 0, "Database backed up to " & sfd.FileName)
            WriteSystemLog("Backup", "Information", "frmLogs", "Database backed up to " & sfd.FileName)
            MessageBox.Show("Backup successful!" & vbCrLf & sfd.FileName, "Backup", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadUserLogs()
            LoadSystemLogs()
        Catch ex As Exception
            MessageBox.Show("Backup failed: " & ex.Message, "Backup", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnRestore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRestore.Click
        Dim ofd As New OpenFileDialog()
        ofd.Title = "Restore Database"
        ofd.Filter = "SQL Server Compact Database (*.sdf)|*.sdf"
        If ofd.ShowDialog() <> DialogResult.OK Then Exit Sub

        If MessageBox.Show("Restore will REPLACE the current database:" & vbCrLf & DbPath() & vbCrLf & vbCrLf & _
                           "A safety copy of the current database will be made first. " & _
                           "The application will close after restoring - run it again to use the restored data." & vbCrLf & vbCrLf & _
                           "Continue?", "Restore", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) <> DialogResult.Yes Then Exit Sub

        Try
            Dim safety As String = Path.Combine(Application.StartupPath, _
                "LibraryDB_BeforeRestore_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".sdf")
            If File.Exists(DbPath()) Then File.Copy(DbPath(), safety, True)

            File.Copy(ofd.FileName, DbPath(), True)

            MessageBox.Show("Restore successful! The application will now close." & vbCrLf & _
                            "Safety copy of the previous database:" & vbCrLf & safety & vbCrLf & vbCrLf & _
                            "Please run the system again.", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Application.Exit()
        Catch ex As Exception
            MessageBox.Show("Restore failed: " & ex.Message & vbCrLf & _
                            "(Close all other forms / make sure the .sdf is not open in Server Explorer, then try again.)", _
                            "Restore", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
