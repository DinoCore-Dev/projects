Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO
Public Class frmLibrarianMain
    Public LoginForm As frmLogin = Nothing
    Private IsLoggingOut As Boolean = False

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim value As Object = GetScalar(sql, pars)
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
        Return CStr(row(col))
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
        Return CInt(row(col))
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
        Return CDec(row(col))
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
        Return CDate(row(col))
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        If gridRow Is Nothing Then Return ""
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return ""
        Return CStr(value)
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        If gridRow Is Nothing Then Return 0
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        If gridRow Is Nothing Then Return Date.Today
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
        Return CDate(value)
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        MessageBox.Show(title & ": " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region


    Private Sub frmLibrarianMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
        lblWelcome.Text = "Welcome, " & CurrentFullName
        lblCurrentUser.Text = CurrentFullName & "  |  " & CurrentUserLevel
        tmrClock.Start()
        UpdateClock()


        LoadDashboard()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub tmrClock_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrClock.Tick
        UpdateClock()
    End Sub

    Private Sub UpdateClock()
        lblDateTime.Text = DateTime.Now.ToString("MMMM dd, yyyy  hh:mm:ss tt")
    End Sub

    Public Sub LoadDashboard()
        Try
            lblStatBooks.Text = CStr(GetCount("SELECT COUNT(*) FROM BOOKS"))
            lblStatStudents.Text = CStr(GetCount("SELECT COUNT(*) FROM STUDENTS"))
            lblStatFaculty.Text = CStr(GetCount("SELECT COUNT(*) FROM FACULTY_STAFF"))

            Dim todayStart As Date = Date.Today
            Dim tomorrow As Date = Date.Today.AddDays(1)
            lblStatVisitorsToday.Text = CStr(GetCount( _
                "SELECT COUNT(*) FROM VISITORS_LOG WHERE visit_date >= @d1 AND visit_date < @d2", _
                P("@d1", todayStart), P("@d2", tomorrow)))

            lblStatBorrowed.Text = CStr(GetCount( _
                "SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE return_date IS NULL AND (status = 'Borrowed' OR status = 'Overdue')"))

            lblStatOverdue.Text = CStr(GetCount( _
                "SELECT COUNT(*) FROM BORROW_TRANSACTIONS WHERE return_date IS NULL AND due_date < @today", _
                P("@today", Date.Today)))

            Dim sql As String = "SELECT TOP (50) t.transaction_code AS [Transaction Code], b.title AS [Book Title], " & _
                "CASE WHEN t.borrower_type = 'Student' THEN (s.last_name + ', ' + s.first_name) " & _
                "ELSE (f.last_name + ', ' + f.first_name) END AS [Borrower], " & _
                "t.borrower_type AS [Type], t.borrow_date AS [Borrow Date], t.due_date AS [Due Date], t.status AS [Status] " & _
                "FROM BORROW_TRANSACTIONS t " & _
                "LEFT JOIN BOOKS b ON t.bookid = b.bookid " & _
                "LEFT JOIN STUDENTS s ON t.studentid = s.studentid " & _
                "LEFT JOIN FACULTY_STAFF f ON t.facultystaffid = f.facultystaffid " & _
                "WHERE t.return_date IS NULL ORDER BY t.due_date"
            dgvCurrentBorrowed.DataSource = GetTable(sql)
            FormatBorrowedGrid()
        Catch ex As Exception
            WriteSystemLog("Dashboard", "Error", "frmLibrarianMain", ex.Message)
        End Try
    End Sub

    Private Sub HideAllGridColumns(ByVal grid As DataGridView)
        grid.RowHeadersWidth = 25
        Dim col As DataGridViewColumn
        For Each col In grid.Columns
            col.Visible = False
        Next
    End Sub

    Private Sub ShowGridColumn(ByVal grid As DataGridView, ByVal columnName As String, ByVal header As String, ByVal width As Integer, ByRef displayIndex As Integer)
        If Not grid.Columns.Contains(columnName) Then Exit Sub
        Dim col As DataGridViewColumn = grid.Columns(columnName)
        col.HeaderText = header
        col.Width = width
        col.Visible = True
        col.DisplayIndex = displayIndex
        displayIndex += 1
        If col.ValueType Is GetType(Date) Then
            If header.Contains("Time") OrElse header.Contains("Login") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
        End If
    End Sub

    Private Sub FormatBorrowedGrid()
        Try
            HideAllGridColumns(dgvCurrentBorrowed)
            Dim i As Integer = 0
            ShowGridColumn(dgvCurrentBorrowed, "Transaction Code", "Transaction Code", 100, i)
            ShowGridColumn(dgvCurrentBorrowed, "Book Title", "Book Title", 175, i)
            ShowGridColumn(dgvCurrentBorrowed, "Borrower", "Borrower", 145, i)
            ShowGridColumn(dgvCurrentBorrowed, "Type", "Type", 60, i)
            ShowGridColumn(dgvCurrentBorrowed, "Borrow Date", "Borrow Date", 88, i)
            ShowGridColumn(dgvCurrentBorrowed, "Due Date", "Due Date", 88, i)
            ShowGridColumn(dgvCurrentBorrowed, "Status", "Status", 65, i)
        Catch
        End Try
    End Sub

    Private Sub btnRefreshDashboard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefreshDashboard.Click
        LoadDashboard()
    End Sub

    Private Sub OpenStudents()
        Try
            Dim f As New frmStudents()
            f.CurrentUserID = CurrentUserID
            f.CurrentLibraryStaffID = CurrentLibraryStaffID
            f.CurrentUsername = CurrentUsername
            f.CurrentFullName = CurrentFullName
            f.CurrentUserLevel = CurrentUserLevel
            f.CurrentStaffRole = CurrentStaffRole
            f.ShowDialog()
            LoadDashboard()
        Catch ex As Exception
            ShowError("Opening form", ex)
        End Try
    End Sub

    Private Sub OpenFaculty()
        Try
            Dim f As New frmFacultyStaff()
            f.CurrentUserID = CurrentUserID
            f.CurrentLibraryStaffID = CurrentLibraryStaffID
            f.CurrentUsername = CurrentUsername
            f.CurrentFullName = CurrentFullName
            f.CurrentUserLevel = CurrentUserLevel
            f.CurrentStaffRole = CurrentStaffRole
            f.ShowDialog()
            LoadDashboard()
        Catch ex As Exception
            ShowError("Opening form", ex)
        End Try
    End Sub

    Private Sub OpenBooks()
        Try
            Dim f As New frmBooks()
            f.CurrentUserID = CurrentUserID
            f.CurrentLibraryStaffID = CurrentLibraryStaffID
            f.CurrentUsername = CurrentUsername
            f.CurrentFullName = CurrentFullName
            f.CurrentUserLevel = CurrentUserLevel
            f.CurrentStaffRole = CurrentStaffRole
            f.ShowDialog()
            LoadDashboard()
        Catch ex As Exception
            ShowError("Opening form", ex)
        End Try
    End Sub

    Private Sub OpenCategories()
        Try
            Dim f As New frmCategories()
            f.CurrentUserID = CurrentUserID
            f.CurrentLibraryStaffID = CurrentLibraryStaffID
            f.CurrentUsername = CurrentUsername
            f.CurrentFullName = CurrentFullName
            f.CurrentUserLevel = CurrentUserLevel
            f.CurrentStaffRole = CurrentStaffRole
            f.ShowDialog()
            LoadDashboard()
        Catch ex As Exception
            ShowError("Opening form", ex)
        End Try
    End Sub

    Private Sub OpenVisitor()
        Try
            Dim f As New frmVisitorLog()
            f.CurrentUserID = CurrentUserID
            f.CurrentLibraryStaffID = CurrentLibraryStaffID
            f.CurrentUsername = CurrentUsername
            f.CurrentFullName = CurrentFullName
            f.CurrentUserLevel = CurrentUserLevel
            f.CurrentStaffRole = CurrentStaffRole
            f.ShowDialog()
            LoadDashboard()
        Catch ex As Exception
            ShowError("Opening form", ex)
        End Try
    End Sub

    Private Sub OpenBorrowReturn()
        Try
            Dim f As New frmBorrowReturn()
            f.CurrentUserID = CurrentUserID
            f.CurrentLibraryStaffID = CurrentLibraryStaffID
            f.CurrentUsername = CurrentUsername
            f.CurrentFullName = CurrentFullName
            f.CurrentUserLevel = CurrentUserLevel
            f.CurrentStaffRole = CurrentStaffRole
            f.ShowDialog()
            LoadDashboard()
        Catch ex As Exception
            ShowError("Opening form", ex)
        End Try
    End Sub

    Private Sub OpenReports()
        Try
            Dim f As New frmReports()
            f.CurrentUserID = CurrentUserID
            f.CurrentLibraryStaffID = CurrentLibraryStaffID
            f.CurrentUsername = CurrentUsername
            f.CurrentFullName = CurrentFullName
            f.CurrentUserLevel = CurrentUserLevel
            f.CurrentStaffRole = CurrentStaffRole
            f.ShowDialog()
            LoadDashboard()
        Catch ex As Exception
            ShowError("Opening form", ex)
        End Try
    End Sub

    Private Sub OpenStaffUsers()
        MessageBox.Show("This form is not available for Librarian accounts.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    End Sub

    Private Sub OpenLogs()
        MessageBox.Show("This form is not available for Librarian accounts.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    End Sub

    Private Sub btnStudents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStudents.Click
        OpenStudents()
    End Sub

    Private Sub btnFaculty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFaculty.Click
        OpenFaculty()
    End Sub

    Private Sub btnBooks_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBooks.Click
        OpenBooks()
    End Sub

    Private Sub btnCategories_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCategories.Click
        OpenCategories()
    End Sub

    Private Sub btnVisitorLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVisitorLog.Click
        OpenVisitor()
    End Sub

    Private Sub btnBorrowReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrowReturn.Click
        OpenBorrowReturn()
    End Sub

    Private Sub btnReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReports.Click
        OpenReports()
    End Sub

    Private Sub btnStaffUsers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStaffUsers.Click
        OpenStaffUsers()
    End Sub

    Private Sub btnLogs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogs.Click
        OpenLogs()
    End Sub

    Private Sub mStudents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mStudents.Click
        OpenStudents()
    End Sub

    Private Sub mFaculty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mFaculty.Click
        OpenFaculty()
    End Sub

    Private Sub mBooks_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mBooks.Click
        OpenBooks()
    End Sub

    Private Sub mCategories_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mCategories.Click
        OpenCategories()
    End Sub

    Private Sub mStaffUsers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mStaffUsers.Click
        OpenStaffUsers()
    End Sub

    Private Sub mVisitor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mVisitor.Click
        OpenVisitor()
    End Sub

    Private Sub mBorrowReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mBorrowReturn.Click
        OpenBorrowReturn()
    End Sub

    Private Sub mReports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mReports.Click
        OpenReports()
    End Sub

    Private Sub mLogs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mLogs.Click
        OpenLogs()
    End Sub

    Private Sub mAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mAbout.Click
        MessageBox.Show("QR-Based Library Management System" & vbCrLf & _
                        "Version 2.0" & vbCrLf & vbCrLf & _
                        "For managing books, borrowers, library visitors," & vbCrLf & _
                        "and borrow / return transactions using QR codes." & vbCrLf & vbCrLf & _
                        "Developed in VB.NET - Visual Studio 2010" & vbCrLf & _
                        "Database: SQL Server Compact (.sdf)", _
                        "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub DoLogout()
        Try
            If MessageBox.Show("Are you sure you want to logout?", "Logout", _
                               MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                IsLoggingOut = True
                WriteUserLog("Logout", "User Authentication", "USER_TABLE", CurrentUserID, _
                             "User '" & CurrentUsername & "' (Librarian) logged out.")
                If LoginForm IsNot Nothing Then
                    LoginForm.Show()
                Else
                    Dim login As New frmLogin()
                    login.Show()
                End If
                Me.Close()
            End If
        Catch ex As Exception
            ShowError("Logout", ex)
        End Try
    End Sub

    Private Sub btnLogout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogout.Click
        DoLogout()
    End Sub

    Private Sub mFileLogout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mFileLogout.Click
        DoLogout()
    End Sub

    Private Sub mFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mFileExit.Click
        Application.Exit()
    End Sub

    Private Sub frmLibrarianMain_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        Try
            If Not IsLoggingOut Then Application.Exit()
        Catch
        End Try
    End Sub

End Class
