<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStaffUsers
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.tabMain = New System.Windows.Forms.TabControl()
        Me.tabStaff = New System.Windows.Forms.TabPage()
        Me.tabUsers = New System.Windows.Forms.TabPage()
        Me.grpStaffInfo = New System.Windows.Forms.GroupBox()
        Me.lblStaffID = New System.Windows.Forms.Label()
        Me.txtStaffID = New System.Windows.Forms.TextBox()
        Me.lblEmployeeNo = New System.Windows.Forms.Label()
        Me.txtEmployeeNo = New System.Windows.Forms.TextBox()
        Me.lblFullName = New System.Windows.Forms.Label()
        Me.txtFullName = New System.Windows.Forms.TextBox()
        Me.lblStaffEmail = New System.Windows.Forms.Label()
        Me.txtStaffEmail = New System.Windows.Forms.TextBox()
        Me.lblStaffContact = New System.Windows.Forms.Label()
        Me.txtStaffContact = New System.Windows.Forms.TextBox()
        Me.lblRole = New System.Windows.Forms.Label()
        Me.cboRole = New System.Windows.Forms.ComboBox()
        Me.lblStaffStatus = New System.Windows.Forms.Label()
        Me.cboStaffStatus = New System.Windows.Forms.ComboBox()
        Me.lblStaffNote = New System.Windows.Forms.Label()
        Me.btnStaffNew = New System.Windows.Forms.Button()
        Me.btnStaffSave = New System.Windows.Forms.Button()
        Me.btnStaffUpdate = New System.Windows.Forms.Button()
        Me.btnStaffDelete = New System.Windows.Forms.Button()
        Me.btnStaffClear = New System.Windows.Forms.Button()
        Me.dgvStaff = New System.Windows.Forms.DataGridView()
        Me.lblStaffCount = New System.Windows.Forms.Label()
        Me.grpUserInfo = New System.Windows.Forms.GroupBox()
        Me.lblUserID = New System.Windows.Forms.Label()
        Me.txtUserID = New System.Windows.Forms.TextBox()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblUserPassword = New System.Windows.Forms.Label()
        Me.txtUserPassword = New System.Windows.Forms.TextBox()
        Me.lblConfirmPassword = New System.Windows.Forms.Label()
        Me.txtConfirmPassword = New System.Windows.Forms.TextBox()
        Me.lblUserLevel = New System.Windows.Forms.Label()
        Me.cboUserLevel = New System.Windows.Forms.ComboBox()
        Me.lblUserStatus = New System.Windows.Forms.Label()
        Me.cboUserStatus = New System.Windows.Forms.ComboBox()
        Me.lblUserNote = New System.Windows.Forms.Label()
        Me.btnUserNew = New System.Windows.Forms.Button()
        Me.btnUserSave = New System.Windows.Forms.Button()
        Me.btnUserUpdate = New System.Windows.Forms.Button()
        Me.btnUserDelete = New System.Windows.Forms.Button()
        Me.btnUserClear = New System.Windows.Forms.Button()
        Me.dgvUsers = New System.Windows.Forms.DataGridView()
        Me.lblUserCount = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.tabMain.SuspendLayout()
        Me.tabStaff.SuspendLayout()
        Me.tabUsers.SuspendLayout()
        Me.grpStaffInfo.SuspendLayout()
        Me.grpUserInfo.SuspendLayout()
        CType(Me.dgvStaff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1200, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(800, 46)
        Me.lblFormTitle.Text = "Staff && Users"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblFormTitle.TabIndex = 1
        Me.tabMain.Controls.Add(Me.tabStaff)
        Me.tabMain.Controls.Add(Me.tabUsers)
        Me.tabMain.Location = New System.Drawing.Point(12, 58)
        Me.tabMain.Name = "tabMain"
        Me.tabMain.SelectedIndex = 0
        Me.tabMain.Size = New System.Drawing.Size(1176, 540)
        Me.tabMain.TabIndex = 2
        Me.tabStaff.Controls.Add(Me.grpStaffInfo)
        Me.tabStaff.Controls.Add(Me.btnStaffNew)
        Me.tabStaff.Controls.Add(Me.btnStaffSave)
        Me.tabStaff.Controls.Add(Me.btnStaffUpdate)
        Me.tabStaff.Controls.Add(Me.btnStaffDelete)
        Me.tabStaff.Controls.Add(Me.btnStaffClear)
        Me.tabStaff.Controls.Add(Me.dgvStaff)
        Me.tabStaff.Controls.Add(Me.lblStaffCount)
        Me.tabStaff.Location = New System.Drawing.Point(4, 22)
        Me.tabStaff.Name = "tabStaff"
        Me.tabStaff.Padding = New System.Windows.Forms.Padding(3)
        Me.tabStaff.Size = New System.Drawing.Size(1168, 514)
        Me.tabStaff.Text = "Library Staff (Personnel)"
        Me.tabStaff.UseVisualStyleBackColor = True
        Me.tabStaff.TabIndex = 3
        Me.tabUsers.Controls.Add(Me.grpUserInfo)
        Me.tabUsers.Controls.Add(Me.btnUserNew)
        Me.tabUsers.Controls.Add(Me.btnUserSave)
        Me.tabUsers.Controls.Add(Me.btnUserUpdate)
        Me.tabUsers.Controls.Add(Me.btnUserDelete)
        Me.tabUsers.Controls.Add(Me.btnUserClear)
        Me.tabUsers.Controls.Add(Me.dgvUsers)
        Me.tabUsers.Controls.Add(Me.lblUserCount)
        Me.tabUsers.Location = New System.Drawing.Point(4, 22)
        Me.tabUsers.Name = "tabUsers"
        Me.tabUsers.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUsers.Size = New System.Drawing.Size(1168, 514)
        Me.tabUsers.Text = "User Accounts (Login)"
        Me.tabUsers.UseVisualStyleBackColor = True
        Me.tabUsers.TabIndex = 4
        Me.grpStaffInfo.Controls.Add(Me.lblStaffID)
        Me.grpStaffInfo.Controls.Add(Me.txtStaffID)
        Me.grpStaffInfo.Controls.Add(Me.lblEmployeeNo)
        Me.grpStaffInfo.Controls.Add(Me.txtEmployeeNo)
        Me.grpStaffInfo.Controls.Add(Me.lblFullName)
        Me.grpStaffInfo.Controls.Add(Me.txtFullName)
        Me.grpStaffInfo.Controls.Add(Me.lblStaffEmail)
        Me.grpStaffInfo.Controls.Add(Me.txtStaffEmail)
        Me.grpStaffInfo.Controls.Add(Me.lblStaffContact)
        Me.grpStaffInfo.Controls.Add(Me.txtStaffContact)
        Me.grpStaffInfo.Controls.Add(Me.lblRole)
        Me.grpStaffInfo.Controls.Add(Me.cboRole)
        Me.grpStaffInfo.Controls.Add(Me.lblStaffStatus)
        Me.grpStaffInfo.Controls.Add(Me.cboStaffStatus)
        Me.grpStaffInfo.Controls.Add(Me.lblStaffNote)
        Me.grpStaffInfo.Location = New System.Drawing.Point(15, 15)
        Me.grpStaffInfo.Name = "grpStaffInfo"
        Me.grpStaffInfo.Size = New System.Drawing.Size(400, 300)
        Me.grpStaffInfo.TabStop = False
        Me.grpStaffInfo.Text = "Library Staff Record"
        Me.grpStaffInfo.TabIndex = 5
        Me.lblStaffNote.AutoSize = False
        Me.lblStaffNote.Location = New System.Drawing.Point(18, 272)
        Me.lblStaffNote.Size = New System.Drawing.Size(360, 20)
        Me.lblStaffNote.Name = "lblStaffNote"
        Me.lblStaffNote.Text = "Personnel record only. Login access is set in User Accounts."
        Me.lblStaffNote.TabIndex = 30
        Me.lblStaffID.AutoSize = False
        Me.lblStaffID.Location = New System.Drawing.Point(18, 35)
        Me.lblStaffID.Size = New System.Drawing.Size(115, 20)
        Me.lblStaffID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblStaffID.Name = "lblStaffID"
        Me.lblStaffID.Text = "Staff ID :"
        Me.lblStaffID.TabIndex = 6
        Me.txtStaffID.Location = New System.Drawing.Point(140, 35)
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.Size = New System.Drawing.Size(240, 20)
        Me.txtStaffID.ReadOnly = True
        Me.txtStaffID.TabIndex = 7
        Me.lblEmployeeNo.AutoSize = False
        Me.lblEmployeeNo.Location = New System.Drawing.Point(18, 70)
        Me.lblEmployeeNo.Size = New System.Drawing.Size(115, 20)
        Me.lblEmployeeNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblEmployeeNo.Name = "lblEmployeeNo"
        Me.lblEmployeeNo.Text = "Employee No. :"
        Me.lblEmployeeNo.TabIndex = 8
        Me.txtEmployeeNo.Location = New System.Drawing.Point(140, 70)
        Me.txtEmployeeNo.Name = "txtEmployeeNo"
        Me.txtEmployeeNo.Size = New System.Drawing.Size(240, 20)
        Me.txtEmployeeNo.TabIndex = 9
        Me.lblFullName.AutoSize = False
        Me.lblFullName.Location = New System.Drawing.Point(18, 105)
        Me.lblFullName.Size = New System.Drawing.Size(115, 20)
        Me.lblFullName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblFullName.Name = "lblFullName"
        Me.lblFullName.Text = "Full Name :"
        Me.lblFullName.TabIndex = 10
        Me.txtFullName.Location = New System.Drawing.Point(140, 105)
        Me.txtFullName.Name = "txtFullName"
        Me.txtFullName.Size = New System.Drawing.Size(240, 20)
        Me.txtFullName.TabIndex = 11
        Me.lblStaffEmail.AutoSize = False
        Me.lblStaffEmail.Location = New System.Drawing.Point(18, 175)
        Me.lblStaffEmail.Size = New System.Drawing.Size(115, 20)
        Me.lblStaffEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblStaffEmail.Name = "lblStaffEmail"
        Me.lblStaffEmail.Text = "Email :"
        Me.lblStaffEmail.TabIndex = 12
        Me.txtStaffEmail.Location = New System.Drawing.Point(140, 175)
        Me.txtStaffEmail.Name = "txtStaffEmail"
        Me.txtStaffEmail.Size = New System.Drawing.Size(240, 20)
        Me.txtStaffEmail.TabIndex = 13
        Me.lblStaffContact.AutoSize = False
        Me.lblStaffContact.Location = New System.Drawing.Point(18, 210)
        Me.lblStaffContact.Size = New System.Drawing.Size(115, 20)
        Me.lblStaffContact.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblStaffContact.Name = "lblStaffContact"
        Me.lblStaffContact.Text = "Contact Number :"
        Me.lblStaffContact.TabIndex = 14
        Me.txtStaffContact.Location = New System.Drawing.Point(140, 210)
        Me.txtStaffContact.Name = "txtStaffContact"
        Me.txtStaffContact.Size = New System.Drawing.Size(240, 20)
        Me.txtStaffContact.TabIndex = 15
        Me.lblRole.AutoSize = False
        Me.lblRole.Location = New System.Drawing.Point(18, 140)
        Me.lblRole.Size = New System.Drawing.Size(115, 20)
        Me.lblRole.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblRole.Name = "lblRole"
        Me.lblRole.Text = "Position :"
        Me.lblRole.TabIndex = 16
        Me.cboRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRole.FormattingEnabled = True
        Me.cboRole.Items.AddRange(New Object() {"Head Librarian", "Librarian", "Library Assistant", "Library Staff"})
        Me.cboRole.Location = New System.Drawing.Point(140, 140)
        Me.cboRole.Name = "cboRole"
        Me.cboRole.Size = New System.Drawing.Size(240, 21)
        Me.cboRole.TabIndex = 17
        Me.lblStaffStatus.AutoSize = False
        Me.lblStaffStatus.Location = New System.Drawing.Point(18, 245)
        Me.lblStaffStatus.Size = New System.Drawing.Size(115, 20)
        Me.lblStaffStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblStaffStatus.Name = "lblStaffStatus"
        Me.lblStaffStatus.Text = "Status :"
        Me.lblStaffStatus.TabIndex = 18
        Me.cboStaffStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStaffStatus.FormattingEnabled = True
        Me.cboStaffStatus.Items.AddRange(New Object() {"Active", "Inactive"})
        Me.cboStaffStatus.Location = New System.Drawing.Point(140, 245)
        Me.cboStaffStatus.Name = "cboStaffStatus"
        Me.cboStaffStatus.Size = New System.Drawing.Size(240, 21)
        Me.cboStaffStatus.TabIndex = 19
        Me.btnStaffNew.Location = New System.Drawing.Point(15, 330)
        Me.btnStaffNew.Name = "btnStaffNew"
        Me.btnStaffNew.Size = New System.Drawing.Size(75, 34)
        Me.btnStaffNew.Text = "&New"
        Me.btnStaffNew.UseVisualStyleBackColor = True
        Me.btnStaffNew.TabIndex = 20
        Me.btnStaffSave.Location = New System.Drawing.Point(95, 330)
        Me.btnStaffSave.Name = "btnStaffSave"
        Me.btnStaffSave.Size = New System.Drawing.Size(75, 34)
        Me.btnStaffSave.Text = "&Save"
        Me.btnStaffSave.UseVisualStyleBackColor = True
        Me.btnStaffSave.TabIndex = 21
        Me.btnStaffUpdate.Location = New System.Drawing.Point(175, 330)
        Me.btnStaffUpdate.Name = "btnStaffUpdate"
        Me.btnStaffUpdate.Size = New System.Drawing.Size(75, 34)
        Me.btnStaffUpdate.Text = "&Update"
        Me.btnStaffUpdate.UseVisualStyleBackColor = True
        Me.btnStaffUpdate.TabIndex = 22
        Me.btnStaffDelete.Location = New System.Drawing.Point(255, 330)
        Me.btnStaffDelete.Name = "btnStaffDelete"
        Me.btnStaffDelete.Size = New System.Drawing.Size(75, 34)
        Me.btnStaffDelete.Text = "&Delete"
        Me.btnStaffDelete.UseVisualStyleBackColor = True
        Me.btnStaffDelete.TabIndex = 23
        Me.btnStaffClear.Location = New System.Drawing.Point(335, 330)
        Me.btnStaffClear.Name = "btnStaffClear"
        Me.btnStaffClear.Size = New System.Drawing.Size(75, 34)
        Me.btnStaffClear.Text = "&Clear"
        Me.btnStaffClear.UseVisualStyleBackColor = True
        Me.btnStaffClear.TabIndex = 24
        Me.dgvStaff.AllowUserToAddRows = False
        Me.dgvStaff.AllowUserToDeleteRows = False
        Me.dgvStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvStaff.Location = New System.Drawing.Point(430, 15)
        Me.dgvStaff.MultiSelect = False
        Me.dgvStaff.Name = "dgvStaff"
        Me.dgvStaff.ReadOnly = True
        Me.dgvStaff.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvStaff.Size = New System.Drawing.Size(721, 430)
        Me.dgvStaff.TabIndex = 25
        Me.lblStaffCount.AutoSize = True
        Me.lblStaffCount.Location = New System.Drawing.Point(430, 455)
        Me.lblStaffCount.Name = "lblStaffCount"
        Me.lblStaffCount.Text = "Records: 0"
        Me.lblStaffCount.TabIndex = 26
        Me.grpUserInfo.Controls.Add(Me.lblUserID)
        Me.grpUserInfo.Controls.Add(Me.txtUserID)
        Me.grpUserInfo.Controls.Add(Me.lblUsername)
        Me.grpUserInfo.Controls.Add(Me.txtUsername)
        Me.grpUserInfo.Controls.Add(Me.lblUserPassword)
        Me.grpUserInfo.Controls.Add(Me.txtUserPassword)
        Me.grpUserInfo.Controls.Add(Me.lblConfirmPassword)
        Me.grpUserInfo.Controls.Add(Me.txtConfirmPassword)
        Me.grpUserInfo.Controls.Add(Me.lblUserLevel)
        Me.grpUserInfo.Controls.Add(Me.cboUserLevel)
        Me.grpUserInfo.Controls.Add(Me.lblUserStatus)
        Me.grpUserInfo.Controls.Add(Me.cboUserStatus)
        Me.grpUserInfo.Controls.Add(Me.lblUserNote)
        Me.grpUserInfo.Location = New System.Drawing.Point(15, 15)
        Me.grpUserInfo.Name = "grpUserInfo"
        Me.grpUserInfo.Size = New System.Drawing.Size(400, 300)
        Me.grpUserInfo.TabStop = False
        Me.grpUserInfo.Text = "Login Account"
        Me.grpUserInfo.TabIndex = 27
        Me.lblUserID.AutoSize = False
        Me.lblUserID.Location = New System.Drawing.Point(18, 35)
        Me.lblUserID.Size = New System.Drawing.Size(115, 20)
        Me.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.Text = "User ID :"
        Me.lblUserID.TabIndex = 28
        Me.txtUserID.Location = New System.Drawing.Point(140, 35)
        Me.txtUserID.Name = "txtUserID"
        Me.txtUserID.Size = New System.Drawing.Size(240, 20)
        Me.txtUserID.ReadOnly = True
        Me.txtUserID.TabIndex = 29
        Me.lblUsername.AutoSize = False
        Me.lblUsername.Location = New System.Drawing.Point(18, 70)
        Me.lblUsername.Size = New System.Drawing.Size(115, 20)
        Me.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Text = "Username :"
        Me.lblUsername.TabIndex = 32
        Me.txtUsername.Location = New System.Drawing.Point(140, 70)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(240, 20)
        Me.txtUsername.TabIndex = 33
        Me.lblUserPassword.AutoSize = False
        Me.lblUserPassword.Location = New System.Drawing.Point(18, 105)
        Me.lblUserPassword.Size = New System.Drawing.Size(115, 20)
        Me.lblUserPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblUserPassword.Name = "lblUserPassword"
        Me.lblUserPassword.Text = "New Password :"
        Me.lblUserPassword.TabIndex = 34
        Me.txtUserPassword.Location = New System.Drawing.Point(140, 105)
        Me.txtUserPassword.Name = "txtUserPassword"
        Me.txtUserPassword.Size = New System.Drawing.Size(240, 20)
        Me.txtUserPassword.UseSystemPasswordChar = True
        Me.txtUserPassword.TabIndex = 35
        Me.lblConfirmPassword.AutoSize = False
        Me.lblConfirmPassword.Location = New System.Drawing.Point(3, 137)
        Me.lblConfirmPassword.Size = New System.Drawing.Size(130, 20)
        Me.lblConfirmPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblConfirmPassword.Name = "lblConfirmPassword"
        Me.lblConfirmPassword.Text = "Confirm Password :"
        Me.lblConfirmPassword.TabIndex = 36
        Me.txtConfirmPassword.Location = New System.Drawing.Point(140, 137)
        Me.txtConfirmPassword.Name = "txtConfirmPassword"
        Me.txtConfirmPassword.Size = New System.Drawing.Size(240, 20)
        Me.txtConfirmPassword.UseSystemPasswordChar = True
        Me.txtConfirmPassword.TabIndex = 37
        Me.lblUserLevel.AutoSize = False
        Me.lblUserLevel.Location = New System.Drawing.Point(18, 169)
        Me.lblUserLevel.Size = New System.Drawing.Size(115, 20)
        Me.lblUserLevel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblUserLevel.Name = "lblUserLevel"
        Me.lblUserLevel.Text = "System Role :"
        Me.lblUserLevel.TabIndex = 37
        Me.cboUserLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUserLevel.FormattingEnabled = True
        Me.cboUserLevel.Items.AddRange(New Object() {"Administrator", "Librarian", "Library Staff"})
        Me.cboUserLevel.Location = New System.Drawing.Point(140, 169)
        Me.cboUserLevel.Name = "cboUserLevel"
        Me.cboUserLevel.Size = New System.Drawing.Size(240, 21)
        Me.cboUserLevel.TabIndex = 38
        Me.lblUserStatus.AutoSize = False
        Me.lblUserStatus.Location = New System.Drawing.Point(18, 203)
        Me.lblUserStatus.Size = New System.Drawing.Size(115, 20)
        Me.lblUserStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblUserStatus.Name = "lblUserStatus"
        Me.lblUserStatus.Text = "Status :"
        Me.lblUserStatus.TabIndex = 39
        Me.cboUserStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUserStatus.FormattingEnabled = True
        Me.cboUserStatus.Items.AddRange(New Object() {"Active", "Inactive"})
        Me.cboUserStatus.Location = New System.Drawing.Point(140, 203)
        Me.cboUserStatus.Name = "cboUserStatus"
        Me.cboUserStatus.Size = New System.Drawing.Size(240, 21)
        Me.cboUserStatus.TabIndex = 40
        Me.lblUserNote.AutoSize = False
        Me.lblUserNote.Location = New System.Drawing.Point(18, 237)
        Me.lblUserNote.Size = New System.Drawing.Size(360, 52)
        Me.lblUserNote.Name = "lblUserNote"
        Me.lblUserNote.Text = "Passwords are encrypted and never shown. Changing one requires the account owner to type the current password. Leave both fields blank to keep it."
        Me.lblUserNote.TabIndex = 41
        Me.btnUserNew.Location = New System.Drawing.Point(15, 330)
        Me.btnUserNew.Name = "btnUserNew"
        Me.btnUserNew.Size = New System.Drawing.Size(75, 34)
        Me.btnUserNew.Text = "&New"
        Me.btnUserNew.UseVisualStyleBackColor = True
        Me.btnUserNew.TabIndex = 42
        Me.btnUserSave.Location = New System.Drawing.Point(95, 330)
        Me.btnUserSave.Name = "btnUserSave"
        Me.btnUserSave.Size = New System.Drawing.Size(75, 34)
        Me.btnUserSave.Text = "&Save"
        Me.btnUserSave.UseVisualStyleBackColor = True
        Me.btnUserSave.TabIndex = 43
        Me.btnUserUpdate.Location = New System.Drawing.Point(175, 330)
        Me.btnUserUpdate.Name = "btnUserUpdate"
        Me.btnUserUpdate.Size = New System.Drawing.Size(75, 34)
        Me.btnUserUpdate.Text = "&Update"
        Me.btnUserUpdate.UseVisualStyleBackColor = True
        Me.btnUserUpdate.TabIndex = 44
        Me.btnUserDelete.Location = New System.Drawing.Point(255, 330)
        Me.btnUserDelete.Name = "btnUserDelete"
        Me.btnUserDelete.Size = New System.Drawing.Size(75, 34)
        Me.btnUserDelete.Text = "&Delete"
        Me.btnUserDelete.UseVisualStyleBackColor = True
        Me.btnUserDelete.TabIndex = 45
        Me.btnUserClear.Location = New System.Drawing.Point(335, 330)
        Me.btnUserClear.Name = "btnUserClear"
        Me.btnUserClear.Size = New System.Drawing.Size(75, 34)
        Me.btnUserClear.Text = "&Clear"
        Me.btnUserClear.UseVisualStyleBackColor = True
        Me.btnUserClear.TabIndex = 46
        Me.dgvUsers.AllowUserToAddRows = False
        Me.dgvUsers.AllowUserToDeleteRows = False
        Me.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvUsers.Location = New System.Drawing.Point(430, 15)
        Me.dgvUsers.MultiSelect = False
        Me.dgvUsers.Name = "dgvUsers"
        Me.dgvUsers.ReadOnly = True
        Me.dgvUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvUsers.Size = New System.Drawing.Size(721, 430)
        Me.dgvUsers.TabIndex = 47
        Me.lblUserCount.AutoSize = True
        Me.lblUserCount.Location = New System.Drawing.Point(430, 455)
        Me.lblUserCount.Name = "lblUserCount"
        Me.lblUserCount.Text = "Records: 0"
        Me.lblUserCount.TabIndex = 48
        Me.btnClose.Location = New System.Drawing.Point(1061, 608)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(115, 34)
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.btnClose.TabIndex = 49
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 654)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.tabMain)
        Me.Controls.Add(Me.btnClose)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmStaffUsers"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Staff & Users"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.tabMain.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.tabMain.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.tabMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabMain.Padding = New System.Drawing.Point(18, 4)
        Me.tabMain.HotTrack = True
        Me.tabStaff.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.tabStaff.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.tabStaff.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.tabStaff.Padding = New System.Windows.Forms.Padding(3)
        Me.tabStaff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabStaff.UseVisualStyleBackColor = False
        Me.tabUsers.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.tabUsers.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.tabUsers.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.tabUsers.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabUsers.UseVisualStyleBackColor = False
        Me.grpStaffInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpStaffInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpStaffInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpStaffInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblStaffID.BackColor = System.Drawing.Color.Transparent
        Me.lblStaffID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtStaffID.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.txtStaffID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtStaffID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStaffID.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblEmployeeNo.BackColor = System.Drawing.Color.Transparent
        Me.lblEmployeeNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtEmployeeNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtEmployeeNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtEmployeeNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmployeeNo.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblFullName.BackColor = System.Drawing.Color.Transparent
        Me.lblFullName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtFullName.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtFullName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtFullName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFullName.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblStaffEmail.BackColor = System.Drawing.Color.Transparent
        Me.lblStaffEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtStaffEmail.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtStaffEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtStaffEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStaffEmail.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblStaffContact.BackColor = System.Drawing.Color.Transparent
        Me.lblStaffContact.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtStaffContact.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtStaffContact.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtStaffContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStaffContact.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblRole.BackColor = System.Drawing.Color.Transparent
        Me.lblRole.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboRole.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboRole.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboRole.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboRole.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblStaffStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblStaffStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboStaffStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboStaffStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboStaffStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboStaffStatus.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnStaffNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStaffNew.FlatAppearance.BorderSize = 1
        Me.btnStaffNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnStaffNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnStaffNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnStaffNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnStaffNew.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnStaffNew.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnStaffNew.UseVisualStyleBackColor = False
        Me.btnStaffNew.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnStaffSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStaffSave.FlatAppearance.BorderSize = 2
        Me.btnStaffSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnStaffSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnStaffSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnStaffSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnStaffSave.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnStaffSave.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnStaffSave.UseVisualStyleBackColor = False
        Me.btnStaffSave.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnStaffUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStaffUpdate.FlatAppearance.BorderSize = 1
        Me.btnStaffUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnStaffUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnStaffUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnStaffUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnStaffUpdate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnStaffUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnStaffUpdate.UseVisualStyleBackColor = False
        Me.btnStaffUpdate.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnStaffDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStaffDelete.FlatAppearance.BorderSize = 1
        Me.btnStaffDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.btnStaffDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnStaffDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnStaffDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnStaffDelete.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnStaffDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnStaffDelete.UseVisualStyleBackColor = False
        Me.btnStaffDelete.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnStaffClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStaffClear.FlatAppearance.BorderSize = 1
        Me.btnStaffClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnStaffClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnStaffClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnStaffClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnStaffClear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnStaffClear.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnStaffClear.UseVisualStyleBackColor = False
        Me.btnStaffClear.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvStaff.EnableHeadersVisualStyles = False
        Me.dgvStaff.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvStaff.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvStaff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvStaff.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvStaff.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvStaff.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvStaff.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvStaff.ColumnHeadersHeight = 32
        Me.dgvStaff.RowTemplate.Height = 24
        Me.dgvStaff.RowHeadersVisible = False
        Me.dgvStaff.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvStaff.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvStaff.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvStaff.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvStaff.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvStaff.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvStaff.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvStaff.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvStaff.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvStaff.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvStaff.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvStaff.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvStaff.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvStaff.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvStaff.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvStaff.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvStaff.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvStaff.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvStaff.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblStaffCount.BackColor = System.Drawing.Color.Transparent
        Me.lblStaffCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.grpUserInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpUserInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpUserInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpUserInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblUserID.BackColor = System.Drawing.Color.Transparent
        Me.lblUserID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtUserID.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.txtUserID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUserID.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblUsername.BackColor = System.Drawing.Color.Transparent
        Me.lblUsername.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtUsername.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtUsername.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUsername.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblUserPassword.BackColor = System.Drawing.Color.Transparent
        Me.lblUserPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblConfirmPassword.BackColor = System.Drawing.Color.Transparent
        Me.lblConfirmPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtUserPassword.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtUserPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtUserPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUserPassword.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.txtConfirmPassword.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtConfirmPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtConfirmPassword.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblUserLevel.BackColor = System.Drawing.Color.Transparent
        Me.lblUserLevel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboUserLevel.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboUserLevel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboUserLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboUserLevel.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblUserStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblUserStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboUserStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboUserStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboUserStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboUserStatus.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblUserNote.BackColor = System.Drawing.Color.Transparent
        Me.lblUserNote.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblUserNote.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblStaffNote.BackColor = System.Drawing.Color.Transparent
        Me.lblStaffNote.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblStaffNote.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnUserNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUserNew.FlatAppearance.BorderSize = 1
        Me.btnUserNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnUserNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnUserNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUserNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUserNew.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnUserNew.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUserNew.UseVisualStyleBackColor = False
        Me.btnUserNew.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnUserSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUserSave.FlatAppearance.BorderSize = 2
        Me.btnUserSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnUserSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnUserSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnUserSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnUserSave.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnUserSave.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUserSave.UseVisualStyleBackColor = False
        Me.btnUserSave.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnUserUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUserUpdate.FlatAppearance.BorderSize = 1
        Me.btnUserUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnUserUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnUserUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUserUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUserUpdate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnUserUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUserUpdate.UseVisualStyleBackColor = False
        Me.btnUserUpdate.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnUserDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUserDelete.FlatAppearance.BorderSize = 1
        Me.btnUserDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.btnUserDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnUserDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnUserDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnUserDelete.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnUserDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUserDelete.UseVisualStyleBackColor = False
        Me.btnUserDelete.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnUserClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUserClear.FlatAppearance.BorderSize = 1
        Me.btnUserClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnUserClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnUserClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUserClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUserClear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnUserClear.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUserClear.UseVisualStyleBackColor = False
        Me.btnUserClear.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvUsers.EnableHeadersVisualStyles = False
        Me.dgvUsers.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvUsers.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvUsers.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvUsers.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvUsers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvUsers.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvUsers.ColumnHeadersHeight = 32
        Me.dgvUsers.RowTemplate.Height = 24
        Me.dgvUsers.RowHeadersVisible = False
        Me.dgvUsers.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvUsers.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvUsers.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvUsers.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvUsers.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvUsers.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvUsers.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvUsers.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvUsers.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvUsers.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvUsers.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvUsers.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvUsers.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvUsers.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvUsers.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvUsers.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvUsers.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvUsers.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvUsers.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblUserCount.BackColor = System.Drawing.Color.Transparent
        Me.lblUserCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.pnlHeader.ResumeLayout(False)
        Me.tabMain.ResumeLayout(False)
        Me.tabStaff.ResumeLayout(False)
        Me.tabStaff.PerformLayout()
        Me.tabUsers.ResumeLayout(False)
        Me.tabUsers.PerformLayout()
        Me.grpStaffInfo.ResumeLayout(False)
        Me.grpStaffInfo.PerformLayout()
        Me.grpUserInfo.ResumeLayout(False)
        Me.grpUserInfo.PerformLayout()
        CType(Me.dgvStaff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvUsers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents tabMain As System.Windows.Forms.TabControl
    Friend WithEvents tabStaff As System.Windows.Forms.TabPage
    Friend WithEvents tabUsers As System.Windows.Forms.TabPage
    Friend WithEvents grpStaffInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblStaffID As System.Windows.Forms.Label
    Friend WithEvents txtStaffID As System.Windows.Forms.TextBox
    Friend WithEvents lblEmployeeNo As System.Windows.Forms.Label
    Friend WithEvents txtEmployeeNo As System.Windows.Forms.TextBox
    Friend WithEvents lblFullName As System.Windows.Forms.Label
    Friend WithEvents txtFullName As System.Windows.Forms.TextBox
    Friend WithEvents lblStaffEmail As System.Windows.Forms.Label
    Friend WithEvents txtStaffEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblStaffContact As System.Windows.Forms.Label
    Friend WithEvents txtStaffContact As System.Windows.Forms.TextBox
    Friend WithEvents lblRole As System.Windows.Forms.Label
    Friend WithEvents cboRole As System.Windows.Forms.ComboBox
    Friend WithEvents lblStaffStatus As System.Windows.Forms.Label
    Friend WithEvents cboStaffStatus As System.Windows.Forms.ComboBox
    Friend WithEvents btnStaffNew As System.Windows.Forms.Button
    Friend WithEvents btnStaffSave As System.Windows.Forms.Button
    Friend WithEvents btnStaffUpdate As System.Windows.Forms.Button
    Friend WithEvents btnStaffDelete As System.Windows.Forms.Button
    Friend WithEvents btnStaffClear As System.Windows.Forms.Button
    Friend WithEvents dgvStaff As System.Windows.Forms.DataGridView
    Friend WithEvents lblStaffCount As System.Windows.Forms.Label
    Friend WithEvents grpUserInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblUserID As System.Windows.Forms.Label
    Friend WithEvents txtUserID As System.Windows.Forms.TextBox
    Friend WithEvents lblUsername As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents lblUserPassword As System.Windows.Forms.Label
    Friend WithEvents txtUserPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblConfirmPassword As System.Windows.Forms.Label
    Friend WithEvents txtConfirmPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblUserLevel As System.Windows.Forms.Label
    Friend WithEvents cboUserLevel As System.Windows.Forms.ComboBox
    Friend WithEvents lblUserStatus As System.Windows.Forms.Label
    Friend WithEvents cboUserStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblUserNote As System.Windows.Forms.Label
    Friend WithEvents lblStaffNote As System.Windows.Forms.Label
    Friend WithEvents btnUserNew As System.Windows.Forms.Button
    Friend WithEvents btnUserSave As System.Windows.Forms.Button
    Friend WithEvents btnUserUpdate As System.Windows.Forms.Button
    Friend WithEvents btnUserDelete As System.Windows.Forms.Button
    Friend WithEvents btnUserClear As System.Windows.Forms.Button
    Friend WithEvents dgvUsers As System.Windows.Forms.DataGridView
    Friend WithEvents lblUserCount As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
