<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmQRPreview
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.picQR = New System.Windows.Forms.PictureBox()
        Me.lblCodeValue = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblDetail1 = New System.Windows.Forms.Label()
        Me.lblDetail2 = New System.Windows.Forms.Label()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnSaveImage = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.prnQR = New System.Drawing.Printing.PrintDocument()
        Me.ppdQR = New System.Windows.Forms.PrintPreviewDialog()
        CType(Me.picQR, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 15)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(360, 25)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "QR Code"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.picQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picQR.Location = New System.Drawing.Point(77, 55)
        Me.picQR.Name = "picQR"
        Me.picQR.Size = New System.Drawing.Size(230, 230)
        Me.picQR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picQR.TabIndex = 1
        Me.picQR.TabStop = False
        Me.lblCodeValue.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCodeValue.Location = New System.Drawing.Point(12, 295)
        Me.lblCodeValue.Name = "lblCodeValue"
        Me.lblCodeValue.Size = New System.Drawing.Size(360, 22)
        Me.lblCodeValue.TabIndex = 2
        Me.lblCodeValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblName.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(12, 325)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(360, 22)
        Me.lblName.TabIndex = 3
        Me.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblDetail1.Location = New System.Drawing.Point(12, 350)
        Me.lblDetail1.Name = "lblDetail1"
        Me.lblDetail1.Size = New System.Drawing.Size(360, 20)
        Me.lblDetail1.TabIndex = 4
        Me.lblDetail1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblDetail2.Location = New System.Drawing.Point(12, 372)
        Me.lblDetail2.Name = "lblDetail2"
        Me.lblDetail2.Size = New System.Drawing.Size(360, 20)
        Me.lblDetail2.TabIndex = 5
        Me.lblDetail2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnPrint.Location = New System.Drawing.Point(25, 410)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(105, 32)
        Me.btnPrint.TabIndex = 6
        Me.btnPrint.Text = "&Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        Me.btnSaveImage.Location = New System.Drawing.Point(140, 410)
        Me.btnSaveImage.Name = "btnSaveImage"
        Me.btnSaveImage.Size = New System.Drawing.Size(105, 32)
        Me.btnSaveImage.TabIndex = 7
        Me.btnSaveImage.Text = "&Save"
        Me.btnSaveImage.UseVisualStyleBackColor = True
        Me.btnClose.Location = New System.Drawing.Point(255, 410)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(105, 32)
        Me.btnClose.TabIndex = 8
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.ppdQR.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.ppdQR.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.ppdQR.ClientSize = New System.Drawing.Size(400, 300)
        Me.ppdQR.Enabled = True
        Me.ppdQR.Name = "ppdQR"
        Me.ppdQR.Visible = False
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 461)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnSaveImage)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.lblDetail2)
        Me.Controls.Add(Me.lblDetail1)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblCodeValue)
        Me.Controls.Add(Me.picQR)
        Me.Controls.Add(Me.lblFormTitle)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmQRPreview"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "QR Code"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblFormTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.lblFormTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.picQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCodeValue.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.lblCodeValue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblCodeValue.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular)
        Me.lblCodeValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblName.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.lblName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblName.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular)
        Me.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDetail1.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.lblDetail1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.lblDetail1.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDetail2.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.lblDetail2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.lblDetail2.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPrint.FlatAppearance.BorderSize = 1
        Me.btnPrint.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnPrint.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnPrint.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPrint.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnPrint.UseVisualStyleBackColor = False
        Me.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnSaveImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaveImage.FlatAppearance.BorderSize = 2
        Me.btnSaveImage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSaveImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnSaveImage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnSaveImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSaveImage.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnSaveImage.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSaveImage.UseVisualStyleBackColor = False
        Me.btnSaveImage.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.ppdQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.ppdQR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents picQR As System.Windows.Forms.PictureBox
    Friend WithEvents lblCodeValue As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblDetail1 As System.Windows.Forms.Label
    Friend WithEvents lblDetail2 As System.Windows.Forms.Label
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnSaveImage As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents prnQR As System.Drawing.Printing.PrintDocument
    Friend WithEvents ppdQR As System.Windows.Forms.PrintPreviewDialog
End Class
