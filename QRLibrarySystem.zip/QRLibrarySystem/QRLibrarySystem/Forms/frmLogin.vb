Imports System.Data
Imports System.Data.SqlServerCe
Imports System.IO
Imports System.Security.Cryptography

Public Class frmLogin

    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = Path.Combine(Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"
    Private DatabaseReady As Boolean = False
    Private Shared GlobalErrorHandlersInstalled As Boolean = False

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            InstallGlobalErrorHandlers()
            DatabaseReady = EnsureDatabase()
            btnLogin.Enabled = DatabaseReady
            lblDbInfo.Text = "Database: " & DatabaseFile
            txtUsername.Focus()
        Catch ex As Exception
            DatabaseReady = False
            btnLogin.Enabled = False
            MessageBox.Show("The login form could not start correctly." & vbCrLf & ex.Message, _
                            "Login", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub chkShowPassword_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowPassword.CheckedChanged
        Try
            txtPassword.UseSystemPasswordChar = Not chkShowPassword.Checked
        Catch ex As Exception
            ShowError("Show password", ex)
        End Try
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Try
            If Not DatabaseReady Then
                MessageBox.Show("The database is not ready. Please restart the system and read the database message shown at startup.", _
                                "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            If txtUsername.Text.Trim() = "" Then
                MessageBox.Show("Please enter your username.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtUsername.Focus()
                Exit Sub
            End If

            If txtPassword.Text = "" Then
                MessageBox.Show("Please enter your password.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtPassword.Focus()
                Exit Sub
            End If

            Dim sql As String = "SELECT u.userid, u.librarystaffid, u.username, u.password, u.user_level, " & _
                                "u.status AS user_status, s.full_name, s.role, s.status AS staff_status " & _
                                "FROM USER_TABLE u LEFT JOIN LIBRARY_STAFF s ON u.librarystaffid = s.librarystaffid " & _
                                "WHERE u.username = @user"
            Dim dt As DataTable = GetTable(sql, P("@user", txtUsername.Text.Trim()))
            Dim passwordOK As Boolean = False
            If dt.Rows.Count = 1 Then passwordOK = VerifyPassword(txtPassword.Text, DbStr(dt.Rows(0), "password"))

            If dt.Rows.Count <> 1 OrElse Not passwordOK Then
                WriteSystemLog("Authentication", "Warning", "frmLogin", _
                               "Failed login attempt for username '" & txtUsername.Text.Trim() & "'")
                MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtPassword.Clear()
                txtPassword.Focus()
                Exit Sub
            End If

            Dim r As DataRow = dt.Rows(0)
            If DbStr(r, "user_status") <> "Active" Then
                MessageBox.Show("This account is inactive. Please ask the Administrator to activate it.", _
                                "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            CurrentUserID = DbInt(r, "userid")
            CurrentLibraryStaffID = DbInt(r, "librarystaffid")
            CurrentUsername = DbStr(r, "username")
            CurrentUserLevel = DbStr(r, "user_level")
            CurrentFullName = DbStr(r, "full_name")
            If CurrentFullName = "" Then CurrentFullName = CurrentUsername
            CurrentStaffRole = DbStr(r, "role")
            If CurrentStaffRole = "" Then
                If CurrentUserLevel = "Staff" Then
                    CurrentStaffRole = "Library Staff"
                Else
                    CurrentStaffRole = CurrentUserLevel
                End If
            End If

            If CurrentLibraryStaffID > 0 AndAlso DbStr(r, "staff_status") <> "Active" Then
                WriteSystemLog("Authentication", "Warning", "frmLogin", _
                               "User '" & CurrentUsername & "' is not linked to an Active LIBRARY_STAFF record.")
                MessageBox.Show("This account is not linked to an active Library Staff record." & vbCrLf & _
                                "Please ask the Administrator to check Library Staff & User Accounts.", _
                                "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            If CurrentUserLevel <> "Administrator" AndAlso CurrentUserLevel <> "Librarian" AndAlso CurrentUserLevel <> "Staff" Then
                WriteSystemLog("Authentication", "Warning", "frmLogin", _
                               "User '" & CurrentUsername & "' has an unsupported user_level: " & CurrentUserLevel)
                MessageBox.Show("This account has an unsupported user level: " & CurrentUserLevel & vbCrLf & _
                                "Only Administrator, Librarian and Library Staff are allowed.", _
                                "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            Dim storedPassword As String = DbStr(r, "password")
            If Not storedPassword.StartsWith("PBKDF2$") Then
                RunNonQuery("UPDATE USER_TABLE SET password = @pass WHERE userid = @id", _
                            P("@pass", HashPassword(txtPassword.Text)), P("@id", CurrentUserID))
            End If

            RunNonQuery("UPDATE USER_TABLE SET last_login = @now WHERE userid = @id", _
                        P("@now", DateTime.Now), P("@id", CurrentUserID))
            WriteUserLog("Login", "User Authentication", "USER_TABLE", CurrentUserID, _
                         "User '" & CurrentUsername & "' (" & CurrentUserLevel & ") logged in.")

            Dim nextForm As Form = Nothing
            Select Case CurrentUserLevel
                Case "Administrator"
                    Dim f As New frmAdminMain()
                    f.CurrentUserID = CurrentUserID
                    f.CurrentLibraryStaffID = CurrentLibraryStaffID
                    f.CurrentUsername = CurrentUsername
                    f.CurrentFullName = CurrentFullName
                    f.CurrentUserLevel = CurrentUserLevel
                    f.CurrentStaffRole = CurrentStaffRole
                    f.LoginForm = Me
                    nextForm = f

                Case "Librarian"
                    Dim f As New frmLibrarianMain()
                    f.CurrentUserID = CurrentUserID
                    f.CurrentLibraryStaffID = CurrentLibraryStaffID
                    f.CurrentUsername = CurrentUsername
                    f.CurrentFullName = CurrentFullName
                    f.CurrentUserLevel = CurrentUserLevel
                    f.CurrentStaffRole = CurrentStaffRole
                    f.LoginForm = Me
                    nextForm = f

                Case "Staff"
                    Dim f As New frmStaffMain()
                    f.CurrentUserID = CurrentUserID
                    f.CurrentLibraryStaffID = CurrentLibraryStaffID
                    f.CurrentUsername = CurrentUsername
                    f.CurrentFullName = CurrentFullName
                    f.CurrentUserLevel = CurrentUserLevel
                    f.CurrentStaffRole = CurrentStaffRole
                    f.LoginForm = Me
                    nextForm = f
            End Select

            If nextForm Is Nothing Then
                MessageBox.Show("No main form is assigned to this user level.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            txtPassword.Clear()
            Me.Hide()
            nextForm.Show()

        Catch ex As Exception
            ShowError("Login error", ex)
            Try
                txtPassword.Clear()
                txtUsername.Focus()
            Catch
            End Try
        End Try
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Try
            Application.Exit()
        Catch
            Me.Close()
        End Try
    End Sub

    Private Function HashPassword(ByVal plainPassword As String) As String
        If plainPassword Is Nothing Then plainPassword = ""
        Dim salt(15) As Byte
        Dim rng As New RNGCryptoServiceProvider()
        rng.GetBytes(salt)
        Dim hash As Byte()
        Using derive As New Rfc2898DeriveBytes(plainPassword, salt, 20000)
            hash = derive.GetBytes(32)
        End Using
        Return "PBKDF2$20000$" & Convert.ToBase64String(salt) & "$" & Convert.ToBase64String(hash)
    End Function

    Private Function VerifyPassword(ByVal plainPassword As String, ByVal storedPassword As String) As Boolean
        If plainPassword Is Nothing Then plainPassword = ""
        If storedPassword Is Nothing Then storedPassword = ""
        If Not storedPassword.StartsWith("PBKDF2$") Then Return String.Equals(plainPassword, storedPassword, StringComparison.Ordinal)
        Try
            Dim parts() As String = storedPassword.Split("$"c)
            If parts.Length <> 4 Then Return False
            Dim iterations As Integer = 0
            If Not Integer.TryParse(parts(1), iterations) OrElse iterations < 1000 OrElse iterations > 200000 Then Return False
            Dim salt As Byte() = Convert.FromBase64String(parts(2))
            Dim expected As Byte() = Convert.FromBase64String(parts(3))
            If salt.Length < 8 OrElse expected.Length < 16 Then Return False
            Dim computed As Byte()
            Using derive As New Rfc2898DeriveBytes(plainPassword, salt, iterations)
                computed = derive.GetBytes(expected.Length)
            End Using
            Dim difference As Integer = 0
            Dim i As Integer
            For i = 0 To expected.Length - 1
                difference = difference Or (expected(i) Xor computed(i))
            Next
            Return difference = 0
        Catch
            Return False
        End Try
    End Function

    Private Sub MigratePlainTextPasswords()
        Try
            Dim dt As DataTable = GetTable("SELECT userid, password FROM USER_TABLE")
            Dim row As DataRow
            For Each row In dt.Rows
                Dim storedPassword As String = DbStr(row, "password")
                If storedPassword <> "" AndAlso Not storedPassword.StartsWith("PBKDF2$") Then
                    RunNonQuery("UPDATE USER_TABLE SET password = @pass WHERE userid = @id", P("@pass", HashPassword(storedPassword)), P("@id", DbInt(row, "userid")))
                End If
            Next
        Catch ex As Exception
            AppendErrorLog("frmLogin.MigratePlainTextPasswords", ex)
        End Try
    End Sub

    Private Sub MigrateStaffPositions()
        Try
            RunNonQuery("UPDATE LIBRARY_STAFF SET role = 'Library Staff' WHERE role = 'Staff'")
            RunNonQuery("UPDATE LIBRARY_STAFF SET role = 'Library Assistant' WHERE role = 'Assistant'")
        Catch ex As Exception
            AppendErrorLog("frmLogin.MigrateStaffPositions", ex)
        End Try
    End Sub

#Region "Global error handling (installed by this login form)"
    Private Sub InstallGlobalErrorHandlers()
        If GlobalErrorHandlersInstalled Then Exit Sub

        Try
            AddHandler Application.ThreadException, AddressOf Application_ThreadException
        Catch
        End Try
        Try
            AddHandler AppDomain.CurrentDomain.UnhandledException, AddressOf CurrentDomain_UnhandledException
        Catch
        End Try
        Try
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException)
        Catch
        End Try
        GlobalErrorHandlersInstalled = True
    End Sub

    Private Sub AppendErrorLog(ByVal source As String, ByVal ex As Exception)
        Try
            Dim message As String = "Unknown error."
            If ex IsNot Nothing Then message = ex.ToString()
            File.AppendAllText(Path.Combine(Application.StartupPath, "ErrorLog.txt"), _
                               DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") & " [" & source & "] " & _
                               message & Environment.NewLine)
        Catch
        End Try
    End Sub

    Private Sub Application_ThreadException(ByVal sender As Object, ByVal e As System.Threading.ThreadExceptionEventArgs)
        Try
            AppendErrorLog("Application.ThreadException", e.Exception)
            WriteSystemLog("Unhandled Thread Error", "Error", "Application.ThreadException", e.Exception.Message)
            MessageBox.Show("An unexpected error occurred, but the system will continue if possible." & vbCrLf & vbCrLf & _
                            e.Exception.Message, "Unexpected Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch
        End Try
    End Sub

    Private Sub CurrentDomain_UnhandledException(ByVal sender As Object, ByVal e As UnhandledExceptionEventArgs)
        Try
            Dim ex As Exception = TryCast(e.ExceptionObject, Exception)
            Dim msg As String = "Unknown fatal error."
            If ex IsNot Nothing Then msg = ex.Message
            AppendErrorLog("AppDomain.UnhandledException", ex)
            WriteSystemLog("Unhandled Fatal Error", "Error", "AppDomain.UnhandledException", msg)
            MessageBox.Show("A fatal unexpected error occurred." & vbCrLf & vbCrLf & msg, _
                            "Fatal Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            AppendErrorLog(title, ex)
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        MessageBox.Show(title & ": " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region

#Region "This form's own database creation and data-access code"
    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim value As Object = GetScalar(sql, pars)
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
        Return CStr(row(col))
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
        Return CInt(row(col))
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Function EnsureDatabase() As Boolean
        Try
            If Not File.Exists(DatabaseFile) Then
                Dim folder As String = Path.GetDirectoryName(DatabaseFile)
                If folder <> "" AndAlso Not Directory.Exists(folder) Then
                    Directory.CreateDirectory(folder)
                End If

                Dim engine As SqlCeEngine = Nothing
                Try
                    engine = New SqlCeEngine(DatabaseConnectionString)
                    engine.CreateDatabase()
                Finally
                    If engine IsNot Nothing Then engine.Dispose()
                End Try

                Dim statements As String() = CreateTableStatements()
                Dim i As Integer
                For i = 0 To statements.Length - 1
                    RunNonQuery(statements(i))
                Next
            End If

            SeedDefaultCategoriesAndUsers()
            MigrateStaffPositions()
            MigratePlainTextPasswords()
            SeedDemoTestData()
            Return True

        Catch ex As Exception
            AppendErrorLog("frmLogin.EnsureDatabase", ex)
            MessageBox.Show("Cannot create/open the database:" & vbCrLf & DatabaseFile & vbCrLf & vbCrLf & _
                            ex.Message & vbCrLf & vbCrLf & _
                            "Please check:" & vbCrLf & _
                            "1) Microsoft SQL Server Compact 3.5 SP2 is installed (included in VS2010)." & vbCrLf & _
                            "2) The project platform is x86." & vbCrLf & _
                            "3) The System.Data.SqlServerCe reference exists." & vbCrLf & _
                            "4) If LibraryDB.sdf is a damaged/0-byte file, close the system, delete it, and run again.", _
                            "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub SeedDefaultCategoriesAndUsers()
        EnsureCategory("IT", "Information Technology", "Programming, networking and computer books", "Shelf A")
        EnsureCategory("EDUC", "Education", "Teaching and education books", "Shelf B")
        EnsureCategory("GEN", "General Reference", "Dictionaries, encyclopedias and general references", "Shelf C")

        EnsureStaffAndUser("EMP-001", "System Administrator", "Head Librarian", "admin@library.local", _
                           "admin", "admin123", "Administrator")
        EnsureStaffAndUser("EMP-002", "Default Librarian", "Librarian", "librarian@library.local", _
                           "librarian", "librarian123", "Librarian")
        EnsureStaffAndUser("EMP-003", "Default Library Staff", "Library Staff", "staff@library.local", _
                           "staff", "staff123", "Staff")
    End Sub

    Private Sub EnsureCategory(ByVal code As String, ByVal name As String, _
                               ByVal description As String, ByVal shelf As String)
        If GetCount("SELECT COUNT(*) FROM CATEGORIES WHERE category_code = @code", P("@code", code)) = 0 Then
            RunNonQuery("INSERT INTO CATEGORIES (category_code, category_name, description, shelf_location, created_at) " & _
                        "VALUES (@code,@name,@desc,@shelf,@created)", _
                        P("@code", code), P("@name", name), P("@desc", description), _
                        P("@shelf", shelf), P("@created", DateTime.Now))
        End If
    End Sub

    Private Sub EnsureStaffAndUser(ByVal employeeNo As String, ByVal fullName As String, ByVal role As String, _
                                   ByVal email As String, ByVal username As String, ByVal password As String, _
                                   ByVal userLevel As String)
        Dim staffValue As Object = GetScalar("SELECT librarystaffid FROM LIBRARY_STAFF WHERE employee_no = @eno", _
                                             P("@eno", employeeNo))
        Dim staffId As Integer = 0
        If staffValue IsNot Nothing AndAlso Not IsDBNull(staffValue) Then staffId = CInt(staffValue)

        If staffId = 0 Then
            RunNonQuery("INSERT INTO LIBRARY_STAFF (employee_no, full_name, role, email, contact_number, status, created_at, updated_at) " & _
                        "VALUES (@eno,@name,@role,@email,@contact,@status,@created,@updated)", _
                        P("@eno", employeeNo), P("@name", fullName), P("@role", role), _
                        P("@email", email), P("@contact", ""), P("@status", "Active"), _
                        P("@created", DateTime.Now), P("@updated", DateTime.Now))
            staffValue = GetScalar("SELECT librarystaffid FROM LIBRARY_STAFF WHERE employee_no = @eno", _
                                   P("@eno", employeeNo))
            If staffValue IsNot Nothing AndAlso Not IsDBNull(staffValue) Then staffId = CInt(staffValue)
        End If

        If staffId = 0 Then
            Throw New Exception("Could not create the default library staff record for " & username & ".")
        End If

        If GetCount("SELECT COUNT(*) FROM USER_TABLE WHERE username = @user", P("@user", username)) = 0 Then
            RunNonQuery("INSERT INTO USER_TABLE (librarystaffid, username, password, user_level, status, created_at) " & _
                        "VALUES (@sid,@user,@pass,@level,@status,@created)", _
                        P("@sid", staffId), P("@user", username), P("@pass", HashPassword(password)), _
                        P("@level", userLevel), P("@status", "Active"), P("@created", DateTime.Now))
        End If
    End Sub

    Private Sub SeedDemoTestData()
        If GetCount("SELECT COUNT(*) FROM STUDENTS") > 0 OrElse _
           GetCount("SELECT COUNT(*) FROM FACULTY_STAFF") > 0 OrElse _
           GetCount("SELECT COUNT(*) FROM BOOKS") > 0 Then Exit Sub

        EnsureDemoStudent("2024-0001", "Juan", "Santos", "Dela Cruz", "BSIT", "3rd Year", "A", _
                          "juan.delacruz@example.com", "09123456789")
        EnsureDemoStudent("2024-0002", "Ana", "Reyes", "Reyes", "BSCS", "2nd Year", "B", _
                          "ana.reyes@example.com", "09987654321")
        EnsureDemoFaculty("EMP-1001", "Maria", "Clara", "Santos", "College of Computer Studies", _
                          "Instructor", "Full-Time", "maria.santos@example.com", "09112223333")
        EnsureDemoBook("IT", "ACC-0001", "Introduction to Visual Basic .NET", "Juan Dela Cruz", _
                       "Tech Books Publishing", 2023, "1st", "9789710000012", "Shelf A", 3)
        EnsureDemoBook("IT", "ACC-0002", "Database Management Systems", "Maria Santos", _
                       "Academic Press", 2022, "2nd", "9789710000029", "Shelf A", 2)
    End Sub

    Private Sub EnsureDemoStudent(ByVal studentNumber As String, ByVal firstName As String, _
                                  ByVal middleName As String, ByVal lastName As String, _
                                  ByVal course As String, ByVal yearLevel As String, _
                                  ByVal section As String, ByVal email As String, _
                                  ByVal contactNumber As String)
        If GetCount("SELECT COUNT(*) FROM STUDENTS WHERE student_number = @num", _
                    P("@num", studentNumber)) > 0 Then Exit Sub

        RunNonQuery("INSERT INTO STUDENTS (student_number, qr_code, first_name, middle_name, last_name, " & _
                    "course, year_level, section, email, contact_number, status, date_registered) " & _
                    "VALUES (@num,@qr,@first,@middle,@last,@course,@year,@section,@email,@contact,@status,@date)", _
                    P("@num", studentNumber), P("@qr", "STU-" & studentNumber), _
                    P("@first", firstName), P("@middle", middleName), P("@last", lastName), _
                    P("@course", course), P("@year", yearLevel), P("@section", section), _
                    P("@email", email), P("@contact", contactNumber), P("@status", "Active"), _
                    P("@date", DateTime.Now))
    End Sub

    Private Sub EnsureDemoFaculty(ByVal employeeNumber As String, ByVal firstName As String, _
                                  ByVal middleName As String, ByVal lastName As String, _
                                  ByVal department As String, ByVal position As String, _
                                  ByVal employmentType As String, ByVal email As String, _
                                  ByVal contactNumber As String)
        If GetCount("SELECT COUNT(*) FROM FACULTY_STAFF WHERE employee_number = @num", _
                    P("@num", employeeNumber)) > 0 Then Exit Sub

        RunNonQuery("INSERT INTO FACULTY_STAFF (employee_number, qr_code, first_name, middle_name, last_name, " & _
                    "department, position, employment_type, email, contact_number, status, date_registered) " & _
                    "VALUES (@num,@qr,@first,@middle,@last,@dept,@position,@type,@email,@contact,@status,@date)", _
                    P("@num", employeeNumber), P("@qr", "FAC-" & employeeNumber), _
                    P("@first", firstName), P("@middle", middleName), P("@last", lastName), _
                    P("@dept", department), P("@position", position), P("@type", employmentType), _
                    P("@email", email), P("@contact", contactNumber), P("@status", "Active"), _
                    P("@date", DateTime.Now))
    End Sub

    Private Sub EnsureDemoBook(ByVal categoryCode As String, ByVal accessionNo As String, _
                               ByVal title As String, ByVal author As String, _
                               ByVal publisher As String, ByVal publicationYear As Integer, _
                               ByVal edition As String, ByVal isbn As String, _
                               ByVal shelfLocation As String, ByVal totalCopies As Integer)
        If GetCount("SELECT COUNT(*) FROM BOOKS WHERE accession_no = @acc", _
                    P("@acc", accessionNo)) > 0 Then Exit Sub

        Dim categoryValue As Object = GetScalar("SELECT categoryid FROM CATEGORIES WHERE category_code = @code", _
                                                P("@code", categoryCode))
        If categoryValue Is Nothing OrElse IsDBNull(categoryValue) Then Exit Sub

        RunNonQuery("INSERT INTO BOOKS (categoryid, accession_no, title, author, publisher, publication_year, " & _
                    "edition, isbn, qr_code, shelf_location, total_copies, available_copies, status, date_acquired) " & _
                    "VALUES (@cat,@acc,@title,@author,@publisher,@year,@edition,@isbn,@qr,@shelf,@total,@avail,@status,@date)", _
                    P("@cat", CInt(categoryValue)), P("@acc", accessionNo), P("@title", title), _
                    P("@author", author), P("@publisher", publisher), P("@year", publicationYear), _
                    P("@edition", edition), P("@isbn", isbn), P("@qr", "BOOK-" & accessionNo), _
                    P("@shelf", shelfLocation), P("@total", totalCopies), P("@avail", totalCopies), _
                    P("@status", "Available"), P("@date", DateTime.Now))
    End Sub

    Private Function CreateTableStatements() As String()
        Dim s As New System.Collections.Generic.List(Of String)()

        s.Add("CREATE TABLE [LIBRARY_STAFF] ([librarystaffid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[employee_no] NVARCHAR(20) NULL, [full_name] NVARCHAR(100) NULL, [role] NVARCHAR(30) NULL, " & _
              "[email] NVARCHAR(100) NULL, [contact_number] NVARCHAR(20) NULL, [status] NVARCHAR(30) NULL, " & _
              "[created_at] DATETIME NULL, [updated_at] DATETIME NULL)")

        s.Add("CREATE TABLE [USER_TABLE] ([userid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[librarystaffid] INT NULL, [username] NVARCHAR(50) NULL, [password] NVARCHAR(255) NULL, " & _
              "[user_level] NVARCHAR(30) NULL, [status] NVARCHAR(30) NULL, [last_login] DATETIME NULL, " & _
              "[created_at] DATETIME NULL)")

        s.Add("CREATE TABLE [CATEGORIES] ([categoryid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[category_code] NVARCHAR(20) NULL, [category_name] NVARCHAR(100) NULL, [description] NTEXT NULL, " & _
              "[shelf_location] NVARCHAR(50) NULL, [created_at] DATETIME NULL)")

        s.Add("CREATE TABLE [BOOKS] ([bookid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, [categoryid] INT NULL, " & _
              "[accession_no] NVARCHAR(30) NULL, [title] NVARCHAR(200) NULL, [author] NVARCHAR(150) NULL, " & _
              "[publisher] NVARCHAR(150) NULL, [publication_year] INT NULL, [edition] NVARCHAR(30) NULL, " & _
              "[isbn] NVARCHAR(20) NULL, [qr_code] NVARCHAR(100) NULL, [shelf_location] NVARCHAR(50) NULL, " & _
              "[total_copies] INT NULL, [available_copies] INT NULL, [status] NVARCHAR(30) NULL, " & _
              "[date_acquired] DATETIME NULL)")

        s.Add("CREATE TABLE [STUDENTS] ([studentid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[student_number] NVARCHAR(20) NULL, [qr_code] NVARCHAR(100) NULL, [first_name] NVARCHAR(50) NULL, " & _
              "[middle_name] NVARCHAR(50) NULL, [last_name] NVARCHAR(50) NULL, [course] NVARCHAR(100) NULL, " & _
              "[year_level] NVARCHAR(20) NULL, [section] NVARCHAR(20) NULL, [email] NVARCHAR(100) NULL, " & _
              "[contact_number] NVARCHAR(20) NULL, [status] NVARCHAR(30) NULL, [date_registered] DATETIME NULL)")

        s.Add("CREATE TABLE [FACULTY_STAFF] ([facultystaffid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[employee_number] NVARCHAR(20) NULL, [qr_code] NVARCHAR(100) NULL, [first_name] NVARCHAR(50) NULL, " & _
              "[middle_name] NVARCHAR(50) NULL, [last_name] NVARCHAR(50) NULL, [department] NVARCHAR(100) NULL, " & _
              "[position] NVARCHAR(50) NULL, [employment_type] NVARCHAR(30) NULL, [email] NVARCHAR(100) NULL, " & _
              "[contact_number] NVARCHAR(20) NULL, [status] NVARCHAR(30) NULL, [date_registered] DATETIME NULL)")

        s.Add("CREATE TABLE [BORROW_TRANSACTIONS] ([borrowid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[bookid] INT NULL, [studentid] INT NULL, [facultystaffid] INT NULL, [librarystaffid] INT NULL, " & _
              "[transaction_code] NVARCHAR(30) NULL, [borrower_type] NVARCHAR(30) NULL, [borrow_date] DATETIME NULL, " & _
              "[due_date] DATETIME NULL, [return_date] DATETIME NULL, [days_overdue] INT NULL, " & _
              "[fine_amount] NUMERIC(8,2) NULL, [status] NVARCHAR(30) NULL)")

        s.Add("CREATE TABLE [VISITORS_LOG] ([visitorlogid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[studentid] INT NULL, [facultystaffid] INT NULL, [visitor_type] NVARCHAR(30) NULL, " & _
              "[purpose_of_visit] NVARCHAR(150) NULL, [visit_date] DATETIME NULL, [time_in] DATETIME NULL, " & _
              "[time_out] DATETIME NULL, [duration_minutes] INT NULL)")

        s.Add("CREATE TABLE [USER_LOGS] ([userlogid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, [userid] INT NULL, " & _
              "[action_performed] NVARCHAR(255) NULL, [module_accessed] NVARCHAR(50) NULL, " & _
              "[table_affected] NVARCHAR(50) NULL, [record_id] INT NULL, [description] NTEXT NULL, " & _
              "[ip_address] NVARCHAR(45) NULL, [log_timestamp] DATETIME NULL)")

        s.Add("CREATE TABLE [SYSTEM_LOGS] ([systemlogid] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, " & _
              "[userlogid] INT NULL, [log_type] NVARCHAR(30) NULL, [log_level] NVARCHAR(30) NULL, " & _
              "[event_source] NVARCHAR(100) NULL, [description] NTEXT NULL, [ip_address] NVARCHAR(45) NULL, " & _
              "[device_info] NVARCHAR(150) NULL, [logged_at] DATETIME NULL)")

        s.Add("ALTER TABLE [USER_TABLE] ADD CONSTRAINT [FK_USER_STAFF] FOREIGN KEY ([librarystaffid]) REFERENCES [LIBRARY_STAFF]([librarystaffid])")
        s.Add("ALTER TABLE [BOOKS] ADD CONSTRAINT [FK_BOOK_CAT] FOREIGN KEY ([categoryid]) REFERENCES [CATEGORIES]([categoryid])")
        s.Add("ALTER TABLE [BORROW_TRANSACTIONS] ADD CONSTRAINT [FK_BORROW_BOOK] FOREIGN KEY ([bookid]) REFERENCES [BOOKS]([bookid])")
        s.Add("ALTER TABLE [BORROW_TRANSACTIONS] ADD CONSTRAINT [FK_BORROW_STU] FOREIGN KEY ([studentid]) REFERENCES [STUDENTS]([studentid])")
        s.Add("ALTER TABLE [BORROW_TRANSACTIONS] ADD CONSTRAINT [FK_BORROW_FAC] FOREIGN KEY ([facultystaffid]) REFERENCES [FACULTY_STAFF]([facultystaffid])")
        s.Add("ALTER TABLE [BORROW_TRANSACTIONS] ADD CONSTRAINT [FK_BORROW_LIB] FOREIGN KEY ([librarystaffid]) REFERENCES [LIBRARY_STAFF]([librarystaffid])")
        s.Add("ALTER TABLE [VISITORS_LOG] ADD CONSTRAINT [FK_VISIT_STU] FOREIGN KEY ([studentid]) REFERENCES [STUDENTS]([studentid])")
        s.Add("ALTER TABLE [VISITORS_LOG] ADD CONSTRAINT [FK_VISIT_FAC] FOREIGN KEY ([facultystaffid]) REFERENCES [FACULTY_STAFF]([facultystaffid])")
        s.Add("ALTER TABLE [USER_LOGS] ADD CONSTRAINT [FK_USERLOG_USER] FOREIGN KEY ([userid]) REFERENCES [USER_TABLE]([userid])")
        s.Add("ALTER TABLE [SYSTEM_LOGS] ADD CONSTRAINT [FK_SYSLOG_USERLOG] FOREIGN KEY ([userlogid]) REFERENCES [USER_LOGS]([userlogid])")

        s.Add("CREATE UNIQUE INDEX [UX_STUDENTS_NUMBER] ON [STUDENTS]([student_number])")
        s.Add("CREATE UNIQUE INDEX [UX_STUDENTS_QR] ON [STUDENTS]([qr_code])")
        s.Add("CREATE UNIQUE INDEX [UX_FACULTY_NUMBER] ON [FACULTY_STAFF]([employee_number])")
        s.Add("CREATE UNIQUE INDEX [UX_FACULTY_QR] ON [FACULTY_STAFF]([qr_code])")
        s.Add("CREATE UNIQUE INDEX [UX_BOOKS_ACCESSION] ON [BOOKS]([accession_no])")
        s.Add("CREATE UNIQUE INDEX [UX_BOOKS_QR] ON [BOOKS]([qr_code])")
        s.Add("CREATE UNIQUE INDEX [UX_USER_USERNAME] ON [USER_TABLE]([username])")
        s.Add("CREATE UNIQUE INDEX [UX_CAT_CODE] ON [CATEGORIES]([category_code])")

        Return s.ToArray()
    End Function
#End Region

End Class
