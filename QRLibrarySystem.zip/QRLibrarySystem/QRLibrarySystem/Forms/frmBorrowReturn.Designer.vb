<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBorrowReturn
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.tabMain = New System.Windows.Forms.TabControl()
        Me.tabBorrow = New System.Windows.Forms.TabPage()
        Me.tabReturn = New System.Windows.Forms.TabPage()
        Me.tabTransactions = New System.Windows.Forms.TabPage()
        Me.grpBorrower = New System.Windows.Forms.GroupBox()
        Me.lblScanBorrower = New System.Windows.Forms.Label()
        Me.txtScanBorrower = New System.Windows.Forms.TextBox()
        Me.lblBorrowerStatus = New System.Windows.Forms.Label()
        Me.lblBorrowerName = New System.Windows.Forms.Label()
        Me.lblBorrowerType = New System.Windows.Forms.Label()
        Me.lblBorrowerIDNo = New System.Windows.Forms.Label()
        Me.lblBorrowerDetail = New System.Windows.Forms.Label()
        Me.lblBorrowerBorrowedCount = New System.Windows.Forms.Label()
        Me.grpBook = New System.Windows.Forms.GroupBox()
        Me.lblScanBook = New System.Windows.Forms.Label()
        Me.txtScanBook = New System.Windows.Forms.TextBox()
        Me.lblBookStatus = New System.Windows.Forms.Label()
        Me.lblBookTitle = New System.Windows.Forms.Label()
        Me.lblBookAccession = New System.Windows.Forms.Label()
        Me.lblBookAuthor = New System.Windows.Forms.Label()
        Me.lblBookAvailable = New System.Windows.Forms.Label()
        Me.grpBorrowDetails = New System.Windows.Forms.GroupBox()
        Me.lblBorrowDate = New System.Windows.Forms.Label()
        Me.dtpBorrowDate = New System.Windows.Forms.DateTimePicker()
        Me.lblLoanDays = New System.Windows.Forms.Label()
        Me.nudLoanDays = New System.Windows.Forms.NumericUpDown()
        Me.lblDueDate = New System.Windows.Forms.Label()
        Me.dtpDueDate = New System.Windows.Forms.DateTimePicker()
        Me.btnBorrowBook = New System.Windows.Forms.Button()
        Me.btnClearBorrow = New System.Windows.Forms.Button()
        Me.lblBorrowResult = New System.Windows.Forms.Label()
        Me.grpReturnScan = New System.Windows.Forms.GroupBox()
        Me.lblReturnInstruction = New System.Windows.Forms.Label()
        Me.lblScanReturnBook = New System.Windows.Forms.Label()
        Me.txtScanReturnBook = New System.Windows.Forms.TextBox()
        Me.btnFindBorrowed = New System.Windows.Forms.Button()
        Me.grpReturnInfo = New System.Windows.Forms.GroupBox()
        Me.lblReturnTransCode = New System.Windows.Forms.Label()
        Me.lblReturnBookTitle = New System.Windows.Forms.Label()
        Me.lblReturnBorrower = New System.Windows.Forms.Label()
        Me.lblReturnBorrowDate = New System.Windows.Forms.Label()
        Me.lblReturnDueDate = New System.Windows.Forms.Label()
        Me.lblDaysOverdue = New System.Windows.Forms.Label()
        Me.lblFineAmount = New System.Windows.Forms.Label()
        Me.btnProcessReturn = New System.Windows.Forms.Button()
        Me.btnClearReturn = New System.Windows.Forms.Button()
        Me.lblReturnResult = New System.Windows.Forms.Label()
        Me.lblSearchTrans = New System.Windows.Forms.Label()
        Me.txtSearchTrans = New System.Windows.Forms.TextBox()
        Me.lblTransStatus = New System.Windows.Forms.Label()
        Me.cboTransStatus = New System.Windows.Forms.ComboBox()
        Me.btnSearchTrans = New System.Windows.Forms.Button()
        Me.btnFlagOverdue = New System.Windows.Forms.Button()
        Me.dgvTransactions = New System.Windows.Forms.DataGridView()
        Me.lblTransCount = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.tabMain.SuspendLayout()
        Me.tabBorrow.SuspendLayout()
        Me.tabReturn.SuspendLayout()
        Me.tabTransactions.SuspendLayout()
        Me.grpBorrower.SuspendLayout()
        Me.grpBook.SuspendLayout()
        Me.grpBorrowDetails.SuspendLayout()
        CType(Me.nudLoanDays, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpReturnScan.SuspendLayout()
        Me.grpReturnInfo.SuspendLayout()
        CType(Me.dgvTransactions, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1024, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(900, 46)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "Borrow && Return"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.tabMain.Controls.Add(Me.tabBorrow)
        Me.tabMain.Controls.Add(Me.tabReturn)
        Me.tabMain.Controls.Add(Me.tabTransactions)
        Me.tabMain.Location = New System.Drawing.Point(12, 58)
        Me.tabMain.Name = "tabMain"
        Me.tabMain.SelectedIndex = 0
        Me.tabMain.Size = New System.Drawing.Size(1000, 580)
        Me.tabMain.TabIndex = 1
        Me.tabBorrow.Controls.Add(Me.grpBorrower)
        Me.tabBorrow.Controls.Add(Me.grpBook)
        Me.tabBorrow.Controls.Add(Me.grpBorrowDetails)
        Me.tabBorrow.Controls.Add(Me.lblBorrowResult)
        Me.tabBorrow.Location = New System.Drawing.Point(4, 22)
        Me.tabBorrow.Name = "tabBorrow"
        Me.tabBorrow.Padding = New System.Windows.Forms.Padding(3)
        Me.tabBorrow.Size = New System.Drawing.Size(992, 554)
        Me.tabBorrow.TabIndex = 0
        Me.tabBorrow.Text = "Borrow"
        Me.tabBorrow.UseVisualStyleBackColor = True
        Me.grpBorrower.Controls.Add(Me.lblScanBorrower)
        Me.grpBorrower.Controls.Add(Me.txtScanBorrower)
        Me.grpBorrower.Controls.Add(Me.lblBorrowerStatus)
        Me.grpBorrower.Controls.Add(Me.lblBorrowerName)
        Me.grpBorrower.Controls.Add(Me.lblBorrowerType)
        Me.grpBorrower.Controls.Add(Me.lblBorrowerIDNo)
        Me.grpBorrower.Controls.Add(Me.lblBorrowerDetail)
        Me.grpBorrower.Controls.Add(Me.lblBorrowerBorrowedCount)
        Me.grpBorrower.Location = New System.Drawing.Point(15, 15)
        Me.grpBorrower.Name = "grpBorrower"
        Me.grpBorrower.Size = New System.Drawing.Size(470, 235)
        Me.grpBorrower.TabIndex = 0
        Me.grpBorrower.TabStop = False
        Me.grpBorrower.Text = "1  Borrower"
        Me.lblScanBorrower.AutoSize = True
        Me.lblScanBorrower.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScanBorrower.Location = New System.Drawing.Point(18, 28)
        Me.lblScanBorrower.Name = "lblScanBorrower"
        Me.lblScanBorrower.TabIndex = 0
        Me.lblScanBorrower.Text = "Borrower QR"
        Me.txtScanBorrower.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanBorrower.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtScanBorrower.Location = New System.Drawing.Point(18, 52)
        Me.txtScanBorrower.Name = "txtScanBorrower"
        Me.txtScanBorrower.Size = New System.Drawing.Size(430, 27)
        Me.txtScanBorrower.TabIndex = 1
        Me.txtScanBorrower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.lblBorrowerStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBorrowerStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowerStatus.Location = New System.Drawing.Point(18, 86)
        Me.lblBorrowerStatus.Name = "lblBorrowerStatus"
        Me.lblBorrowerStatus.Size = New System.Drawing.Size(430, 18)
        Me.lblBorrowerStatus.TabIndex = 2
        Me.lblBorrowerStatus.Text = "Scan borrower ID"
        Me.lblBorrowerName.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBorrowerName.Location = New System.Drawing.Point(18, 112)
        Me.lblBorrowerName.Name = "lblBorrowerName"
        Me.lblBorrowerName.Size = New System.Drawing.Size(430, 24)
        Me.lblBorrowerName.TabIndex = 3
        Me.lblBorrowerName.Text = "Name : -"
        Me.lblBorrowerType.Location = New System.Drawing.Point(18, 142)
        Me.lblBorrowerType.Name = "lblBorrowerType"
        Me.lblBorrowerType.Size = New System.Drawing.Size(430, 20)
        Me.lblBorrowerType.TabIndex = 4
        Me.lblBorrowerType.Text = "Type : -"
        Me.lblBorrowerIDNo.Location = New System.Drawing.Point(18, 165)
        Me.lblBorrowerIDNo.Name = "lblBorrowerIDNo"
        Me.lblBorrowerIDNo.Size = New System.Drawing.Size(430, 20)
        Me.lblBorrowerIDNo.TabIndex = 5
        Me.lblBorrowerIDNo.Text = "ID No. : -"
        Me.lblBorrowerDetail.Location = New System.Drawing.Point(18, 188)
        Me.lblBorrowerDetail.Name = "lblBorrowerDetail"
        Me.lblBorrowerDetail.Size = New System.Drawing.Size(430, 20)
        Me.lblBorrowerDetail.TabIndex = 6
        Me.lblBorrowerDetail.Text = "Course/Dept : -"
        Me.lblBorrowerBorrowedCount.Location = New System.Drawing.Point(18, 211)
        Me.lblBorrowerBorrowedCount.Name = "lblBorrowerBorrowedCount"
        Me.lblBorrowerBorrowedCount.Size = New System.Drawing.Size(430, 20)
        Me.lblBorrowerBorrowedCount.TabIndex = 7
        Me.lblBorrowerBorrowedCount.Text = "Borrowed : -"
        Me.grpBook.Controls.Add(Me.lblScanBook)
        Me.grpBook.Controls.Add(Me.txtScanBook)
        Me.grpBook.Controls.Add(Me.lblBookStatus)
        Me.grpBook.Controls.Add(Me.lblBookTitle)
        Me.grpBook.Controls.Add(Me.lblBookAccession)
        Me.grpBook.Controls.Add(Me.lblBookAuthor)
        Me.grpBook.Controls.Add(Me.lblBookAvailable)
        Me.grpBook.Location = New System.Drawing.Point(500, 15)
        Me.grpBook.Name = "grpBook"
        Me.grpBook.Size = New System.Drawing.Size(470, 235)
        Me.grpBook.TabIndex = 1
        Me.grpBook.TabStop = False
        Me.grpBook.Text = "2  Book"
        Me.lblScanBook.AutoSize = True
        Me.lblScanBook.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScanBook.Location = New System.Drawing.Point(18, 28)
        Me.lblScanBook.Name = "lblScanBook"
        Me.lblScanBook.TabIndex = 0
        Me.lblScanBook.Text = "Book QR"
        Me.txtScanBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanBook.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtScanBook.Location = New System.Drawing.Point(18, 52)
        Me.txtScanBook.Name = "txtScanBook"
        Me.txtScanBook.Size = New System.Drawing.Size(430, 27)
        Me.txtScanBook.TabIndex = 1
        Me.txtScanBook.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.lblBookStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBookStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBookStatus.Location = New System.Drawing.Point(18, 86)
        Me.lblBookStatus.Name = "lblBookStatus"
        Me.lblBookStatus.Size = New System.Drawing.Size(430, 18)
        Me.lblBookStatus.TabIndex = 2
        Me.lblBookStatus.Text = "Scan book QR"
        Me.lblBookTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBookTitle.Location = New System.Drawing.Point(18, 112)
        Me.lblBookTitle.Name = "lblBookTitle"
        Me.lblBookTitle.Size = New System.Drawing.Size(430, 24)
        Me.lblBookTitle.TabIndex = 3
        Me.lblBookTitle.Text = "Title : -"
        Me.lblBookAccession.Location = New System.Drawing.Point(18, 142)
        Me.lblBookAccession.Name = "lblBookAccession"
        Me.lblBookAccession.Size = New System.Drawing.Size(430, 20)
        Me.lblBookAccession.TabIndex = 4
        Me.lblBookAccession.Text = "Accession : -"
        Me.lblBookAuthor.Location = New System.Drawing.Point(18, 165)
        Me.lblBookAuthor.Name = "lblBookAuthor"
        Me.lblBookAuthor.Size = New System.Drawing.Size(430, 20)
        Me.lblBookAuthor.TabIndex = 5
        Me.lblBookAuthor.Text = "Author : -"
        Me.lblBookAvailable.Location = New System.Drawing.Point(18, 188)
        Me.lblBookAvailable.Name = "lblBookAvailable"
        Me.lblBookAvailable.Size = New System.Drawing.Size(430, 20)
        Me.lblBookAvailable.TabIndex = 6
        Me.lblBookAvailable.Text = "Available : -"
        Me.grpBorrowDetails.Controls.Add(Me.lblBorrowDate)
        Me.grpBorrowDetails.Controls.Add(Me.dtpBorrowDate)
        Me.grpBorrowDetails.Controls.Add(Me.lblLoanDays)
        Me.grpBorrowDetails.Controls.Add(Me.nudLoanDays)
        Me.grpBorrowDetails.Controls.Add(Me.lblDueDate)
        Me.grpBorrowDetails.Controls.Add(Me.dtpDueDate)
        Me.grpBorrowDetails.Controls.Add(Me.btnBorrowBook)
        Me.grpBorrowDetails.Controls.Add(Me.btnClearBorrow)
        Me.grpBorrowDetails.Location = New System.Drawing.Point(15, 262)
        Me.grpBorrowDetails.Name = "grpBorrowDetails"
        Me.grpBorrowDetails.Size = New System.Drawing.Size(955, 145)
        Me.grpBorrowDetails.TabIndex = 2
        Me.grpBorrowDetails.TabStop = False
        Me.grpBorrowDetails.Text = "3  Details"
        Me.lblBorrowDate.AutoSize = True
        Me.lblBorrowDate.Location = New System.Drawing.Point(18, 38)
        Me.lblBorrowDate.Name = "lblBorrowDate"
        Me.lblBorrowDate.TabIndex = 0
        Me.lblBorrowDate.Text = "Borrow Date :"
        Me.dtpBorrowDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpBorrowDate.Location = New System.Drawing.Point(120, 35)
        Me.dtpBorrowDate.Name = "dtpBorrowDate"
        Me.dtpBorrowDate.Size = New System.Drawing.Size(150, 20)
        Me.dtpBorrowDate.TabIndex = 1
        Me.lblLoanDays.AutoSize = True
        Me.lblLoanDays.Location = New System.Drawing.Point(300, 38)
        Me.lblLoanDays.Name = "lblLoanDays"
        Me.lblLoanDays.TabIndex = 2
        Me.lblLoanDays.Text = "Loan Days :"
        Me.nudLoanDays.Location = New System.Drawing.Point(385, 35)
        Me.nudLoanDays.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.nudLoanDays.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudLoanDays.Name = "nudLoanDays"
        Me.nudLoanDays.Size = New System.Drawing.Size(70, 20)
        Me.nudLoanDays.TabIndex = 3
        Me.nudLoanDays.Value = New Decimal(New Integer() {3, 0, 0, 0})
        Me.lblDueDate.AutoSize = True
        Me.lblDueDate.Location = New System.Drawing.Point(490, 38)
        Me.lblDueDate.Name = "lblDueDate"
        Me.lblDueDate.TabIndex = 4
        Me.lblDueDate.Text = "Due Date :"
        Me.dtpDueDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpDueDate.Location = New System.Drawing.Point(565, 35)
        Me.dtpDueDate.Name = "dtpDueDate"
        Me.dtpDueDate.Size = New System.Drawing.Size(150, 20)
        Me.dtpDueDate.TabIndex = 5
        Me.btnBorrowBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnBorrowBook.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrowBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnBorrowBook.Location = New System.Drawing.Point(120, 80)
        Me.btnBorrowBook.Name = "btnBorrowBook"
        Me.btnBorrowBook.Size = New System.Drawing.Size(250, 45)
        Me.btnBorrowBook.TabIndex = 7
        Me.btnBorrowBook.Text = "&Borrow"
        Me.btnBorrowBook.UseVisualStyleBackColor = False
        Me.btnClearBorrow.Location = New System.Drawing.Point(385, 80)
        Me.btnClearBorrow.Name = "btnClearBorrow"
        Me.btnClearBorrow.Size = New System.Drawing.Size(180, 45)
        Me.btnClearBorrow.TabIndex = 8
        Me.btnClearBorrow.Text = "&Clear"
        Me.btnClearBorrow.UseVisualStyleBackColor = True
        Me.lblBorrowResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBorrowResult.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBorrowResult.Location = New System.Drawing.Point(15, 452)
        Me.lblBorrowResult.Name = "lblBorrowResult"
        Me.lblBorrowResult.Size = New System.Drawing.Size(955, 45)
        Me.lblBorrowResult.TabIndex = 3
        Me.lblBorrowResult.Text = "Waiting for scans..."
        Me.lblBorrowResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.tabReturn.Controls.Add(Me.grpReturnScan)
        Me.tabReturn.Controls.Add(Me.grpReturnInfo)
        Me.tabReturn.Controls.Add(Me.btnProcessReturn)
        Me.tabReturn.Controls.Add(Me.btnClearReturn)
        Me.tabReturn.Controls.Add(Me.lblReturnResult)
        Me.tabReturn.Location = New System.Drawing.Point(4, 22)
        Me.tabReturn.Name = "tabReturn"
        Me.tabReturn.Padding = New System.Windows.Forms.Padding(3)
        Me.tabReturn.Size = New System.Drawing.Size(992, 554)
        Me.tabReturn.TabIndex = 1
        Me.tabReturn.Text = "Return"
        Me.tabReturn.UseVisualStyleBackColor = True
        Me.grpReturnScan.Controls.Add(Me.lblReturnInstruction)
        Me.grpReturnScan.Controls.Add(Me.lblScanReturnBook)
        Me.grpReturnScan.Controls.Add(Me.txtScanReturnBook)
        Me.grpReturnScan.Controls.Add(Me.btnFindBorrowed)
        Me.grpReturnScan.Location = New System.Drawing.Point(15, 15)
        Me.grpReturnScan.Name = "grpReturnScan"
        Me.grpReturnScan.Size = New System.Drawing.Size(955, 165)
        Me.grpReturnScan.TabIndex = 0
        Me.grpReturnScan.TabStop = False
        Me.grpReturnScan.Text = "Return"
        Me.lblReturnInstruction.Location = New System.Drawing.Point(18, 25)
        Me.lblReturnInstruction.Name = "lblReturnInstruction"
        Me.lblReturnInstruction.Size = New System.Drawing.Size(900, 35)
        Me.lblReturnInstruction.TabIndex = 0
        Me.lblReturnInstruction.Text = "Scan the book QR. Fine: Php 5/day if overdue."
        Me.lblScanReturnBook.AutoSize = True
        Me.lblScanReturnBook.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScanReturnBook.Location = New System.Drawing.Point(18, 75)
        Me.lblScanReturnBook.Name = "lblScanReturnBook"
        Me.lblScanReturnBook.TabIndex = 1
        Me.lblScanReturnBook.Text = "Book QR"
        Me.txtScanReturnBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanReturnBook.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtScanReturnBook.Location = New System.Drawing.Point(18, 100)
        Me.txtScanReturnBook.Name = "txtScanReturnBook"
        Me.txtScanReturnBook.Size = New System.Drawing.Size(500, 27)
        Me.txtScanReturnBook.TabIndex = 2
        Me.txtScanReturnBook.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnFindBorrowed.Location = New System.Drawing.Point(535, 95)
        Me.btnFindBorrowed.Name = "btnFindBorrowed"
        Me.btnFindBorrowed.Size = New System.Drawing.Size(200, 38)
        Me.btnFindBorrowed.TabIndex = 3
        Me.btnFindBorrowed.Text = "&Find"
        Me.btnFindBorrowed.UseVisualStyleBackColor = True
        Me.grpReturnInfo.Controls.Add(Me.lblReturnTransCode)
        Me.grpReturnInfo.Controls.Add(Me.lblReturnBookTitle)
        Me.grpReturnInfo.Controls.Add(Me.lblReturnBorrower)
        Me.grpReturnInfo.Controls.Add(Me.lblReturnBorrowDate)
        Me.grpReturnInfo.Controls.Add(Me.lblReturnDueDate)
        Me.grpReturnInfo.Controls.Add(Me.lblDaysOverdue)
        Me.grpReturnInfo.Controls.Add(Me.lblFineAmount)
        Me.grpReturnInfo.Location = New System.Drawing.Point(15, 195)
        Me.grpReturnInfo.Name = "grpReturnInfo"
        Me.grpReturnInfo.Size = New System.Drawing.Size(955, 235)
        Me.grpReturnInfo.TabIndex = 1
        Me.grpReturnInfo.TabStop = False
        Me.grpReturnInfo.Text = "Borrow Record"
        Me.lblReturnTransCode.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReturnTransCode.Location = New System.Drawing.Point(18, 30)
        Me.lblReturnTransCode.Name = "lblReturnTransCode"
        Me.lblReturnTransCode.Size = New System.Drawing.Size(900, 22)
        Me.lblReturnTransCode.TabIndex = 0
        Me.lblReturnTransCode.Text = "Transaction : -"
        Me.lblReturnBookTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReturnBookTitle.Location = New System.Drawing.Point(18, 58)
        Me.lblReturnBookTitle.Name = "lblReturnBookTitle"
        Me.lblReturnBookTitle.Size = New System.Drawing.Size(900, 25)
        Me.lblReturnBookTitle.TabIndex = 1
        Me.lblReturnBookTitle.Text = "Book : -"
        Me.lblReturnBorrower.Location = New System.Drawing.Point(18, 90)
        Me.lblReturnBorrower.Name = "lblReturnBorrower"
        Me.lblReturnBorrower.Size = New System.Drawing.Size(900, 22)
        Me.lblReturnBorrower.TabIndex = 2
        Me.lblReturnBorrower.Text = "Borrower : -"
        Me.lblReturnBorrowDate.Location = New System.Drawing.Point(18, 118)
        Me.lblReturnBorrowDate.Name = "lblReturnBorrowDate"
        Me.lblReturnBorrowDate.Size = New System.Drawing.Size(450, 22)
        Me.lblReturnBorrowDate.TabIndex = 3
        Me.lblReturnBorrowDate.Text = "Borrow Date : -"
        Me.lblReturnDueDate.Location = New System.Drawing.Point(490, 118)
        Me.lblReturnDueDate.Name = "lblReturnDueDate"
        Me.lblReturnDueDate.Size = New System.Drawing.Size(430, 22)
        Me.lblReturnDueDate.TabIndex = 4
        Me.lblReturnDueDate.Text = "Due Date : -"
        Me.lblDaysOverdue.Location = New System.Drawing.Point(18, 150)
        Me.lblDaysOverdue.Name = "lblDaysOverdue"
        Me.lblDaysOverdue.Size = New System.Drawing.Size(450, 22)
        Me.lblDaysOverdue.TabIndex = 5
        Me.lblDaysOverdue.Text = "Days Overdue : 0"
        Me.lblFineAmount.Font = New System.Drawing.Font("Segoe UI Semibold", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFineAmount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.lblFineAmount.Location = New System.Drawing.Point(490, 145)
        Me.lblFineAmount.Name = "lblFineAmount"
        Me.lblFineAmount.Size = New System.Drawing.Size(430, 35)
        Me.lblFineAmount.TabIndex = 6
        Me.lblFineAmount.Text = "Fine Amount : Php 0.00"
        Me.btnProcessReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnProcessReturn.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProcessReturn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnProcessReturn.Location = New System.Drawing.Point(15, 445)
        Me.btnProcessReturn.Name = "btnProcessReturn"
        Me.btnProcessReturn.Size = New System.Drawing.Size(250, 45)
        Me.btnProcessReturn.TabIndex = 2
        Me.btnProcessReturn.Text = "&Return"
        Me.btnProcessReturn.UseVisualStyleBackColor = False
        Me.btnClearReturn.Location = New System.Drawing.Point(280, 445)
        Me.btnClearReturn.Name = "btnClearReturn"
        Me.btnClearReturn.Size = New System.Drawing.Size(180, 45)
        Me.btnClearReturn.TabIndex = 3
        Me.btnClearReturn.Text = "&Clear"
        Me.btnClearReturn.UseVisualStyleBackColor = True
        Me.lblReturnResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblReturnResult.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReturnResult.Location = New System.Drawing.Point(15, 500)
        Me.lblReturnResult.Name = "lblReturnResult"
        Me.lblReturnResult.Size = New System.Drawing.Size(955, 45)
        Me.lblReturnResult.TabIndex = 4
        Me.lblReturnResult.Text = "Scan book QR"
        Me.lblReturnResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.tabTransactions.Controls.Add(Me.lblSearchTrans)
        Me.tabTransactions.Controls.Add(Me.txtSearchTrans)
        Me.tabTransactions.Controls.Add(Me.lblTransStatus)
        Me.tabTransactions.Controls.Add(Me.cboTransStatus)
        Me.tabTransactions.Controls.Add(Me.btnSearchTrans)
        Me.tabTransactions.Controls.Add(Me.btnFlagOverdue)
        Me.tabTransactions.Controls.Add(Me.dgvTransactions)
        Me.tabTransactions.Controls.Add(Me.lblTransCount)
        Me.tabTransactions.Location = New System.Drawing.Point(4, 22)
        Me.tabTransactions.Name = "tabTransactions"
        Me.tabTransactions.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTransactions.Size = New System.Drawing.Size(992, 554)
        Me.tabTransactions.TabIndex = 2
        Me.tabTransactions.Text = "Transactions"
        Me.tabTransactions.UseVisualStyleBackColor = True
        Me.lblSearchTrans.AutoSize = True
        Me.lblSearchTrans.Location = New System.Drawing.Point(15, 22)
        Me.lblSearchTrans.Name = "lblSearchTrans"
        Me.lblSearchTrans.TabIndex = 0
        Me.lblSearchTrans.Text = "Search"
        Me.txtSearchTrans.Location = New System.Drawing.Point(70, 19)
        Me.txtSearchTrans.Name = "txtSearchTrans"
        Me.txtSearchTrans.Size = New System.Drawing.Size(250, 20)
        Me.txtSearchTrans.TabIndex = 1
        Me.lblTransStatus.AutoSize = True
        Me.lblTransStatus.Location = New System.Drawing.Point(335, 22)
        Me.lblTransStatus.Name = "lblTransStatus"
        Me.lblTransStatus.TabIndex = 2
        Me.lblTransStatus.Text = "Status :"
        Me.cboTransStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTransStatus.FormattingEnabled = True
        Me.cboTransStatus.Items.AddRange(New Object() {"All", "Borrowed", "Returned", "Overdue"})
        Me.cboTransStatus.Location = New System.Drawing.Point(390, 19)
        Me.cboTransStatus.Name = "cboTransStatus"
        Me.cboTransStatus.Size = New System.Drawing.Size(140, 21)
        Me.cboTransStatus.TabIndex = 3
        Me.btnSearchTrans.Location = New System.Drawing.Point(545, 12)
        Me.btnSearchTrans.Name = "btnSearchTrans"
        Me.btnSearchTrans.Size = New System.Drawing.Size(130, 34)
        Me.btnSearchTrans.TabIndex = 4
        Me.btnSearchTrans.Text = "&Search"
        Me.btnSearchTrans.UseVisualStyleBackColor = True
        Me.btnFlagOverdue.Location = New System.Drawing.Point(690, 12)
        Me.btnFlagOverdue.Name = "btnFlagOverdue"
        Me.btnFlagOverdue.Size = New System.Drawing.Size(220, 34)
        Me.btnFlagOverdue.TabIndex = 5
        Me.btnFlagOverdue.Text = "Flag Overdue"
        Me.btnFlagOverdue.UseVisualStyleBackColor = True
        Me.dgvTransactions.AllowUserToAddRows = False
        Me.dgvTransactions.AllowUserToDeleteRows = False
        Me.dgvTransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTransactions.Location = New System.Drawing.Point(15, 60)
        Me.dgvTransactions.MultiSelect = False
        Me.dgvTransactions.Name = "dgvTransactions"
        Me.dgvTransactions.ReadOnly = True
        Me.dgvTransactions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvTransactions.Size = New System.Drawing.Size(955, 450)
        Me.dgvTransactions.TabIndex = 6
        Me.lblTransCount.AutoSize = True
        Me.lblTransCount.Location = New System.Drawing.Point(15, 522)
        Me.lblTransCount.Name = "lblTransCount"
        Me.lblTransCount.TabIndex = 7
        Me.lblTransCount.Text = "Records: 0"
        Me.btnClose.Location = New System.Drawing.Point(885, 648)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(115, 34)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1024, 692)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.tabMain)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmBorrowReturn"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Borrow & Return"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.tabMain.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.tabMain.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.tabMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabMain.Padding = New System.Drawing.Point(18, 4)
        Me.tabMain.HotTrack = True
        Me.tabBorrow.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.tabBorrow.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.tabBorrow.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.tabBorrow.Padding = New System.Windows.Forms.Padding(3)
        Me.tabBorrow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabBorrow.UseVisualStyleBackColor = False
        Me.tabReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.tabReturn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.tabReturn.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.tabReturn.Padding = New System.Windows.Forms.Padding(3)
        Me.tabReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabReturn.UseVisualStyleBackColor = False
        Me.tabTransactions.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.tabTransactions.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.tabTransactions.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.tabTransactions.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTransactions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabTransactions.UseVisualStyleBackColor = False
        Me.grpBorrower.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpBorrower.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpBorrower.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpBorrower.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblScanBorrower.BackColor = System.Drawing.Color.Transparent
        Me.lblScanBorrower.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanBorrower.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanBorrower.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanBorrower.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBorrowerStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.lblBorrowerStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowerStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBorrowerName.BackColor = System.Drawing.Color.Transparent
        Me.lblBorrowerName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowerType.BackColor = System.Drawing.Color.Transparent
        Me.lblBorrowerType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowerIDNo.BackColor = System.Drawing.Color.Transparent
        Me.lblBorrowerIDNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowerDetail.BackColor = System.Drawing.Color.Transparent
        Me.lblBorrowerDetail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowerBorrowedCount.BackColor = System.Drawing.Color.Transparent
        Me.lblBorrowerBorrowedCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.grpBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpBook.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblScanBook.BackColor = System.Drawing.Color.Transparent
        Me.lblScanBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanBook.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBookStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.lblBookStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBookStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBookTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblBookTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBookAccession.BackColor = System.Drawing.Color.Transparent
        Me.lblBookAccession.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBookAuthor.BackColor = System.Drawing.Color.Transparent
        Me.lblBookAuthor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBookAvailable.BackColor = System.Drawing.Color.Transparent
        Me.lblBookAvailable.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpBorrowDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpBorrowDetails.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpBorrowDetails.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpBorrowDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblBorrowDate.BackColor = System.Drawing.Color.Transparent
        Me.lblBorrowDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpBorrowDate.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.dtpBorrowDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpBorrowDate.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dtpBorrowDate.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpBorrowDate.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dtpBorrowDate.CalendarTitleBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpBorrowDate.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dtpBorrowDate.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblLoanDays.BackColor = System.Drawing.Color.Transparent
        Me.lblLoanDays.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.nudLoanDays.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.nudLoanDays.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.nudLoanDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nudLoanDays.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDueDate.BackColor = System.Drawing.Color.Transparent
        Me.lblDueDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpDueDate.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.dtpDueDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpDueDate.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dtpDueDate.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpDueDate.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dtpDueDate.CalendarTitleBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpDueDate.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dtpDueDate.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnBorrowBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBorrowBook.FlatAppearance.BorderSize = 2
        Me.btnBorrowBook.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnBorrowBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnBorrowBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBorrowBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnBorrowBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnBorrowBook.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnBorrowBook.UseVisualStyleBackColor = False
        Me.btnBorrowBook.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClearBorrow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearBorrow.FlatAppearance.BorderSize = 1
        Me.btnClearBorrow.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClearBorrow.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClearBorrow.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClearBorrow.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClearBorrow.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClearBorrow.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClearBorrow.UseVisualStyleBackColor = False
        Me.btnClearBorrow.Cursor = System.Windows.Forms.Cursors.Hand

        Me.lblBorrowResult.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.lblBorrowResult.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblBorrowResult.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular)
        Me.lblBorrowResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.grpReturnScan.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpReturnScan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpReturnScan.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpReturnScan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblReturnInstruction.BackColor = System.Drawing.Color.Transparent
        Me.lblReturnInstruction.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblScanReturnBook.BackColor = System.Drawing.Color.Transparent
        Me.lblScanReturnBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanReturnBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtScanReturnBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtScanReturnBook.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btnFindBorrowed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFindBorrowed.FlatAppearance.BorderSize = 1
        Me.btnFindBorrowed.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnFindBorrowed.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnFindBorrowed.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnFindBorrowed.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnFindBorrowed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFindBorrowed.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnFindBorrowed.UseVisualStyleBackColor = False
        Me.btnFindBorrowed.Cursor = System.Windows.Forms.Cursors.Hand

        Me.grpReturnInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpReturnInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpReturnInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpReturnInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblReturnTransCode.BackColor = System.Drawing.Color.Transparent
        Me.lblReturnTransCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblReturnBookTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblReturnBookTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblReturnBorrower.BackColor = System.Drawing.Color.Transparent
        Me.lblReturnBorrower.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblReturnBorrowDate.BackColor = System.Drawing.Color.Transparent
        Me.lblReturnBorrowDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblReturnDueDate.BackColor = System.Drawing.Color.Transparent
        Me.lblReturnDueDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblDaysOverdue.BackColor = System.Drawing.Color.Transparent
        Me.lblDaysOverdue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.lblFineAmount.BackColor = System.Drawing.Color.Transparent
        Me.lblFineAmount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnProcessReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProcessReturn.FlatAppearance.BorderSize = 2
        Me.btnProcessReturn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnProcessReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnProcessReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnProcessReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnProcessReturn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnProcessReturn.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnProcessReturn.UseVisualStyleBackColor = False
        Me.btnProcessReturn.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClearReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearReturn.FlatAppearance.BorderSize = 1
        Me.btnClearReturn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClearReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClearReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClearReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClearReturn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClearReturn.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClearReturn.UseVisualStyleBackColor = False
        Me.btnClearReturn.Cursor = System.Windows.Forms.Cursors.Hand

        Me.lblReturnResult.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.lblReturnResult.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.lblReturnResult.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Regular)
        Me.lblReturnResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSearchTrans.BackColor = System.Drawing.Color.Transparent
        Me.lblSearchTrans.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtSearchTrans.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtSearchTrans.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtSearchTrans.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearchTrans.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblTransStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblTransStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboTransStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboTransStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboTransStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboTransStatus.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnSearchTrans.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearchTrans.FlatAppearance.BorderSize = 1
        Me.btnSearchTrans.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSearchTrans.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnSearchTrans.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnSearchTrans.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSearchTrans.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnSearchTrans.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSearchTrans.UseVisualStyleBackColor = False
        Me.btnSearchTrans.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnFlagOverdue.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFlagOverdue.FlatAppearance.BorderSize = 1
        Me.btnFlagOverdue.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.btnFlagOverdue.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnFlagOverdue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnFlagOverdue.BackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnFlagOverdue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnFlagOverdue.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnFlagOverdue.UseVisualStyleBackColor = False
        Me.btnFlagOverdue.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvTransactions.EnableHeadersVisualStyles = False
        Me.dgvTransactions.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvTransactions.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvTransactions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvTransactions.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvTransactions.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvTransactions.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvTransactions.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvTransactions.ColumnHeadersHeight = 32
        Me.dgvTransactions.RowTemplate.Height = 24
        Me.dgvTransactions.RowHeadersVisible = False
        Me.dgvTransactions.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvTransactions.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvTransactions.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvTransactions.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvTransactions.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvTransactions.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvTransactions.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvTransactions.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvTransactions.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvTransactions.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvTransactions.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvTransactions.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvTransactions.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvTransactions.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvTransactions.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvTransactions.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvTransactions.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvTransactions.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvTransactions.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblTransCount.BackColor = System.Drawing.Color.Transparent
        Me.lblTransCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.pnlHeader.ResumeLayout(False)
        Me.tabMain.ResumeLayout(False)
        Me.tabBorrow.ResumeLayout(False)
        Me.tabReturn.ResumeLayout(False)
        Me.tabTransactions.ResumeLayout(False)
        Me.tabTransactions.PerformLayout()
        Me.grpBorrower.ResumeLayout(False)
        Me.grpBorrower.PerformLayout()
        Me.grpBook.ResumeLayout(False)
        Me.grpBook.PerformLayout()
        Me.grpBorrowDetails.ResumeLayout(False)
        Me.grpBorrowDetails.PerformLayout()
        CType(Me.nudLoanDays, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpReturnScan.ResumeLayout(False)
        Me.grpReturnScan.PerformLayout()
        Me.grpReturnInfo.ResumeLayout(False)
        CType(Me.dgvTransactions, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents tabMain As System.Windows.Forms.TabControl
    Friend WithEvents tabBorrow As System.Windows.Forms.TabPage
    Friend WithEvents tabReturn As System.Windows.Forms.TabPage
    Friend WithEvents tabTransactions As System.Windows.Forms.TabPage
    Friend WithEvents grpBorrower As System.Windows.Forms.GroupBox
    Friend WithEvents lblScanBorrower As System.Windows.Forms.Label
    Friend WithEvents txtScanBorrower As System.Windows.Forms.TextBox
    Friend WithEvents lblBorrowerStatus As System.Windows.Forms.Label
    Friend WithEvents lblBorrowerName As System.Windows.Forms.Label
    Friend WithEvents lblBorrowerType As System.Windows.Forms.Label
    Friend WithEvents lblBorrowerIDNo As System.Windows.Forms.Label
    Friend WithEvents lblBorrowerDetail As System.Windows.Forms.Label
    Friend WithEvents lblBorrowerBorrowedCount As System.Windows.Forms.Label
    Friend WithEvents grpBook As System.Windows.Forms.GroupBox
    Friend WithEvents lblScanBook As System.Windows.Forms.Label
    Friend WithEvents txtScanBook As System.Windows.Forms.TextBox
    Friend WithEvents lblBookStatus As System.Windows.Forms.Label
    Friend WithEvents lblBookTitle As System.Windows.Forms.Label
    Friend WithEvents lblBookAccession As System.Windows.Forms.Label
    Friend WithEvents lblBookAuthor As System.Windows.Forms.Label
    Friend WithEvents lblBookAvailable As System.Windows.Forms.Label
    Friend WithEvents grpBorrowDetails As System.Windows.Forms.GroupBox
    Friend WithEvents lblBorrowDate As System.Windows.Forms.Label
    Friend WithEvents dtpBorrowDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblLoanDays As System.Windows.Forms.Label
    Friend WithEvents nudLoanDays As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblDueDate As System.Windows.Forms.Label
    Friend WithEvents dtpDueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnBorrowBook As System.Windows.Forms.Button
    Friend WithEvents btnClearBorrow As System.Windows.Forms.Button
    Friend WithEvents lblBorrowResult As System.Windows.Forms.Label
    Friend WithEvents grpReturnScan As System.Windows.Forms.GroupBox
    Friend WithEvents lblReturnInstruction As System.Windows.Forms.Label
    Friend WithEvents lblScanReturnBook As System.Windows.Forms.Label
    Friend WithEvents txtScanReturnBook As System.Windows.Forms.TextBox
    Friend WithEvents btnFindBorrowed As System.Windows.Forms.Button
    Friend WithEvents grpReturnInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblReturnTransCode As System.Windows.Forms.Label
    Friend WithEvents lblReturnBookTitle As System.Windows.Forms.Label
    Friend WithEvents lblReturnBorrower As System.Windows.Forms.Label
    Friend WithEvents lblReturnBorrowDate As System.Windows.Forms.Label
    Friend WithEvents lblReturnDueDate As System.Windows.Forms.Label
    Friend WithEvents lblDaysOverdue As System.Windows.Forms.Label
    Friend WithEvents lblFineAmount As System.Windows.Forms.Label
    Friend WithEvents btnProcessReturn As System.Windows.Forms.Button
    Friend WithEvents btnClearReturn As System.Windows.Forms.Button
    Friend WithEvents lblReturnResult As System.Windows.Forms.Label
    Friend WithEvents lblSearchTrans As System.Windows.Forms.Label
    Friend WithEvents txtSearchTrans As System.Windows.Forms.TextBox
    Friend WithEvents lblTransStatus As System.Windows.Forms.Label
    Friend WithEvents cboTransStatus As System.Windows.Forms.ComboBox
    Friend WithEvents btnSearchTrans As System.Windows.Forms.Button
    Friend WithEvents btnFlagOverdue As System.Windows.Forms.Button
    Friend WithEvents dgvTransactions As System.Windows.Forms.DataGridView
    Friend WithEvents lblTransCount As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
