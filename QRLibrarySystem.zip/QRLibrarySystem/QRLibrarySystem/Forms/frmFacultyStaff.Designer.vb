<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFacultyStaff
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.grpFacultyInfo = New System.Windows.Forms.GroupBox()
        Me.picQR = New System.Windows.Forms.PictureBox()
        Me.btnGenerateQR = New System.Windows.Forms.Button()
        Me.txtQRCode = New System.Windows.Forms.TextBox()
        Me.lblQRCode = New System.Windows.Forms.Label()
        Me.dtpDateRegistered = New System.Windows.Forms.DateTimePicker()
        Me.lblDateRegistered = New System.Windows.Forms.Label()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.txtContactNumber = New System.Windows.Forms.TextBox()
        Me.lblContactNumber = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.lblPosition = New System.Windows.Forms.Label()
        Me.cboEmploymentType = New System.Windows.Forms.ComboBox()
        Me.lblEmploymentType = New System.Windows.Forms.Label()
        Me.cboDepartment = New System.Windows.Forms.ComboBox()
        Me.lblDepartment = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.txtMiddleName = New System.Windows.Forms.TextBox()
        Me.lblMiddleName = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.txtEmployeeNumber = New System.Windows.Forms.TextBox()
        Me.lblEmployeeNumber = New System.Windows.Forms.Label()
        Me.txtFacultyStaffID = New System.Windows.Forms.TextBox()
        Me.lblFacultyStaffID = New System.Windows.Forms.Label()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dgvFaculty = New System.Windows.Forms.DataGridView()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnPrintQR = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.grpFacultyInfo.SuspendLayout()
        CType(Me.picQR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvFaculty, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1200, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(700, 46)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "Faculty && Staff"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpFacultyInfo.Controls.Add(Me.picQR)
        Me.grpFacultyInfo.Controls.Add(Me.btnGenerateQR)
        Me.grpFacultyInfo.Controls.Add(Me.txtQRCode)
        Me.grpFacultyInfo.Controls.Add(Me.lblQRCode)
        Me.grpFacultyInfo.Controls.Add(Me.dtpDateRegistered)
        Me.grpFacultyInfo.Controls.Add(Me.lblDateRegistered)
        Me.grpFacultyInfo.Controls.Add(Me.cboStatus)
        Me.grpFacultyInfo.Controls.Add(Me.lblStatus)
        Me.grpFacultyInfo.Controls.Add(Me.txtContactNumber)
        Me.grpFacultyInfo.Controls.Add(Me.lblContactNumber)
        Me.grpFacultyInfo.Controls.Add(Me.txtEmail)
        Me.grpFacultyInfo.Controls.Add(Me.lblEmail)
        Me.grpFacultyInfo.Controls.Add(Me.txtPosition)
        Me.grpFacultyInfo.Controls.Add(Me.lblPosition)
        Me.grpFacultyInfo.Controls.Add(Me.cboEmploymentType)
        Me.grpFacultyInfo.Controls.Add(Me.lblEmploymentType)
        Me.grpFacultyInfo.Controls.Add(Me.cboDepartment)
        Me.grpFacultyInfo.Controls.Add(Me.lblDepartment)
        Me.grpFacultyInfo.Controls.Add(Me.txtLastName)
        Me.grpFacultyInfo.Controls.Add(Me.lblLastName)
        Me.grpFacultyInfo.Controls.Add(Me.txtMiddleName)
        Me.grpFacultyInfo.Controls.Add(Me.lblMiddleName)
        Me.grpFacultyInfo.Controls.Add(Me.txtFirstName)
        Me.grpFacultyInfo.Controls.Add(Me.lblFirstName)
        Me.grpFacultyInfo.Controls.Add(Me.txtEmployeeNumber)
        Me.grpFacultyInfo.Controls.Add(Me.lblEmployeeNumber)
        Me.grpFacultyInfo.Controls.Add(Me.txtFacultyStaffID)
        Me.grpFacultyInfo.Controls.Add(Me.lblFacultyStaffID)
        Me.grpFacultyInfo.Location = New System.Drawing.Point(12, 58)
        Me.grpFacultyInfo.Name = "grpFacultyInfo"
        Me.grpFacultyInfo.Size = New System.Drawing.Size(400, 545)
        Me.grpFacultyInfo.TabIndex = 1
        Me.grpFacultyInfo.TabStop = False
        Me.grpFacultyInfo.Text = "Faculty / Staff Information"
        Me.picQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picQR.Location = New System.Drawing.Point(135, 405)
        Me.picQR.Name = "picQR"
        Me.picQR.Size = New System.Drawing.Size(120, 120)
        Me.picQR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picQR.TabIndex = 27
        Me.picQR.TabStop = False
        Me.btnGenerateQR.Location = New System.Drawing.Point(265, 405)
        Me.btnGenerateQR.Name = "btnGenerateQR"
        Me.btnGenerateQR.Size = New System.Drawing.Size(115, 40)
        Me.btnGenerateQR.TabIndex = 26
        Me.btnGenerateQR.Text = "Generate QR"
        Me.btnGenerateQR.UseVisualStyleBackColor = True
        Me.txtQRCode.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtQRCode.Location = New System.Drawing.Point(135, 372)
        Me.txtQRCode.Name = "txtQRCode"
        Me.txtQRCode.ReadOnly = True
        Me.txtQRCode.Size = New System.Drawing.Size(245, 20)
        Me.txtQRCode.TabIndex = 25
        Me.lblQRCode.AutoSize = False
        Me.lblQRCode.Location = New System.Drawing.Point(18, 372)
        Me.lblQRCode.Name = "lblQRCode"
        Me.lblQRCode.Size = New System.Drawing.Size(110, 20)
        Me.lblQRCode.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblQRCode.TabIndex = 24
        Me.lblQRCode.Text = "QR Code :"
        Me.dtpDateRegistered.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpDateRegistered.Location = New System.Drawing.Point(135, 340)
        Me.dtpDateRegistered.Name = "dtpDateRegistered"
        Me.dtpDateRegistered.Size = New System.Drawing.Size(245, 20)
        Me.dtpDateRegistered.TabIndex = 23
        Me.lblDateRegistered.AutoSize = False
        Me.lblDateRegistered.Location = New System.Drawing.Point(18, 341)
        Me.lblDateRegistered.Name = "lblDateRegistered"
        Me.lblDateRegistered.Size = New System.Drawing.Size(110, 20)
        Me.lblDateRegistered.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblDateRegistered.TabIndex = 22
        Me.lblDateRegistered.Text = "Date Registered :"
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Items.AddRange(New Object() {"Active", "Inactive", "On Leave"})
        Me.cboStatus.Location = New System.Drawing.Point(135, 309)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(245, 21)
        Me.cboStatus.TabIndex = 21
        Me.lblStatus.AutoSize = False
        Me.lblStatus.Location = New System.Drawing.Point(18, 309)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(110, 20)
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblStatus.TabIndex = 20
        Me.lblStatus.Text = "Status :"
        Me.txtContactNumber.Location = New System.Drawing.Point(135, 278)
        Me.txtContactNumber.Name = "txtContactNumber"
        Me.txtContactNumber.Size = New System.Drawing.Size(245, 20)
        Me.txtContactNumber.TabIndex = 19
        Me.lblContactNumber.AutoSize = False
        Me.lblContactNumber.Location = New System.Drawing.Point(18, 278)
        Me.lblContactNumber.Name = "lblContactNumber"
        Me.lblContactNumber.Size = New System.Drawing.Size(110, 20)
        Me.lblContactNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblContactNumber.TabIndex = 18
        Me.lblContactNumber.Text = "Contact Number :"
        Me.txtEmail.Location = New System.Drawing.Point(135, 247)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(245, 20)
        Me.txtEmail.TabIndex = 17
        Me.lblEmail.AutoSize = False
        Me.lblEmail.Location = New System.Drawing.Point(18, 247)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(110, 20)
        Me.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblEmail.TabIndex = 16
        Me.lblEmail.Text = "Email :"
        Me.txtPosition.Location = New System.Drawing.Point(300, 216)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(80, 20)
        Me.txtPosition.TabIndex = 15
        Me.lblPosition.AutoSize = True
        Me.lblPosition.Location = New System.Drawing.Point(252, 219)
        Me.lblPosition.Name = "lblPosition"
        Me.lblPosition.Size = New System.Drawing.Size(49, 13)
        Me.lblPosition.TabIndex = 14
        Me.lblPosition.Text = "Position :"
        Me.cboEmploymentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEmploymentType.FormattingEnabled = True
        Me.cboEmploymentType.Items.AddRange(New Object() {"Full-Time", "Part-Time", "Contractual"})
        Me.cboEmploymentType.Location = New System.Drawing.Point(135, 216)
        Me.cboEmploymentType.Name = "cboEmploymentType"
        Me.cboEmploymentType.Size = New System.Drawing.Size(110, 21)
        Me.cboEmploymentType.TabIndex = 13
        Me.lblEmploymentType.AutoSize = False
        Me.lblEmploymentType.Location = New System.Drawing.Point(18, 216)
        Me.lblEmploymentType.Name = "lblEmploymentType"
        Me.lblEmploymentType.Size = New System.Drawing.Size(110, 20)
        Me.lblEmploymentType.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblEmploymentType.TabIndex = 12
        Me.lblEmploymentType.Text = "Emp. Type :"
        Me.cboDepartment.FormattingEnabled = True
        Me.cboDepartment.Items.AddRange(New Object() {"College of Information Technology", "College of Education", "College of Business", "College of Hospitality Management", "Senior High School", "Administration", "Other"})
        Me.cboDepartment.Location = New System.Drawing.Point(135, 185)
        Me.cboDepartment.Name = "cboDepartment"
        Me.cboDepartment.Size = New System.Drawing.Size(245, 21)
        Me.cboDepartment.TabIndex = 11
        Me.lblDepartment.AutoSize = False
        Me.lblDepartment.Location = New System.Drawing.Point(18, 185)
        Me.lblDepartment.Name = "lblDepartment"
        Me.lblDepartment.Size = New System.Drawing.Size(110, 20)
        Me.lblDepartment.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblDepartment.TabIndex = 10
        Me.lblDepartment.Text = "Department :"
        Me.txtLastName.Location = New System.Drawing.Point(135, 154)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(245, 20)
        Me.txtLastName.TabIndex = 9
        Me.lblLastName.AutoSize = False
        Me.lblLastName.Location = New System.Drawing.Point(18, 154)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(110, 20)
        Me.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblLastName.TabIndex = 8
        Me.lblLastName.Text = "Last Name :"
        Me.txtMiddleName.Location = New System.Drawing.Point(135, 123)
        Me.txtMiddleName.Name = "txtMiddleName"
        Me.txtMiddleName.Size = New System.Drawing.Size(245, 20)
        Me.txtMiddleName.TabIndex = 7
        Me.lblMiddleName.AutoSize = False
        Me.lblMiddleName.Location = New System.Drawing.Point(18, 123)
        Me.lblMiddleName.Name = "lblMiddleName"
        Me.lblMiddleName.Size = New System.Drawing.Size(110, 20)
        Me.lblMiddleName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblMiddleName.TabIndex = 6
        Me.lblMiddleName.Text = "Middle Name :"
        Me.txtFirstName.Location = New System.Drawing.Point(135, 92)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(245, 20)
        Me.txtFirstName.TabIndex = 5
        Me.lblFirstName.AutoSize = False
        Me.lblFirstName.Location = New System.Drawing.Point(18, 92)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(110, 20)
        Me.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblFirstName.TabIndex = 4
        Me.lblFirstName.Text = "First Name :"
        Me.txtEmployeeNumber.Location = New System.Drawing.Point(135, 61)
        Me.txtEmployeeNumber.Name = "txtEmployeeNumber"
        Me.txtEmployeeNumber.Size = New System.Drawing.Size(245, 20)
        Me.txtEmployeeNumber.TabIndex = 3
        Me.lblEmployeeNumber.AutoSize = False
        Me.lblEmployeeNumber.Location = New System.Drawing.Point(18, 61)
        Me.lblEmployeeNumber.Name = "lblEmployeeNumber"
        Me.lblEmployeeNumber.Size = New System.Drawing.Size(110, 20)
        Me.lblEmployeeNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblEmployeeNumber.TabIndex = 2
        Me.lblEmployeeNumber.Text = "Employee Number :"
        Me.txtFacultyStaffID.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.txtFacultyStaffID.Location = New System.Drawing.Point(135, 30)
        Me.txtFacultyStaffID.Name = "txtFacultyStaffID"
        Me.txtFacultyStaffID.ReadOnly = True
        Me.txtFacultyStaffID.Size = New System.Drawing.Size(245, 20)
        Me.txtFacultyStaffID.TabIndex = 1
        Me.lblFacultyStaffID.AutoSize = False
        Me.lblFacultyStaffID.Location = New System.Drawing.Point(18, 30)
        Me.lblFacultyStaffID.Name = "lblFacultyStaffID"
        Me.lblFacultyStaffID.Size = New System.Drawing.Size(110, 20)
        Me.lblFacultyStaffID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblFacultyStaffID.TabIndex = 0
        Me.lblFacultyStaffID.Text = "Faculty ID :"
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Location = New System.Drawing.Point(432, 68)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Size = New System.Drawing.Size(47, 13)
        Me.lblSearch.TabIndex = 2
        Me.lblSearch.Text = "Search"
        Me.txtSearch.Location = New System.Drawing.Point(485, 65)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(566, 20)
        Me.txtSearch.TabIndex = 3
        Me.btnSearch.Location = New System.Drawing.Point(1061, 58)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(115, 32)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "&Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        Me.dgvFaculty.AllowUserToAddRows = False
        Me.dgvFaculty.AllowUserToDeleteRows = False
        Me.dgvFaculty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvFaculty.Location = New System.Drawing.Point(432, 100)
        Me.dgvFaculty.MultiSelect = False
        Me.dgvFaculty.Name = "dgvFaculty"
        Me.dgvFaculty.ReadOnly = True
        Me.dgvFaculty.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvFaculty.Size = New System.Drawing.Size(744, 475)
        Me.dgvFaculty.TabIndex = 5
        Me.lblCount.AutoSize = True
        Me.lblCount.Location = New System.Drawing.Point(432, 585)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(102, 13)
        Me.lblCount.TabIndex = 6
        Me.lblCount.Text = "Records: 0"
        Me.btnNew.Location = New System.Drawing.Point(12, 615)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(85, 34)
        Me.btnNew.TabIndex = 7
        Me.btnNew.Text = "&New"
        Me.btnNew.UseVisualStyleBackColor = True
        Me.btnSave.Location = New System.Drawing.Point(105, 615)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(85, 34)
        Me.btnSave.TabIndex = 8
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        Me.btnUpdate.Location = New System.Drawing.Point(198, 615)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(85, 34)
        Me.btnUpdate.TabIndex = 9
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        Me.btnDelete.Location = New System.Drawing.Point(291, 615)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(85, 34)
        Me.btnDelete.TabIndex = 10
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        Me.btnClear.Location = New System.Drawing.Point(384, 615)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(85, 34)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        Me.btnPrintQR.Location = New System.Drawing.Point(477, 615)
        Me.btnPrintQR.Name = "btnPrintQR"
        Me.btnPrintQR.Size = New System.Drawing.Size(130, 34)
        Me.btnPrintQR.TabIndex = 12
        Me.btnPrintQR.Text = "&Print QR"
        Me.btnPrintQR.UseVisualStyleBackColor = True
        Me.btnClose.Location = New System.Drawing.Point(1061, 615)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(115, 34)
        Me.btnClose.TabIndex = 13
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 661)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnPrintQR)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.dgvFaculty)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.lblSearch)
        Me.Controls.Add(Me.grpFacultyInfo)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmFacultyStaff"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Faculty & Staff"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.grpFacultyInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpFacultyInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpFacultyInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpFacultyInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFacultyStaffID.BackColor = System.Drawing.Color.Transparent
        Me.lblFacultyStaffID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtFacultyStaffID.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.txtFacultyStaffID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txtFacultyStaffID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFacultyStaffID.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblEmployeeNumber.BackColor = System.Drawing.Color.Transparent
        Me.lblEmployeeNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtEmployeeNumber.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtEmployeeNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtEmployeeNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmployeeNumber.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblFirstName.BackColor = System.Drawing.Color.Transparent
        Me.lblFirstName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtFirstName.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtFirstName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFirstName.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblMiddleName.BackColor = System.Drawing.Color.Transparent
        Me.lblMiddleName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtMiddleName.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtMiddleName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtMiddleName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMiddleName.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblLastName.BackColor = System.Drawing.Color.Transparent
        Me.lblLastName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtLastName.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtLastName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLastName.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDepartment.BackColor = System.Drawing.Color.Transparent
        Me.lblDepartment.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboDepartment.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboDepartment.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboDepartment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboDepartment.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblEmploymentType.BackColor = System.Drawing.Color.Transparent
        Me.lblEmploymentType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboEmploymentType.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboEmploymentType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboEmploymentType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboEmploymentType.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblPosition.BackColor = System.Drawing.Color.Transparent
        Me.lblPosition.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtPosition.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtPosition.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPosition.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblEmail.BackColor = System.Drawing.Color.Transparent
        Me.lblEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtEmail.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmail.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblContactNumber.BackColor = System.Drawing.Color.Transparent
        Me.lblContactNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtContactNumber.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtContactNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtContactNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtContactNumber.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboStatus.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblDateRegistered.BackColor = System.Drawing.Color.Transparent
        Me.lblDateRegistered.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpDateRegistered.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.dtpDateRegistered.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpDateRegistered.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dtpDateRegistered.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dtpDateRegistered.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dtpDateRegistered.CalendarTitleBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dtpDateRegistered.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dtpDateRegistered.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblQRCode.BackColor = System.Drawing.Color.Transparent
        Me.lblQRCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtQRCode.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.txtQRCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtQRCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQRCode.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnGenerateQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGenerateQR.FlatAppearance.BorderSize = 1
        Me.btnGenerateQR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnGenerateQR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnGenerateQR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnGenerateQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnGenerateQR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnGenerateQR.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnGenerateQR.UseVisualStyleBackColor = False
        Me.btnGenerateQR.Cursor = System.Windows.Forms.Cursors.Hand

        Me.picQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.picQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSearch.BackColor = System.Drawing.Color.Transparent
        Me.lblSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.FlatAppearance.BorderSize = 1
        Me.btnSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSearch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnSearch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSearch.UseVisualStyleBackColor = False
        Me.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvFaculty.EnableHeadersVisualStyles = False
        Me.dgvFaculty.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvFaculty.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvFaculty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvFaculty.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvFaculty.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvFaculty.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvFaculty.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvFaculty.ColumnHeadersHeight = 32
        Me.dgvFaculty.RowTemplate.Height = 24
        Me.dgvFaculty.RowHeadersVisible = False
        Me.dgvFaculty.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvFaculty.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvFaculty.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvFaculty.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvFaculty.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvFaculty.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvFaculty.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvFaculty.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvFaculty.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvFaculty.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvFaculty.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvFaculty.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvFaculty.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvFaculty.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvFaculty.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvFaculty.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvFaculty.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvFaculty.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvFaculty.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblCount.BackColor = System.Drawing.Color.Transparent
        Me.lblCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNew.FlatAppearance.BorderSize = 1
        Me.btnNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnNew.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnNew.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnNew.UseVisualStyleBackColor = False
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.FlatAppearance.BorderSize = 2
        Me.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnSave.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnSave.UseVisualStyleBackColor = False
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.FlatAppearance.BorderSize = 1
        Me.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnUpdate.UseVisualStyleBackColor = False
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.FlatAppearance.BorderSize = 1
        Me.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(165, Byte), Integer))
        Me.btnDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.btnDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(127, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer))
        Me.btnDelete.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnDelete.UseVisualStyleBackColor = False
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.FlatAppearance.BorderSize = 1
        Me.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnPrintQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPrintQR.FlatAppearance.BorderSize = 1
        Me.btnPrintQR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnPrintQR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnPrintQR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnPrintQR.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnPrintQR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPrintQR.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnPrintQR.UseVisualStyleBackColor = False
        Me.btnPrintQR.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.pnlHeader.ResumeLayout(False)
        Me.grpFacultyInfo.ResumeLayout(False)
        Me.grpFacultyInfo.PerformLayout()
        CType(Me.picQR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvFaculty, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents grpFacultyInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblFacultyStaffID As System.Windows.Forms.Label
    Friend WithEvents txtFacultyStaffID As System.Windows.Forms.TextBox
    Friend WithEvents lblEmployeeNumber As System.Windows.Forms.Label
    Friend WithEvents txtEmployeeNumber As System.Windows.Forms.TextBox
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents lblMiddleName As System.Windows.Forms.Label
    Friend WithEvents txtMiddleName As System.Windows.Forms.TextBox
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents lblDepartment As System.Windows.Forms.Label
    Friend WithEvents cboDepartment As System.Windows.Forms.ComboBox
    Friend WithEvents lblEmploymentType As System.Windows.Forms.Label
    Friend WithEvents cboEmploymentType As System.Windows.Forms.ComboBox
    Friend WithEvents lblPosition As System.Windows.Forms.Label
    Friend WithEvents txtPosition As System.Windows.Forms.TextBox
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblContactNumber As System.Windows.Forms.Label
    Friend WithEvents txtContactNumber As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblDateRegistered As System.Windows.Forms.Label
    Friend WithEvents dtpDateRegistered As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblQRCode As System.Windows.Forms.Label
    Friend WithEvents txtQRCode As System.Windows.Forms.TextBox
    Friend WithEvents btnGenerateQR As System.Windows.Forms.Button
    Friend WithEvents picQR As System.Windows.Forms.PictureBox
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents dgvFaculty As System.Windows.Forms.DataGridView
    Friend WithEvents lblCount As System.Windows.Forms.Label
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnPrintQR As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
