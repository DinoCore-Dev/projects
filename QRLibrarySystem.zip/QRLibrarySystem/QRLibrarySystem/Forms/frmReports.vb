Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Drawing.Printing
Imports System.IO
Imports System.Text

Public Class frmReports

#Region "Form-local session and database code (NO MODULES are used in this project)"
    Public CurrentUserID As Integer = 0
    Public CurrentLibraryStaffID As Integer = 0
    Public CurrentUsername As String = ""
    Public CurrentFullName As String = ""
    Public CurrentUserLevel As String = ""
    Public CurrentStaffRole As String = ""

    Private ReadOnly DatabaseFile As String = System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "LibraryDB.sdf")
    Private ReadOnly DatabaseConnectionString As String = "Data Source=" & DatabaseFile & ";Persist Security Info=False;"

    Private Function DbPath() As String
        Return DatabaseFile
    End Function

    Private Function ConnString() As String
        Return DatabaseConnectionString
    End Function

    Private Function IsAdministrator() As Boolean
        Return (CurrentUserLevel = "Administrator")
    End Function

    Private Function OpenDatabaseConnection() As SqlCeConnection
        Dim cn As New SqlCeConnection(DatabaseConnectionString)
        cn.Open()
        Return cn
    End Function

    Private Function P(ByVal name As String, ByVal value As Object) As SqlCeParameter
        If value Is Nothing Then value = DBNull.Value
        Return New SqlCeParameter(name, value)
    End Function

    Private Function RunNonQuery(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteNonQuery()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetTable(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As DataTable
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Dim da As New SqlCeDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            Return dt
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetScalar(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Object
        Dim cn As SqlCeConnection = Nothing
        Try
            cn = OpenDatabaseConnection()
            Dim cmd As New SqlCeCommand(sql, cn)
            Dim i As Integer
            For i = 0 To pars.Length - 1
                cmd.Parameters.Add(pars(i))
            Next
            Return cmd.ExecuteScalar()
        Finally
            If cn IsNot Nothing Then
                cn.Close()
                cn.Dispose()
            End If
        End Try
    End Function

    Private Function GetCount(ByVal sql As String, ByVal ParamArray pars() As SqlCeParameter) As Integer
        Dim value As Object = GetScalar(sql, pars)
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function DbStr(ByVal row As DataRow, ByVal col As String) As String
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return ""
        Return CStr(row(col))
    End Function

    Private Function DbInt(ByVal row As DataRow, ByVal col As String) As Integer
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0
        Return CInt(row(col))
    End Function

    Private Function DbDec(ByVal row As DataRow, ByVal col As String) As Decimal
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return 0D
        Return CDec(row(col))
    End Function

    Private Function DbDate(ByVal row As DataRow, ByVal col As String) As Date
        If row Is Nothing OrElse IsDBNull(row(col)) Then Return Date.Today
        Return CDate(row(col))
    End Function

    Private Function CellStr(ByVal gridRow As DataGridViewRow, ByVal col As String) As String
        If gridRow Is Nothing Then Return ""
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return ""
        Return CStr(value)
    End Function

    Private Function CellInt(ByVal gridRow As DataGridViewRow, ByVal col As String) As Integer
        If gridRow Is Nothing Then Return 0
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return 0
        Return CInt(value)
    End Function

    Private Function CellDate(ByVal gridRow As DataGridViewRow, ByVal col As String) As Date
        If gridRow Is Nothing Then Return Date.Today
        Dim value As Object = gridRow.Cells(col).Value
        If value Is Nothing OrElse IsDBNull(value) Then Return Date.Today
        Return CDate(value)
    End Function

    Private Sub WriteUserLog(ByVal actionPerformed As String, ByVal moduleAccessed As String, _
                             ByVal tableAffected As String, ByVal recordId As Integer, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            Dim uid As Object = DBNull.Value
            If CurrentUserID > 0 Then uid = CurrentUserID
            Dim rid As Object = DBNull.Value
            If recordId > 0 Then rid = recordId
            RunNonQuery("INSERT INTO USER_LOGS (userid, action_performed, module_accessed, table_affected, record_id, description, ip_address, log_timestamp) " & _
                        "VALUES (@uid,@act,@mod,@tbl,@rid,@desc,@ip,@ts)", _
                        P("@uid", uid), P("@act", actionPerformed), P("@mod", moduleAccessed), _
                        P("@tbl", tableAffected), P("@rid", rid), P("@desc", description), _
                        P("@ip", "127.0.0.1"), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub WriteSystemLog(ByVal logType As String, ByVal logLevel As String, _
                               ByVal eventSource As String, ByVal description As String)
        Try
            If Not System.IO.File.Exists(DatabaseFile) Then Exit Sub
            RunNonQuery("INSERT INTO SYSTEM_LOGS (userlogid, log_type, log_level, event_source, description, ip_address, device_info, logged_at) " & _
                        "VALUES (@ul,@type,@level,@src,@desc,@ip,@dev,@ts)", _
                        P("@ul", DBNull.Value), P("@type", logType), P("@level", logLevel), _
                        P("@src", eventSource), P("@desc", description), P("@ip", "127.0.0.1"), _
                        P("@dev", Environment.MachineName), P("@ts", DateTime.Now))
        Catch
        End Try
    End Sub

    Private Sub ShowError(ByVal title As String, ByVal ex As Exception)
        Try
            WriteSystemLog("Error", "Error", title, ex.Message)
        Catch
        End Try
        MessageBox.Show(title & ": " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
#End Region


    Private _reportTitle As String = "Report"
    Private _printRow As Integer = 0

    Private Sub frmReports_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
        cboReportType.SelectedIndex = 0
        dtpFrom.Value = Date.Today.AddMonths(-1)
        dtpTo.Value = Date.Today
        GenerateReport()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        GenerateReport()
    End Sub

    Private Sub FormatReportGrid()
        Try
            dgvReport.RowHeadersWidth = 25
            dgvReport.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            Dim col As DataGridViewColumn
            For Each col In dgvReport.Columns
                col.MinimumWidth = 60
                If col.ValueType Is GetType(Date) Then
                    If col.HeaderText.Contains("Time") Then col.DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt" Else col.DefaultCellStyle.Format = "MM/dd/yyyy"
                End If
            Next
        Catch
        End Try
    End Sub

    Private Sub GenerateReport()
        If dtpFrom.Value.Date > dtpTo.Value.Date Then
            MessageBox.Show("Date From cannot be later than Date To.", "Reports", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim dFrom As Date = dtpFrom.Value.Date
        Dim dToEx As Date = dtpTo.Value.Date.AddDays(1)
        _reportTitle = cboReportType.Text

        Try
            Dim dt As DataTable = Nothing
            Dim sql As String = ""

            Select Case cboReportType.Text
                Case "Visitor Report"
                    sql = "SELECT v.visitorlogid AS [Log ID], " & _
                          "CASE WHEN v.visitor_type='Student' THEN (s.last_name + ', ' + s.first_name) " & _
                          "ELSE (f.last_name + ', ' + f.first_name) END AS [Visitor Name], " & _
                          "v.visitor_type AS [Type], v.purpose_of_visit AS [Purpose], v.visit_date AS [Visit Date], " & _
                          "v.time_in AS [Time In], v.time_out AS [Time Out], v.duration_minutes AS [Minutes] " & _
                          "FROM VISITORS_LOG v LEFT JOIN STUDENTS s ON v.studentid=s.studentid " & _
                          "LEFT JOIN FACULTY_STAFF f ON v.facultystaffid=f.facultystaffid " & _
                          "WHERE v.visit_date >= @f AND v.visit_date < @t ORDER BY v.time_in"
                    dt = GetTable(sql, P("@f", dFrom), P("@t", dToEx))

                Case "Circulation Report"
                    sql = "SELECT t.transaction_code AS [Transaction Code], b.title AS [Book Title], " & _
                          "CASE WHEN t.borrower_type='Student' THEN (s.last_name + ', ' + s.first_name) " & _
                          "ELSE (f.last_name + ', ' + f.first_name) END AS [Borrower], " & _
                          "t.borrower_type AS [Type], t.borrow_date AS [Borrow Date], t.due_date AS [Due Date], " & _
                          "t.return_date AS [Return Date], t.days_overdue AS [Days Overdue], " & _
                          "t.fine_amount AS [Fine], t.status AS [Status] " & _
                          "FROM BORROW_TRANSACTIONS t LEFT JOIN BOOKS b ON t.bookid=b.bookid " & _
                          "LEFT JOIN STUDENTS s ON t.studentid=s.studentid " & _
                          "LEFT JOIN FACULTY_STAFF f ON t.facultystaffid=f.facultystaffid " & _
                          "WHERE t.borrow_date >= @f AND t.borrow_date < @t ORDER BY t.borrow_date"
                    dt = GetTable(sql, P("@f", dFrom), P("@t", dToEx))

                Case "Book Inventory Report"
                    sql = "SELECT b.accession_no AS [Accession No.], b.title AS [Title], b.author AS [Author], " & _
                          "b.isbn AS [ISBN], c.category_name AS [Category], b.shelf_location AS [Shelf], " & _
                          "b.total_copies AS [Total Copies], b.available_copies AS [Available], " & _
                          "b.status AS [Status], b.qr_code AS [QR Code] " & _
                          "FROM BOOKS b LEFT JOIN CATEGORIES c ON b.categoryid=c.categoryid " & _
                          "ORDER BY c.category_name, b.title"
                    dt = GetTable(sql)

                Case "Overdue Report"
                    sql = "SELECT t.transaction_code AS [Transaction Code], b.title AS [Book Title], " & _
                          "CASE WHEN t.borrower_type='Student' THEN (s.last_name + ', ' + s.first_name) " & _
                          "ELSE (f.last_name + ', ' + f.first_name) END AS [Borrower], " & _
                          "t.borrower_type AS [Type], t.borrow_date AS [Borrow Date], t.due_date AS [Due Date], " & _
                          "t.status AS [Status] " & _
                          "FROM BORROW_TRANSACTIONS t LEFT JOIN BOOKS b ON t.bookid=b.bookid " & _
                          "LEFT JOIN STUDENTS s ON t.studentid=s.studentid " & _
                          "LEFT JOIN FACULTY_STAFF f ON t.facultystaffid=f.facultystaffid " & _
                          "WHERE t.return_date IS NULL AND t.due_date < @today " & _
                          "AND t.borrow_date >= @f AND t.borrow_date < @t ORDER BY t.due_date"
                    dt = GetTable(sql, P("@today", Date.Today), P("@f", dFrom), P("@t", dToEx))
            End Select

            dgvReport.DataSource = dt
            FormatReportGrid()
            If dt Is Nothing Then
                lblTotalRecords.Text = "Records: 0"
                lblSummary.Text = "Summary : -"
            Else
                lblTotalRecords.Text = "Records: " & dt.Rows.Count
                lblSummary.Text = BuildSummary(dt)
            End If

            WriteUserLog("Generate Report", "Reports & Statistics", "", 0, _
                         _reportTitle & " from " & dFrom.ToString("yyyy-MM-dd") & " to " & dtpTo.Value.ToString("yyyy-MM-dd"))

        Catch ex As Exception
            WriteSystemLog("Reports", "Error", "frmReports.Generate", ex.Message)
            MessageBox.Show("Error generating report: " & ex.Message, "Reports", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function BuildSummary(ByVal dt As DataTable) As String
        Select Case cboReportType.Text
            Case "Visitor Report"
                Dim students As Integer = 0
                Dim faculty As Integer = 0
                Dim r As DataRow
                For Each r In dt.Rows
                    If DbStr(r, "Type") = "Student" Then students += 1 Else faculty += 1
                Next
                Return "Summary : Student visits = " & students & "   |   Faculty/Staff visits = " & faculty

            Case "Circulation Report"
                Dim returned As Integer = 0
                Dim unreturned As Integer = 0
                Dim totalFine As Decimal = 0D
                Dim r As DataRow
                For Each r In dt.Rows
                    If DbStr(r, "Status") = "Returned" Then returned += 1 Else unreturned += 1
                    totalFine += DbDec(r, "Fine")
                Next
                Return "Summary : Returned = " & returned & "   |   Still Borrowed / Overdue = " & unreturned & _
                       "   |   Total Fines Collected = Php " & totalFine.ToString("N2")

            Case "Book Inventory Report"
                Dim totalCopies As Integer = 0
                Dim availCopies As Integer = 0
                Dim r As DataRow
                For Each r In dt.Rows
                    totalCopies += DbInt(r, "Total Copies")
                    availCopies += DbInt(r, "Available")
                Next
                Return "Summary : Book Titles = " & dt.Rows.Count & "   |   Total Copies = " & totalCopies & _
                       "   |   Available Copies = " & availCopies

            Case "Overdue Report"
                Return "Summary : " & dt.Rows.Count & " unreturned book(s) are already past the due date. " & _
                       "Fine (Php 5.00/day) is computed on return."
            Case Else
                Return "Summary : -"
        End Select
    End Function

    Private Sub btnExportCSV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportCSV.Click
        Dim dt As DataTable = CType(dgvReport.DataSource, DataTable)
        If dt Is Nothing OrElse dt.Rows.Count = 0 Then
            MessageBox.Show("Nothing to export. Generate a report first.", "Export CSV", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim sfd As New SaveFileDialog()
        sfd.Title = "Export Report to CSV"
        sfd.Filter = "CSV File (*.csv)|*.csv"
        sfd.FileName = _reportTitle.Replace(" ", "_") & "_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".csv"
        If sfd.ShowDialog() <> DialogResult.OK Then Exit Sub

        Try
            Dim sb As New StringBuilder()
            Dim c As Integer
            For c = 0 To dt.Columns.Count - 1
                If c > 0 Then sb.Append(",")
                sb.Append(CsvCell(dt.Columns(c).ColumnName))
            Next
            sb.AppendLine()

            Dim r As DataRow
            For Each r In dt.Rows
                For c = 0 To dt.Columns.Count - 1
                    If c > 0 Then sb.Append(",")
                    Dim val As String = ""
                    If Not IsDBNull(r(c)) Then val = CStr(r(c))
                    sb.Append(CsvCell(val))
                Next
                sb.AppendLine()
            Next

            File.WriteAllText(sfd.FileName, sb.ToString())
            MessageBox.Show("Report exported to:" & vbCrLf & sfd.FileName, "Export CSV", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error exporting CSV: " & ex.Message, "Export CSV", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function CsvCell(ByVal value As String) As String
        If value Is Nothing Then value = ""
        Return """" & value.Replace("""", """""") & """"
    End Function

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Try
        Dim dt As DataTable = CType(dgvReport.DataSource, DataTable)
        If dt Is Nothing OrElse dt.Rows.Count = 0 Then
            MessageBox.Show("Nothing to print. Generate a report first.", "Print", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        prnReport.DefaultPageSettings.Landscape = True
        ppdReport.Document = prnReport
        ppdReport.Width = 900
        ppdReport.Height = 650
        ppdReport.ShowDialog()
        Catch ex As Exception
            ShowError("Unexpected error in " & Me.Name, ex)
        End Try
    End Sub

    Private Sub prnReport_BeginPrint(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles prnReport.BeginPrint
        _printRow = 0
    End Sub

    Private Sub prnReport_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles prnReport.PrintPage
        Dim dt As DataTable = CType(dgvReport.DataSource, DataTable)
        If dt Is Nothing Then
            e.HasMorePages = False
            Exit Sub
        End If

        Dim g As Graphics = e.Graphics
        Dim left As Integer = e.MarginBounds.Left
        Dim top As Integer = e.MarginBounds.Top
        Dim width As Integer = e.MarginBounds.Width
        Dim bottom As Integer = e.MarginBounds.Bottom

        Dim fontTitle As New Font("Segoe UI Semibold", 13, FontStyle.Regular)
        Dim fontSub As New Font("Segoe UI", 9)
        Dim fontHead As New Font("Segoe UI Semibold", 7.5, FontStyle.Regular)
        Dim fontRow As New Font("Segoe UI", 7.5)

        Dim y As Integer = top
        If _printRow = 0 Then
            g.DrawString("QR-BASED LIBRARY MANAGEMENT SYSTEM", fontTitle, Brushes.Black, left, y)
            y += 24
            g.DrawString(_reportTitle & "   |   " & dtpFrom.Value.ToString("MMM dd, yyyy") & " to " & _
                         dtpTo.Value.ToString("MMM dd, yyyy") & "   |   Printed: " & DateTime.Now.ToString("MMM dd, yyyy hh:mm tt") & _
                         "   |   By: " & CurrentFullName, fontSub, Brushes.Black, left, y)
            y += 26
        End If

        If dt.Columns.Count = 0 Then
            e.HasMorePages = False
            Exit Sub
        End If
        Dim colW As Integer = width \ dt.Columns.Count
        If colW < 55 Then colW = 55

        Dim x As Integer = left
        Dim c As Integer
        For c = 0 To dt.Columns.Count - 1
            g.DrawString(SafeText(dt.Columns(c).ColumnName, 18), fontHead, Brushes.Black, x, y)
            x += colW
        Next
        y += 18
        g.DrawLine(Pens.Black, left, y, left + width, y)
        y += 6

        While _printRow < dt.Rows.Count
            x = left
            For c = 0 To dt.Columns.Count - 1
                Dim val As String = ""
                If Not IsDBNull(dt.Rows(_printRow)(c)) Then
                    Dim obj As Object = dt.Rows(_printRow)(c)
                    If TypeOf obj Is DateTime Then
                        val = CDate(obj).ToString("yyyy-MM-dd HH:mm")
                    Else
                        val = CStr(obj)
                    End If
                End If
                g.DrawString(SafeText(val, 20), fontRow, Brushes.Black, x, y)
                x += colW
            Next
            y += 16
            _printRow += 1
            If y > bottom - 30 AndAlso _printRow < dt.Rows.Count Then
                e.HasMorePages = True
                Exit Sub
            End If
        End While

        y += 12
        g.DrawString(lblTotalRecords.Text & "    " & lblSummary.Text, fontSub, Brushes.Black, left, y)
        e.HasMorePages = False
    End Sub

    Private Function SafeText(ByVal value As String, ByVal maxLen As Integer) As String
        If value Is Nothing Then Return ""
        value = value.Replace(vbCrLf, " ").Replace(vbCr, " ").Replace(vbLf, " ")
        If value.Length > maxLen Then Return value.Substring(0, maxLen - 3) & "..."
        Return value
    End Function

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
