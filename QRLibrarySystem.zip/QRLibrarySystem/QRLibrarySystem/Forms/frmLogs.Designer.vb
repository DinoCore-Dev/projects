<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLogs
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.tabMain = New System.Windows.Forms.TabControl()
        Me.tabUserLogs = New System.Windows.Forms.TabPage()
        Me.tabSystemLogs = New System.Windows.Forms.TabPage()
        Me.lblSearchUserLog = New System.Windows.Forms.Label()
        Me.txtSearchUserLog = New System.Windows.Forms.TextBox()
        Me.btnRefreshUserLogs = New System.Windows.Forms.Button()
        Me.dgvUserLogs = New System.Windows.Forms.DataGridView()
        Me.lblUserLogCount = New System.Windows.Forms.Label()
        Me.lblSearchSystemLog = New System.Windows.Forms.Label()
        Me.txtSearchSystemLog = New System.Windows.Forms.TextBox()
        Me.lblSystemLogLevel = New System.Windows.Forms.Label()
        Me.cboSystemLogLevel = New System.Windows.Forms.ComboBox()
        Me.btnRefreshSystemLogs = New System.Windows.Forms.Button()
        Me.dgvSystemLogs = New System.Windows.Forms.DataGridView()
        Me.lblSystemLogCount = New System.Windows.Forms.Label()
        Me.grpBackup = New System.Windows.Forms.GroupBox()
        Me.lblDbPath = New System.Windows.Forms.Label()
        Me.btnBackup = New System.Windows.Forms.Button()
        Me.btnRestore = New System.Windows.Forms.Button()
        Me.lblBackupNote = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.tabMain.SuspendLayout()
        Me.tabUserLogs.SuspendLayout()
        Me.tabSystemLogs.SuspendLayout()
        CType(Me.dgvUserLogs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvSystemLogs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpBackup.SuspendLayout()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1024, 46)
        Me.pnlHeader.TabIndex = 0
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Location = New System.Drawing.Point(12, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(850, 46)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "Logs && Backup"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.tabMain.Controls.Add(Me.tabUserLogs)
        Me.tabMain.Controls.Add(Me.tabSystemLogs)
        Me.tabMain.Location = New System.Drawing.Point(12, 58)
        Me.tabMain.Name = "tabMain"
        Me.tabMain.SelectedIndex = 0
        Me.tabMain.Size = New System.Drawing.Size(1000, 475)
        Me.tabMain.TabIndex = 1
        Me.tabUserLogs.Controls.Add(Me.lblSearchUserLog)
        Me.tabUserLogs.Controls.Add(Me.txtSearchUserLog)
        Me.tabUserLogs.Controls.Add(Me.btnRefreshUserLogs)
        Me.tabUserLogs.Controls.Add(Me.dgvUserLogs)
        Me.tabUserLogs.Controls.Add(Me.lblUserLogCount)
        Me.tabUserLogs.Location = New System.Drawing.Point(4, 22)
        Me.tabUserLogs.Name = "tabUserLogs"
        Me.tabUserLogs.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUserLogs.Size = New System.Drawing.Size(992, 449)
        Me.tabUserLogs.TabIndex = 0
        Me.tabUserLogs.Text = "User Log"
        Me.tabUserLogs.UseVisualStyleBackColor = True
        Me.lblSearchUserLog.AutoSize = True
        Me.lblSearchUserLog.Location = New System.Drawing.Point(15, 22)
        Me.lblSearchUserLog.Name = "lblSearchUserLog"
        Me.lblSearchUserLog.TabIndex = 0
        Me.lblSearchUserLog.Text = "Search"
        Me.txtSearchUserLog.Location = New System.Drawing.Point(70, 19)
        Me.txtSearchUserLog.Name = "txtSearchUserLog"
        Me.txtSearchUserLog.Size = New System.Drawing.Size(450, 20)
        Me.txtSearchUserLog.TabIndex = 1
        Me.btnRefreshUserLogs.Location = New System.Drawing.Point(535, 12)
        Me.btnRefreshUserLogs.Name = "btnRefreshUserLogs"
        Me.btnRefreshUserLogs.Size = New System.Drawing.Size(150, 34)
        Me.btnRefreshUserLogs.TabIndex = 2
        Me.btnRefreshUserLogs.Text = "&Refresh"
        Me.btnRefreshUserLogs.UseVisualStyleBackColor = True
        Me.dgvUserLogs.AllowUserToAddRows = False
        Me.dgvUserLogs.AllowUserToDeleteRows = False
        Me.dgvUserLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvUserLogs.Location = New System.Drawing.Point(15, 58)
        Me.dgvUserLogs.MultiSelect = False
        Me.dgvUserLogs.Name = "dgvUserLogs"
        Me.dgvUserLogs.ReadOnly = True
        Me.dgvUserLogs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvUserLogs.Size = New System.Drawing.Size(955, 350)
        Me.dgvUserLogs.TabIndex = 3
        Me.lblUserLogCount.AutoSize = True
        Me.lblUserLogCount.Location = New System.Drawing.Point(15, 418)
        Me.lblUserLogCount.Name = "lblUserLogCount"
        Me.lblUserLogCount.TabIndex = 4
        Me.lblUserLogCount.Text = "Records: 0"
        Me.tabSystemLogs.Controls.Add(Me.lblSearchSystemLog)
        Me.tabSystemLogs.Controls.Add(Me.txtSearchSystemLog)
        Me.tabSystemLogs.Controls.Add(Me.lblSystemLogLevel)
        Me.tabSystemLogs.Controls.Add(Me.cboSystemLogLevel)
        Me.tabSystemLogs.Controls.Add(Me.btnRefreshSystemLogs)
        Me.tabSystemLogs.Controls.Add(Me.dgvSystemLogs)
        Me.tabSystemLogs.Controls.Add(Me.lblSystemLogCount)
        Me.tabSystemLogs.Location = New System.Drawing.Point(4, 22)
        Me.tabSystemLogs.Name = "tabSystemLogs"
        Me.tabSystemLogs.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSystemLogs.Size = New System.Drawing.Size(992, 449)
        Me.tabSystemLogs.TabIndex = 1
        Me.tabSystemLogs.Text = "System Log"
        Me.tabSystemLogs.UseVisualStyleBackColor = True
        Me.lblSearchSystemLog.AutoSize = True
        Me.lblSearchSystemLog.Location = New System.Drawing.Point(15, 22)
        Me.lblSearchSystemLog.Name = "lblSearchSystemLog"
        Me.lblSearchSystemLog.TabIndex = 0
        Me.lblSearchSystemLog.Text = "Search"
        Me.txtSearchSystemLog.Location = New System.Drawing.Point(70, 19)
        Me.txtSearchSystemLog.Name = "txtSearchSystemLog"
        Me.txtSearchSystemLog.Size = New System.Drawing.Size(320, 20)
        Me.txtSearchSystemLog.TabIndex = 1
        Me.lblSystemLogLevel.AutoSize = True
        Me.lblSystemLogLevel.Location = New System.Drawing.Point(405, 22)
        Me.lblSystemLogLevel.Name = "lblSystemLogLevel"
        Me.lblSystemLogLevel.TabIndex = 2
        Me.lblSystemLogLevel.Text = "Log Level :"
        Me.cboSystemLogLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSystemLogLevel.FormattingEnabled = True
        Me.cboSystemLogLevel.Items.AddRange(New Object() {"All", "Information", "Warning", "Error"})
        Me.cboSystemLogLevel.Location = New System.Drawing.Point(475, 19)
        Me.cboSystemLogLevel.Name = "cboSystemLogLevel"
        Me.cboSystemLogLevel.Size = New System.Drawing.Size(150, 21)
        Me.cboSystemLogLevel.TabIndex = 3
        Me.btnRefreshSystemLogs.Location = New System.Drawing.Point(640, 12)
        Me.btnRefreshSystemLogs.Name = "btnRefreshSystemLogs"
        Me.btnRefreshSystemLogs.Size = New System.Drawing.Size(150, 34)
        Me.btnRefreshSystemLogs.TabIndex = 4
        Me.btnRefreshSystemLogs.Text = "&Refresh"
        Me.btnRefreshSystemLogs.UseVisualStyleBackColor = True
        Me.dgvSystemLogs.AllowUserToAddRows = False
        Me.dgvSystemLogs.AllowUserToDeleteRows = False
        Me.dgvSystemLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSystemLogs.Location = New System.Drawing.Point(15, 58)
        Me.dgvSystemLogs.MultiSelect = False
        Me.dgvSystemLogs.Name = "dgvSystemLogs"
        Me.dgvSystemLogs.ReadOnly = True
        Me.dgvSystemLogs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSystemLogs.Size = New System.Drawing.Size(955, 350)
        Me.dgvSystemLogs.TabIndex = 5
        Me.lblSystemLogCount.AutoSize = True
        Me.lblSystemLogCount.Location = New System.Drawing.Point(15, 418)
        Me.lblSystemLogCount.Name = "lblSystemLogCount"
        Me.lblSystemLogCount.TabIndex = 6
        Me.lblSystemLogCount.Text = "Records: 0"
        Me.grpBackup.Controls.Add(Me.lblDbPath)
        Me.grpBackup.Controls.Add(Me.btnBackup)
        Me.grpBackup.Controls.Add(Me.btnRestore)
        Me.grpBackup.Controls.Add(Me.lblBackupNote)
        Me.grpBackup.Controls.Add(Me.btnClose)
        Me.grpBackup.Location = New System.Drawing.Point(12, 545)
        Me.grpBackup.Name = "grpBackup"
        Me.grpBackup.Size = New System.Drawing.Size(1000, 125)
        Me.grpBackup.TabIndex = 2
        Me.grpBackup.TabStop = False
        Me.grpBackup.Text = "Backup && Restore"
        Me.lblDbPath.Location = New System.Drawing.Point(18, 25)
        Me.lblDbPath.Name = "lblDbPath"
        Me.lblDbPath.Size = New System.Drawing.Size(950, 20)
        Me.lblDbPath.TabIndex = 0
        Me.lblDbPath.Text = "Database : -"
        Me.btnBackup.Location = New System.Drawing.Point(18, 55)
        Me.btnBackup.Name = "btnBackup"
        Me.btnBackup.Size = New System.Drawing.Size(200, 40)
        Me.btnBackup.TabIndex = 1
        Me.btnBackup.Text = "&Backup"
        Me.btnBackup.UseVisualStyleBackColor = True
        Me.btnRestore.Location = New System.Drawing.Point(232, 55)
        Me.btnRestore.Name = "btnRestore"
        Me.btnRestore.Size = New System.Drawing.Size(200, 40)
        Me.btnRestore.TabIndex = 2
        Me.btnRestore.Text = "&Restore"
        Me.btnRestore.UseVisualStyleBackColor = True
        Me.lblBackupNote.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblBackupNote.Location = New System.Drawing.Point(450, 55)
        Me.lblBackupNote.Name = "lblBackupNote"
        Me.lblBackupNote.Size = New System.Drawing.Size(380, 55)
        Me.lblBackupNote.TabIndex = 3
        Me.lblBackupNote.Text = "Restore replaces LibraryDB.sdf. Restart after restoring."
        Me.btnClose.Location = New System.Drawing.Point(855, 55)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(125, 40)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "Cl&ose"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1024, 682)
        Me.Controls.Add(Me.grpBackup)
        Me.Controls.Add(Me.tabMain)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "frmLogs"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Logs & Backup"
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.lblFormTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 13.0!, System.Drawing.FontStyle.Regular)
        Me.tabMain.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.tabMain.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Regular)
        Me.tabMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabMain.Padding = New System.Drawing.Point(18, 4)
        Me.tabMain.HotTrack = True
        Me.tabUserLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.tabUserLogs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.tabUserLogs.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.tabUserLogs.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUserLogs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabUserLogs.UseVisualStyleBackColor = False
        Me.tabSystemLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.tabSystemLogs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.tabSystemLogs.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.tabSystemLogs.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSystemLogs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabSystemLogs.UseVisualStyleBackColor = False
        Me.lblSearchUserLog.BackColor = System.Drawing.Color.Transparent
        Me.lblSearchUserLog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtSearchUserLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtSearchUserLog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtSearchUserLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearchUserLog.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnRefreshUserLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefreshUserLogs.FlatAppearance.BorderSize = 1
        Me.btnRefreshUserLogs.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnRefreshUserLogs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnRefreshUserLogs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnRefreshUserLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnRefreshUserLogs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRefreshUserLogs.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnRefreshUserLogs.UseVisualStyleBackColor = False
        Me.btnRefreshUserLogs.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvUserLogs.EnableHeadersVisualStyles = False
        Me.dgvUserLogs.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvUserLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvUserLogs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvUserLogs.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvUserLogs.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvUserLogs.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvUserLogs.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvUserLogs.ColumnHeadersHeight = 32
        Me.dgvUserLogs.RowTemplate.Height = 24
        Me.dgvUserLogs.RowHeadersVisible = False
        Me.dgvUserLogs.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvUserLogs.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvUserLogs.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvUserLogs.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvUserLogs.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvUserLogs.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvUserLogs.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvUserLogs.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvUserLogs.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvUserLogs.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvUserLogs.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvUserLogs.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvUserLogs.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvUserLogs.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvUserLogs.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvUserLogs.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvUserLogs.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvUserLogs.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvUserLogs.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblUserLogCount.BackColor = System.Drawing.Color.Transparent
        Me.lblUserLogCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblSearchSystemLog.BackColor = System.Drawing.Color.Transparent
        Me.lblSearchSystemLog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.txtSearchSystemLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.txtSearchSystemLog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.txtSearchSystemLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearchSystemLog.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.lblSystemLogLevel.BackColor = System.Drawing.Color.Transparent
        Me.lblSystemLogLevel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.cboSystemLogLevel.BackColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.cboSystemLogLevel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.cboSystemLogLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboSystemLogLevel.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.btnRefreshSystemLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefreshSystemLogs.FlatAppearance.BorderSize = 1
        Me.btnRefreshSystemLogs.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnRefreshSystemLogs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnRefreshSystemLogs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnRefreshSystemLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnRefreshSystemLogs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRefreshSystemLogs.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnRefreshSystemLogs.UseVisualStyleBackColor = False
        Me.btnRefreshSystemLogs.Cursor = System.Windows.Forms.Cursors.Hand

        Me.dgvSystemLogs.EnableHeadersVisualStyles = False
        Me.dgvSystemLogs.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvSystemLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.dgvSystemLogs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dgvSystemLogs.GridColor = System.Drawing.Color.FromArgb(CType(CType(148, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.dgvSystemLogs.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvSystemLogs.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvSystemLogs.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single
        Me.dgvSystemLogs.ColumnHeadersHeight = 32
        Me.dgvSystemLogs.RowTemplate.Height = 24
        Me.dgvSystemLogs.RowHeadersVisible = False
        Me.dgvSystemLogs.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.dgvSystemLogs.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgvSystemLogs.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvSystemLogs.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvSystemLogs.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvSystemLogs.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvSystemLogs.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.dgvSystemLogs.AlternatingRowsDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.dgvSystemLogs.AlternatingRowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvSystemLogs.AlternatingRowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgvSystemLogs.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvSystemLogs.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvSystemLogs.ColumnHeadersDefaultCellStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.dgvSystemLogs.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgvSystemLogs.ColumnHeadersDefaultCellStyle.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dgvSystemLogs.RowHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dgvSystemLogs.RowHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.dgvSystemLogs.RowHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.dgvSystemLogs.RowHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))

        Me.lblSystemLogCount.BackColor = System.Drawing.Color.Transparent
        Me.lblSystemLogCount.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.grpBackup.BackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.grpBackup.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.grpBackup.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.grpBackup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDbPath.BackColor = System.Drawing.Color.Transparent
        Me.lblDbPath.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnBackup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBackup.FlatAppearance.BorderSize = 2
        Me.btnBackup.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnBackup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnBackup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.btnBackup.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnBackup.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(253, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.btnBackup.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnBackup.UseVisualStyleBackColor = False
        Me.btnBackup.Cursor = System.Windows.Forms.Cursors.Hand

        Me.btnRestore.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRestore.FlatAppearance.BorderSize = 1
        Me.btnRestore.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnRestore.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(179, Byte), Integer), CType(CType(8, Byte), Integer))
        Me.btnRestore.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(98, Byte), Integer), CType(CType(7, Byte), Integer))
        Me.btnRestore.BackColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.btnRestore.ForeColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRestore.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnRestore.UseVisualStyleBackColor = False
        Me.btnRestore.Cursor = System.Windows.Forms.Cursors.Hand

        Me.lblBackupNote.BackColor = System.Drawing.Color.Transparent
        Me.lblBackupNote.ForeColor = System.Drawing.Color.FromArgb(CType(CType(82, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.FlatAppearance.BorderSize = 1
        Me.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(122, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(199, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand

        Me.pnlHeader.ResumeLayout(False)
        Me.tabMain.ResumeLayout(False)
        Me.tabUserLogs.ResumeLayout(False)
        Me.tabUserLogs.PerformLayout()
        Me.tabSystemLogs.ResumeLayout(False)
        Me.tabSystemLogs.PerformLayout()
        CType(Me.dgvUserLogs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvSystemLogs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpBackup.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents tabMain As System.Windows.Forms.TabControl
    Friend WithEvents tabUserLogs As System.Windows.Forms.TabPage
    Friend WithEvents tabSystemLogs As System.Windows.Forms.TabPage
    Friend WithEvents lblSearchUserLog As System.Windows.Forms.Label
    Friend WithEvents txtSearchUserLog As System.Windows.Forms.TextBox
    Friend WithEvents btnRefreshUserLogs As System.Windows.Forms.Button
    Friend WithEvents dgvUserLogs As System.Windows.Forms.DataGridView
    Friend WithEvents lblUserLogCount As System.Windows.Forms.Label
    Friend WithEvents lblSearchSystemLog As System.Windows.Forms.Label
    Friend WithEvents txtSearchSystemLog As System.Windows.Forms.TextBox
    Friend WithEvents lblSystemLogLevel As System.Windows.Forms.Label
    Friend WithEvents cboSystemLogLevel As System.Windows.Forms.ComboBox
    Friend WithEvents btnRefreshSystemLogs As System.Windows.Forms.Button
    Friend WithEvents dgvSystemLogs As System.Windows.Forms.DataGridView
    Friend WithEvents lblSystemLogCount As System.Windows.Forms.Label
    Friend WithEvents grpBackup As System.Windows.Forms.GroupBox
    Friend WithEvents lblDbPath As System.Windows.Forms.Label
    Friend WithEvents btnBackup As System.Windows.Forms.Button
    Friend WithEvents btnRestore As System.Windows.Forms.Button
    Friend WithEvents lblBackupNote As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
