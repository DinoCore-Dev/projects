Imports MessagingToolkit.QRCode.Codec
Imports System.Drawing
Imports System.Drawing.Printing

Public Class frmQRPreview

    Public QRText As String = ""
    Public DisplayName As String = ""
    Public Detail1 As String = ""
    Public Detail2 As String = ""
    Public FormTitle As String = "QR CODE"

    Private Sub frmQRPreview_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
        lblFormTitle.Text = FormTitle
        lblCodeValue.Text = QRText
        lblName.Text = DisplayName
        lblDetail1.Text = Detail1
        lblDetail2.Text = Detail2
        ShowQRCodeInPictureBox(picQR, QRText)
        If picQR.Image Is Nothing Then
            btnPrint.Enabled = False
            btnSaveImage.Enabled = False
        End If
        Catch ex As Exception
            MessageBox.Show("Unexpected error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnSaveImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveImage.Click
        Try
        If picQR.Image Is Nothing Then Exit Sub
        Dim sfd As New SaveFileDialog()
        sfd.Title = "Save QR Code Image"
        sfd.Filter = "PNG Image (*.png)|*.png|JPEG Image (*.jpg)|*.jpg|Bitmap (*.bmp)|*.bmp"
        sfd.FileName = QRText & ".png"
        If sfd.ShowDialog() = DialogResult.OK Then
            Dim fmt As System.Drawing.Imaging.ImageFormat = System.Drawing.Imaging.ImageFormat.Png
            If sfd.FileName.ToLower().EndsWith(".jpg") Then fmt = System.Drawing.Imaging.ImageFormat.Jpeg
            If sfd.FileName.ToLower().EndsWith(".bmp") Then fmt = System.Drawing.Imaging.ImageFormat.Bmp
            picQR.Image.Save(sfd.FileName, fmt)
            MessageBox.Show("QR image saved to:" & vbCrLf & sfd.FileName, "Save Image", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        Catch ex As Exception
            MessageBox.Show("Unexpected error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Try
        If picQR.Image Is Nothing Then Exit Sub
        ppdQR.Document = prnQR
        ppdQR.Width = 700
        ppdQR.Height = 600
        ppdQR.ShowDialog()
        Catch ex As Exception
            MessageBox.Show("Unexpected error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub prnQR_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles prnQR.PrintPage
        Dim g As Graphics = e.Graphics
        Dim cx As Integer = e.PageBounds.Width \ 2
        Dim sf As New StringFormat()
        sf.Alignment = StringAlignment.Center
        Dim forestBrush As New SolidBrush(Color.FromArgb(20, 83, 45))
        Dim amberPen As New Pen(Color.FromArgb(202, 138, 4), 2)

        g.DrawString("QR LIBRARY SYSTEM", New Font("Segoe UI Semibold", 13, FontStyle.Regular), forestBrush, cx, 60, sf)
        g.DrawString(FormTitle, New Font("Segoe UI Semibold", 10, FontStyle.Regular), forestBrush, cx, 90, sf)
        g.DrawLine(amberPen, cx - 160, 118, cx + 160, 118)

        If picQR.Image IsNot Nothing Then
            g.DrawImage(picQR.Image, cx - 125, 130, 250, 250)
        End If

        g.DrawString(QRText, New Font("Segoe UI Semibold", 12, FontStyle.Regular), forestBrush, cx, 395, sf)
        g.DrawString(DisplayName, New Font("Segoe UI Semibold", 12, FontStyle.Regular), forestBrush, cx, 430, sf)
        g.DrawString(Detail1, New Font("Segoe UI", 10), forestBrush, cx, 460, sf)
        g.DrawString(Detail2, New Font("Segoe UI", 10), forestBrush, cx, 482, sf)
        forestBrush.Dispose()
        amberPen.Dispose()
        e.HasMorePages = False
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


#Region "Form-local QR code generation (NO MODULES / NO HELPER CLASS)"
    Private Function GenerateQRCodeImage(ByVal content As String) As System.Drawing.Bitmap
        If content Is Nothing OrElse content.Trim() = "" Then Return Nothing
        Dim encoder As New QRCodeEncoder()
        encoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE
        encoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M
        encoder.QRCodeScale = 6
        encoder.QRCodeVersion = 7
        encoder.QRCodeBackgroundColor = System.Drawing.Color.FromArgb(240, 253, 244)
        encoder.QRCodeForegroundColor = System.Drawing.Color.FromArgb(20, 83, 45)
        Dim qrOnly As System.Drawing.Bitmap = encoder.Encode(content.Trim())
        Dim margin As Integer = encoder.QRCodeScale * 4
        Dim result As New System.Drawing.Bitmap(qrOnly.Width + (margin * 2), qrOnly.Height + (margin * 2))
        Dim g As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(result)
        Try
            g.Clear(System.Drawing.Color.FromArgb(240, 253, 244))
            g.DrawImage(qrOnly, margin, margin)
        Finally
            g.Dispose()
            qrOnly.Dispose()
        End Try
        Return result
    End Function

    Private Sub ShowQRCodeInPictureBox(ByVal pic As System.Windows.Forms.PictureBox, ByVal content As String)
        Try
            If content Is Nothing OrElse content.Trim() = "" Then
                pic.Image = Nothing
                Exit Sub
            End If
            Dim oldImage As System.Drawing.Image = pic.Image
            pic.Image = GenerateQRCodeImage(content.Trim())
            pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            If oldImage IsNot Nothing Then oldImage.Dispose()
            If pic.Image Is Nothing Then
                MessageBox.Show("The QR code could not be generated. Please check the QR value.", _
                                "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            pic.Image = Nothing
            MessageBox.Show("QR code generation failed: " & ex.Message & vbCrLf & _
                            "Check that MessagingToolkit.QRCode.dll is beside the EXE in bin\Debug.", _
                            "QR Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

End Class
