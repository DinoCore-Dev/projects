Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmTeachers
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"

    Public Property LoggedAdminId As Integer = 1
    Private _selectedId As Integer = 0

    Private Sub frmTeachers_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvTeachers)
            cmbStatus.Items.Clear()
            cmbStatus.Items.AddRange(New Object() {"Active", "Inactive"})
            cmbStatus.SelectedIndex = 0
            txtDepartment.Text = "Information Technology"
            LoadTeachers()
        Catch ex As Exception
            MessageBox.Show("Failed to load Teachers:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try
        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 36
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 34
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.25F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub txtContact_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles txtContact.KeyPress
        If Char.IsControl(e.KeyChar) Then Return
        If Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "+"c OrElse e.KeyChar = "-"c OrElse e.KeyChar = " "c OrElse e.KeyChar = "("c OrElse e.KeyChar = ")"c Then Return
        e.Handled = True
    End Sub

    Private Function IsValidEmail(ByVal email As String) As Boolean
        If String.IsNullOrEmpty(email) Then Return True
        Dim atPos As Integer = email.IndexOf("@"c)
        If atPos <= 0 OrElse atPos <> email.LastIndexOf("@"c) Then Return False
        Dim dotPos As Integer = email.IndexOf("."c, atPos + 2)
        Return (dotPos > atPos + 1 AndAlso dotPos < email.Length - 1 AndAlso Not email.Contains(" "))
    End Function

    Private Sub LoadTeachers()
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Dim q As String = txtSearch.Text.Trim()
                Dim sql As String = "SELECT teacherid, employee_no, full_name, contact_number, email, department, status FROM TEACHERS"
                Using cmd As New SqlCeCommand()
                    cmd.Connection = conn
                    If Not String.IsNullOrEmpty(q) Then
                        sql &= " WHERE employee_no LIKE @q OR full_name LIKE @q OR department LIKE @q"
                        cmd.Parameters.AddWithValue("@q", "%" & q & "%")
                    End If
                    sql &= " ORDER BY full_name ASC"
                    cmd.CommandText = sql

                    Dim dt As New DataTable()
                    Using da As New SqlCeDataAdapter(cmd)
                        da.Fill(dt)
                    End Using
                    dgvTeachers.DataSource = dt
                End Using
            End Using

            If dgvTeachers.Columns.Contains("teacherid") Then dgvTeachers.Columns("teacherid").Visible = False
            If dgvTeachers.Columns.Contains("employee_no") Then dgvTeachers.Columns("employee_no").HeaderText = "Employee No."
            If dgvTeachers.Columns.Contains("full_name") Then dgvTeachers.Columns("full_name").HeaderText = "Full Name"
            If dgvTeachers.Columns.Contains("contact_number") Then dgvTeachers.Columns("contact_number").HeaderText = "Contact"
            If dgvTeachers.Columns.Contains("email") Then dgvTeachers.Columns("email").HeaderText = "Email"
            If dgvTeachers.Columns.Contains("department") Then dgvTeachers.Columns("department").HeaderText = "Department"
            If dgvTeachers.Columns.Contains("status") Then dgvTeachers.Columns("status").HeaderText = "Status"
        Catch ex As Exception
            MessageBox.Show("Error loading teachers:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgvTeachers_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvTeachers.CellClick
        If e.RowIndex < 0 OrElse dgvTeachers.CurrentRow Is Nothing Then Return
        Try
            Dim drv As DataRowView = TryCast(dgvTeachers.CurrentRow.DataBoundItem, DataRowView)
            If drv Is Nothing Then Return

            _selectedId = Convert.ToInt32(drv("teacherid"))
            txtEmployeeNo.Text = Convert.ToString(drv("employee_no"))
            txtFullName.Text = Convert.ToString(drv("full_name"))
            txtContact.Text = If(IsDBNull(drv("contact_number")), "", Convert.ToString(drv("contact_number")))
            txtEmail.Text = If(IsDBNull(drv("email")), "", Convert.ToString(drv("email")))
            txtDepartment.Text = If(IsDBNull(drv("department")), "", Convert.ToString(drv("department")))
            cmbStatus.Text = Convert.ToString(drv("status"))
            btnSave.Text = "Update"
        Catch ex As Exception
            MessageBox.Show("Selection error:" & Environment.NewLine & ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub ClearInputs()
        _selectedId = 0
        txtEmployeeNo.Text = ""
        txtFullName.Text = ""
        txtContact.Text = ""
        txtEmail.Text = ""
        txtDepartment.Text = "Information Technology"
        If cmbStatus.Items.Count > 0 Then cmbStatus.SelectedIndex = 0
        btnSave.Text = "Save"
        dgvTeachers.ClearSelection()
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ClearInputs()
        txtEmployeeNo.Focus()
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Dim empNo As String = txtEmployeeNo.Text.Trim()
        Dim fullName As String = txtFullName.Text.Trim()
        Dim phone As String = txtContact.Text.Trim()
        Dim mail As String = txtEmail.Text.Trim()
        Dim dept As String = txtDepartment.Text.Trim()

        If String.IsNullOrEmpty(empNo) Then
            MessageBox.Show("Employee No. is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtEmployeeNo.Focus()
            Return
        End If
        If String.IsNullOrEmpty(fullName) Then
            MessageBox.Show("Full Name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtFullName.Focus()
            Return
        End If
        If Not IsValidEmail(mail) Then
            MessageBox.Show("Enter a valid email address (e.g. name@domain.edu).", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtEmail.Focus()
            Return
        End If
        If String.IsNullOrEmpty(dept) Then
            MessageBox.Show("Department is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtDepartment.Focus()
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using dupCmd As New SqlCeCommand("SELECT COUNT(*) FROM TEACHERS WHERE employee_no = @en AND teacherid <> @id", conn)
                    dupCmd.Parameters.AddWithValue("@en", empNo)
                    dupCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(dupCmd.ExecuteScalar()) > 0 Then
                        MessageBox.Show("Employee No. '" & empNo & "' already exists.", "Duplicate Employee No.", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        txtEmployeeNo.Focus()
                        Return
                    End If
                End Using

                If _selectedId = 0 Then
                    Using cmd As New SqlCeCommand("INSERT INTO TEACHERS (employee_no, full_name, contact_number, email, department, status, created_at) VALUES (@en, @fn, @cn, @em, @dp, @st, @dt)", conn)
                        cmd.Parameters.AddWithValue("@en", empNo)
                        cmd.Parameters.AddWithValue("@fn", fullName)
                        cmd.Parameters.AddWithValue("@cn", phone)
                        cmd.Parameters.AddWithValue("@em", mail)
                        cmd.Parameters.AddWithValue("@dp", dept)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                        cmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "CREATE", empNo, "Added teacher " & fullName)
                    MessageBox.Show("Teacher saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    Using cmd As New SqlCeCommand("UPDATE TEACHERS SET employee_no=@en, full_name=@fn, contact_number=@cn, email=@em, department=@dp, status=@st WHERE teacherid=@id", conn)
                        cmd.Parameters.AddWithValue("@en", empNo)
                        cmd.Parameters.AddWithValue("@fn", fullName)
                        cmd.Parameters.AddWithValue("@cn", phone)
                        cmd.Parameters.AddWithValue("@em", mail)
                        cmd.Parameters.AddWithValue("@dp", dept)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.Parameters.AddWithValue("@id", _selectedId)
                        cmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "UPDATE", empNo, "Updated teacher " & fullName)
                    MessageBox.Show("Teacher updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using

            ClearInputs()
            LoadTeachers()
        Catch ex As SqlCeException
            MessageBox.Show("Database error while saving teacher:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("Unexpected error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click
        If _selectedId <= 0 Then
            MessageBox.Show("Select a teacher from the list first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using chkCmd As New SqlCeCommand("SELECT COUNT(*) FROM SCHEDULES WHERE teacherid = @id", conn)
                    chkCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(chkCmd.ExecuteScalar()) > 0 Then
                        If MessageBox.Show("This teacher is assigned to schedules. Set status to Inactive instead?", "Teacher Assigned", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                            Using upCmd As New SqlCeCommand("UPDATE TEACHERS SET status = 'Inactive' WHERE teacherid = @id", conn)
                                upCmd.Parameters.AddWithValue("@id", _selectedId)
                                upCmd.ExecuteNonQuery()
                            End Using
                            LogAudit(conn, "ARCHIVE", txtEmployeeNo.Text.Trim(), "Set teacher Inactive")
                            ClearInputs()
                            LoadTeachers()
                        End If
                        Return
                    End If
                End Using

                If MessageBox.Show("Delete teacher '" & txtFullName.Text.Trim() & "'?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
                    Using delCmd As New SqlCeCommand("DELETE FROM TEACHERS WHERE teacherid = @id", conn)
                        delCmd.Parameters.AddWithValue("@id", _selectedId)
                        delCmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "DELETE", txtEmployeeNo.Text.Trim(), "Deleted teacher")
                    ClearInputs()
                    LoadTeachers()
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Delete error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged
        LoadTeachers()
    End Sub

    Private Sub LogAudit(ByVal conn As SqlCeConnection, ByVal action As String, ByVal refCode As String, ByVal desc As String)
        Try
            Dim aidObj As Object = If(LoggedAdminId > 0, CObj(LoggedAdminId), CObj(DBNull.Value))
            Using cmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, @act, 'Teachers', @ref, @dsc, @dev, @dt)", conn)
                cmd.Parameters.AddWithValue("@aid", aidObj)
                cmd.Parameters.AddWithValue("@act", action)
                cmd.Parameters.AddWithValue("@ref", refCode)
                cmd.Parameters.AddWithValue("@dsc", desc)
                cmd.Parameters.AddWithValue("@dev", Environment.MachineName)
                cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                cmd.ExecuteNonQuery()
            End Using
        Catch
        End Try
    End Sub
End Class
