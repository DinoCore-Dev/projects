Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Reflection
Imports System.Security.Cryptography
Imports System.Text
Imports System.Windows.Forms

Public Class frmAdmins
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"

    Public Property LoggedAdminId As Integer = 1
    Private _selectedId As Integer = 0

    Private Sub frmAdmins_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvAdmins)
            cmbRole.Items.Clear()
            cmbRole.Items.AddRange(New Object() {"Super Admin", "Attendance Officer", "Registrar Staff"})
            cmbRole.SelectedIndex = 0

            cmbStatus.Items.Clear()
            cmbStatus.Items.AddRange(New Object() {"Active", "Inactive"})
            cmbStatus.SelectedIndex = 0

            LoadAdmins()
        Catch ex As Exception
            MessageBox.Show("Failed to initialize Admins:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try
        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 36
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 34
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.25F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Function HashPassword(ByVal plainText As String) As String
        Using sha As SHA256 = SHA256.Create()
            Dim bytes As Byte() = sha.ComputeHash(Encoding.UTF8.GetBytes(plainText))
            Dim sb As New StringBuilder()
            For Each b As Byte In bytes
                sb.Append(b.ToString("x2"))
            Next
            Return sb.ToString()
        End Using
    End Function

    Private Sub txtContact_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles txtContact.KeyPress
        If Char.IsControl(e.KeyChar) Then Return
        If Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "+"c OrElse e.KeyChar = "-"c OrElse e.KeyChar = " "c Then Return
        e.Handled = True
    End Sub

    Private Function IsValidEmail(ByVal email As String) As Boolean
        If String.IsNullOrEmpty(email) Then Return True
        Dim atPos As Integer = email.IndexOf("@"c)
        If atPos <= 0 OrElse atPos <> email.LastIndexOf("@"c) Then Return False
        Dim dotPos As Integer = email.IndexOf("."c, atPos + 2)
        Return (dotPos > atPos + 1 AndAlso dotPos < email.Length - 1 AndAlso Not email.Contains(" "))
    End Function

    Private Sub LoadAdmins()
        Using conn As New SqlCeConnection(ConnStr)
            conn.Open()
            Dim dt As New DataTable()
            Using da As New SqlCeDataAdapter("SELECT adminid, username, full_name, contact_number, email, role, status, last_login FROM ADMINS ORDER BY adminid ASC", conn)
                da.Fill(dt)
            End Using
            dgvAdmins.DataSource = dt
        End Using

        If dgvAdmins.Columns.Contains("adminid") Then dgvAdmins.Columns("adminid").Visible = False
        If dgvAdmins.Columns.Contains("username") Then dgvAdmins.Columns("username").HeaderText = "Username"
        If dgvAdmins.Columns.Contains("full_name") Then dgvAdmins.Columns("full_name").HeaderText = "Full Name"
        If dgvAdmins.Columns.Contains("contact_number") Then dgvAdmins.Columns("contact_number").HeaderText = "Contact"
        If dgvAdmins.Columns.Contains("email") Then dgvAdmins.Columns("email").HeaderText = "Email"
        If dgvAdmins.Columns.Contains("role") Then dgvAdmins.Columns("role").HeaderText = "Role"
        If dgvAdmins.Columns.Contains("status") Then dgvAdmins.Columns("status").HeaderText = "Status"
        If dgvAdmins.Columns.Contains("last_login") Then dgvAdmins.Columns("last_login").HeaderText = "Last Login"
    End Sub

    Private Sub dgvAdmins_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvAdmins.CellClick
        If e.RowIndex < 0 OrElse dgvAdmins.CurrentRow Is Nothing Then Return
        Try
            Dim drv As DataRowView = TryCast(dgvAdmins.CurrentRow.DataBoundItem, DataRowView)
            If drv Is Nothing Then Return

            _selectedId = Convert.ToInt32(drv("adminid"))
            txtUsername.Text = Convert.ToString(drv("username"))
            txtFullName.Text = Convert.ToString(drv("full_name"))
            txtContact.Text = If(IsDBNull(drv("contact_number")), "", Convert.ToString(drv("contact_number")))
            txtEmail.Text = If(IsDBNull(drv("email")), "", Convert.ToString(drv("email")))
            cmbRole.Text = Convert.ToString(drv("role"))
            cmbStatus.Text = Convert.ToString(drv("status"))
            txtPassword.Text = ""
            txtConfirm.Text = ""
            lblPassword.Text = "New Password (optional)"
            btnSave.Text = "Update"
        Catch ex As Exception
            MessageBox.Show("Selection error:" & Environment.NewLine & ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub ClearInputs()
        _selectedId = 0
        txtUsername.Text = ""
        txtFullName.Text = ""
        txtContact.Text = ""
        txtEmail.Text = ""
        If cmbRole.Items.Count > 0 Then cmbRole.SelectedIndex = 0
        If cmbStatus.Items.Count > 0 Then cmbStatus.SelectedIndex = 0
        txtPassword.Text = ""
        txtConfirm.Text = ""
        lblPassword.Text = "Password"
        btnSave.Text = "Save"
        dgvAdmins.ClearSelection()
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ClearInputs()
        txtUsername.Focus()
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Dim uname As String = txtUsername.Text.Trim()
        Dim fullName As String = txtFullName.Text.Trim()
        Dim phone As String = txtContact.Text.Trim()
        Dim mail As String = txtEmail.Text.Trim()
        Dim pwd As String = txtPassword.Text
        Dim conf As String = txtConfirm.Text

        If String.IsNullOrEmpty(uname) Then
            MessageBox.Show("Username is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtUsername.Focus()
            Return
        End If
        If uname.Contains(" ") Then
            MessageBox.Show("Username cannot contain spaces.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtUsername.Focus()
            Return
        End If
        If String.IsNullOrEmpty(fullName) Then
            MessageBox.Show("Full Name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtFullName.Focus()
            Return
        End If
        If Not IsValidEmail(mail) Then
            MessageBox.Show("Enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtEmail.Focus()
            Return
        End If

        If _selectedId = 0 AndAlso String.IsNullOrEmpty(pwd) Then
            MessageBox.Show("Password is required for a new account.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPassword.Focus()
            Return
        End If
        If Not String.IsNullOrEmpty(pwd) OrElse Not String.IsNullOrEmpty(conf) Then
            If pwd.Length < 6 Then
                MessageBox.Show("Password must be at least 6 characters.", "Weak Password", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtPassword.Focus()
                Return
            End If
            If pwd <> conf Then
                MessageBox.Show("Passwords do not match.", "Password Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtConfirm.Focus()
                Return
            End If
        End If

        If _selectedId = LoggedAdminId AndAlso cmbStatus.Text <> "Active" Then
            MessageBox.Show("You cannot deactivate your own active session account.", "Action Blocked", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using dupCmd As New SqlCeCommand("SELECT COUNT(*) FROM ADMINS WHERE username = @u AND adminid <> @id", conn)
                    dupCmd.Parameters.AddWithValue("@u", uname)
                    dupCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(dupCmd.ExecuteScalar()) > 0 Then
                        MessageBox.Show("Username '" & uname & "' is already taken.", "Duplicate Username", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        txtUsername.Focus()
                        Return
                    End If
                End Using

                If _selectedId > 0 AndAlso (cmbRole.Text <> "Super Admin" OrElse cmbStatus.Text <> "Active") Then
                    Using saCmd As New SqlCeCommand("SELECT COUNT(*) FROM ADMINS WHERE role = 'Super Admin' AND status = 'Active' AND adminid <> @id", conn)
                        saCmd.Parameters.AddWithValue("@id", _selectedId)
                        If Convert.ToInt32(saCmd.ExecuteScalar()) = 0 Then
                            MessageBox.Show("At least one active Super Admin account must remain.", "Lockout Prevention", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            Return
                        End If
                    End Using
                End If

                If _selectedId = 0 Then
                    Using cmd As New SqlCeCommand("INSERT INTO ADMINS (username, password_hash, full_name, contact_number, email, role, status, created_at) VALUES (@u, @p, @fn, @cn, @em, @rl, @st, @dt)", conn)
                        cmd.Parameters.AddWithValue("@u", uname)
                        cmd.Parameters.AddWithValue("@p", HashPassword(pwd))
                        cmd.Parameters.AddWithValue("@fn", fullName)
                        cmd.Parameters.AddWithValue("@cn", phone)
                        cmd.Parameters.AddWithValue("@em", mail)
                        cmd.Parameters.AddWithValue("@rl", cmbRole.Text)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                        cmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "CREATE", uname, "Created admin " & uname)
                    MessageBox.Show("Admin account created.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    If Not String.IsNullOrEmpty(pwd) Then
                        Using cmd As New SqlCeCommand("UPDATE ADMINS SET username=@u, password_hash=@p, full_name=@fn, contact_number=@cn, email=@em, role=@rl, status=@st WHERE adminid=@id", conn)
                            cmd.Parameters.AddWithValue("@u", uname)
                            cmd.Parameters.AddWithValue("@p", HashPassword(pwd))
                            cmd.Parameters.AddWithValue("@fn", fullName)
                            cmd.Parameters.AddWithValue("@cn", phone)
                            cmd.Parameters.AddWithValue("@em", mail)
                            cmd.Parameters.AddWithValue("@rl", cmbRole.Text)
                            cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                            cmd.Parameters.AddWithValue("@id", _selectedId)
                            cmd.ExecuteNonQuery()
                        End Using
                    Else
                        Using cmd As New SqlCeCommand("UPDATE ADMINS SET username=@u, full_name=@fn, contact_number=@cn, email=@em, role=@rl, status=@st WHERE adminid=@id", conn)
                            cmd.Parameters.AddWithValue("@u", uname)
                            cmd.Parameters.AddWithValue("@fn", fullName)
                            cmd.Parameters.AddWithValue("@cn", phone)
                            cmd.Parameters.AddWithValue("@em", mail)
                            cmd.Parameters.AddWithValue("@rl", cmbRole.Text)
                            cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                            cmd.Parameters.AddWithValue("@id", _selectedId)
                            cmd.ExecuteNonQuery()
                        End Using
                    End If
                    LogAudit(conn, "UPDATE", uname, "Updated admin " & uname)
                    MessageBox.Show("Admin account updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using

            ClearInputs()
            LoadAdmins()
        Catch ex As Exception
            MessageBox.Show("Error saving admin account:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click
        If _selectedId <= 0 Then
            MessageBox.Show("Select an admin account first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        If _selectedId = LoggedAdminId Then
            MessageBox.Show("You cannot delete your own active session account.", "Action Blocked", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using saCmd As New SqlCeCommand("SELECT COUNT(*) FROM ADMINS WHERE role = 'Super Admin' AND status = 'Active' AND adminid <> @id", conn)
                    saCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(saCmd.ExecuteScalar()) = 0 Then
                        MessageBox.Show("Cannot delete the last active Super Admin account.", "Lockout Prevention", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If
                End Using

                Dim refCount As Integer = 0
                Using c1 As New SqlCeCommand("SELECT COUNT(*) FROM AUDIT_LOGS WHERE adminid = @id", conn)
                    c1.Parameters.AddWithValue("@id", _selectedId)
                    refCount += Convert.ToInt32(c1.ExecuteScalar())
                End Using
                Using c2 As New SqlCeCommand("SELECT COUNT(*) FROM BIOMETRIC_DATA WHERE enrolled_by = @id", conn)
                    c2.Parameters.AddWithValue("@id", _selectedId)
                    refCount += Convert.ToInt32(c2.ExecuteScalar())
                End Using
                Using c3 As New SqlCeCommand("SELECT COUNT(*) FROM ATTENDANCE_LOGS WHERE adminid = @id", conn)
                    c3.Parameters.AddWithValue("@id", _selectedId)
                    refCount += Convert.ToInt32(c3.ExecuteScalar())
                End Using

                If refCount > 0 Then
                    If MessageBox.Show("This account has linked audit or enrollment records. Set status to Inactive instead?", "Account In Use", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                        Using upCmd As New SqlCeCommand("UPDATE ADMINS SET status = 'Inactive' WHERE adminid = @id", conn)
                            upCmd.Parameters.AddWithValue("@id", _selectedId)
                            upCmd.ExecuteNonQuery()
                        End Using
                        LogAudit(conn, "ARCHIVE", txtUsername.Text.Trim(), "Set admin Inactive")
                        ClearInputs()
                        LoadAdmins()
                    End If
                    Return
                End If

                If MessageBox.Show("Delete admin '" & txtUsername.Text.Trim() & "'?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
                    Using delCmd As New SqlCeCommand("DELETE FROM ADMINS WHERE adminid = @id", conn)
                        delCmd.Parameters.AddWithValue("@id", _selectedId)
                        delCmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "DELETE", txtUsername.Text.Trim(), "Deleted admin")
                    ClearInputs()
                    LoadAdmins()
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Delete error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LogAudit(ByVal conn As SqlCeConnection, ByVal action As String, ByVal refCode As String, ByVal desc As String)
        Try
            Dim aidObj As Object = If(LoggedAdminId > 0, CObj(LoggedAdminId), CObj(DBNull.Value))
            Using cmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, @act, 'Admins', @ref, @dsc, @dev, @dt)", conn)
                cmd.Parameters.AddWithValue("@aid", aidObj)
                cmd.Parameters.AddWithValue("@act", action)
                cmd.Parameters.AddWithValue("@ref", refCode)
                cmd.Parameters.AddWithValue("@dsc", desc)
                cmd.Parameters.AddWithValue("@dev", Environment.MachineName)
                cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                cmd.ExecuteNonQuery()
            End Using
        Catch
        End Try
    End Sub
End Class
