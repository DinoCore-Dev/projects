Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmMain
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"

    Public Property LoggedAdminId As Integer = 1
    Public Property LoggedUsername As String = "admin"
    Public Property LoggedFullName As String = "Administrator"
    Public Property LoggedRole As String = "Super Admin"
    Public Property SignedOutToLogin As Boolean = False

    Private _navList As List(Of Button)
    Private _activeChild As Form = Nothing

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            frmLogin.EnsureDatabaseReady()
            _navList = New List(Of Button)(New Button() {
                btnNavDashboard, btnNavKiosk, btnNavStudents, btnNavBiometric,
                btnNavCourses, btnNavTeachers, btnNavSchedules, btnNavReports, btnNavAdmins
            })

            For Each b As Button In _navList
                b.FlatStyle = FlatStyle.Flat
                b.FlatAppearance.BorderSize = 0
                b.TextAlign = ContentAlignment.MiddleLeft
                b.Cursor = Cursors.Hand
                b.Font = New Font("Segoe UI Semibold", 9.5F, FontStyle.Bold)
                b.UseVisualStyleBackColor = False
            Next

            If Not String.Equals(LoggedRole, "Super Admin", StringComparison.OrdinalIgnoreCase) Then
                btnNavAdmins.Visible = False
            End If

            FormatGrid(dgvDashLogs)
            FormatGrid(dgvDashSchedules)
            UpdateClockHeader()
            SetActiveNav(btnNavDashboard, "Dashboard")
            LoadDashboardMetrics()
        Catch ex As Exception
            MessageBox.Show("Failed to load dashboard:" & Environment.NewLine & ex.Message, "Dashboard Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub FormatGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try

        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 36
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 34
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.25F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub SetActiveNav(ByVal selected As Button, ByVal title As String)
        lblPageTitle.Text = title
        For Each b As Button In _navList
            If Object.ReferenceEquals(b, selected) Then
                b.BackColor = Color.FromArgb(37, 99, 235)
                b.ForeColor = Color.White
            Else
                b.BackColor = Color.FromArgb(15, 23, 42)
                b.ForeColor = Color.FromArgb(148, 163, 184)
            End If
        Next
    End Sub

    Private Sub CloseActiveChild()
        If _activeChild IsNot Nothing Then
            Try
                pnlWorkspace.Controls.Remove(_activeChild)
                _activeChild.Close()
                _activeChild.Dispose()
            Catch
            End Try
            _activeChild = Nothing
        End If
    End Sub

    Private Sub OpenEmbeddedForm(ByVal child As Form, ByVal navBtn As Button, ByVal title As String)
        Try
            SetActiveNav(navBtn, title)
            pnlDashboardHome.Visible = False
            CloseActiveChild()

            _activeChild = child
            child.TopLevel = False
            child.FormBorderStyle = FormBorderStyle.None
            child.Dock = DockStyle.Fill
            pnlWorkspace.Controls.Add(child)
            child.BringToFront()
            child.Show()
        Catch ex As Exception
            MessageBox.Show("Unable to open view:" & Environment.NewLine & ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub OpenBiometricForStudent(ByVal studentId As Integer)
        Dim bioForm As New frmBiometric()
        bioForm.LoggedAdminId = Me.LoggedAdminId
        bioForm.PreselectedStudentId = studentId
        OpenEmbeddedForm(bioForm, btnNavBiometric, "Biometric Enrollment")
    End Sub

    Private Sub LoadDashboardMetrics()
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using c1 As New SqlCeCommand("SELECT COUNT(*) FROM STUDENTS WHERE status = 'Active'", conn)
                    lblKpi1Val.Text = Convert.ToInt32(c1.ExecuteScalar()).ToString()
                End Using

                Dim dtBio As New DataTable()
                Using daBio As New SqlCeDataAdapter("SELECT DISTINCT studentid FROM BIOMETRIC_DATA WHERE status = 'Active'", conn)
                    daBio.Fill(dtBio)
                End Using
                lblKpi2Val.Text = dtBio.Rows.Count.ToString()

                Dim d0 As DateTime = DateTime.Today
                Dim d1 As DateTime = d0.AddDays(1)
                Using c3 As New SqlCeCommand("SELECT COUNT(*) FROM ATTENDANCE_LOGS WHERE log_date >= @d0 AND log_date < @d1", conn)
                    c3.Parameters.AddWithValue("@d0", d0)
                    c3.Parameters.AddWithValue("@d1", d1)
                    lblKpi3Val.Text = Convert.ToInt32(c3.ExecuteScalar()).ToString()
                End Using

                Using c4 As New SqlCeCommand("SELECT COUNT(*) FROM SCHEDULES WHERE status = 'Active'", conn)
                    lblKpi4Val.Text = Convert.ToInt32(c4.ExecuteScalar()).ToString()
                End Using

                Dim rawLogs As New DataTable()
                Using cmdLogs As New SqlCeCommand( _
                    "SELECT s.student_number, s.last_name + ', ' + s.first_name AS student_name, " & _
                    "COALESCE(c.course_code, a.log_mode) AS subject_mode, a.time_in, a.time_out, a.attendance_status " & _
                    "FROM ATTENDANCE_LOGS a INNER JOIN STUDENTS s ON a.studentid = s.studentid " & _
                    "LEFT OUTER JOIN SCHEDULES sc ON a.scheduleid = sc.scheduleid " & _
                    "LEFT OUTER JOIN COURSES c ON sc.courseid = c.courseid " & _
                    "WHERE a.log_date >= @d0 AND a.log_date < @d1 ORDER BY a.time_in DESC", conn)
                    cmdLogs.Parameters.AddWithValue("@d0", d0)
                    cmdLogs.Parameters.AddWithValue("@d1", d1)
                    Using da As New SqlCeDataAdapter(cmdLogs)
                        da.Fill(rawLogs)
                    End Using
                End Using

                Dim viewLogs As New DataTable()
                viewLogs.Columns.Add("Student No.", GetType(String))
                viewLogs.Columns.Add("Name", GetType(String))
                viewLogs.Columns.Add("Class", GetType(String))
                viewLogs.Columns.Add("Time In", GetType(String))
                viewLogs.Columns.Add("Time Out", GetType(String))
                viewLogs.Columns.Add("Status", GetType(String))

                For Each r As DataRow In rawLogs.Rows
                    Dim tIn As String = If(IsDBNull(r("time_in")), "—", Convert.ToDateTime(r("time_in")).ToString("hh:mm tt"))
                    Dim tOut As String = If(IsDBNull(r("time_out")), "—", Convert.ToDateTime(r("time_out")).ToString("hh:mm tt"))
                    viewLogs.Rows.Add(Convert.ToString(r("student_number")), Convert.ToString(r("student_name")), Convert.ToString(r("subject_mode")), tIn, tOut, Convert.ToString(r("attendance_status")))
                Next
                dgvDashLogs.DataSource = viewLogs

                Dim rawSched As New DataTable()
                Using daSc As New SqlCeDataAdapter( _
                    "SELECT c.course_code AS [Course], sc.section AS [Section], sc.day_of_week AS [Days], " & _
                    "sc.time_start + ' - ' + sc.time_end AS [Time], sc.room AS [Room] " & _
                    "FROM SCHEDULES sc INNER JOIN COURSES c ON sc.courseid = c.courseid " & _
                    "WHERE sc.status = 'Active' ORDER BY sc.time_start ASC", conn)
                    daSc.Fill(rawSched)
                End Using
                dgvDashSchedules.DataSource = rawSched
            End Using
        Catch ex As Exception
            MessageBox.Show("Could not refresh metrics:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub btnNavDashboard_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavDashboard.Click
        CloseActiveChild()
        SetActiveNav(btnNavDashboard, "Dashboard")
        pnlDashboardHome.Visible = True
        LoadDashboardMetrics()
    End Sub

    Private Sub btnNavKiosk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavKiosk.Click
        Dim f As New frmAttendanceKiosk()
        f.LoggedAdminId = Me.LoggedAdminId
        f.IsEmbeddedMode = True
        OpenEmbeddedForm(f, btnNavKiosk, "Attendance Kiosk")
    End Sub

    Private Sub btnNavStudents_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavStudents.Click
        Dim f As New frmStudents()
        f.LoggedAdminId = Me.LoggedAdminId
        f.ParentDashboard = Me
        OpenEmbeddedForm(f, btnNavStudents, "Students")
    End Sub

    Private Sub btnNavBiometric_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavBiometric.Click
        Dim f As New frmBiometric()
        f.LoggedAdminId = Me.LoggedAdminId
        OpenEmbeddedForm(f, btnNavBiometric, "Biometric Enrollment")
    End Sub

    Private Sub btnNavCourses_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavCourses.Click
        Dim f As New frmCourses()
        f.LoggedAdminId = Me.LoggedAdminId
        OpenEmbeddedForm(f, btnNavCourses, "Courses")
    End Sub

    Private Sub btnNavTeachers_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavTeachers.Click
        Dim f As New frmTeachers()
        f.LoggedAdminId = Me.LoggedAdminId
        OpenEmbeddedForm(f, btnNavTeachers, "Teachers")
    End Sub

    Private Sub btnNavSchedules_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavSchedules.Click
        Dim f As New frmSchedules()
        f.LoggedAdminId = Me.LoggedAdminId
        OpenEmbeddedForm(f, btnNavSchedules, "Schedules & Roster")
    End Sub

    Private Sub btnNavReports_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavReports.Click
        Dim f As New frmReports()
        f.LoggedAdminId = Me.LoggedAdminId
        OpenEmbeddedForm(f, btnNavReports, "Reports & Backup")
    End Sub

    Private Sub btnNavAdmins_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNavAdmins.Click
        Dim f As New frmAdmins()
        f.LoggedAdminId = Me.LoggedAdminId
        OpenEmbeddedForm(f, btnNavAdmins, "Administrators")
    End Sub

    Private Sub btnSignOut_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSignOut.Click
        If MessageBox.Show("Sign out of current session?", "Sign Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                Using conn As New SqlCeConnection(ConnStr)
                    conn.Open()
                    Using cmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, 'LOGOUT', 'Auth', @ref, 'Administrator signed out', @dev, @dt)", conn)
                        cmd.Parameters.AddWithValue("@aid", LoggedAdminId)
                        cmd.Parameters.AddWithValue("@ref", LoggedUsername)
                        cmd.Parameters.AddWithValue("@dev", Environment.MachineName)
                        cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                        cmd.ExecuteNonQuery()
                    End Using
                End Using
            Catch
            End Try

            CloseActiveChild()
            SignedOutToLogin = True
            Me.Close()
        End If
    End Sub

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        CloseActiveChild()
    End Sub

    Private Sub tmrClock_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrClock.Tick
        UpdateClockHeader()
    End Sub

    Private Sub UpdateClockHeader()
        lblSessionClock.Text = LoggedFullName & " (" & LoggedRole & ")   |   " & DateTime.Now.ToString("MMM dd, yyyy  hh:mm:ss tt")
    End Sub
End Class
