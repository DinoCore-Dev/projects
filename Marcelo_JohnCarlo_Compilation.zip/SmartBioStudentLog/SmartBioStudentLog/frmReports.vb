Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Drawing.Printing
Imports System.IO
Imports System.Reflection
Imports System.Text
Imports System.Windows.Forms

Public Class frmReports
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"

    Public Property LoggedAdminId As Integer = 1
    Private _printRowIndex As Integer = 0

    Private Sub frmReports_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvAttendance)
            StyleGrid(dgvAudit)

            dtpFrom.Value = DateTime.Today.AddDays(-7)
            dtpTo.Value = DateTime.Today

            cmbMode.Items.Clear()
            cmbMode.Items.AddRange(New Object() {"All Modes", "Class Schedule", "Campus Gate"})
            cmbMode.SelectedIndex = 0

            cmbStatus.Items.Clear()
            cmbStatus.Items.AddRange(New Object() {"All Status", "Present", "Late", "Completed"})
            cmbStatus.SelectedIndex = 0

            LoadReports()
        Catch ex As Exception
            MessageBox.Show("Failed to initialize Reports:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try
        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 35
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 32
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub LoadReports()
        Try
            If dtpFrom.Value.Date > dtpTo.Value.Date Then
                Dim tmp As DateTime = dtpFrom.Value.Date
                dtpFrom.Value = dtpTo.Value.Date
                dtpTo.Value = tmp
            End If

            Dim d1 As DateTime = dtpFrom.Value.Date
            Dim d2 As DateTime = dtpTo.Value.Date.AddDays(1)
            Dim q As String = txtSearch.Text.Trim()

            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Dim sql As String = _
                    "SELECT al.log_date, s.student_number AS [Student No.], s.last_name + ', ' + s.first_name AS [Student Name], " & _
                    "s.program AS [Program], al.log_mode AS [Mode], COALESCE(c.course_code, 'Campus Gate') AS [Course], " & _
                    "al.time_in, al.time_out, al.attendance_status AS [Status], al.scanner_device AS [Device] " & _
                    "FROM ATTENDANCE_LOGS al " & _
                    "INNER JOIN STUDENTS s ON al.studentid = s.studentid " & _
                    "LEFT JOIN SCHEDULES sc ON al.scheduleid = sc.scheduleid " & _
                    "LEFT JOIN COURSES c ON sc.courseid = c.courseid " & _
                    "WHERE al.log_date >= @d1 AND al.log_date < @d2"

                Using cmd As New SqlCeCommand()
                    cmd.Connection = conn
                    cmd.Parameters.AddWithValue("@d1", d1)
                    cmd.Parameters.AddWithValue("@d2", d2)

                    If cmbMode.SelectedIndex > 0 Then
                        sql &= " AND al.log_mode = @md"
                        cmd.Parameters.AddWithValue("@md", cmbMode.Text)
                    End If
                    If cmbStatus.SelectedIndex > 0 Then
                        sql &= " AND al.attendance_status = @st"
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                    End If
                    If Not String.IsNullOrEmpty(q) Then
                        sql &= " AND (s.student_number LIKE @q OR s.last_name LIKE @q OR s.first_name LIKE @q OR c.course_code LIKE @q)"
                        cmd.Parameters.AddWithValue("@q", "%" & q & "%")
                    End If
                    sql &= " ORDER BY al.time_in DESC"
                    cmd.CommandText = sql

                    Dim raw As New DataTable()
                    Using da As New SqlCeDataAdapter(cmd)
                        da.Fill(raw)
                    End Using

                    Dim disp As New DataTable()
                    disp.Columns.Add("Date")
                    disp.Columns.Add("Student No.")
                    disp.Columns.Add("Student Name")
                    disp.Columns.Add("Program")
                    disp.Columns.Add("Mode")
                    disp.Columns.Add("Course")
                    disp.Columns.Add("Time In")
                    disp.Columns.Add("Time Out")
                    disp.Columns.Add("Status")
                    disp.Columns.Add("Device")

                    Dim cntPres As Integer = 0
                    Dim cntLate As Integer = 0
                    Dim cntOpen As Integer = 0

                    For Each r As DataRow In raw.Rows
                        Dim dtStr As String = Convert.ToDateTime(r("log_date")).ToString("yyyy-MM-dd")
                        Dim tIn As String = Convert.ToDateTime(r("time_in")).ToString("hh:mm:ss tt")
                        Dim tOut As String = "--"
                        If Not IsDBNull(r("time_out")) Then
                            tOut = Convert.ToDateTime(r("time_out")).ToString("hh:mm:ss tt")
                        Else
                            cntOpen += 1
                        End If
                        Dim st As String = Convert.ToString(r("Status"))
                        If st = "Present" OrElse st = "Completed" Then cntPres += 1
                        If st = "Late" Then cntLate += 1

                        disp.Rows.Add(dtStr, r("Student No."), r("Student Name"), r("Program"), r("Mode"), r("Course"), tIn, tOut, st, r("Device"))
                    Next

                    dgvAttendance.DataSource = disp
                    lblSumTotal.Text = raw.Rows.Count.ToString()
                    lblSumPresent.Text = cntPres.ToString()
                    lblSumLate.Text = cntLate.ToString()
                    lblSumOpen.Text = cntOpen.ToString()
                End Using

                Dim dtAudit As New DataTable()
                Using audCmd As New SqlCeCommand( _
                    "SELECT TOP (300) au.logged_at, COALESCE(ad.username, 'System') AS [User], au.action_type AS [Action], " & _
                    "au.module_name AS [Module], au.record_ref AS [Ref], au.description AS [Description], au.device_info AS [Workstation] " & _
                    "FROM AUDIT_LOGS au LEFT JOIN ADMINS ad ON au.adminid = ad.adminid " & _
                    "WHERE au.logged_at >= @d1 AND au.logged_at < @d2 ORDER BY au.logged_at DESC", conn)
                    audCmd.Parameters.AddWithValue("@d1", d1)
                    audCmd.Parameters.AddWithValue("@d2", d2)
                    Using daA As New SqlCeDataAdapter(audCmd)
                        daA.Fill(dtAudit)
                    End Using
                End Using

                Dim dispAud As New DataTable()
                dispAud.Columns.Add("Timestamp")
                dispAud.Columns.Add("User")
                dispAud.Columns.Add("Action")
                dispAud.Columns.Add("Module")
                dispAud.Columns.Add("Ref")
                dispAud.Columns.Add("Description")
                dispAud.Columns.Add("Workstation")
                For Each r As DataRow In dtAudit.Rows
                    dispAud.Rows.Add(Convert.ToDateTime(r("logged_at")).ToString("yyyy-MM-dd hh:mm:ss tt"), r("User"), r("Action"), r("Module"), r("Ref"), r("Description"), r("Workstation"))
                Next
                dgvAudit.DataSource = dispAud
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading reports:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnFilter_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFilter.Click
        LoadReports()
    End Sub

    Private Sub btnExportCsv_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnExportCsv.Click
        Dim activeGrid As DataGridView = If(tabLogs.SelectedIndex = 0, dgvAttendance, dgvAudit)
        If activeGrid.Rows.Count = 0 Then
            MessageBox.Show("No rows to export.", "Export CSV", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Using sfd As New SaveFileDialog()
            sfd.Filter = "CSV File (*.csv)|*.csv"
            sfd.FileName = If(tabLogs.SelectedIndex = 0, "AttendanceLogs_", "AuditLogs_") & DateTime.Now.ToString("yyyyMMdd_HHmm") & ".csv"
            If sfd.ShowDialog() = DialogResult.OK Then
                Try
                    Dim sb As New StringBuilder()
                    Dim headers As New List(Of String)()
                    For Each col As DataGridViewColumn In activeGrid.Columns
                        If col.Visible Then headers.Add("""" & col.HeaderText.Replace("""", """""") & """")
                    Next
                    sb.AppendLine(String.Join(",", headers.ToArray()))

                    For Each row As DataGridViewRow In activeGrid.Rows
                        If Not row.IsNewRow Then
                            Dim cells As New List(Of String)()
                            For Each col As DataGridViewColumn In activeGrid.Columns
                                If col.Visible Then
                                    Dim v As String = If(row.Cells(col.Index).Value Is Nothing, "", Convert.ToString(row.Cells(col.Index).Value))
                                    cells.Add("""" & v.Replace("""", """""") & """")
                                End If
                            Next
                            sb.AppendLine(String.Join(",", cells.ToArray()))
                        End If
                    Next

                    File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8)
                    MessageBox.Show("Exported successfully:" & Environment.NewLine & sfd.FileName, "Export Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch ioEx As IOException
                    MessageBox.Show("Cannot write to the selected file because it may be open in another program (such as Excel). Close it and try again.", "File In Use", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Catch ex As Exception
                    MessageBox.Show("Export failed:" & Environment.NewLine & ex.Message, "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        End Using
    End Sub

    Private Sub btnPrint_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnPrint.Click
        If dgvAttendance.Rows.Count = 0 Then
            MessageBox.Show("No attendance rows to print.", "Print", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        Try
            _printRowIndex = 0
            prtDoc.DefaultPageSettings.Landscape = True
            Using dlg As New PrintPreviewDialog()
                dlg.Document = prtDoc
                dlg.Width = 1000
                dlg.Height = 720
                dlg.ShowDialog(Me)
            End Using
        Catch ex As Exception
            MessageBox.Show("Print preview failed:" & Environment.NewLine & ex.Message, "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub prtDoc_PrintPage(ByVal sender As Object, ByVal e As PrintPageEventArgs) Handles prtDoc.PrintPage
        Dim g As Graphics = e.Graphics
        Dim left As Integer = e.MarginBounds.Left
        Dim top As Integer = e.MarginBounds.Top
        Dim width As Integer = e.MarginBounds.Width

        Using titleFont As New Font("Segoe UI", 14.0F, FontStyle.Bold), _
              subFont As New Font("Segoe UI", 9.0F, FontStyle.Regular), _
              hdrFont As New Font("Segoe UI Semibold", 8.5F, FontStyle.Bold), _
              rowFont As New Font("Segoe UI", 8.25F, FontStyle.Regular)

            g.DrawString("SMART BIO STUDENT LOG — ATTENDANCE REPORT", titleFont, Brushes.Black, left, top)
            g.DrawString("Range: " & dtpFrom.Value.ToString("yyyy-MM-dd") & " to " & dtpTo.Value.ToString("yyyy-MM-dd") & "   |   Generated: " & DateTime.Now.ToString("yyyy-MM-dd hh:mm tt"), subFont, Brushes.DimGray, left, top + 26)

            Dim y As Integer = top + 54
            Dim colWidths As Integer() = New Integer() {82, 92, 165, 70, 105, 85, 88, 88, 75}
            Dim colNames As String() = New String() {"Date", "Student No.", "Student Name", "Program", "Mode", "Course", "Time In", "Time Out", "Status"}

            g.FillRectangle(Brushes.DarkSlateGray, New Rectangle(left, y, width, 24))
            Dim x As Integer = left + 4
            For i As Integer = 0 To colNames.Length - 1
                g.DrawString(colNames(i), hdrFont, Brushes.White, x, y + 4)
                x += colWidths(i)
            Next
            y += 26

            While _printRowIndex < dgvAttendance.Rows.Count
                Dim row As DataGridViewRow = dgvAttendance.Rows(_printRowIndex)
                If y + 22 > e.MarginBounds.Bottom Then
                    e.HasMorePages = True
                    Return
                End If
                If _printRowIndex Mod 2 = 1 Then
                    g.FillRectangle(Brushes.WhiteSmoke, New Rectangle(left, y, width, 20))
                End If
                x = left + 4
                For i As Integer = 0 To colNames.Length - 1
                    Dim v As String = Convert.ToString(row.Cells(colNames(i)).Value)
                    g.DrawString(v, rowFont, Brushes.Black, New RectangleF(x, y + 2, colWidths(i) - 4, 18))
                    x += colWidths(i)
                Next
                y += 21
                _printRowIndex += 1
            End While
        End Using
        e.HasMorePages = False
    End Sub

    Private Sub btnBackupDb_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnBackupDb.Click
        Try
            Dim dataDirObj As Object = AppDomain.CurrentDomain.GetData("DataDirectory")
            Dim baseDir As String = If(dataDirObj IsNot Nothing, dataDirObj.ToString(), Application.StartupPath)
            Dim dbPath As String = Path.Combine(baseDir, "SmartBioStudentLog.sdf")

            If Not File.Exists(dbPath) Then
                MessageBox.Show("Database file was not found at:" & Environment.NewLine & dbPath, "Backup Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Using sfd As New SaveFileDialog()
                sfd.Filter = "SQL Server Compact Database (*.sdf)|*.sdf"
                sfd.FileName = "SmartBioStudentLog_Backup_" & DateTime.Now.ToString("yyyyMMdd_HHmm") & ".sdf"
                If sfd.ShowDialog() = DialogResult.OK Then
                    If String.Equals(Path.GetFullPath(sfd.FileName), Path.GetFullPath(dbPath), StringComparison.OrdinalIgnoreCase) Then
                        MessageBox.Show("Choose a backup filename different from the active database file.", "Invalid Backup Target", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If
                    File.Copy(dbPath, sfd.FileName, True)
                    MessageBox.Show("Database backup saved:" & Environment.NewLine & sfd.FileName, "Backup Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Database backup failed:" & Environment.NewLine & ex.Message, "Backup Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
