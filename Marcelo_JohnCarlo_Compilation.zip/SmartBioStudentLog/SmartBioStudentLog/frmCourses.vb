Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmCourses
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"

    Public Property LoggedAdminId As Integer = 1
    Private _selectedId As Integer = 0

    Private Sub frmCourses_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvCourses)
            cmbStatus.Items.Clear()
            cmbStatus.Items.AddRange(New Object() {"Active", "Archived"})
            cmbStatus.SelectedIndex = 0
            txtDepartment.Text = "Information Technology"
            LoadCourses()
        Catch ex As Exception
            MessageBox.Show("Failed to load Courses:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try
        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 36
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 34
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.25F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub LoadCourses()
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Dim q As String = txtSearch.Text.Trim()
                Dim sql As String = "SELECT courseid, course_code, course_name, units, department, description, status FROM COURSES"
                Using cmd As New SqlCeCommand()
                    cmd.Connection = conn
                    If Not String.IsNullOrEmpty(q) Then
                        sql &= " WHERE course_code LIKE @q OR course_name LIKE @q OR department LIKE @q"
                        cmd.Parameters.AddWithValue("@q", "%" & q & "%")
                    End If
                    sql &= " ORDER BY course_code ASC"
                    cmd.CommandText = sql

                    Dim dt As New DataTable()
                    Using da As New SqlCeDataAdapter(cmd)
                        da.Fill(dt)
                    End Using
                    dgvCourses.DataSource = dt
                End Using
            End Using

            If dgvCourses.Columns.Contains("courseid") Then dgvCourses.Columns("courseid").Visible = False
            If dgvCourses.Columns.Contains("course_code") Then dgvCourses.Columns("course_code").HeaderText = "Code"
            If dgvCourses.Columns.Contains("course_name") Then dgvCourses.Columns("course_name").HeaderText = "Course Name"
            If dgvCourses.Columns.Contains("units") Then dgvCourses.Columns("units").HeaderText = "Units"
            If dgvCourses.Columns.Contains("department") Then dgvCourses.Columns("department").HeaderText = "Department"
            If dgvCourses.Columns.Contains("description") Then dgvCourses.Columns("description").HeaderText = "Description"
            If dgvCourses.Columns.Contains("status") Then dgvCourses.Columns("status").HeaderText = "Status"
        Catch ex As Exception
            MessageBox.Show("Error loading courses:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgvCourses_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvCourses.CellClick
        If e.RowIndex < 0 OrElse dgvCourses.CurrentRow Is Nothing Then Return
        Try
            Dim drv As DataRowView = TryCast(dgvCourses.CurrentRow.DataBoundItem, DataRowView)
            If drv Is Nothing Then Return

            _selectedId = Convert.ToInt32(drv("courseid"))
            txtCourseCode.Text = Convert.ToString(drv("course_code"))
            txtCourseName.Text = Convert.ToString(drv("course_name"))
            Dim u As Integer = Convert.ToInt32(drv("units"))
            nudUnits.Value = Math.Max(1, Math.Min(12, u))
            txtDepartment.Text = If(IsDBNull(drv("department")), "", Convert.ToString(drv("department")))
            txtDescription.Text = If(IsDBNull(drv("description")), "", Convert.ToString(drv("description")))
            cmbStatus.Text = Convert.ToString(drv("status"))
            btnSave.Text = "Update"
        Catch ex As Exception
            MessageBox.Show("Selection error:" & Environment.NewLine & ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub ClearInputs()
        _selectedId = 0
        txtCourseCode.Text = ""
        txtCourseName.Text = ""
        nudUnits.Value = 3
        txtDepartment.Text = "Information Technology"
        txtDescription.Text = ""
        If cmbStatus.Items.Count > 0 Then cmbStatus.SelectedIndex = 0
        btnSave.Text = "Save"
        dgvCourses.ClearSelection()
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ClearInputs()
        txtCourseCode.Focus()
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Dim code As String = txtCourseCode.Text.Trim().ToUpperInvariant()
        Dim nameText As String = txtCourseName.Text.Trim()
        Dim dept As String = txtDepartment.Text.Trim()
        Dim desc As String = txtDescription.Text.Trim()

        If String.IsNullOrEmpty(code) Then
            MessageBox.Show("Course Code is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCourseCode.Focus()
            Return
        End If
        If String.IsNullOrEmpty(nameText) Then
            MessageBox.Show("Course Name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtCourseName.Focus()
            Return
        End If
        If String.IsNullOrEmpty(dept) Then
            MessageBox.Show("Department is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtDepartment.Focus()
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using dupCmd As New SqlCeCommand("SELECT COUNT(*) FROM COURSES WHERE course_code = @cc AND courseid <> @id", conn)
                    dupCmd.Parameters.AddWithValue("@cc", code)
                    dupCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(dupCmd.ExecuteScalar()) > 0 Then
                        MessageBox.Show("Course Code '" & code & "' already exists.", "Duplicate Code", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        txtCourseCode.Focus()
                        Return
                    End If
                End Using

                If _selectedId = 0 Then
                    Using cmd As New SqlCeCommand("INSERT INTO COURSES (course_code, course_name, units, description, department, status) VALUES (@cc, @cn, @un, @ds, @dp, @st)", conn)
                        cmd.Parameters.AddWithValue("@cc", code)
                        cmd.Parameters.AddWithValue("@cn", nameText)
                        cmd.Parameters.AddWithValue("@un", Convert.ToInt32(nudUnits.Value))
                        cmd.Parameters.AddWithValue("@ds", desc)
                        cmd.Parameters.AddWithValue("@dp", dept)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "CREATE", code, "Added course " & nameText)
                    MessageBox.Show("Course saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    Using cmd As New SqlCeCommand("UPDATE COURSES SET course_code=@cc, course_name=@cn, units=@un, description=@ds, department=@dp, status=@st WHERE courseid=@id", conn)
                        cmd.Parameters.AddWithValue("@cc", code)
                        cmd.Parameters.AddWithValue("@cn", nameText)
                        cmd.Parameters.AddWithValue("@un", Convert.ToInt32(nudUnits.Value))
                        cmd.Parameters.AddWithValue("@ds", desc)
                        cmd.Parameters.AddWithValue("@dp", dept)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.Parameters.AddWithValue("@id", _selectedId)
                        cmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "UPDATE", code, "Updated course " & nameText)
                    MessageBox.Show("Course updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using

            ClearInputs()
            LoadCourses()
        Catch ex As SqlCeException
            MessageBox.Show("Database error while saving course:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("Unexpected error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click
        If _selectedId <= 0 Then
            MessageBox.Show("Select a course from the list first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using chkCmd As New SqlCeCommand("SELECT COUNT(*) FROM SCHEDULES WHERE courseid = @id", conn)
                    chkCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(chkCmd.ExecuteScalar()) > 0 Then
                        If MessageBox.Show("This course is used in class schedules. Set status to Archived instead?", "Course In Use", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                            Using upCmd As New SqlCeCommand("UPDATE COURSES SET status = 'Archived' WHERE courseid = @id", conn)
                                upCmd.Parameters.AddWithValue("@id", _selectedId)
                                upCmd.ExecuteNonQuery()
                            End Using
                            LogAudit(conn, "ARCHIVE", txtCourseCode.Text.Trim(), "Archived course")
                            ClearInputs()
                            LoadCourses()
                        End If
                        Return
                    End If
                End Using

                If MessageBox.Show("Delete course '" & txtCourseCode.Text.Trim() & "'?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
                    Using delCmd As New SqlCeCommand("DELETE FROM COURSES WHERE courseid = @id", conn)
                        delCmd.Parameters.AddWithValue("@id", _selectedId)
                        delCmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "DELETE", txtCourseCode.Text.Trim(), "Deleted course")
                    ClearInputs()
                    LoadCourses()
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Delete error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged
        LoadCourses()
    End Sub

    Private Sub LogAudit(ByVal conn As SqlCeConnection, ByVal action As String, ByVal refCode As String, ByVal desc As String)
        Try
            Dim aidObj As Object = If(LoggedAdminId > 0, CObj(LoggedAdminId), CObj(DBNull.Value))
            Using cmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, @act, 'Courses', @ref, @dsc, @dev, @dt)", conn)
                cmd.Parameters.AddWithValue("@aid", aidObj)
                cmd.Parameters.AddWithValue("@act", action)
                cmd.Parameters.AddWithValue("@ref", refCode)
                cmd.Parameters.AddWithValue("@dsc", desc)
                cmd.Parameters.AddWithValue("@dev", Environment.MachineName)
                cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                cmd.ExecuteNonQuery()
            End Using
        Catch
        End Try
    End Sub
End Class
