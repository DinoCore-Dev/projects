<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudents
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents tlpRoot As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlFormCard As System.Windows.Forms.Panel
    Friend WithEvents lblCardTitle As System.Windows.Forms.Label
    Friend WithEvents lblStudentNo As System.Windows.Forms.Label
    Friend WithEvents txtStudentNo As System.Windows.Forms.TextBox
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents lblMiddleName As System.Windows.Forms.Label
    Friend WithEvents txtMiddleName As System.Windows.Forms.TextBox
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents lblProgram As System.Windows.Forms.Label
    Friend WithEvents cmbProgram As System.Windows.Forms.ComboBox
    Friend WithEvents lblYearLevel As System.Windows.Forms.Label
    Friend WithEvents cmbYearLevel As System.Windows.Forms.ComboBox
    Friend WithEvents lblSection As System.Windows.Forms.Label
    Friend WithEvents txtSection As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents lblGuardian As System.Windows.Forms.Label
    Friend WithEvents txtGuardian As System.Windows.Forms.TextBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnEnrollBio As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents pnlGridCard As System.Windows.Forms.Panel
    Friend WithEvents tlpFilter As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblListTitle As System.Windows.Forms.Label
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents lblFilterProg As System.Windows.Forms.Label
    Friend WithEvents cmbFilterProgram As System.Windows.Forms.ComboBox
    Friend WithEvents dgvStudents As System.Windows.Forms.DataGridView

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpRoot = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlFormCard = New System.Windows.Forms.Panel()
        Me.lblCardTitle = New System.Windows.Forms.Label()
        Me.lblStudentNo = New System.Windows.Forms.Label()
        Me.txtStudentNo = New System.Windows.Forms.TextBox()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lblMiddleName = New System.Windows.Forms.Label()
        Me.txtMiddleName = New System.Windows.Forms.TextBox()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.lblProgram = New System.Windows.Forms.Label()
        Me.cmbProgram = New System.Windows.Forms.ComboBox()
        Me.lblYearLevel = New System.Windows.Forms.Label()
        Me.cmbYearLevel = New System.Windows.Forms.ComboBox()
        Me.lblSection = New System.Windows.Forms.Label()
        Me.txtSection = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.lblGuardian = New System.Windows.Forms.Label()
        Me.txtGuardian = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnEnrollBio = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.pnlGridCard = New System.Windows.Forms.Panel()
        Me.tlpFilter = New System.Windows.Forms.TableLayoutPanel()
        Me.lblListTitle = New System.Windows.Forms.Label()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.lblFilterProg = New System.Windows.Forms.Label()
        Me.cmbFilterProgram = New System.Windows.Forms.ComboBox()
        Me.dgvStudents = New System.Windows.Forms.DataGridView()
        Me.tlpRoot.SuspendLayout()
        Me.pnlFormCard.SuspendLayout()
        Me.pnlGridCard.SuspendLayout()
        Me.tlpFilter.SuspendLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.tlpRoot.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.tlpRoot.ColumnCount = 2
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320.0!))
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Controls.Add(Me.pnlFormCard, 0, 0)
        Me.tlpRoot.Controls.Add(Me.pnlGridCard, 1, 0)
        Me.tlpRoot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRoot.Location = New System.Drawing.Point(0, 0)
        Me.tlpRoot.Name = "tlpRoot"
        Me.tlpRoot.RowCount = 1
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Size = New System.Drawing.Size(964, 620)
        Me.tlpRoot.TabIndex = 0
        Me.pnlFormCard.BackColor = System.Drawing.Color.White
        Me.pnlFormCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFormCard.Controls.Add(Me.lblCardTitle)
        Me.pnlFormCard.Controls.Add(Me.lblStudentNo)
        Me.pnlFormCard.Controls.Add(Me.txtStudentNo)
        Me.pnlFormCard.Controls.Add(Me.lblFirstName)
        Me.pnlFormCard.Controls.Add(Me.txtFirstName)
        Me.pnlFormCard.Controls.Add(Me.lblMiddleName)
        Me.pnlFormCard.Controls.Add(Me.txtMiddleName)
        Me.pnlFormCard.Controls.Add(Me.lblLastName)
        Me.pnlFormCard.Controls.Add(Me.txtLastName)
        Me.pnlFormCard.Controls.Add(Me.lblProgram)
        Me.pnlFormCard.Controls.Add(Me.cmbProgram)
        Me.pnlFormCard.Controls.Add(Me.lblYearLevel)
        Me.pnlFormCard.Controls.Add(Me.cmbYearLevel)
        Me.pnlFormCard.Controls.Add(Me.lblSection)
        Me.pnlFormCard.Controls.Add(Me.txtSection)
        Me.pnlFormCard.Controls.Add(Me.lblStatus)
        Me.pnlFormCard.Controls.Add(Me.cmbStatus)
        Me.pnlFormCard.Controls.Add(Me.lblContact)
        Me.pnlFormCard.Controls.Add(Me.txtContact)
        Me.pnlFormCard.Controls.Add(Me.lblGuardian)
        Me.pnlFormCard.Controls.Add(Me.txtGuardian)
        Me.pnlFormCard.Controls.Add(Me.btnSave)
        Me.pnlFormCard.Controls.Add(Me.btnClear)
        Me.pnlFormCard.Controls.Add(Me.btnEnrollBio)
        Me.pnlFormCard.Controls.Add(Me.btnDelete)
        Me.pnlFormCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlFormCard.Margin = New System.Windows.Forms.Padding(0, 0, 14, 0)
        Me.pnlFormCard.Name = "pnlFormCard"
        Me.pnlFormCard.TabIndex = 0
        Me.lblCardTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblCardTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblCardTitle.Location = New System.Drawing.Point(18, 14)
        Me.lblCardTitle.Size = New System.Drawing.Size(270, 24)
        Me.lblCardTitle.Text = "Student Details"
        Me.lblStudentNo.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblStudentNo.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStudentNo.Location = New System.Drawing.Point(18, 46)
        Me.lblStudentNo.Size = New System.Drawing.Size(270, 18)
        Me.lblStudentNo.Text = "Student No."
        Me.txtStudentNo.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtStudentNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStudentNo.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtStudentNo.Location = New System.Drawing.Point(18, 66)
        Me.txtStudentNo.MaxLength = 25
        Me.txtStudentNo.Size = New System.Drawing.Size(270, 25)
        Me.lblFirstName.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblFirstName.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblFirstName.Location = New System.Drawing.Point(18, 98)
        Me.lblFirstName.Size = New System.Drawing.Size(270, 18)
        Me.lblFirstName.Text = "First Name"
        Me.txtFirstName.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFirstName.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtFirstName.Location = New System.Drawing.Point(18, 118)
        Me.txtFirstName.MaxLength = 50
        Me.txtFirstName.Size = New System.Drawing.Size(270, 25)
        Me.lblMiddleName.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblMiddleName.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblMiddleName.Location = New System.Drawing.Point(18, 150)
        Me.lblMiddleName.Size = New System.Drawing.Size(130, 18)
        Me.lblMiddleName.Text = "Middle Name"
        Me.txtMiddleName.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtMiddleName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMiddleName.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtMiddleName.Location = New System.Drawing.Point(18, 170)
        Me.txtMiddleName.MaxLength = 50
        Me.txtMiddleName.Size = New System.Drawing.Size(130, 25)
        Me.lblLastName.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblLastName.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblLastName.Location = New System.Drawing.Point(158, 150)
        Me.lblLastName.Size = New System.Drawing.Size(130, 18)
        Me.lblLastName.Text = "Last Name"
        Me.txtLastName.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLastName.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtLastName.Location = New System.Drawing.Point(158, 170)
        Me.txtLastName.MaxLength = 50
        Me.txtLastName.Size = New System.Drawing.Size(130, 25)
        Me.lblProgram.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblProgram.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblProgram.Location = New System.Drawing.Point(18, 202)
        Me.lblProgram.Size = New System.Drawing.Size(130, 18)
        Me.lblProgram.Text = "Program"
        Me.cmbProgram.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbProgram.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.cmbProgram.Location = New System.Drawing.Point(18, 222)
        Me.cmbProgram.Size = New System.Drawing.Size(130, 24)
        Me.lblYearLevel.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblYearLevel.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblYearLevel.Location = New System.Drawing.Point(158, 202)
        Me.lblYearLevel.Size = New System.Drawing.Size(130, 18)
        Me.lblYearLevel.Text = "Year Level"
        Me.cmbYearLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbYearLevel.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.cmbYearLevel.Location = New System.Drawing.Point(158, 222)
        Me.cmbYearLevel.Size = New System.Drawing.Size(130, 24)
        Me.lblSection.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSection.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblSection.Location = New System.Drawing.Point(18, 254)
        Me.lblSection.Size = New System.Drawing.Size(130, 18)
        Me.lblSection.Text = "Section"
        Me.txtSection.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtSection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSection.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtSection.Location = New System.Drawing.Point(18, 274)
        Me.txtSection.MaxLength = 20
        Me.txtSection.Size = New System.Drawing.Size(130, 25)
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStatus.Location = New System.Drawing.Point(158, 254)
        Me.lblStatus.Size = New System.Drawing.Size(130, 18)
        Me.lblStatus.Text = "Status"
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.cmbStatus.Location = New System.Drawing.Point(158, 274)
        Me.cmbStatus.Size = New System.Drawing.Size(130, 24)
        Me.lblContact.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblContact.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblContact.Location = New System.Drawing.Point(18, 306)
        Me.lblContact.Size = New System.Drawing.Size(130, 18)
        Me.lblContact.Text = "Contact No."
        Me.txtContact.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtContact.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtContact.Location = New System.Drawing.Point(18, 326)
        Me.txtContact.MaxLength = 20
        Me.txtContact.Size = New System.Drawing.Size(130, 25)
        Me.lblGuardian.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblGuardian.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblGuardian.Location = New System.Drawing.Point(158, 306)
        Me.lblGuardian.Size = New System.Drawing.Size(130, 18)
        Me.lblGuardian.Text = "Guardian No."
        Me.txtGuardian.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtGuardian.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGuardian.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtGuardian.Location = New System.Drawing.Point(158, 326)
        Me.txtGuardian.MaxLength = 20
        Me.txtGuardian.Size = New System.Drawing.Size(130, 25)
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(18, 368)
        Me.btnSave.Size = New System.Drawing.Size(130, 36)
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatAppearance.BorderSize = 0
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.btnClear.Location = New System.Drawing.Point(158, 368)
        Me.btnClear.Size = New System.Drawing.Size(130, 36)
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnEnrollBio.BackColor = System.Drawing.Color.FromArgb(16, 185, 129)
        Me.btnEnrollBio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEnrollBio.FlatAppearance.BorderSize = 0
        Me.btnEnrollBio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEnrollBio.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnEnrollBio.ForeColor = System.Drawing.Color.White
        Me.btnEnrollBio.Location = New System.Drawing.Point(18, 412)
        Me.btnEnrollBio.Size = New System.Drawing.Size(270, 36)
        Me.btnEnrollBio.Text = "Enroll Fingerprint"
        Me.btnEnrollBio.UseVisualStyleBackColor = False
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(239, 68, 68)
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(18, 456)
        Me.btnDelete.Size = New System.Drawing.Size(270, 34)
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        Me.pnlGridCard.BackColor = System.Drawing.Color.White
        Me.pnlGridCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlGridCard.Controls.Add(Me.dgvStudents)
        Me.pnlGridCard.Controls.Add(Me.tlpFilter)
        Me.pnlGridCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlGridCard.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlGridCard.Padding = New System.Windows.Forms.Padding(14)
        Me.tlpFilter.ColumnCount = 5
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180.0!))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.tlpFilter.Controls.Add(Me.lblListTitle, 0, 0)
        Me.tlpFilter.Controls.Add(Me.lblSearch, 1, 0)
        Me.tlpFilter.Controls.Add(Me.txtSearch, 2, 0)
        Me.tlpFilter.Controls.Add(Me.lblFilterProg, 3, 0)
        Me.tlpFilter.Controls.Add(Me.cmbFilterProgram, 4, 0)
        Me.tlpFilter.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpFilter.RowCount = 1
        Me.tlpFilter.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFilter.Size = New System.Drawing.Size(614, 42)
        Me.lblListTitle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblListTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblListTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblListTitle.Text = "Student Roster"
        Me.lblListTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSearch.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSearch.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSearch.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblSearch.Text = "Search"
        Me.txtSearch.Anchor = System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.txtSearch.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtSearch.MaxLength = 50
        Me.lblFilterProg.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblFilterProg.AutoSize = True
        Me.lblFilterProg.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblFilterProg.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblFilterProg.Margin = New System.Windows.Forms.Padding(10, 0, 6, 0)
        Me.lblFilterProg.Text = "Program"
        Me.cmbFilterProgram.Anchor = System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.cmbFilterProgram.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFilterProgram.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.dgvStudents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvStudents.Name = "dgvStudents"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.ClientSize = New System.Drawing.Size(964, 620)
        Me.Controls.Add(Me.tlpRoot)
        Me.Name = "frmStudents"
        Me.Text = "Students"
        Me.tlpRoot.ResumeLayout(False)
        Me.pnlFormCard.ResumeLayout(False)
        Me.pnlFormCard.PerformLayout()
        Me.pnlGridCard.ResumeLayout(False)
        Me.tlpFilter.ResumeLayout(False)
        Me.tlpFilter.PerformLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
