Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Diagnostics
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Globalization
Imports System.IO
Imports System.Media
Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading
Imports System.Windows.Forms

Public Class frmAttendanceKiosk
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"
    Private Const WINBIO_TYPE_FINGERPRINT As UInteger = 8UI
    Private Const WINBIO_POOL_SYSTEM As UInteger = 1UI
    Private Const WINBIO_FLAG_DEFAULT As UInteger = 0UI
    Private Const WINBIO_E_UNKNOWN_ID As Integer = &H80098003
    Private Const WINBIO_E_CANCELED As Integer = &H80098004
    Private Const WINBIO_E_NO_MATCH As Integer = &H80098005
    Private Const WINBIO_E_CAPTURE_ABORTED As Integer = &H80098006
    Private Const WINBIO_E_BAD_CAPTURE As Integer = &H80098008
    Private Const WINBIO_E_DEVICE_BUSY As Integer = &H80098010
    Private Const WINBIO_E_DATABASE_NO_SUCH_RECORD As Integer = &H8009801B
    Private Const WINBIO_E_LOCK_VIOLATION As Integer = &H8009802A
    Private Const WINBIO_E_DISABLED As Integer = &H80098032
    Private Const WINBIO_E_SENSOR_UNAVAILABLE As Integer = &H80098034

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioEnumBiometricUnits(ByVal Factor As UInteger, ByRef UnitSchemaArray As IntPtr, ByRef UnitCount As IntPtr) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioOpenSession(ByVal Factor As UInteger, ByVal PoolType As UInteger, ByVal Flags As UInteger, ByVal UnitArray As IntPtr, ByVal UnitCount As IntPtr, ByVal DatabaseId As IntPtr, ByRef SessionHandle As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioCloseSession(ByVal SessionHandle As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioCancel(ByVal SessionHandle As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioFree(ByVal Address As IntPtr) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioIdentify(ByVal SessionHandle As UInteger, ByRef UnitId As UInteger, ByVal Identity As IntPtr, ByRef SubFactor As Byte, ByRef RejectDetail As UInteger) As Integer
    End Function

    <DllImport("user32.dll")> _
    Private Shared Function GetForegroundWindow() As IntPtr
    End Function

    <DllImport("user32.dll")> _
    Private Shared Function GetWindowThreadProcessId(ByVal hWnd As IntPtr, ByRef lpdwProcessId As UInteger) As UInteger
    End Function

    Private Shared _activeInstance As frmAttendanceKiosk

    Public Property LoggedAdminId As Integer = 0
    Public Property IsEmbeddedMode As Boolean = False

    Private _wbfReady As Boolean = False
    Private _wbfSensorName As String = "USB Biometric Scanner"
    Private _wbfSession As UInteger = 0UI
    Private _wbfThread As Thread
    Private _kioskRunning As Boolean = False
    Private ReadOnly _wbfLock As New Object()

    Private _asmDev As Assembly
    Private _asmEng As Assembly
    Private _asmVer As Assembly
    Private _dpReady As Boolean = False
    Private _dpCapturer As Object
    Private _currentState As String = "ARMED"

    Private Sub frmAttendanceKiosk_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            _activeInstance = Me
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvTodayLogs)

            If IsEmbeddedMode Then
                pnlHeader.Visible = False
            Else
                pnlHeader.Visible = True
            End If

            cmbMode.Items.Clear()
            cmbMode.Items.AddRange(New Object() {"Class Schedule", "Campus Gate"})
            cmbMode.SelectedIndex = 0

            UpdateClockLabels()
            LoadScheduleDropdown()
            LoadTodayLogs()
            StartScannerHardware()
        Catch ex As Exception
            MessageBox.Show("Failed to initialize Attendance Kiosk:" & Environment.NewLine & ex.Message, "Kiosk Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmAttendanceKiosk_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        StopScannerHardware()
        If _activeInstance Is Me Then _activeInstance = Nothing
    End Sub

    Private Sub frmAttendanceKiosk_HandleDestroyed(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.HandleDestroyed
        StopScannerHardware()
        If _activeInstance Is Me Then _activeInstance = Nothing
    End Sub

    Private Sub pnlScannerCard_Click(ByVal sender As Object, ByVal e As EventArgs) Handles pnlScannerCard.Click, picScanner.Click, lblVerifyBanner.Click, lblStudentResult.Click
        ActivateHostWindow()
    End Sub

    Private Sub ActivateHostWindow()
        Try
            Dim topForm As Form = TryCast(Me.TopLevelControl, Form)
            If topForm IsNot Nothing Then
                topForm.Activate()
            Else
                Me.Activate()
            End If
            Me.Focus()
        Catch
        End Try
    End Sub

    Private Function IsOurProcessForeground() As Boolean
        Try
            Dim fg As IntPtr = GetForegroundWindow()
            If fg = IntPtr.Zero Then Return False
            Dim pid As UInteger = 0UI
            GetWindowThreadProcessId(fg, pid)
            Return (CInt(pid) = Process.GetCurrentProcess().Id)
        Catch
            Return True
        End Try
    End Function

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try
        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 36
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 34
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.25F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub StartScannerHardware()
        StopScannerHardware()
        _wbfReady = False
        _dpReady = False

        Try
            Dim schemaPtr As IntPtr = IntPtr.Zero
            Dim countPtr As IntPtr = IntPtr.Zero
            Try
                Dim hr As Integer = WinBioEnumBiometricUnits(WINBIO_TYPE_FINGERPRINT, schemaPtr, countPtr)
                If hr = 0 AndAlso countPtr.ToInt64() > 0 AndAlso schemaPtr <> IntPtr.Zero Then
                    Dim desc As String = Marshal.PtrToStringUni(New IntPtr(schemaPtr.ToInt64() + 532L))
                    Dim model As String = Marshal.PtrToStringUni(New IntPtr(schemaPtr.ToInt64() + 1556L))
                    Dim cleanName As String = If(Not String.IsNullOrEmpty(desc), desc.Trim(), If(Not String.IsNullOrEmpty(model), model.Trim(), "USB Capacitive Scanner"))
                    If cleanName.Length > 34 Then cleanName = cleanName.Substring(0, 34).Trim()
                    _wbfSensorName = cleanName
                    _wbfReady = True
                End If
            Finally
                If schemaPtr <> IntPtr.Zero Then WinBioFree(schemaPtr)
            End Try
        Catch
        End Try

        If _wbfReady Then
            lblDeviceBadge.Text = "Scanner Active: " & _wbfSensorName
            lblDeviceBadge.BackColor = Color.FromArgb(220, 252, 231)
            lblDeviceBadge.ForeColor = Color.FromArgb(22, 101, 52)
            lblVerifyBanner.BackColor = Color.FromArgb(219, 234, 254)
            lblVerifyBanner.ForeColor = Color.FromArgb(30, 64, 175)
            lblVerifyBanner.Text = "PLACE FINGER ON PAD"
            lblStudentResult.Text = "Listening for fingerprint touch..."
            DrawScannerVisual("ARMED")

            ActivateHostWindow()
            _kioskRunning = True
            _wbfThread = New Thread(AddressOf RunWbfVerifyLoop)
            _wbfThread.IsBackground = True
            _wbfThread.Start()
            Return
        End If

        Try
            _asmDev = TryLoadDpAssembly("DPFPDevNET")
            _asmEng = TryLoadDpAssembly("DPFPEngNET")
            _asmVer = TryLoadDpAssembly("DPFPVerNET")

            If _asmDev IsNot Nothing AndAlso _asmEng IsNot Nothing AndAlso _asmVer IsNot Nothing Then
                Dim readersType As Type = _asmDev.GetType("DPFP.Capture.ReadersCollection")
                If readersType IsNot Nothing Then
                    Dim rc As Object = Activator.CreateInstance(readersType)
                    Dim cnt As Integer = Convert.ToInt32(readersType.GetProperty("Count").GetValue(rc, Nothing))
                    If cnt > 0 Then
                        Dim capType As Type = _asmDev.GetType("DPFP.Capture.Capture")
                        Dim handlerIface As Type = _asmDev.GetType("DPFP.Capture.EventHandler")
                        _dpCapturer = Activator.CreateInstance(capType)
                        Dim proxy As Object = CreateDpEventProxy(handlerIface)
                        capType.GetProperty("EventHandler").SetValue(_dpCapturer, proxy, Nothing)
                        capType.GetMethod("StartCapture").Invoke(_dpCapturer, Nothing)
                        _dpReady = True

                        lblDeviceBadge.Text = "Scanner Active: DigitalPersona USB"
                        lblDeviceBadge.BackColor = Color.FromArgb(220, 252, 231)
                        lblDeviceBadge.ForeColor = Color.FromArgb(22, 101, 52)
                        lblVerifyBanner.BackColor = Color.FromArgb(219, 234, 254)
                        lblVerifyBanner.ForeColor = Color.FromArgb(30, 64, 175)
                        lblVerifyBanner.Text = "PLACE FINGER ON PAD"
                        lblStudentResult.Text = "Listening for fingerprint touch..."
                        DrawScannerVisual("ARMED")
                        Return
                    End If
                End If
            End If
        Catch
        End Try

        lblDeviceBadge.Text = "No USB Scanner Detected — Plug In Sensor"
        lblDeviceBadge.BackColor = Color.FromArgb(254, 226, 226)
        lblDeviceBadge.ForeColor = Color.FromArgb(185, 28, 28)
        lblVerifyBanner.BackColor = Color.FromArgb(254, 226, 226)
        lblVerifyBanner.ForeColor = Color.FromArgb(185, 28, 28)
        lblVerifyBanner.Text = "SCANNER DISCONNECTED"
        lblStudentResult.Text = "Connect USB fingerprint scanner & click Reconnect."
        DrawScannerVisual("IDLE")
    End Sub

    Private Sub btnReconnectScanner_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReconnectScanner.Click
        StartScannerHardware()
    End Sub

    Private Sub RunWbfVerifyLoop()
        Dim sess As UInteger = 0UI
        Try
            Dim hr As Integer = WinBioOpenSession(WINBIO_TYPE_FINGERPRINT, WINBIO_POOL_SYSTEM, WINBIO_FLAG_DEFAULT, IntPtr.Zero, IntPtr.Zero, New IntPtr(1), sess)
            If hr <> 0 Then
                hr = WinBioOpenSession(WINBIO_TYPE_FINGERPRINT, WINBIO_POOL_SYSTEM, WINBIO_FLAG_DEFAULT, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, sess)
            End If

            If hr <> 0 OrElse sess = 0UI Then
                PostVerifyStatus("FAIL", "SENSOR UNAVAILABLE", "Cannot open Windows Biometric session (0x" & hr.ToString("X8") & ").")
                Return
            End If

            SyncLock _wbfLock
                _wbfSession = sess
            End SyncLock

            Dim idPtr As IntPtr = Marshal.AllocHGlobal(80)
            Try
                While _kioskRunning
                    If Not IsOurProcessForeground() Then
                        Thread.Sleep(250)
                        Continue While
                    End If

                    For k As Integer = 0 To 79
                        Marshal.WriteByte(idPtr, k, 0)
                    Next
                    Dim unitId As UInteger = 0UI
                    Dim subFactor As Byte = 0
                    Dim reject As UInteger = 0UI

                    Dim idHr As Integer = WinBioIdentify(sess, unitId, idPtr, subFactor, reject)
                    If Not _kioskRunning Then Exit While

                    If idHr = 0 Then
                        Dim rawId(75) As Byte
                        Marshal.Copy(idPtr, rawId, 0, 76)
                        Dim hexId As String = BytesToHex(rawId)
                        PostWbfMatchCheck(subFactor, hexId)
                        Thread.Sleep(450)
                    ElseIf idHr = WINBIO_E_NO_MATCH OrElse idHr = WINBIO_E_UNKNOWN_ID OrElse idHr = WINBIO_E_DATABASE_NO_SUCH_RECORD Then
                        If IsOurProcessForeground() Then
                            SystemSounds.Hand.Play()
                            PostVerifyStatus("FAIL", "UNRECOGNIZED FINGER", "Fingerprint is not enrolled in Student Log.")
                            Thread.Sleep(500)
                        Else
                            Thread.Sleep(250)
                        End If
                    ElseIf idHr = WINBIO_E_BAD_CAPTURE Then
                        PostVerifyStatus("WARN", "SCAN AGAIN", FormatRejectReason(reject))
                        Thread.Sleep(300)
                    ElseIf idHr = WINBIO_E_CANCELED OrElse idHr = WINBIO_E_CAPTURE_ABORTED Then
                        If Not _kioskRunning Then Exit While
                        Thread.Sleep(250)
                    ElseIf idHr = WINBIO_E_SENSOR_UNAVAILABLE OrElse idHr = WINBIO_E_DISABLED Then
                        PostSensorOffline()
                        Exit While
                    ElseIf idHr = WINBIO_E_LOCK_VIOLATION OrElse idHr = WINBIO_E_DEVICE_BUSY Then
                        Thread.Sleep(450)
                    Else
                        Thread.Sleep(400)
                    End If
                End While
            Finally
                Marshal.FreeHGlobal(idPtr)
            End Try
        Catch
        Finally
            SyncLock _wbfLock
                If _wbfSession = sess Then _wbfSession = 0UI
            End SyncLock
            If sess <> 0UI Then
                Try
                    WinBioCloseSession(sess)
                Catch
                End Try
            End If
        End Try
    End Sub

    Private Sub PostWbfMatchCheck(ByVal subFactor As Byte, ByVal hexId As String)
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          VerifyWbfIdentityAgainstDatabase(subFactor, hexId)
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Sub VerifyWbfIdentityAgainstDatabase(ByVal subFactor As Byte, ByVal hexId As String)
        Try
            Dim matchedStudentId As Integer = 0
            Dim matchedBioId As Integer = 0

            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using cmd As New SqlCeCommand("SELECT b.biometricid, b.studentid, b.template_data FROM BIOMETRIC_DATA b INNER JOIN STUDENTS s ON b.studentid = s.studentid WHERE b.status = 'Active' AND s.status = 'Active'", conn)
                    Using rdr As SqlCeDataReader = cmd.ExecuteReader()
                        While rdr.Read()
                            Dim raw As Byte() = TryCast(rdr("template_data"), Byte())
                            If raw Is Nothing OrElse raw.Length < 12 Then Continue While
                            Dim txt As String = Encoding.UTF8.GetString(raw)
                            If txt.StartsWith("WBFBIO1|") Then
                                Dim p As String() = txt.Split("|"c)
                                If p.Length >= 4 Then
                                    Dim savedSf As Byte = 0
                                    Byte.TryParse(p(2), savedSf)
                                    If savedSf = subFactor AndAlso String.Equals(p(3), hexId, StringComparison.OrdinalIgnoreCase) Then
                                        matchedBioId = Convert.ToInt32(rdr("biometricid"))
                                        matchedStudentId = Convert.ToInt32(rdr("studentid"))
                                        Exit While
                                    End If
                                End If
                            End If
                        End While
                    End Using
                End Using
            End Using

            If matchedStudentId > 0 AndAlso matchedBioId > 0 Then
                RecordVerifiedAttendance(matchedStudentId, matchedBioId, 99, _wbfSensorName)
            Else
                SystemSounds.Hand.Play()
                ShowBannerResult("FAIL", "NOT ASSIGNED TO STUDENT", "Enroll this finger in the Biometrics tab first.")
            End If
        Catch ex As Exception
            ShowBannerResult("FAIL", "VERIFICATION ERROR", ex.Message)
        End Try
    End Sub

    Private Sub PostVerifyStatus(ByVal kind As String, ByVal banner As String, ByVal detail As String)
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          ShowBannerResult(kind, banner, detail)
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Sub PostSensorOffline()
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          _wbfReady = False
                                          lblDeviceBadge.Text = "USB Scanner Disconnected"
                                          lblDeviceBadge.BackColor = Color.FromArgb(254, 226, 226)
                                          lblDeviceBadge.ForeColor = Color.FromArgb(185, 28, 28)
                                          ShowBannerResult("FAIL", "SCANNER UNPLUGGED", "Reconnect USB cable and click Detect / Reconnect.")
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Function FormatRejectReason(ByVal rejectCode As UInteger) As String
        Select Case rejectCode
            Case 1UI : Return "Place finger slightly lower on pad"
            Case 2UI : Return "Place finger slightly higher on pad"
            Case 3UI : Return "Move finger slightly right"
            Case 4UI : Return "Move finger slightly left"
            Case 5UI, 9UI : Return "Hold finger steady on pad longer"
            Case 7UI, 10UI : Return "Wipe sensor & press finger flat"
            Case Else : Return "Press finger flat in center of pad"
        End Select
    End Function

    Private Shared Function BytesToHex(ByVal data As Byte()) As String
        Dim sb As New StringBuilder(data.Length * 2)
        For Each b As Byte In data
            sb.Append(b.ToString("X2"))
        Next
        Return sb.ToString()
    End Function

    Private Sub StopScannerHardware()
        _kioskRunning = False

        Dim sessToCancel As UInteger = 0UI
        SyncLock _wbfLock
            sessToCancel = _wbfSession
        End SyncLock
        If sessToCancel <> 0UI Then
            Try
                WinBioCancel(sessToCancel)
            Catch
            End Try
        End If

        If _wbfThread IsNot Nothing AndAlso _wbfThread.IsAlive Then
            Try
                _wbfThread.Join(350)
            Catch
            End Try
        End If
        _wbfThread = Nothing

        Try
            If _dpCapturer IsNot Nothing Then
                _dpCapturer.GetType().GetMethod("StopCapture").Invoke(_dpCapturer, Nothing)
                Dim disp As IDisposable = TryCast(_dpCapturer, IDisposable)
                If disp IsNot Nothing Then disp.Dispose()
                _dpCapturer = Nothing
            End If
        Catch
        End Try
    End Sub

    Private Function TryLoadDpAssembly(ByVal simpleName As String) As Assembly
        Try
            Return Assembly.Load(simpleName)
        Catch
        End Try
        Dim probeDirs As String() = New String() {
            Application.StartupPath,
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "DigitalPersona\One Touch SDK\.NET\Bin"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles), "DigitalPersona\One Touch SDK\.NET\Bin"),
            "C:\Program Files (x86)\DigitalPersona\One Touch SDK\.NET\Bin"
        }
        For Each folder As String In probeDirs
            Try
                If Not String.IsNullOrEmpty(folder) AndAlso Directory.Exists(folder) Then
                    Dim dll As String = Path.Combine(folder, simpleName & ".dll")
                    If File.Exists(dll) Then Return Assembly.LoadFrom(dll)
                End If
            Catch
            End Try
        Next
        Return Nothing
    End Function

    Private Function CreateDpEventProxy(ByVal handlerInterface As Type) As Object
        Dim asmName As New AssemblyName("DpKioskProxy_" & Guid.NewGuid().ToString("N"))
        Dim asmBuilder As AssemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(asmName, AssemblyBuilderAccess.Run)
        Dim modBuilder As ModuleBuilder = asmBuilder.DefineDynamicModule("MainMod")
        Dim tb As TypeBuilder = modBuilder.DefineType("DpKioskProxyImpl", TypeAttributes.Public Or TypeAttributes.Class)
        tb.AddInterfaceImplementation(handlerInterface)

        Dim dispatchMi As MethodInfo = GetType(frmAttendanceKiosk).GetMethod("OnDpKioskEvent", BindingFlags.Public Or BindingFlags.Static)

        For Each mi As MethodInfo In handlerInterface.GetMethods()
            Dim pInfos As ParameterInfo() = mi.GetParameters()
            Dim pTypes(pInfos.Length - 1) As Type
            For i As Integer = 0 To pInfos.Length - 1
                pTypes(i) = pInfos(i).ParameterType
            Next

            Dim mb As MethodBuilder = tb.DefineMethod(mi.Name, MethodAttributes.Public Or MethodAttributes.Virtual Or MethodAttributes.Final Or MethodAttributes.HideBySig Or MethodAttributes.NewSlot, mi.ReturnType, pTypes)
            Dim il As ILGenerator = mb.GetILGenerator()
            il.Emit(OpCodes.Ldstr, mi.Name)
            If pTypes.Length >= 2 Then
                il.Emit(OpCodes.Ldarg_2)
                If pTypes(1).IsValueType Then il.Emit(OpCodes.Box, pTypes(1))
            Else
                il.Emit(OpCodes.Ldnull)
            End If
            If pTypes.Length >= 3 Then
                il.Emit(OpCodes.Ldarg_3)
                If pTypes(2).IsValueType Then il.Emit(OpCodes.Box, pTypes(2))
            Else
                il.Emit(OpCodes.Ldnull)
            End If
            il.Emit(OpCodes.Call, dispatchMi)
            il.Emit(OpCodes.Ret)
            tb.DefineMethodOverride(mb, mi)
        Next

        Return Activator.CreateInstance(tb.CreateType())
    End Function

    Public Shared Sub OnDpKioskEvent(ByVal eventName As String, ByVal arg1 As Object, ByVal arg2 As Object)
        Dim inst As frmAttendanceKiosk = _activeInstance
        If inst Is Nothing OrElse inst.IsDisposed Then Return
        Try
            inst.BeginInvoke(New Action(Of String, Object, Object)(AddressOf inst.HandleDpEventOnUi), eventName, arg1, arg2)
        Catch
        End Try
    End Sub

    Private Sub HandleDpEventOnUi(ByVal eventName As String, ByVal arg1 As Object, ByVal arg2 As Object)
        If eventName = "OnComplete" AndAlso arg2 IsNot Nothing Then
            VerifyDpHardwareSample(arg2)
        End If
    End Sub

    Private Sub VerifyDpHardwareSample(ByVal sample As Object)
        Try
            Dim extractorType As Type = _asmEng.GetType("DPFP.Processing.FeatureExtraction")
            Dim purposeType As Type = _asmEng.GetType("DPFP.Processing.DataPurpose")
            Dim feedbackType As Type = _asmDev.GetType("DPFP.Capture.CaptureFeedback")
            Dim featureSetType As Type = _asmDev.GetType("DPFP.FeatureSet")

            Dim extractor As Object = Activator.CreateInstance(extractorType)
            Dim purposeVer As Object = [Enum].Parse(purposeType, "Verification")
            Dim feedback As Object = [Enum].ToObject(feedbackType, 0)
            Dim featureSet As Object = Nothing

            Dim createMi As MethodInfo = extractorType.GetMethod("CreateFeatureSet", New Type() {sample.GetType(), purposeType, feedbackType.MakeByRefType(), featureSetType.MakeByRefType()})
            If createMi Is Nothing Then Return
            Dim callArgs As Object() = New Object() {sample, purposeVer, feedback, featureSet}
            createMi.Invoke(extractor, callArgs)
            Dim features As Object = callArgs(3)

            If features Is Nothing Then
                ShowBannerResult("WARN", "POOR QUALITY", "Press finger flat on the sensor.")
                Return
            End If

            Dim verType As Type = _asmVer.GetType("DPFP.Verification.Verification")
            Dim resType As Type = _asmVer.GetType("DPFP.Verification.Verification+Result")
            Dim tmplType As Type = _asmDev.GetType("DPFP.Template")
            Dim verifier As Object = Activator.CreateInstance(verType)
            Dim verifyMi As MethodInfo = verType.GetMethod("Verify", New Type() {featureSetType, tmplType, resType.MakeByRefType()})

            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Dim dt As New DataTable()
                Using da As New SqlCeDataAdapter("SELECT b.biometricid, b.studentid, b.template_data FROM BIOMETRIC_DATA b INNER JOIN STUDENTS s ON b.studentid = s.studentid WHERE b.status = 'Active' AND s.status = 'Active'", conn)
                    da.Fill(dt)
                End Using

                For Each r As DataRow In dt.Rows
                    Dim raw As Byte() = TryCast(r("template_data"), Byte())
                    If raw Is Nothing OrElse raw.Length < 40 Then Continue For
                    Dim asStr As String = Encoding.UTF8.GetString(raw, 0, Math.Min(10, raw.Length))
                    If asStr.StartsWith("WBFBIO1|") OrElse asStr.StartsWith("SIMBIO1:") Then Continue For

                    Try
                        Dim tmpl As Object = Activator.CreateInstance(tmplType)
                        Using ms As New MemoryStream(raw)
                            tmplType.GetMethod("DeSerialize", New Type() {GetType(Stream)}).Invoke(tmpl, New Object() {ms})
                        End Using
                        Dim resObj As Object = Activator.CreateInstance(resType)
                        Dim vArgs As Object() = New Object() {features, tmpl, resObj}
                        verifyMi.Invoke(verifier, vArgs)
                        Dim verified As Boolean = Convert.ToBoolean(resType.GetProperty("Verified").GetValue(vArgs(2), Nothing))
                        If verified Then
                            RecordVerifiedAttendance(Convert.ToInt32(r("studentid")), Convert.ToInt32(r("biometricid")), 99, "DigitalPersona USB")
                            Return
                        End If
                    Catch
                    End Try
                Next
            End Using

            SystemSounds.Hand.Play()
            ShowBannerResult("FAIL", "UNRECOGNIZED FINGER", "No matching student record found.")
        Catch ex As Exception
            ShowBannerResult("FAIL", "SCANNER ERROR", ex.Message)
        End Try
    End Sub

    Private Sub LoadScheduleDropdown()
        Using conn As New SqlCeConnection(ConnStr)
            conn.Open()
            Dim dt As New DataTable()
            Using da As New SqlCeDataAdapter( _
                "SELECT sc.scheduleid, c.course_code + ' - ' + sc.section + ' (' + sc.time_start + '-' + sc.time_end + ')' AS sched_label " & _
                "FROM SCHEDULES sc INNER JOIN COURSES c ON sc.courseid = c.courseid " & _
                "WHERE sc.status = 'Active' ORDER BY sc.time_start ASC", conn)
                da.Fill(dt)
            End Using
            cmbSchedule.DisplayMember = "sched_label"
            cmbSchedule.ValueMember = "scheduleid"
            cmbSchedule.DataSource = dt
        End Using
    End Sub

    Private Sub cmbMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cmbMode.SelectedIndexChanged
        Dim isClassMode As Boolean = (cmbMode.Text = "Class Schedule")
        lblSchedule.Enabled = isClassMode
        cmbSchedule.Enabled = isClassMode
    End Sub

    Private Sub RecordVerifiedAttendance(ByVal studentId As Integer, ByVal biometricId As Integer, ByVal score As Integer, ByVal deviceName As String)
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Dim dtS As New DataTable()
                Using cmdS As New SqlCeCommand("SELECT student_number, first_name, last_name, program, year_level, section, status FROM STUDENTS WHERE studentid = @id", conn)
                    cmdS.Parameters.AddWithValue("@id", studentId)
                    Using da As New SqlCeDataAdapter(cmdS)
                        da.Fill(dtS)
                    End Using
                End Using

                If dtS.Rows.Count = 0 Then
                    ShowBannerResult("FAIL", "RECORD NOT FOUND", "Student record missing.")
                    Return
                End If

                Dim sr As DataRow = dtS.Rows(0)
                Dim studentDisplay As String = Convert.ToString(sr("student_number")) & " — " & Convert.ToString(sr("last_name")) & ", " & Convert.ToString(sr("first_name")) & Environment.NewLine & Convert.ToString(sr("program")) & " " & Convert.ToString(sr("year_level")) & "-" & Convert.ToString(sr("section"))

                If Convert.ToString(sr("status")) <> "Active" Then
                    ShowBannerResult("FAIL", "INACTIVE STUDENT", studentDisplay)
                    Return
                End If

                Dim mode As String = cmbMode.Text
                Dim schedIdObj As Object = DBNull.Value
                Dim schedStart As String = "08:00"
                Dim graceMins As Integer = 15

                If mode = "Class Schedule" Then
                    If cmbSchedule.SelectedValue Is Nothing Then
                        ShowBannerResult("WARN", "NO SCHEDULE SELECTED", "Select an active class schedule first.")
                        Return
                    End If
                    Dim selSchedId As Integer = Convert.ToInt32(cmbSchedule.SelectedValue)
                    schedIdObj = selSchedId

                    Using cmdSc As New SqlCeCommand("SELECT time_start, grace_minutes FROM SCHEDULES WHERE scheduleid = @id", conn)
                        cmdSc.Parameters.AddWithValue("@id", selSchedId)
                        Using rdr As SqlCeDataReader = cmdSc.ExecuteReader()
                            If rdr.Read() Then
                                schedStart = Convert.ToString(rdr("time_start"))
                                graceMins = Convert.ToInt32(rdr("grace_minutes"))
                            End If
                        End Using
                    End Using
                End If

                Dim nowDt As DateTime = DateTime.Now
                Dim dStart As DateTime = DateTime.Today
                Dim dEnd As DateTime = dStart.AddDays(1)

                Dim openLogSql As String = "SELECT logid, time_in, time_out, attendance_status FROM ATTENDANCE_LOGS WHERE studentid = @sid AND log_mode = @md AND log_date >= @d0 AND log_date < @d1"
                If mode = "Class Schedule" Then
                    openLogSql &= " AND scheduleid = @scid"
                End If
                openLogSql &= " ORDER BY logid DESC"

                Dim dtExisting As New DataTable()
                Using cmdEx As New SqlCeCommand(openLogSql, conn)
                    cmdEx.Parameters.AddWithValue("@sid", studentId)
                    cmdEx.Parameters.AddWithValue("@md", mode)
                    cmdEx.Parameters.AddWithValue("@d0", dStart)
                    cmdEx.Parameters.AddWithValue("@d1", dEnd)
                    If mode = "Class Schedule" Then
                        cmdEx.Parameters.AddWithValue("@scid", Convert.ToInt32(schedIdObj))
                    End If
                    Using daEx As New SqlCeDataAdapter(cmdEx)
                        daEx.Fill(dtExisting)
                    End Using
                End Using

                Dim aidObj As Object = If(LoggedAdminId > 0, CObj(LoggedAdminId), CObj(DBNull.Value))
                Dim cleanDev As String = If(String.IsNullOrEmpty(deviceName), "USB Capacitive Scanner", deviceName)
                If cleanDev.Length > 58 Then cleanDev = cleanDev.Substring(0, 58)

                If dtExisting.Rows.Count = 0 OrElse (mode = "Campus Gate" AndAlso Not IsDBNull(dtExisting.Rows(0)("time_out"))) Then
                    Dim attStatus As String = "Present"
                    Dim remark As String = "Verified Time-In"

                    If mode = "Class Schedule" Then
                        Dim parsedStart As DateTime
                        If DateTime.TryParseExact(schedStart, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, parsedStart) Then
                            Dim cutoff As DateTime = DateTime.Today.AddHours(parsedStart.Hour).AddMinutes(parsedStart.Minute + graceMins)
                            If nowDt > cutoff Then
                                attStatus = "Late"
                                remark = "Past " & graceMins.ToString() & "m grace"
                            End If
                        End If
                    End If

                    Using insCmd As New SqlCeCommand("INSERT INTO ATTENDANCE_LOGS (studentid, biometricid, scheduleid, adminid, log_mode, log_date, time_in, time_out, attendance_status, verification_score, scanner_device, remarks) VALUES (@sid, @bid, @scid, @aid, @md, @ld, @ti, NULL, @st, @sc, @dv, @rm)", conn)
                        insCmd.Parameters.AddWithValue("@sid", studentId)
                        insCmd.Parameters.AddWithValue("@bid", biometricId)
                        insCmd.Parameters.AddWithValue("@scid", schedIdObj)
                        insCmd.Parameters.AddWithValue("@aid", aidObj)
                        insCmd.Parameters.AddWithValue("@md", mode)
                        insCmd.Parameters.AddWithValue("@ld", dStart)
                        insCmd.Parameters.AddWithValue("@ti", nowDt)
                        insCmd.Parameters.AddWithValue("@st", attStatus)
                        insCmd.Parameters.AddWithValue("@sc", score)
                        insCmd.Parameters.AddWithValue("@dv", cleanDev)
                        insCmd.Parameters.AddWithValue("@rm", remark)
                        insCmd.ExecuteNonQuery()
                    End Using

                    SystemSounds.Asterisk.Play()
                    ShowBannerResult(If(attStatus = "Late", "WARN", "OK"), "TIME-IN (" & attStatus.ToUpper() & ")", studentDisplay)
                Else
                    Dim openRow As DataRow = dtExisting.Rows(0)
                    If IsDBNull(openRow("time_out")) Then
                        Dim prevIn As DateTime = Convert.ToDateTime(openRow("time_in"))
                        If (nowDt - prevIn).TotalSeconds < 60 Then
                            SystemSounds.Exclamation.Play()
                            ShowBannerResult("WARN", "ALREADY TIMED IN", "Wait 1 min before Time-Out." & Environment.NewLine & studentDisplay)
                            Return
                        End If

                        Using outCmd As New SqlCeCommand("UPDATE ATTENDANCE_LOGS SET time_out = @to, remarks = 'Completed Time-In & Time-Out' WHERE logid = @lid", conn)
                            outCmd.Parameters.AddWithValue("@to", nowDt)
                            outCmd.Parameters.AddWithValue("@lid", Convert.ToInt32(openRow("logid")))
                            outCmd.ExecuteNonQuery()
                        End Using

                        SystemSounds.Asterisk.Play()
                        ShowBannerResult("OK", "TIME-OUT RECORDED", studentDisplay)
                    Else
                        SystemSounds.Exclamation.Play()
                        ShowBannerResult("WARN", "CLASS LOG COMPLETE", "Already logged in & out for this class." & Environment.NewLine & studentDisplay)
                        Return
                    End If
                End If
            End Using

            LoadTodayLogs()
        Catch ex As Exception
            ShowBannerResult("FAIL", "DATABASE ERROR", ex.Message)
        End Try
    End Sub

    Private Sub LoadTodayLogs()
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Dim d0 As DateTime = DateTime.Today
                Dim d1 As DateTime = d0.AddDays(1)
                Dim dt As New DataTable()
                Using cmd As New SqlCeCommand( _
                    "SELECT l.time_in, l.time_out, s.student_number, s.last_name + ', ' + s.first_name AS student_name, " & _
                    "l.log_mode, COALESCE(c.course_code, 'Campus Gate') AS subject_ref, l.attendance_status " & _
                    "FROM ATTENDANCE_LOGS l " & _
                    "INNER JOIN STUDENTS s ON l.studentid = s.studentid " & _
                    "LEFT JOIN SCHEDULES sc ON l.scheduleid = sc.scheduleid " & _
                    "LEFT JOIN COURSES c ON sc.courseid = c.courseid " & _
                    "WHERE l.log_date >= @d0 AND l.log_date < @d1 " & _
                    "ORDER BY l.time_in DESC", conn)
                    cmd.Parameters.AddWithValue("@d0", d0)
                    cmd.Parameters.AddWithValue("@d1", d1)
                    Using da As New SqlCeDataAdapter(cmd)
                        da.Fill(dt)
                    End Using
                End Using
                dgvTodayLogs.DataSource = dt
            End Using

            If dgvTodayLogs.Columns.Contains("time_in") Then
                dgvTodayLogs.Columns("time_in").HeaderText = "Time In"
                dgvTodayLogs.Columns("time_in").DefaultCellStyle.Format = "hh:mm:ss tt"
            End If
            If dgvTodayLogs.Columns.Contains("time_out") Then
                dgvTodayLogs.Columns("time_out").HeaderText = "Time Out"
                dgvTodayLogs.Columns("time_out").DefaultCellStyle.Format = "hh:mm:ss tt"
            End If
            If dgvTodayLogs.Columns.Contains("student_number") Then dgvTodayLogs.Columns("student_number").HeaderText = "Student No."
            If dgvTodayLogs.Columns.Contains("student_name") Then dgvTodayLogs.Columns("student_name").HeaderText = "Student"
            If dgvTodayLogs.Columns.Contains("log_mode") Then dgvTodayLogs.Columns("log_mode").HeaderText = "Mode"
            If dgvTodayLogs.Columns.Contains("subject_ref") Then dgvTodayLogs.Columns("subject_ref").HeaderText = "Class / Gate"
            If dgvTodayLogs.Columns.Contains("attendance_status") Then dgvTodayLogs.Columns("attendance_status").HeaderText = "Status"
        Catch
        End Try
    End Sub

    Private Sub ShowBannerResult(ByVal kind As String, ByVal banner As String, ByVal detail As String)
        tmrBannerReset.Stop()
        lblVerifyBanner.Text = banner
        lblStudentResult.Text = detail

        If kind = "OK" Then
            lblVerifyBanner.BackColor = Color.FromArgb(220, 252, 231)
            lblVerifyBanner.ForeColor = Color.FromArgb(22, 101, 52)
            DrawScannerVisual("OK")
        ElseIf kind = "WARN" Then
            lblVerifyBanner.BackColor = Color.FromArgb(254, 243, 199)
            lblVerifyBanner.ForeColor = Color.FromArgb(146, 64, 14)
            DrawScannerVisual("WARN")
        Else
            lblVerifyBanner.BackColor = Color.FromArgb(254, 226, 226)
            lblVerifyBanner.ForeColor = Color.FromArgb(185, 28, 28)
            DrawScannerVisual("FAIL")
        End If
        tmrBannerReset.Start()
    End Sub

    Private Sub tmrBannerReset_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrBannerReset.Tick
        tmrBannerReset.Stop()
        If _wbfReady OrElse _dpReady Then
            lblVerifyBanner.BackColor = Color.FromArgb(219, 234, 254)
            lblVerifyBanner.ForeColor = Color.FromArgb(30, 64, 175)
            lblVerifyBanner.Text = "PLACE FINGER ON PAD"
            lblStudentResult.Text = "Listening for fingerprint touch..."
            DrawScannerVisual("ARMED")
        Else
            lblVerifyBanner.BackColor = Color.FromArgb(254, 226, 226)
            lblVerifyBanner.ForeColor = Color.FromArgb(185, 28, 28)
            lblVerifyBanner.Text = "SCANNER DISCONNECTED"
            lblStudentResult.Text = "Connect USB fingerprint scanner & click Reconnect."
            DrawScannerVisual("IDLE")
        End If
    End Sub

    Private Sub DrawScannerVisual(ByVal state As String)
        _currentState = state
        Dim bmp As New Bitmap(220, 214)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.SmoothingMode = SmoothingMode.AntiAlias
            g.Clear(Color.FromArgb(248, 250, 252))

            Using cablePen As New Pen(Color.FromArgb(30, 41, 59), 6.0F)
                g.DrawLine(cablePen, 110, 0, 110, 22)
            End Using

            Dim bodyRect As New Rectangle(52, 18, 116, 162)
            Using bodyBrush As New LinearGradientBrush(bodyRect, Color.FromArgb(232, 232, 228), Color.FromArgb(196, 198, 194), LinearGradientMode.Vertical)
                FillRoundedRect(g, bodyBrush, bodyRect, 18)
            End Using
            Using borderPen As New Pen(Color.FromArgb(160, 164, 168), 1.5F)
                DrawRoundedRect(g, borderPen, bodyRect, 18)
            End Using

            Using lockPen As New Pen(Color.FromArgb(71, 85, 105), 1.8F), lockBrush As New SolidBrush(Color.FromArgb(71, 85, 105))
                g.DrawArc(lockPen, 105, 31, 10, 10, 180, 180)
                g.FillRectangle(lockBrush, 103, 36, 14, 10)
            End Using

            Dim grooveRect As New Rectangle(76, 56, 68, 106)
            Using grooveBrush As New LinearGradientBrush(grooveRect, Color.FromArgb(182, 184, 180), Color.FromArgb(220, 222, 218), LinearGradientMode.Vertical)
                FillRoundedRect(g, grooveBrush, grooveRect, 28)
            End Using

            Dim padRect As New Rectangle(86, 80, 48, 48)
            Using padBrush As New SolidBrush(Color.FromArgb(15, 23, 42))
                FillRoundedRect(g, padBrush, padRect, 5)
            End Using

            Dim accent As Color = Color.FromArgb(100, 116, 139)
            Dim caption As String = "OFFLINE"
            If state = "ARMED" Then
                accent = Color.FromArgb(56, 189, 248)
                caption = "SENSOR ARMED"
            ElseIf state = "OK" Then
                accent = Color.FromArgb(34, 197, 94)
                caption = "VERIFIED"
            ElseIf state = "WARN" Then
                accent = Color.FromArgb(245, 158, 11)
                caption = "CHECK STATUS"
            ElseIf state = "FAIL" Then
                accent = Color.FromArgb(239, 68, 68)
                caption = "NO MATCH"
            End If

            Using glowPen As New Pen(accent, 2.4F)
                DrawRoundedRect(g, glowPen, padRect, 5)
            End Using

            For i As Integer = 1 To 3
                Dim rPad As Integer = i * 6
                Using rp As New Pen(accent, 1.6F)
                    g.DrawArc(rp, 110 - rPad, 104 - rPad, rPad * 2, rPad * 2, 200, 140)
                    g.DrawArc(rp, 110 - rPad, 104 - rPad + 4, rPad * 2, rPad * 2, 20, 140)
                End Using
            Next

            Using f As New Font("Segoe UI Semibold", 8.25F, FontStyle.Bold), br As New SolidBrush(Color.FromArgb(51, 65, 85))
                Dim sf As New StringFormat()
                sf.Alignment = StringAlignment.Center
                g.DrawString(caption, f, br, New RectangleF(0, 188, 220, 20), sf)
            End Using
        End Using

        If picScanner.Image IsNot Nothing Then picScanner.Image.Dispose()
        picScanner.Image = bmp
    End Sub

    Private Sub FillRoundedRect(ByVal g As Graphics, ByVal br As Brush, ByVal r As Rectangle, ByVal rad As Integer)
        Using gp As New GraphicsPath()
            Dim d As Integer = rad * 2
            gp.AddArc(r.X, r.Y, d, d, 180, 90)
            gp.AddArc(r.Right - d, r.Y, d, d, 270, 90)
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90)
            gp.AddArc(r.X, r.Bottom - d, d, d, 90, 90)
            gp.CloseFigure()
            g.FillPath(br, gp)
        End Using
    End Sub

    Private Sub DrawRoundedRect(ByVal g As Graphics, ByVal p As Pen, ByVal r As Rectangle, ByVal rad As Integer)
        Using gp As New GraphicsPath()
            Dim d As Integer = rad * 2
            gp.AddArc(r.X, r.Y, d, d, 180, 90)
            gp.AddArc(r.Right - d, r.Y, d, d, 270, 90)
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90)
            gp.AddArc(r.X, r.Bottom - d, d, d, 90, 90)
            gp.CloseFigure()
            g.DrawPath(p, gp)
        End Using
    End Sub

    Private Sub UpdateClockLabels()
        Dim nowDt As DateTime = DateTime.Now
        lblLiveClock.Text = nowDt.ToString("hh:mm:ss tt")
        lblLiveDate.Text = nowDt.ToString("dddd, MMM dd, yyyy")

        If _wbfReady AndAlso Not tmrBannerReset.Enabled Then
            If IsOurProcessForeground() Then
                If lblVerifyBanner.Text = "CLICK WINDOW TO ARM" Then
                    lblVerifyBanner.BackColor = Color.FromArgb(219, 234, 254)
                    lblVerifyBanner.ForeColor = Color.FromArgb(30, 64, 175)
                    lblVerifyBanner.Text = "PLACE FINGER ON PAD"
                    lblStudentResult.Text = "Listening for fingerprint touch..."
                    DrawScannerVisual("ARMED")
                End If
            Else
                If lblVerifyBanner.Text = "PLACE FINGER ON PAD" Then
                    lblVerifyBanner.BackColor = Color.FromArgb(241, 245, 249)
                    lblVerifyBanner.ForeColor = Color.FromArgb(71, 85, 105)
                    lblVerifyBanner.Text = "CLICK WINDOW TO ARM"
                    lblStudentResult.Text = "Click inside Kiosk so Windows routes USB touches here."
                End If
            End If
        End If
    End Sub

    Private Sub tmrClock_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrClock.Tick
        UpdateClockLabels()
    End Sub

    Private Sub btnCloseKiosk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnCloseKiosk.Click
        Me.Close()
    End Sub
End Class
