<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdmins
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents tlpRoot As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlFormCard As System.Windows.Forms.Panel
    Friend WithEvents lblCardTitle As System.Windows.Forms.Label
    Friend WithEvents lblUsername As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents lblFullName As System.Windows.Forms.Label
    Friend WithEvents txtFullName As System.Windows.Forms.TextBox
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblRole As System.Windows.Forms.Label
    Friend WithEvents cmbRole As System.Windows.Forms.ComboBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblConfirm As System.Windows.Forms.Label
    Friend WithEvents txtConfirm As System.Windows.Forms.TextBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents pnlGridCard As System.Windows.Forms.Panel
    Friend WithEvents lblListTitle As System.Windows.Forms.Label
    Friend WithEvents dgvAdmins As System.Windows.Forms.DataGridView

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpRoot = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlFormCard = New System.Windows.Forms.Panel()
        Me.lblCardTitle = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblFullName = New System.Windows.Forms.Label()
        Me.txtFullName = New System.Windows.Forms.TextBox()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblRole = New System.Windows.Forms.Label()
        Me.cmbRole = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.lblConfirm = New System.Windows.Forms.Label()
        Me.txtConfirm = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.pnlGridCard = New System.Windows.Forms.Panel()
        Me.lblListTitle = New System.Windows.Forms.Label()
        Me.dgvAdmins = New System.Windows.Forms.DataGridView()
        Me.tlpRoot.SuspendLayout()
        Me.pnlFormCard.SuspendLayout()
        Me.pnlGridCard.SuspendLayout()
        CType(Me.dgvAdmins, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.tlpRoot.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.tlpRoot.ColumnCount = 2
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320.0!))
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Controls.Add(Me.pnlFormCard, 0, 0)
        Me.tlpRoot.Controls.Add(Me.pnlGridCard, 1, 0)
        Me.tlpRoot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRoot.RowCount = 1
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Size = New System.Drawing.Size(964, 620)
        Me.pnlFormCard.BackColor = System.Drawing.Color.White
        Me.pnlFormCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFormCard.Controls.Add(Me.lblCardTitle)
        Me.pnlFormCard.Controls.Add(Me.lblUsername)
        Me.pnlFormCard.Controls.Add(Me.txtUsername)
        Me.pnlFormCard.Controls.Add(Me.lblFullName)
        Me.pnlFormCard.Controls.Add(Me.txtFullName)
        Me.pnlFormCard.Controls.Add(Me.lblContact)
        Me.pnlFormCard.Controls.Add(Me.txtContact)
        Me.pnlFormCard.Controls.Add(Me.lblEmail)
        Me.pnlFormCard.Controls.Add(Me.txtEmail)
        Me.pnlFormCard.Controls.Add(Me.lblRole)
        Me.pnlFormCard.Controls.Add(Me.cmbRole)
        Me.pnlFormCard.Controls.Add(Me.lblStatus)
        Me.pnlFormCard.Controls.Add(Me.cmbStatus)
        Me.pnlFormCard.Controls.Add(Me.lblPassword)
        Me.pnlFormCard.Controls.Add(Me.txtPassword)
        Me.pnlFormCard.Controls.Add(Me.lblConfirm)
        Me.pnlFormCard.Controls.Add(Me.txtConfirm)
        Me.pnlFormCard.Controls.Add(Me.btnSave)
        Me.pnlFormCard.Controls.Add(Me.btnClear)
        Me.pnlFormCard.Controls.Add(Me.btnDelete)
        Me.pnlFormCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlFormCard.Margin = New System.Windows.Forms.Padding(0, 0, 14, 0)
        Me.lblCardTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblCardTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblCardTitle.Location = New System.Drawing.Point(18, 14)
        Me.lblCardTitle.Size = New System.Drawing.Size(270, 24)
        Me.lblCardTitle.Text = "Admin Account"
        Me.lblUsername.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblUsername.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblUsername.Location = New System.Drawing.Point(18, 46)
        Me.lblUsername.Size = New System.Drawing.Size(270, 18)
        Me.lblUsername.Text = "Username"
        Me.txtUsername.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUsername.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtUsername.Location = New System.Drawing.Point(18, 66)
        Me.txtUsername.MaxLength = 40
        Me.txtUsername.Size = New System.Drawing.Size(270, 25)
        Me.lblFullName.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblFullName.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblFullName.Location = New System.Drawing.Point(18, 98)
        Me.lblFullName.Size = New System.Drawing.Size(270, 18)
        Me.lblFullName.Text = "Full Name"
        Me.txtFullName.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtFullName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFullName.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtFullName.Location = New System.Drawing.Point(18, 118)
        Me.txtFullName.MaxLength = 100
        Me.txtFullName.Size = New System.Drawing.Size(270, 25)
        Me.lblContact.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblContact.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblContact.Location = New System.Drawing.Point(18, 150)
        Me.lblContact.Size = New System.Drawing.Size(270, 18)
        Me.lblContact.Text = "Contact No."
        Me.txtContact.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtContact.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtContact.Location = New System.Drawing.Point(18, 170)
        Me.txtContact.MaxLength = 20
        Me.txtContact.Size = New System.Drawing.Size(270, 25)
        Me.lblEmail.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblEmail.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblEmail.Location = New System.Drawing.Point(18, 202)
        Me.lblEmail.Size = New System.Drawing.Size(270, 18)
        Me.lblEmail.Text = "Email"
        Me.txtEmail.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmail.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtEmail.Location = New System.Drawing.Point(18, 222)
        Me.txtEmail.MaxLength = 100
        Me.txtEmail.Size = New System.Drawing.Size(270, 25)
        Me.lblRole.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblRole.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblRole.Location = New System.Drawing.Point(18, 254)
        Me.lblRole.Size = New System.Drawing.Size(156, 18)
        Me.lblRole.Text = "Role"
        Me.cmbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRole.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.cmbRole.Location = New System.Drawing.Point(18, 274)
        Me.cmbRole.Size = New System.Drawing.Size(156, 24)
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStatus.Location = New System.Drawing.Point(184, 254)
        Me.lblStatus.Size = New System.Drawing.Size(104, 18)
        Me.lblStatus.Text = "Status"
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.cmbStatus.Location = New System.Drawing.Point(184, 274)
        Me.cmbStatus.Size = New System.Drawing.Size(104, 24)
        Me.lblPassword.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblPassword.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblPassword.Location = New System.Drawing.Point(18, 306)
        Me.lblPassword.Size = New System.Drawing.Size(270, 18)
        Me.lblPassword.Text = "Password"
        Me.txtPassword.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPassword.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtPassword.Location = New System.Drawing.Point(18, 326)
        Me.txtPassword.MaxLength = 60
        Me.txtPassword.Size = New System.Drawing.Size(270, 25)
        Me.txtPassword.UseSystemPasswordChar = True
        Me.lblConfirm.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblConfirm.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblConfirm.Location = New System.Drawing.Point(18, 358)
        Me.lblConfirm.Size = New System.Drawing.Size(270, 18)
        Me.lblConfirm.Text = "Confirm Password"
        Me.txtConfirm.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtConfirm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtConfirm.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtConfirm.Location = New System.Drawing.Point(18, 378)
        Me.txtConfirm.MaxLength = 60
        Me.txtConfirm.Size = New System.Drawing.Size(270, 25)
        Me.txtConfirm.UseSystemPasswordChar = True
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(18, 418)
        Me.btnSave.Size = New System.Drawing.Size(130, 36)
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatAppearance.BorderSize = 0
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.btnClear.Location = New System.Drawing.Point(158, 418)
        Me.btnClear.Size = New System.Drawing.Size(130, 36)
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(239, 68, 68)
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(18, 462)
        Me.btnDelete.Size = New System.Drawing.Size(270, 34)
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        Me.pnlGridCard.BackColor = System.Drawing.Color.White
        Me.pnlGridCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlGridCard.Controls.Add(Me.dgvAdmins)
        Me.pnlGridCard.Controls.Add(Me.lblListTitle)
        Me.pnlGridCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlGridCard.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlGridCard.Padding = New System.Windows.Forms.Padding(14)
        Me.lblListTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblListTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblListTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblListTitle.Size = New System.Drawing.Size(614, 34)
        Me.lblListTitle.Text = "Administrators"
        Me.dgvAdmins.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvAdmins.Name = "dgvAdmins"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.ClientSize = New System.Drawing.Size(964, 620)
        Me.Controls.Add(Me.tlpRoot)
        Me.Name = "frmAdmins"
        Me.Text = "Admins"
        Me.tlpRoot.ResumeLayout(False)
        Me.pnlFormCard.ResumeLayout(False)
        Me.pnlFormCard.PerformLayout()
        Me.pnlGridCard.ResumeLayout(False)
        CType(Me.dgvAdmins, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
