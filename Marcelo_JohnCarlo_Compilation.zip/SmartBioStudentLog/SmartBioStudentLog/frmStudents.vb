Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Reflection
Imports System.Text
Imports System.Windows.Forms

Public Class frmStudents
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"

    Public Property LoggedAdminId As Integer = 1
    Public Property ParentDashboard As frmMain = Nothing

    Private _selectedId As Integer = 0

    Private Sub frmStudents_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvStudents)

            cmbProgram.Items.Clear()
            cmbProgram.Items.AddRange(New Object() {"BSIT", "BSCS", "BSIS", "BSCpE", "ACT", "BSEd"})
            cmbProgram.SelectedIndex = 0

            cmbYearLevel.Items.Clear()
            cmbYearLevel.Items.AddRange(New Object() {"1st Year", "2nd Year", "3rd Year", "4th Year"})
            cmbYearLevel.SelectedIndex = 0

            cmbStatus.Items.Clear()
            cmbStatus.Items.AddRange(New Object() {"Active", "Inactive", "Graduated"})
            cmbStatus.SelectedIndex = 0

            cmbFilterProgram.Items.Clear()
            cmbFilterProgram.Items.AddRange(New Object() {"All", "BSIT", "BSCS", "BSIS", "BSCpE", "ACT", "BSEd"})
            cmbFilterProgram.SelectedIndex = 0

            txtSection.Text = "A"
            LoadStudents()
        Catch ex As Exception
            MessageBox.Show("Failed to initialize Students view:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try

        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 36
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 34
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.25F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub LoadStudents()
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Dim bioCounts As New Dictionary(Of Integer, Integer)()
                Using cmdBio As New SqlCeCommand("SELECT studentid, COUNT(*) AS cnt FROM BIOMETRIC_DATA WHERE status = 'Active' GROUP BY studentid", conn)
                    Using rdr As SqlCeDataReader = cmdBio.ExecuteReader()
                        While rdr.Read()
                            bioCounts(Convert.ToInt32(rdr("studentid"))) = Convert.ToInt32(rdr("cnt"))
                        End While
                    End Using
                End Using

                Dim sb As New StringBuilder("SELECT studentid, student_number, first_name, middle_name, last_name, program, year_level, section, contact_number, guardian_contact, status FROM STUDENTS WHERE 1=1")
                Using cmd As New SqlCeCommand()
                    cmd.Connection = conn
                    If cmbFilterProgram.SelectedItem IsNot Nothing AndAlso cmbFilterProgram.SelectedItem.ToString() <> "All" Then
                        sb.Append(" AND program = @pr")
                        cmd.Parameters.AddWithValue("@pr", cmbFilterProgram.SelectedItem.ToString())
                    End If

                    Dim q As String = txtSearch.Text.Trim()
                    If Not String.IsNullOrEmpty(q) Then
                        sb.Append(" AND (student_number LIKE @q OR first_name LIKE @q OR last_name LIKE @q OR section LIKE @q)")
                        cmd.Parameters.AddWithValue("@q", "%" & q & "%")
                    End If

                    sb.Append(" ORDER BY last_name ASC, first_name ASC")
                    cmd.CommandText = sb.ToString()

                    Dim dt As New DataTable()
                    Using da As New SqlCeDataAdapter(cmd)
                        da.Fill(dt)
                    End Using

                    dt.Columns.Add("full_name", GetType(String))
                    dt.Columns.Add("bio_status", GetType(String))

                    For Each r As DataRow In dt.Rows
                        Dim sid As Integer = Convert.ToInt32(r("studentid"))
                        Dim mn As String = If(IsDBNull(r("middle_name")), "", Convert.ToString(r("middle_name")).Trim())
                        Dim mi As String = If(mn.Length > 0, " " & mn.Substring(0, 1) & ".", "")
                        r("full_name") = Convert.ToString(r("last_name")) & ", " & Convert.ToString(r("first_name")) & mi

                        Dim cnt As Integer = If(bioCounts.ContainsKey(sid), bioCounts(sid), 0)
                        r("bio_status") = If(cnt > 0, "Enrolled (" & cnt.ToString() & ")", "None")
                    Next

                    dgvStudents.DataSource = dt
                End Using
            End Using

            Dim hideCols As String() = New String() {"studentid", "first_name", "middle_name", "last_name", "guardian_contact"}
            For Each cName As String In hideCols
                If dgvStudents.Columns.Contains(cName) Then dgvStudents.Columns(cName).Visible = False
            Next

            If dgvStudents.Columns.Contains("student_number") Then dgvStudents.Columns("student_number").HeaderText = "Student No."
            If dgvStudents.Columns.Contains("full_name") Then
                dgvStudents.Columns("full_name").HeaderText = "Full Name"
                dgvStudents.Columns("full_name").DisplayIndex = 1
            End If
            If dgvStudents.Columns.Contains("program") Then dgvStudents.Columns("program").HeaderText = "Program"
            If dgvStudents.Columns.Contains("year_level") Then dgvStudents.Columns("year_level").HeaderText = "Year"
            If dgvStudents.Columns.Contains("section") Then dgvStudents.Columns("section").HeaderText = "Section"
            If dgvStudents.Columns.Contains("contact_number") Then dgvStudents.Columns("contact_number").HeaderText = "Contact"
            If dgvStudents.Columns.Contains("bio_status") Then dgvStudents.Columns("bio_status").HeaderText = "Biometric"
            If dgvStudents.Columns.Contains("status") Then dgvStudents.Columns("status").HeaderText = "Status"
        Catch ex As Exception
            MessageBox.Show("Error loading students:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub NameBox_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles txtFirstName.KeyPress, txtMiddleName.KeyPress, txtLastName.KeyPress
        If Char.IsControl(e.KeyChar) Then Return
        If Char.IsLetter(e.KeyChar) OrElse e.KeyChar = " "c OrElse e.KeyChar = "-"c OrElse e.KeyChar = "."c OrElse e.KeyChar = "'"c Then Return
        e.Handled = True
    End Sub

    Private Sub PhoneBox_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles txtContact.KeyPress, txtGuardian.KeyPress
        If Char.IsControl(e.KeyChar) Then Return
        If Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "+"c OrElse e.KeyChar = "-"c OrElse e.KeyChar = " "c OrElse e.KeyChar = "("c OrElse e.KeyChar = ")"c Then Return
        e.Handled = True
    End Sub

    Private Function CountDigits(ByVal s As String) As Integer
        Dim n As Integer = 0
        For Each ch As Char In s
            If Char.IsDigit(ch) Then n += 1
        Next
        Return n
    End Function

    Private Sub dgvStudents_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvStudents.CellClick
        If e.RowIndex < 0 OrElse dgvStudents.CurrentRow Is Nothing Then Return
        Try
            Dim drv As DataRowView = TryCast(dgvStudents.CurrentRow.DataBoundItem, DataRowView)
            If drv Is Nothing Then Return

            _selectedId = Convert.ToInt32(drv("studentid"))
            txtStudentNo.Text = Convert.ToString(drv("student_number"))
            txtFirstName.Text = Convert.ToString(drv("first_name"))
            txtMiddleName.Text = If(IsDBNull(drv("middle_name")), "", Convert.ToString(drv("middle_name")))
            txtLastName.Text = Convert.ToString(drv("last_name"))
            cmbProgram.Text = Convert.ToString(drv("program"))
            cmbYearLevel.Text = Convert.ToString(drv("year_level"))
            txtSection.Text = If(IsDBNull(drv("section")), "", Convert.ToString(drv("section")))
            txtContact.Text = If(IsDBNull(drv("contact_number")), "", Convert.ToString(drv("contact_number")))
            txtGuardian.Text = If(IsDBNull(drv("guardian_contact")), "", Convert.ToString(drv("guardian_contact")))
            cmbStatus.Text = Convert.ToString(drv("status"))
            btnSave.Text = "Update"
        Catch ex As Exception
            MessageBox.Show("Unable to read selected row:" & Environment.NewLine & ex.Message, "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub ClearInputs()
        _selectedId = 0
        txtStudentNo.Text = ""
        txtFirstName.Text = ""
        txtMiddleName.Text = ""
        txtLastName.Text = ""
        If cmbProgram.Items.Count > 0 Then cmbProgram.SelectedIndex = 0
        If cmbYearLevel.Items.Count > 0 Then cmbYearLevel.SelectedIndex = 0
        txtSection.Text = "A"
        If cmbStatus.Items.Count > 0 Then cmbStatus.SelectedIndex = 0
        txtContact.Text = ""
        txtGuardian.Text = ""
        btnSave.Text = "Save"
        dgvStudents.ClearSelection()
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ClearInputs()
        txtStudentNo.Focus()
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Dim sn As String = txtStudentNo.Text.Trim()
        Dim fn As String = txtFirstName.Text.Trim()
        Dim mn As String = txtMiddleName.Text.Trim()
        Dim ln As String = txtLastName.Text.Trim()
        Dim sec As String = txtSection.Text.Trim()
        Dim phone As String = txtContact.Text.Trim()
        Dim guardPhone As String = txtGuardian.Text.Trim()

        If String.IsNullOrEmpty(sn) Then
            MessageBox.Show("Student No. is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtStudentNo.Focus()
            Return
        End If
        If sn.Length < 3 Then
            MessageBox.Show("Student No. must be at least 3 characters.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtStudentNo.Focus()
            Return
        End If
        If String.IsNullOrEmpty(fn) Then
            MessageBox.Show("First Name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtFirstName.Focus()
            Return
        End If
        If String.IsNullOrEmpty(ln) Then
            MessageBox.Show("Last Name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtLastName.Focus()
            Return
        End If
        If String.IsNullOrEmpty(sec) Then
            MessageBox.Show("Section is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSection.Focus()
            Return
        End If
        If Not String.IsNullOrEmpty(phone) AndAlso CountDigits(phone) < 7 Then
            MessageBox.Show("Contact No. must contain at least 7 digits.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContact.Focus()
            Return
        End If
        If Not String.IsNullOrEmpty(guardPhone) AndAlso CountDigits(guardPhone) < 7 Then
            MessageBox.Show("Guardian No. must contain at least 7 digits.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtGuardian.Focus()
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using dupCmd As New SqlCeCommand("SELECT COUNT(*) FROM STUDENTS WHERE student_number = @sn AND studentid <> @id", conn)
                    dupCmd.Parameters.AddWithValue("@sn", sn)
                    dupCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(dupCmd.ExecuteScalar()) > 0 Then
                        MessageBox.Show("Student No. '" & sn & "' is already registered.", "Duplicate Student No.", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        txtStudentNo.Focus()
                        Return
                    End If
                End Using

                If _selectedId = 0 Then
                    Using cmd As New SqlCeCommand("INSERT INTO STUDENTS (student_number, first_name, middle_name, last_name, program, year_level, section, contact_number, guardian_contact, status, date_registered) VALUES (@sn, @fn, @mn, @ln, @pr, @yl, @sc, @cn, @gc, @st, @dt)", conn)
                        cmd.Parameters.AddWithValue("@sn", sn)
                        cmd.Parameters.AddWithValue("@fn", fn)
                        cmd.Parameters.AddWithValue("@mn", mn)
                        cmd.Parameters.AddWithValue("@ln", ln)
                        cmd.Parameters.AddWithValue("@pr", cmbProgram.Text)
                        cmd.Parameters.AddWithValue("@yl", cmbYearLevel.Text)
                        cmd.Parameters.AddWithValue("@sc", sec)
                        cmd.Parameters.AddWithValue("@cn", phone)
                        cmd.Parameters.AddWithValue("@gc", guardPhone)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                        cmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "CREATE", sn, "Added student " & ln & ", " & fn)
                    MessageBox.Show("Student saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    Using cmd As New SqlCeCommand("UPDATE STUDENTS SET student_number=@sn, first_name=@fn, middle_name=@mn, last_name=@ln, program=@pr, year_level=@yl, section=@sc, contact_number=@cn, guardian_contact=@gc, status=@st WHERE studentid=@id", conn)
                        cmd.Parameters.AddWithValue("@sn", sn)
                        cmd.Parameters.AddWithValue("@fn", fn)
                        cmd.Parameters.AddWithValue("@mn", mn)
                        cmd.Parameters.AddWithValue("@ln", ln)
                        cmd.Parameters.AddWithValue("@pr", cmbProgram.Text)
                        cmd.Parameters.AddWithValue("@yl", cmbYearLevel.Text)
                        cmd.Parameters.AddWithValue("@sc", sec)
                        cmd.Parameters.AddWithValue("@cn", phone)
                        cmd.Parameters.AddWithValue("@gc", guardPhone)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.Parameters.AddWithValue("@id", _selectedId)
                        cmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "UPDATE", sn, "Updated student " & ln & ", " & fn)
                    MessageBox.Show("Student updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using

            ClearInputs()
            LoadStudents()
        Catch ex As SqlCeException
            MessageBox.Show("Database error while saving student:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("Unexpected error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnEnrollBio_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnEnrollBio.Click
        If _selectedId <= 0 Then
            MessageBox.Show("Select a student from the list first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        If ParentDashboard IsNot Nothing Then
            ParentDashboard.OpenBiometricForStudent(_selectedId)
        Else
            Using f As New frmBiometric()
                f.LoggedAdminId = Me.LoggedAdminId
                f.PreselectedStudentId = _selectedId
                f.FormBorderStyle = FormBorderStyle.Sizable
                f.StartPosition = FormStartPosition.CenterParent
                f.ShowDialog(Me)
                LoadStudents()
            End Using
        End If
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click
        If _selectedId <= 0 Then
            MessageBox.Show("Select a student from the list first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using chkCmd As New SqlCeCommand("SELECT COUNT(*) FROM ATTENDANCE_LOGS WHERE studentid = @id", conn)
                    chkCmd.Parameters.AddWithValue("@id", _selectedId)
                    If Convert.ToInt32(chkCmd.ExecuteScalar()) > 0 Then
                        If MessageBox.Show("This student has attendance history. Set status to Inactive instead?", "Preserve History", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                            Using archCmd As New SqlCeCommand("UPDATE STUDENTS SET status = 'Inactive' WHERE studentid = @id", conn)
                                archCmd.Parameters.AddWithValue("@id", _selectedId)
                                archCmd.ExecuteNonQuery()
                            End Using
                            LogAudit(conn, "ARCHIVE", txtStudentNo.Text.Trim(), "Set student Inactive")
                            ClearInputs()
                            LoadStudents()
                        End If
                        Return
                    End If
                End Using

                If MessageBox.Show("Delete student '" & txtStudentNo.Text.Trim() & "'?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
                    Using bioCmd As New SqlCeCommand("SELECT template_data FROM BIOMETRIC_DATA WHERE studentid = @id", conn)
                        bioCmd.Parameters.AddWithValue("@id", _selectedId)
                        Using rdr As SqlCeDataReader = bioCmd.ExecuteReader()
                            While rdr.Read()
                                Dim raw As Byte() = TryCast(rdr("template_data"), Byte())
                                If raw IsNot Nothing Then frmBiometric.ReleaseHardwareTemplate(raw)
                            End While
                        End Using
                    End Using
                    Using delCmd As New SqlCeCommand("DELETE FROM STUDENTS WHERE studentid = @id", conn)
                        delCmd.Parameters.AddWithValue("@id", _selectedId)
                        delCmd.ExecuteNonQuery()
                    End Using
                    LogAudit(conn, "DELETE", txtStudentNo.Text.Trim(), "Deleted student record")
                    ClearInputs()
                    LoadStudents()
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Unable to delete student:" & Environment.NewLine & ex.Message, "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged
        LoadStudents()
    End Sub

    Private Sub cmbFilterProgram_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cmbFilterProgram.SelectedIndexChanged
        LoadStudents()
    End Sub

    Private Sub LogAudit(ByVal conn As SqlCeConnection, ByVal action As String, ByVal refCode As String, ByVal desc As String)
        Try
            Dim aidObj As Object = If(LoggedAdminId > 0, CObj(LoggedAdminId), CObj(DBNull.Value))
            Using cmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, @act, 'Students', @ref, @dsc, @dev, @dt)", conn)
                cmd.Parameters.AddWithValue("@aid", aidObj)
                cmd.Parameters.AddWithValue("@act", action)
                cmd.Parameters.AddWithValue("@ref", refCode)
                cmd.Parameters.AddWithValue("@dsc", desc)
                cmd.Parameters.AddWithValue("@dev", Environment.MachineName)
                cmd.Parameters.AddWithValue("@dt", DateTime.Now)
                cmd.ExecuteNonQuery()
            End Using
        Catch
        End Try
    End Sub
End Class
