<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBiometric
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents tlpRoot As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlScannerCard As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblDeviceBadge As System.Windows.Forms.Label
    Friend WithEvents lblSelectedStudent As System.Windows.Forms.Label
    Friend WithEvents lblFinger As System.Windows.Forms.Label
    Friend WithEvents cmbFinger As System.Windows.Forms.ComboBox
    Friend WithEvents picFinger As System.Windows.Forms.PictureBox
    Friend WithEvents prgSamples As System.Windows.Forms.ProgressBar
    Friend WithEvents lblScanPrompt As System.Windows.Forms.Label
    Friend WithEvents btnStartEnroll As System.Windows.Forms.Button
    Friend WithEvents btnDetectScanner As System.Windows.Forms.Button
    Friend WithEvents btnRevoke As System.Windows.Forms.Button
    Friend WithEvents pnlGridCard As System.Windows.Forms.Panel
    Friend WithEvents tlpFilter As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblListTitle As System.Windows.Forms.Label
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents dgvStudents As System.Windows.Forms.DataGridView

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpRoot = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlScannerCard = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblDeviceBadge = New System.Windows.Forms.Label()
        Me.lblSelectedStudent = New System.Windows.Forms.Label()
        Me.lblFinger = New System.Windows.Forms.Label()
        Me.cmbFinger = New System.Windows.Forms.ComboBox()
        Me.picFinger = New System.Windows.Forms.PictureBox()
        Me.prgSamples = New System.Windows.Forms.ProgressBar()
        Me.lblScanPrompt = New System.Windows.Forms.Label()
        Me.btnStartEnroll = New System.Windows.Forms.Button()
        Me.btnDetectScanner = New System.Windows.Forms.Button()
        Me.btnRevoke = New System.Windows.Forms.Button()
        Me.pnlGridCard = New System.Windows.Forms.Panel()
        Me.tlpFilter = New System.Windows.Forms.TableLayoutPanel()
        Me.lblListTitle = New System.Windows.Forms.Label()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.dgvStudents = New System.Windows.Forms.DataGridView()
        Me.tlpRoot.SuspendLayout()
        Me.pnlScannerCard.SuspendLayout()
        CType(Me.picFinger, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlGridCard.SuspendLayout()
        Me.tlpFilter.SuspendLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.tlpRoot.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.tlpRoot.ColumnCount = 2
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 360.0!))
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Controls.Add(Me.pnlScannerCard, 0, 0)
        Me.tlpRoot.Controls.Add(Me.pnlGridCard, 1, 0)
        Me.tlpRoot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRoot.RowCount = 1
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Size = New System.Drawing.Size(964, 620)
        Me.pnlScannerCard.BackColor = System.Drawing.Color.White
        Me.pnlScannerCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlScannerCard.Controls.Add(Me.lblTitle)
        Me.pnlScannerCard.Controls.Add(Me.lblDeviceBadge)
        Me.pnlScannerCard.Controls.Add(Me.lblSelectedStudent)
        Me.pnlScannerCard.Controls.Add(Me.lblFinger)
        Me.pnlScannerCard.Controls.Add(Me.cmbFinger)
        Me.pnlScannerCard.Controls.Add(Me.picFinger)
        Me.pnlScannerCard.Controls.Add(Me.prgSamples)
        Me.pnlScannerCard.Controls.Add(Me.lblScanPrompt)
        Me.pnlScannerCard.Controls.Add(Me.btnStartEnroll)
        Me.pnlScannerCard.Controls.Add(Me.btnDetectScanner)
        Me.pnlScannerCard.Controls.Add(Me.btnRevoke)
        Me.pnlScannerCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlScannerCard.Margin = New System.Windows.Forms.Padding(0, 0, 14, 0)
        Me.lblTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblTitle.Location = New System.Drawing.Point(20, 14)
        Me.lblTitle.Size = New System.Drawing.Size(304, 24)
        Me.lblTitle.Text = "Fingerprint Enrollment"
        Me.lblDeviceBadge.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.lblDeviceBadge.Font = New System.Drawing.Font("Segoe UI Semibold", 8.5!, System.Drawing.FontStyle.Bold)
        Me.lblDeviceBadge.ForeColor = System.Drawing.Color.FromArgb(30, 64, 175)
        Me.lblDeviceBadge.Location = New System.Drawing.Point(20, 44)
        Me.lblDeviceBadge.Size = New System.Drawing.Size(304, 26)
        Me.lblDeviceBadge.Text = "Checking USB Biometric Sensor..."
        Me.lblDeviceBadge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblSelectedStudent.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.lblSelectedStudent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSelectedStudent.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.lblSelectedStudent.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblSelectedStudent.Location = New System.Drawing.Point(20, 80)
        Me.lblSelectedStudent.Padding = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Me.lblSelectedStudent.Size = New System.Drawing.Size(304, 38)
        Me.lblSelectedStudent.Text = "Select a student on the right"
        Me.lblSelectedStudent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblFinger.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblFinger.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblFinger.Location = New System.Drawing.Point(20, 128)
        Me.lblFinger.Size = New System.Drawing.Size(304, 18)
        Me.lblFinger.Text = "Finger Position"
        Me.cmbFinger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFinger.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.cmbFinger.Location = New System.Drawing.Point(20, 148)
        Me.cmbFinger.Size = New System.Drawing.Size(304, 24)
        Me.picFinger.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.picFinger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picFinger.Location = New System.Drawing.Point(72, 184)
        Me.picFinger.Size = New System.Drawing.Size(200, 210)
        Me.picFinger.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.prgSamples.Location = New System.Drawing.Point(20, 406)
        Me.prgSamples.Maximum = 4
        Me.prgSamples.Size = New System.Drawing.Size(304, 14)
        Me.lblScanPrompt.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblScanPrompt.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblScanPrompt.Location = New System.Drawing.Point(20, 426)
        Me.lblScanPrompt.Size = New System.Drawing.Size(304, 24)
        Me.lblScanPrompt.Text = "Ready"
        Me.lblScanPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnStartEnroll.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnStartEnroll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStartEnroll.FlatAppearance.BorderSize = 0
        Me.btnStartEnroll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStartEnroll.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnStartEnroll.ForeColor = System.Drawing.Color.White
        Me.btnStartEnroll.Location = New System.Drawing.Point(20, 458)
        Me.btnStartEnroll.Size = New System.Drawing.Size(147, 36)
        Me.btnStartEnroll.Text = "Start Capture"
        Me.btnStartEnroll.UseVisualStyleBackColor = False
        Me.btnDetectScanner.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.btnDetectScanner.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDetectScanner.FlatAppearance.BorderSize = 0
        Me.btnDetectScanner.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDetectScanner.Font = New System.Drawing.Font("Segoe UI Semibold", 9.25!, System.Drawing.FontStyle.Bold)
        Me.btnDetectScanner.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.btnDetectScanner.Location = New System.Drawing.Point(177, 458)
        Me.btnDetectScanner.Size = New System.Drawing.Size(147, 36)
        Me.btnDetectScanner.Text = "Detect Scanner"
        Me.btnDetectScanner.UseVisualStyleBackColor = False
        Me.btnRevoke.BackColor = System.Drawing.Color.FromArgb(239, 68, 68)
        Me.btnRevoke.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRevoke.FlatAppearance.BorderSize = 0
        Me.btnRevoke.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRevoke.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnRevoke.ForeColor = System.Drawing.Color.White
        Me.btnRevoke.Location = New System.Drawing.Point(20, 502)
        Me.btnRevoke.Size = New System.Drawing.Size(304, 34)
        Me.btnRevoke.Text = "Revoke Template"
        Me.btnRevoke.UseVisualStyleBackColor = False
        Me.pnlGridCard.BackColor = System.Drawing.Color.White
        Me.pnlGridCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlGridCard.Controls.Add(Me.dgvStudents)
        Me.pnlGridCard.Controls.Add(Me.tlpFilter)
        Me.pnlGridCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlGridCard.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlGridCard.Padding = New System.Windows.Forms.Padding(14)
        Me.tlpFilter.ColumnCount = 3
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.tlpFilter.Controls.Add(Me.lblListTitle, 0, 0)
        Me.tlpFilter.Controls.Add(Me.lblSearch, 1, 0)
        Me.tlpFilter.Controls.Add(Me.txtSearch, 2, 0)
        Me.tlpFilter.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpFilter.RowCount = 1
        Me.tlpFilter.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFilter.Size = New System.Drawing.Size(574, 42)
        Me.lblListTitle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblListTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblListTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblListTitle.Text = "Student Biometric Status"
        Me.lblListTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSearch.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSearch.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSearch.Margin = New System.Windows.Forms.Padding(6, 0, 8, 0)
        Me.lblSearch.Text = "Search"
        Me.txtSearch.Anchor = System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.txtSearch.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtSearch.MaxLength = 50
        Me.dgvStudents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvStudents.Name = "dgvStudents"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.ClientSize = New System.Drawing.Size(964, 620)
        Me.Controls.Add(Me.tlpRoot)
        Me.Name = "frmBiometric"
        Me.Text = "Biometrics"
        Me.tlpRoot.ResumeLayout(False)
        Me.pnlScannerCard.ResumeLayout(False)
        CType(Me.picFinger, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlGridCard.ResumeLayout(False)
        Me.tlpFilter.ResumeLayout(False)
        Me.tlpFilter.PerformLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
