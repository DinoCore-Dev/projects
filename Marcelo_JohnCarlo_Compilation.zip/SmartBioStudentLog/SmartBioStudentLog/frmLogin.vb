Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Windows.Forms

Public Class frmLogin
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"
    Private Shared _dbVerified As Boolean = False

    Private _failedAttempts As Integer = 0
    Private _lockoutSeconds As Integer = 0
    Private _closingApp As Boolean = True

    Private Sub frmLogin_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            EnsureDatabaseReady()
            lblStatus.Text = ""
        Catch ex As SqlCeException
            lblStatus.Text = "Database engine error. Use x86 build target."
            MessageBox.Show("SQL Server Compact 3.5 could not initialize:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            lblStatus.Text = "Startup error."
            MessageBox.Show("Failed to initialize local database:" & Environment.NewLine & ex.Message, "Startup Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Shared Sub EnsureDatabaseReady()
        If _dbVerified Then Return

        Dim dataDirObj As Object = AppDomain.CurrentDomain.GetData("DataDirectory")
        Dim baseDir As String = If(dataDirObj IsNot Nothing AndAlso Not String.IsNullOrEmpty(dataDirObj.ToString()), dataDirObj.ToString(), Application.StartupPath)
        If Not Directory.Exists(baseDir) Then
            Directory.CreateDirectory(baseDir)
        End If

        Dim sdfPath As String = Path.Combine(baseDir, "SmartBioStudentLog.sdf")
        If Not File.Exists(sdfPath) Then
            Using engine As New SqlCeEngine(ConnStr)
                engine.CreateDatabase()
            End Using
            BuildTablesAndSeed()
        End If
        _dbVerified = True
    End Sub

    Private Shared Sub BuildTablesAndSeed()
        Dim ddl As String() = New String() {
            "CREATE TABLE ADMINS (adminid INT IDENTITY(1,1) PRIMARY KEY, username NVARCHAR(50) NOT NULL, password_hash NVARCHAR(128) NOT NULL, full_name NVARCHAR(100) NOT NULL, contact_number NVARCHAR(20), email NVARCHAR(100), role NVARCHAR(30) NOT NULL, status NVARCHAR(20) NOT NULL, last_login DATETIME NULL, created_at DATETIME NOT NULL)",
            "CREATE UNIQUE INDEX UQ_ADMINS_USER ON ADMINS (username)",
            "CREATE TABLE AUDIT_LOGS (auditid INT IDENTITY(1,1) PRIMARY KEY, adminid INT NULL, action_type NVARCHAR(50) NOT NULL, module_name NVARCHAR(50) NOT NULL, record_ref NVARCHAR(50), description NVARCHAR(255), device_info NVARCHAR(100), logged_at DATETIME NOT NULL)",
            "ALTER TABLE AUDIT_LOGS ADD CONSTRAINT FK_AUDIT_ADMIN FOREIGN KEY (adminid) REFERENCES ADMINS(adminid)",
            "CREATE TABLE STUDENTS (studentid INT IDENTITY(1,1) PRIMARY KEY, student_number NVARCHAR(25) NOT NULL, first_name NVARCHAR(50) NOT NULL, middle_name NVARCHAR(50), last_name NVARCHAR(50) NOT NULL, program NVARCHAR(50) NOT NULL, year_level NVARCHAR(20) NOT NULL, section NVARCHAR(20), contact_number NVARCHAR(20), guardian_contact NVARCHAR(20), status NVARCHAR(20) NOT NULL, date_registered DATETIME NOT NULL)",
            "CREATE UNIQUE INDEX UQ_STUDENTS_NO ON STUDENTS (student_number)",
            "CREATE TABLE BIOMETRIC_DATA (biometricid INT IDENTITY(1,1) PRIMARY KEY, studentid INT NOT NULL, enrolled_by INT NULL, biometric_type NVARCHAR(30) NOT NULL, finger_position NVARCHAR(30) NOT NULL, template_data IMAGE, template_hash NVARCHAR(64), sample_quality NVARCHAR(20), scanner_model NVARCHAR(60), status NVARCHAR(20) NOT NULL, date_captured DATETIME NOT NULL)",
            "ALTER TABLE BIOMETRIC_DATA ADD CONSTRAINT FK_BIO_STUD FOREIGN KEY (studentid) REFERENCES STUDENTS(studentid) ON DELETE CASCADE",
            "ALTER TABLE BIOMETRIC_DATA ADD CONSTRAINT FK_BIO_ADM FOREIGN KEY (enrolled_by) REFERENCES ADMINS(adminid)",
            "CREATE TABLE TEACHERS (teacherid INT IDENTITY(1,1) PRIMARY KEY, employee_no NVARCHAR(25) NOT NULL, full_name NVARCHAR(100) NOT NULL, contact_number NVARCHAR(20), email NVARCHAR(100), department NVARCHAR(80), status NVARCHAR(20) NOT NULL, created_at DATETIME NOT NULL)",
            "CREATE UNIQUE INDEX UQ_TEACHERS_EMP ON TEACHERS (employee_no)",
            "CREATE TABLE COURSES (courseid INT IDENTITY(1,1) PRIMARY KEY, course_code NVARCHAR(20) NOT NULL, course_name NVARCHAR(120) NOT NULL, units INT NOT NULL, description NVARCHAR(255), department NVARCHAR(80), status NVARCHAR(20) NOT NULL)",
            "CREATE UNIQUE INDEX UQ_COURSES_CD ON COURSES (course_code)",
            "CREATE TABLE SCHEDULES (scheduleid INT IDENTITY(1,1) PRIMARY KEY, courseid INT NOT NULL, teacherid INT NOT NULL, section NVARCHAR(30) NOT NULL, day_of_week NVARCHAR(30) NOT NULL, time_start NVARCHAR(10) NOT NULL, time_end NVARCHAR(10) NOT NULL, room NVARCHAR(40), grace_minutes INT NOT NULL, semester NVARCHAR(40), status NVARCHAR(20) NOT NULL)",
            "ALTER TABLE SCHEDULES ADD CONSTRAINT FK_SCH_CRS FOREIGN KEY (courseid) REFERENCES COURSES(courseid)",
            "ALTER TABLE SCHEDULES ADD CONSTRAINT FK_SCH_TCH FOREIGN KEY (teacherid) REFERENCES TEACHERS(teacherid)",
            "CREATE TABLE CLASS_ENROLLMENTS (enrollmentid INT IDENTITY(1,1) PRIMARY KEY, studentid INT NOT NULL, scheduleid INT NOT NULL, date_enrolled DATETIME NOT NULL, status NVARCHAR(20) NOT NULL)",
            "ALTER TABLE CLASS_ENROLLMENTS ADD CONSTRAINT FK_ENR_STD FOREIGN KEY (studentid) REFERENCES STUDENTS(studentid) ON DELETE CASCADE",
            "ALTER TABLE CLASS_ENROLLMENTS ADD CONSTRAINT FK_ENR_SCH FOREIGN KEY (scheduleid) REFERENCES SCHEDULES(scheduleid) ON DELETE CASCADE",
            "CREATE TABLE ATTENDANCE_LOGS (logid INT IDENTITY(1,1) PRIMARY KEY, studentid INT NOT NULL, biometricid INT NOT NULL, scheduleid INT NULL, adminid INT NULL, log_mode NVARCHAR(25) NOT NULL, log_date DATETIME NOT NULL, time_in DATETIME NOT NULL, time_out DATETIME NULL, attendance_status NVARCHAR(20) NOT NULL, verification_score INT NOT NULL, scanner_device NVARCHAR(60), remarks NVARCHAR(150))",
            "ALTER TABLE ATTENDANCE_LOGS ADD CONSTRAINT FK_LOG_STD FOREIGN KEY (studentid) REFERENCES STUDENTS(studentid)",
            "ALTER TABLE ATTENDANCE_LOGS ADD CONSTRAINT FK_LOG_BIO FOREIGN KEY (biometricid) REFERENCES BIOMETRIC_DATA(biometricid)",
            "ALTER TABLE ATTENDANCE_LOGS ADD CONSTRAINT FK_LOG_SCH FOREIGN KEY (scheduleid) REFERENCES SCHEDULES(scheduleid)",
            "ALTER TABLE ATTENDANCE_LOGS ADD CONSTRAINT FK_LOG_ADM FOREIGN KEY (adminid) REFERENCES ADMINS(adminid)"
        }

        Using conn As New SqlCeConnection(ConnStr)
            conn.Open()
            For Each stmt As String In ddl
                Using cmd As New SqlCeCommand(stmt, conn)
                    cmd.ExecuteNonQuery()
                End Using
            Next

            Dim nowDt As DateTime = DateTime.Now
            Dim aid As Integer = ExecInsertId(conn, "INSERT INTO ADMINS (username, password_hash, full_name, contact_number, email, role, status, created_at) VALUES (@u, @p, @fn, @cn, @em, @rl, 'Active', @dt)", _
                New SqlCeParameter("@u", "admin"), New SqlCeParameter("@p", HashPassword("admin123")), _
                New SqlCeParameter("@fn", "System Administrator"), New SqlCeParameter("@cn", "0917-555-0101"), _
                New SqlCeParameter("@em", "admin@smartbio.edu.ph"), New SqlCeParameter("@rl", "Super Admin"), New SqlCeParameter("@dt", nowDt))

            ExecInsertId(conn, "INSERT INTO ADMINS (username, password_hash, full_name, contact_number, email, role, status, created_at) VALUES (@u, @p, @fn, @cn, @em, @rl, 'Active', @dt)", _
                New SqlCeParameter("@u", "officer"), New SqlCeParameter("@p", HashPassword("officer123")), _
                New SqlCeParameter("@fn", "Attendance Officer"), New SqlCeParameter("@cn", "0918-555-0199"), _
                New SqlCeParameter("@em", "officer@smartbio.edu.ph"), New SqlCeParameter("@rl", "Attendance Officer"), New SqlCeParameter("@dt", nowDt))

            Dim c1 As Integer = ExecInsertId(conn, "INSERT INTO COURSES (course_code, course_name, units, description, department, status) VALUES (@cc, @cn, @un, @ds, @dp, 'Active')", _
                New SqlCeParameter("@cc", "IT 301"), New SqlCeParameter("@cn", "Database Management Systems 2"), _
                New SqlCeParameter("@un", 3), New SqlCeParameter("@ds", "Relational modeling and biometric database design"), New SqlCeParameter("@dp", "Information Technology"))

            Dim c2 As Integer = ExecInsertId(conn, "INSERT INTO COURSES (course_code, course_name, units, description, department, status) VALUES (@cc, @cn, @un, @ds, @dp, 'Active')", _
                New SqlCeParameter("@cc", "IT 304"), New SqlCeParameter("@cn", "Systems Analysis and Design"), _
                New SqlCeParameter("@un", 3), New SqlCeParameter("@ds", "ERD, HIPO and enterprise systems architecture"), New SqlCeParameter("@dp", "Information Technology"))

            Dim c3 As Integer = ExecInsertId(conn, "INSERT INTO COURSES (course_code, course_name, units, description, department, status) VALUES (@cc, @cn, @un, @ds, @dp, 'Active')", _
                New SqlCeParameter("@cc", "CS 202"), New SqlCeParameter("@cn", "Event-Driven Programming"), _
                New SqlCeParameter("@un", 3), New SqlCeParameter("@ds", "Windows Forms and hardware integration"), New SqlCeParameter("@dp", "Computer Science"))

            Dim t1 As Integer = ExecInsertId(conn, "INSERT INTO TEACHERS (employee_no, full_name, contact_number, email, department, status, created_at) VALUES (@en, @fn, @cn, @em, @dp, 'Active', @dt)", _
                New SqlCeParameter("@en", "FAC-2026-001"), New SqlCeParameter("@fn", "Engr. Ramon Villanueva"), _
                New SqlCeParameter("@cn", "0917-801-2210"), New SqlCeParameter("@em", "r.villanueva@smartbio.edu.ph"), _
                New SqlCeParameter("@dp", "Information Technology"), New SqlCeParameter("@dt", nowDt))

            Dim t2 As Integer = ExecInsertId(conn, "INSERT INTO TEACHERS (employee_no, full_name, contact_number, email, department, status, created_at) VALUES (@en, @fn, @cn, @em, @dp, 'Active', @dt)", _
                New SqlCeParameter("@en", "FAC-2026-002"), New SqlCeParameter("@fn", "Prof. Elena Reyes"), _
                New SqlCeParameter("@cn", "0919-440-3381"), New SqlCeParameter("@em", "e.reyes@smartbio.edu.ph"), _
                New SqlCeParameter("@dp", "Information Technology"), New SqlCeParameter("@dt", nowDt))

            Dim sc1 As Integer = ExecInsertId(conn, "INSERT INTO SCHEDULES (courseid, teacherid, section, day_of_week, time_start, time_end, room, grace_minutes, semester, status) VALUES (@cid, @tid, @sec, @dow, @ts, @te, @rm, @gr, @sem, 'Active')", _
                New SqlCeParameter("@cid", c1), New SqlCeParameter("@tid", t1), New SqlCeParameter("@sec", "BSIT 3A"), _
                New SqlCeParameter("@dow", "Daily"), New SqlCeParameter("@ts", "07:30"), New SqlCeParameter("@te", "11:30"), _
                New SqlCeParameter("@rm", "CompLab 1"), New SqlCeParameter("@gr", 15), New SqlCeParameter("@sem", "1st Sem 2026-2027"))

            Dim sc2 As Integer = ExecInsertId(conn, "INSERT INTO SCHEDULES (courseid, teacherid, section, day_of_week, time_start, time_end, room, grace_minutes, semester, status) VALUES (@cid, @tid, @sec, @dow, @ts, @te, @rm, @gr, @sem, 'Active')", _
                New SqlCeParameter("@cid", c2), New SqlCeParameter("@tid", t2), New SqlCeParameter("@sec", "BSIT 3A"), _
                New SqlCeParameter("@dow", "Daily"), New SqlCeParameter("@ts", "12:00"), New SqlCeParameter("@te", "17:30"), _
                New SqlCeParameter("@rm", "CompLab 2"), New SqlCeParameter("@gr", 15), New SqlCeParameter("@sem", "1st Sem 2026-2027"))

            Dim students As String()() = New String()() {
                New String() {"2026-00101", "Juan", "Santos", "Dela Cruz", "BSIT", "3rd Year", "A", "0917-201-1101", "0917-900-1101"},
                New String() {"2026-00102", "Maria Clara", "Reyes", "Mendoza", "BSIT", "3rd Year", "A", "0918-201-1102", "0918-900-1102"},
                New String() {"2026-00103", "Gabriel", "Cruz", "Soriano", "BSIT", "3rd Year", "A", "0919-201-1103", "0919-900-1103"},
                New String() {"2026-00104", "Angela Mae", "Lopez", "Aquino", "BSCS", "2nd Year", "A", "0920-201-1104", "0920-900-1104"},
                New String() {"2026-00105", "Christian", "Diaz", "Navarro", "BSIT", "3rd Year", "B", "0921-201-1105", "0921-900-1105"}
            }

            For i As Integer = 0 To students.Length - 1
                Dim s As String() = students(i)
                Dim sid As Integer = ExecInsertId(conn, "INSERT INTO STUDENTS (student_number, first_name, middle_name, last_name, program, year_level, section, contact_number, guardian_contact, status, date_registered) VALUES (@sn, @fn, @mn, @ln, @pr, @yl, @sc, @cn, @gc, 'Active', @dt)", _
                    New SqlCeParameter("@sn", s(0)), New SqlCeParameter("@fn", s(1)), New SqlCeParameter("@mn", s(2)), _
                    New SqlCeParameter("@ln", s(3)), New SqlCeParameter("@pr", s(4)), New SqlCeParameter("@yl", s(5)), _
                    New SqlCeParameter("@sc", s(6)), New SqlCeParameter("@cn", s(7)), New SqlCeParameter("@gc", s(8)), _
                    New SqlCeParameter("@dt", nowDt.AddDays(-10)))

                If i < 3 Then
                    ExecInsertId(conn, "INSERT INTO CLASS_ENROLLMENTS (studentid, scheduleid, date_enrolled, status) VALUES (@sid, @scid, @dt, 'Enrolled')", _
                        New SqlCeParameter("@sid", sid), New SqlCeParameter("@scid", sc1), New SqlCeParameter("@dt", nowDt.AddDays(-7)))
                    ExecInsertId(conn, "INSERT INTO CLASS_ENROLLMENTS (studentid, scheduleid, date_enrolled, status) VALUES (@sid, @scid, @dt, 'Enrolled')", _
                        New SqlCeParameter("@sid", sid), New SqlCeParameter("@scid", sc2), New SqlCeParameter("@dt", nowDt.AddDays(-7)))
                End If
            Next

            ExecInsertId(conn, "INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, 'INIT', 'Database', 'SDF-3.5', 'Created local database and initial seed records', @dev, @dt)", _
                New SqlCeParameter("@aid", aid), New SqlCeParameter("@dev", Environment.MachineName), New SqlCeParameter("@dt", nowDt))
        End Using
    End Sub

    Private Shared Function ExecInsertId(ByVal conn As SqlCeConnection, ByVal sql As String, ByVal ParamArray prms As SqlCeParameter()) As Integer
        Using cmd As New SqlCeCommand(sql, conn)
            If prms IsNot Nothing Then
                For Each p As SqlCeParameter In prms
                    cmd.Parameters.Add(p)
                Next
            End If
            cmd.ExecuteNonQuery()
        End Using
        Using idCmd As New SqlCeCommand("SELECT @@IDENTITY", conn)
            Dim v As Object = idCmd.ExecuteScalar()
            If v IsNot Nothing AndAlso Not IsDBNull(v) Then Return Convert.ToInt32(v)
        End Using
        Return 0
    End Function

    Private Shared Function HashPassword(ByVal text As String) As String
        Using sha As SHA256 = SHA256.Create()
            Dim b As Byte() = sha.ComputeHash(Encoding.UTF8.GetBytes(If(text, "")))
            Dim sb As New StringBuilder(b.Length * 2)
            For i As Integer = 0 To b.Length - 1
                sb.Append(b(i).ToString("x2"))
            Next
            Return sb.ToString()
        End Using
    End Function

    Private Sub pnlBrand_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles pnlBrand.Paint
        Dim g As Graphics = e.Graphics
        g.SmoothingMode = SmoothingMode.AntiAlias

        Using grad As New LinearGradientBrush(pnlBrand.ClientRectangle, Color.FromArgb(15, 23, 42), Color.FromArgb(23, 37, 84), LinearGradientMode.Vertical)
            g.FillRectangle(grad, pnlBrand.ClientRectangle)
        End Using

        Dim ringRect As New Rectangle(118, 92, 84, 84)
        Using softB As New SolidBrush(Color.FromArgb(30, 56, 189, 248))
            g.FillEllipse(softB, ringRect)
        End Using
        Using ringP As New Pen(Color.FromArgb(56, 189, 248), 2.0F)
            g.DrawEllipse(ringP, ringRect)
        End Using
        For i As Integer = 1 To 4
            Dim pad As Integer = 14 + i * 7
            Using arcP As New Pen(Color.FromArgb(210, 56, 189, 248), 1.8F)
                g.DrawArc(arcP, ringRect.X + pad \ 2, ringRect.Y + pad \ 2, ringRect.Width - pad, ringRect.Height - pad, -155, 230)
            End Using
        Next

        Using fMain As New Font("Segoe UI", 19.0F, FontStyle.Bold)
            TextRenderer.DrawText(g, "Smart Bio", fMain, New Rectangle(20, 198, 280, 36), Color.White, TextFormatFlags.HorizontalCenter Or TextFormatFlags.VerticalCenter)
        End Using
        Using fSub As New Font("Segoe UI Semibold", 11.0F, FontStyle.Bold)
            TextRenderer.DrawText(g, "Student Log System", fSub, New Rectangle(20, 234, 280, 26), Color.FromArgb(56, 189, 248), TextFormatFlags.HorizontalCenter Or TextFormatFlags.VerticalCenter)
        End Using
        Using fFoot As New Font("Segoe UI", 8.5F, FontStyle.Regular)
            TextRenderer.DrawText(g, "USB Biometric  •  SQL CE 3.5", fFoot, New Rectangle(20, 408, 280, 24), Color.FromArgb(148, 163, 184), TextFormatFlags.HorizontalCenter Or TextFormatFlags.VerticalCenter)
        End Using
    End Sub

    Private Sub chkShowPassword_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chkShowPassword.CheckedChanged
        txtPassword.UseSystemPasswordChar = Not chkShowPassword.Checked
    End Sub

    Private Sub tmrLockout_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrLockout.Tick
        If _lockoutSeconds > 0 Then
            _lockoutSeconds -= 1
            lblStatus.Text = "Too many attempts. Wait " & _lockoutSeconds.ToString() & "s."
            If _lockoutSeconds <= 0 Then
                tmrLockout.Stop()
                _failedAttempts = 0
                btnSignIn.Enabled = True
                lblStatus.Text = ""
            End If
        End If
    End Sub

    Private Sub btnSignIn_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSignIn.Click
        If _lockoutSeconds > 0 Then Return

        Dim userText As String = txtUsername.Text.Trim()
        Dim passText As String = txtPassword.Text

        If String.IsNullOrEmpty(userText) Then
            lblStatus.Text = "Enter your username."
            txtUsername.Focus()
            Return
        End If
        If String.IsNullOrEmpty(passText) Then
            lblStatus.Text = "Enter your password."
            txtPassword.Focus()
            Return
        End If

        Try
            EnsureDatabaseReady()
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Dim dt As New DataTable()
                Using cmd As New SqlCeCommand("SELECT adminid, username, password_hash, full_name, role, status FROM ADMINS WHERE username = @u", conn)
                    cmd.Parameters.AddWithValue("@u", userText)
                    Using da As New SqlCeDataAdapter(cmd)
                        da.Fill(dt)
                    End Using
                End Using

                If dt.Rows.Count = 0 Then
                    RegisterFailedLogin(conn, userText)
                    Return
                End If

                Dim r As DataRow = dt.Rows(0)
                Dim stored As String = Convert.ToString(r("password_hash"))
                Dim enteredHash As String = HashPassword(passText)

                If Not String.Equals(stored, enteredHash, StringComparison.OrdinalIgnoreCase) AndAlso Not String.Equals(stored, passText, StringComparison.Ordinal) Then
                    RegisterFailedLogin(conn, userText)
                    Return
                End If

                If Not String.Equals(Convert.ToString(r("status")), "Active", StringComparison.OrdinalIgnoreCase) Then
                    lblStatus.Text = "Account is inactive."
                    Return
                End If

                Dim adminId As Integer = Convert.ToInt32(r("adminid"))
                Dim fullName As String = Convert.ToString(r("full_name"))
                Dim roleName As String = Convert.ToString(r("role"))

                Using upCmd As New SqlCeCommand("UPDATE ADMINS SET last_login = @dt WHERE adminid = @id", conn)
                    upCmd.Parameters.AddWithValue("@dt", DateTime.Now)
                    upCmd.Parameters.AddWithValue("@id", adminId)
                    upCmd.ExecuteNonQuery()
                End Using

                Using logCmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, 'LOGIN', 'Auth', @ref, 'Administrator signed in', @dev, @dt)", conn)
                    logCmd.Parameters.AddWithValue("@aid", adminId)
                    logCmd.Parameters.AddWithValue("@ref", userText)
                    logCmd.Parameters.AddWithValue("@dev", Environment.MachineName)
                    logCmd.Parameters.AddWithValue("@dt", DateTime.Now)
                    logCmd.ExecuteNonQuery()
                End Using

                _failedAttempts = 0
                lblStatus.Text = ""
                _closingApp = False

                Dim mainWin As New frmMain()
                mainWin.LoggedAdminId = adminId
                mainWin.LoggedUsername = userText
                mainWin.LoggedFullName = fullName
                mainWin.LoggedRole = roleName
                AddHandler mainWin.FormClosed, AddressOf MainWin_FormClosed
                Me.Hide()
                mainWin.Show()
            End Using
        Catch ex As SqlCeException
            lblStatus.Text = "Database error during sign in."
            MessageBox.Show("Database query error:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            lblStatus.Text = "Unexpected error occurred."
            MessageBox.Show("Sign-in error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub RegisterFailedLogin(ByVal conn As SqlCeConnection, ByVal attemptedUser As String)
        _failedAttempts += 1
        Try
            Using logCmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (NULL, 'LOGIN_FAIL', 'Auth', @ref, 'Failed sign-in attempt', @dev, @dt)", conn)
                logCmd.Parameters.AddWithValue("@ref", If(attemptedUser.Length > 45, attemptedUser.Substring(0, 45), attemptedUser))
                logCmd.Parameters.AddWithValue("@dev", Environment.MachineName)
                logCmd.Parameters.AddWithValue("@dt", DateTime.Now)
                logCmd.ExecuteNonQuery()
            End Using
        Catch
        End Try

        If _failedAttempts >= 5 Then
            _lockoutSeconds = 15
            btnSignIn.Enabled = False
            lblStatus.Text = "Too many attempts. Wait 15s."
            tmrLockout.Start()
        Else
            lblStatus.Text = "Invalid username or password."
            txtPassword.SelectAll()
            txtPassword.Focus()
        End If
    End Sub

    Private Sub MainWin_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Dim dash As frmMain = TryCast(sender, frmMain)
        If dash IsNot Nothing AndAlso dash.SignedOutToLogin Then
            _closingApp = True
            txtPassword.Text = ""
            lblStatus.Text = ""
            Me.Show()
            txtPassword.Focus()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub btnOpenKiosk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnOpenKiosk.Click
        Try
            EnsureDatabaseReady()
            Using kiosk As New frmAttendanceKiosk()
                kiosk.LoggedAdminId = 0
                Me.Hide()
                kiosk.ShowDialog(Me)
                Me.Show()
            End Using
        Catch ex As Exception
            Me.Show()
            MessageBox.Show("Unable to open Attendance Kiosk:" & Environment.NewLine & ex.Message, "Kiosk Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
