<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSchedules
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents tlpRoot As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlFormCard As System.Windows.Forms.Panel
    Friend WithEvents lblCardTitle As System.Windows.Forms.Label
    Friend WithEvents lblCourse As System.Windows.Forms.Label
    Friend WithEvents cmbCourse As System.Windows.Forms.ComboBox
    Friend WithEvents lblTeacher As System.Windows.Forms.Label
    Friend WithEvents cmbTeacher As System.Windows.Forms.ComboBox
    Friend WithEvents lblSection As System.Windows.Forms.Label
    Friend WithEvents txtSection As System.Windows.Forms.TextBox
    Friend WithEvents lblDays As System.Windows.Forms.Label
    Friend WithEvents cmbDays As System.Windows.Forms.ComboBox
    Friend WithEvents lblStart As System.Windows.Forms.Label
    Friend WithEvents dtpStart As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblEnd As System.Windows.Forms.Label
    Friend WithEvents dtpEnd As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblRoom As System.Windows.Forms.Label
    Friend WithEvents txtRoom As System.Windows.Forms.TextBox
    Friend WithEvents lblGrace As System.Windows.Forms.Label
    Friend WithEvents nudGrace As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblSemester As System.Windows.Forms.Label
    Friend WithEvents txtSemester As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents tlpRight As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlSchedulesCard As System.Windows.Forms.Panel
    Friend WithEvents lblSchedulesTitle As System.Windows.Forms.Label
    Friend WithEvents dgvSchedules As System.Windows.Forms.DataGridView
    Friend WithEvents pnlRosterCard As System.Windows.Forms.Panel
    Friend WithEvents tlpRosterBar As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblRosterTitle As System.Windows.Forms.Label
    Friend WithEvents cmbRosterStudent As System.Windows.Forms.ComboBox
    Friend WithEvents btnAddStudent As System.Windows.Forms.Button
    Friend WithEvents btnRemoveStudent As System.Windows.Forms.Button
    Friend WithEvents dgvRoster As System.Windows.Forms.DataGridView

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpRoot = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlFormCard = New System.Windows.Forms.Panel()
        Me.lblCardTitle = New System.Windows.Forms.Label()
        Me.lblCourse = New System.Windows.Forms.Label()
        Me.cmbCourse = New System.Windows.Forms.ComboBox()
        Me.lblTeacher = New System.Windows.Forms.Label()
        Me.cmbTeacher = New System.Windows.Forms.ComboBox()
        Me.lblSection = New System.Windows.Forms.Label()
        Me.txtSection = New System.Windows.Forms.TextBox()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.cmbDays = New System.Windows.Forms.ComboBox()
        Me.lblStart = New System.Windows.Forms.Label()
        Me.dtpStart = New System.Windows.Forms.DateTimePicker()
        Me.lblEnd = New System.Windows.Forms.Label()
        Me.dtpEnd = New System.Windows.Forms.DateTimePicker()
        Me.lblRoom = New System.Windows.Forms.Label()
        Me.txtRoom = New System.Windows.Forms.TextBox()
        Me.lblGrace = New System.Windows.Forms.Label()
        Me.nudGrace = New System.Windows.Forms.NumericUpDown()
        Me.lblSemester = New System.Windows.Forms.Label()
        Me.txtSemester = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.tlpRight = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlSchedulesCard = New System.Windows.Forms.Panel()
        Me.lblSchedulesTitle = New System.Windows.Forms.Label()
        Me.dgvSchedules = New System.Windows.Forms.DataGridView()
        Me.pnlRosterCard = New System.Windows.Forms.Panel()
        Me.tlpRosterBar = New System.Windows.Forms.TableLayoutPanel()
        Me.lblRosterTitle = New System.Windows.Forms.Label()
        Me.cmbRosterStudent = New System.Windows.Forms.ComboBox()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.btnRemoveStudent = New System.Windows.Forms.Button()
        Me.dgvRoster = New System.Windows.Forms.DataGridView()
        Me.tlpRoot.SuspendLayout()
        Me.pnlFormCard.SuspendLayout()
        CType(Me.nudGrace, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tlpRight.SuspendLayout()
        Me.pnlSchedulesCard.SuspendLayout()
        CType(Me.dgvSchedules, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlRosterCard.SuspendLayout()
        Me.tlpRosterBar.SuspendLayout()
        CType(Me.dgvRoster, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.tlpRoot.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.tlpRoot.ColumnCount = 2
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320.0!))
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Controls.Add(Me.pnlFormCard, 0, 0)
        Me.tlpRoot.Controls.Add(Me.tlpRight, 1, 0)
        Me.tlpRoot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRoot.RowCount = 1
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Size = New System.Drawing.Size(964, 620)
        Me.pnlFormCard.BackColor = System.Drawing.Color.White
        Me.pnlFormCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFormCard.Controls.Add(Me.lblCardTitle)
        Me.pnlFormCard.Controls.Add(Me.lblCourse)
        Me.pnlFormCard.Controls.Add(Me.cmbCourse)
        Me.pnlFormCard.Controls.Add(Me.lblTeacher)
        Me.pnlFormCard.Controls.Add(Me.cmbTeacher)
        Me.pnlFormCard.Controls.Add(Me.lblSection)
        Me.pnlFormCard.Controls.Add(Me.txtSection)
        Me.pnlFormCard.Controls.Add(Me.lblDays)
        Me.pnlFormCard.Controls.Add(Me.cmbDays)
        Me.pnlFormCard.Controls.Add(Me.lblStart)
        Me.pnlFormCard.Controls.Add(Me.dtpStart)
        Me.pnlFormCard.Controls.Add(Me.lblEnd)
        Me.pnlFormCard.Controls.Add(Me.dtpEnd)
        Me.pnlFormCard.Controls.Add(Me.lblRoom)
        Me.pnlFormCard.Controls.Add(Me.txtRoom)
        Me.pnlFormCard.Controls.Add(Me.lblGrace)
        Me.pnlFormCard.Controls.Add(Me.nudGrace)
        Me.pnlFormCard.Controls.Add(Me.lblSemester)
        Me.pnlFormCard.Controls.Add(Me.txtSemester)
        Me.pnlFormCard.Controls.Add(Me.lblStatus)
        Me.pnlFormCard.Controls.Add(Me.cmbStatus)
        Me.pnlFormCard.Controls.Add(Me.btnSave)
        Me.pnlFormCard.Controls.Add(Me.btnClear)
        Me.pnlFormCard.Controls.Add(Me.btnDelete)
        Me.pnlFormCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlFormCard.Margin = New System.Windows.Forms.Padding(0, 0, 14, 0)
        Me.lblCardTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblCardTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblCardTitle.Location = New System.Drawing.Point(18, 14)
        Me.lblCardTitle.Size = New System.Drawing.Size(270, 24)
        Me.lblCardTitle.Text = "Schedule Details"
        Me.lblCourse.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblCourse.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblCourse.Location = New System.Drawing.Point(18, 46)
        Me.lblCourse.Size = New System.Drawing.Size(270, 18)
        Me.lblCourse.Text = "Course"
        Me.cmbCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCourse.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.cmbCourse.Location = New System.Drawing.Point(18, 66)
        Me.cmbCourse.Size = New System.Drawing.Size(270, 24)
        Me.lblTeacher.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblTeacher.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblTeacher.Location = New System.Drawing.Point(18, 98)
        Me.lblTeacher.Size = New System.Drawing.Size(270, 18)
        Me.lblTeacher.Text = "Teacher"
        Me.cmbTeacher.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTeacher.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.cmbTeacher.Location = New System.Drawing.Point(18, 118)
        Me.cmbTeacher.Size = New System.Drawing.Size(270, 24)
        Me.lblSection.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSection.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblSection.Location = New System.Drawing.Point(18, 150)
        Me.lblSection.Size = New System.Drawing.Size(130, 18)
        Me.lblSection.Text = "Section"
        Me.txtSection.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtSection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSection.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtSection.Location = New System.Drawing.Point(18, 170)
        Me.txtSection.MaxLength = 30
        Me.txtSection.Size = New System.Drawing.Size(130, 24)
        Me.lblDays.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblDays.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblDays.Location = New System.Drawing.Point(158, 150)
        Me.lblDays.Size = New System.Drawing.Size(130, 18)
        Me.lblDays.Text = "Days"
        Me.cmbDays.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbDays.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.cmbDays.Location = New System.Drawing.Point(158, 170)
        Me.cmbDays.Size = New System.Drawing.Size(130, 24)
        Me.lblStart.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblStart.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStart.Location = New System.Drawing.Point(18, 202)
        Me.lblStart.Size = New System.Drawing.Size(130, 18)
        Me.lblStart.Text = "Start Time"
        Me.dtpStart.CustomFormat = "HH:mm"
        Me.dtpStart.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.dtpStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStart.Location = New System.Drawing.Point(18, 222)
        Me.dtpStart.ShowUpDown = True
        Me.dtpStart.Size = New System.Drawing.Size(130, 24)
        Me.lblEnd.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblEnd.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblEnd.Location = New System.Drawing.Point(158, 202)
        Me.lblEnd.Size = New System.Drawing.Size(130, 18)
        Me.lblEnd.Text = "End Time"
        Me.dtpEnd.CustomFormat = "HH:mm"
        Me.dtpEnd.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.dtpEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpEnd.Location = New System.Drawing.Point(158, 222)
        Me.dtpEnd.ShowUpDown = True
        Me.dtpEnd.Size = New System.Drawing.Size(130, 24)
        Me.lblRoom.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblRoom.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblRoom.Location = New System.Drawing.Point(18, 254)
        Me.lblRoom.Size = New System.Drawing.Size(150, 18)
        Me.lblRoom.Text = "Room"
        Me.txtRoom.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtRoom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRoom.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtRoom.Location = New System.Drawing.Point(18, 274)
        Me.txtRoom.MaxLength = 40
        Me.txtRoom.Size = New System.Drawing.Size(150, 24)
        Me.lblGrace.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblGrace.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblGrace.Location = New System.Drawing.Point(178, 254)
        Me.lblGrace.Size = New System.Drawing.Size(110, 18)
        Me.lblGrace.Text = "Grace (min)"
        Me.nudGrace.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.nudGrace.Location = New System.Drawing.Point(178, 274)
        Me.nudGrace.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.nudGrace.Minimum = New Decimal(New Integer() {0, 0, 0, 0})
        Me.nudGrace.Size = New System.Drawing.Size(110, 24)
        Me.nudGrace.Value = New Decimal(New Integer() {15, 0, 0, 0})
        Me.lblSemester.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSemester.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblSemester.Location = New System.Drawing.Point(18, 306)
        Me.lblSemester.Size = New System.Drawing.Size(160, 18)
        Me.lblSemester.Text = "Semester"
        Me.txtSemester.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtSemester.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSemester.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtSemester.Location = New System.Drawing.Point(18, 326)
        Me.txtSemester.MaxLength = 40
        Me.txtSemester.Size = New System.Drawing.Size(160, 24)
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStatus.Location = New System.Drawing.Point(188, 306)
        Me.lblStatus.Size = New System.Drawing.Size(100, 18)
        Me.lblStatus.Text = "Status"
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.cmbStatus.Location = New System.Drawing.Point(188, 326)
        Me.cmbStatus.Size = New System.Drawing.Size(100, 24)
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(18, 368)
        Me.btnSave.Size = New System.Drawing.Size(130, 36)
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatAppearance.BorderSize = 0
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.btnClear.Location = New System.Drawing.Point(158, 368)
        Me.btnClear.Size = New System.Drawing.Size(130, 36)
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(239, 68, 68)
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(18, 412)
        Me.btnDelete.Size = New System.Drawing.Size(270, 34)
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        Me.tlpRight.ColumnCount = 1
        Me.tlpRight.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRight.Controls.Add(Me.pnlSchedulesCard, 0, 0)
        Me.tlpRight.Controls.Add(Me.pnlRosterCard, 0, 1)
        Me.tlpRight.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRight.Margin = New System.Windows.Forms.Padding(0)
        Me.tlpRight.RowCount = 2
        Me.tlpRight.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.0!))
        Me.tlpRight.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.0!))
        Me.pnlSchedulesCard.BackColor = System.Drawing.Color.White
        Me.pnlSchedulesCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlSchedulesCard.Controls.Add(Me.dgvSchedules)
        Me.pnlSchedulesCard.Controls.Add(Me.lblSchedulesTitle)
        Me.pnlSchedulesCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlSchedulesCard.Margin = New System.Windows.Forms.Padding(0, 0, 0, 8)
        Me.pnlSchedulesCard.Padding = New System.Windows.Forms.Padding(14)
        Me.lblSchedulesTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblSchedulesTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblSchedulesTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblSchedulesTitle.Size = New System.Drawing.Size(614, 30)
        Me.lblSchedulesTitle.Text = "Class Schedules"
        Me.dgvSchedules.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvSchedules.Name = "dgvSchedules"
        Me.pnlRosterCard.BackColor = System.Drawing.Color.White
        Me.pnlRosterCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlRosterCard.Controls.Add(Me.dgvRoster)
        Me.pnlRosterCard.Controls.Add(Me.tlpRosterBar)
        Me.pnlRosterCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlRosterCard.Margin = New System.Windows.Forms.Padding(0, 6, 0, 0)
        Me.pnlRosterCard.Padding = New System.Windows.Forms.Padding(14)
        Me.tlpRosterBar.ColumnCount = 4
        Me.tlpRosterBar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRosterBar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 230.0!))
        Me.tlpRosterBar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96.0!))
        Me.tlpRosterBar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96.0!))
        Me.tlpRosterBar.Controls.Add(Me.lblRosterTitle, 0, 0)
        Me.tlpRosterBar.Controls.Add(Me.cmbRosterStudent, 1, 0)
        Me.tlpRosterBar.Controls.Add(Me.btnAddStudent, 2, 0)
        Me.tlpRosterBar.Controls.Add(Me.btnRemoveStudent, 3, 0)
        Me.tlpRosterBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpRosterBar.RowCount = 1
        Me.tlpRosterBar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRosterBar.Size = New System.Drawing.Size(614, 38)
        Me.lblRosterTitle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblRosterTitle.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold)
        Me.lblRosterTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblRosterTitle.Text = "Class Roster"
        Me.lblRosterTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmbRosterStudent.Anchor = System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.cmbRosterStudent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRosterStudent.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmbRosterStudent.Margin = New System.Windows.Forms.Padding(4, 6, 6, 4)
        Me.btnAddStudent.Anchor = System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.btnAddStudent.BackColor = System.Drawing.Color.FromArgb(16, 185, 129)
        Me.btnAddStudent.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAddStudent.FlatAppearance.BorderSize = 0
        Me.btnAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddStudent.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.btnAddStudent.ForeColor = System.Drawing.Color.White
        Me.btnAddStudent.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnAddStudent.Size = New System.Drawing.Size(90, 29)
        Me.btnAddStudent.Text = "Enroll"
        Me.btnAddStudent.UseVisualStyleBackColor = False
        Me.btnRemoveStudent.Anchor = System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.btnRemoveStudent.BackColor = System.Drawing.Color.FromArgb(239, 68, 68)
        Me.btnRemoveStudent.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRemoveStudent.FlatAppearance.BorderSize = 0
        Me.btnRemoveStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRemoveStudent.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.btnRemoveStudent.ForeColor = System.Drawing.Color.White
        Me.btnRemoveStudent.Margin = New System.Windows.Forms.Padding(3, 4, 0, 4)
        Me.btnRemoveStudent.Size = New System.Drawing.Size(90, 29)
        Me.btnRemoveStudent.Text = "Remove"
        Me.btnRemoveStudent.UseVisualStyleBackColor = False
        Me.dgvRoster.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvRoster.Name = "dgvRoster"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.ClientSize = New System.Drawing.Size(964, 620)
        Me.Controls.Add(Me.tlpRoot)
        Me.Name = "frmSchedules"
        Me.Text = "Schedules"
        Me.tlpRoot.ResumeLayout(False)
        Me.pnlFormCard.ResumeLayout(False)
        Me.pnlFormCard.PerformLayout()
        CType(Me.nudGrace, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tlpRight.ResumeLayout(False)
        Me.pnlSchedulesCard.ResumeLayout(False)
        CType(Me.dgvSchedules, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlRosterCard.ResumeLayout(False)
        Me.tlpRosterBar.ResumeLayout(False)
        CType(Me.dgvRoster, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
