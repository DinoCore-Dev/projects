<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReports
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents tlpRoot As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlFilterCard As System.Windows.Forms.Panel
    Friend WithEvents tlpFilters As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblFrom As System.Windows.Forms.Label
    Friend WithEvents dtpFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblTo As System.Windows.Forms.Label
    Friend WithEvents dtpTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblMode As System.Windows.Forms.Label
    Friend WithEvents cmbMode As System.Windows.Forms.ComboBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents flpActions As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents btnFilter As System.Windows.Forms.Button
    Friend WithEvents btnExportCsv As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnBackupDb As System.Windows.Forms.Button
    Friend WithEvents tlpSummary As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlSum1 As System.Windows.Forms.Panel
    Friend WithEvents lblSum1Title As System.Windows.Forms.Label
    Friend WithEvents lblSumTotal As System.Windows.Forms.Label
    Friend WithEvents pnlSum2 As System.Windows.Forms.Panel
    Friend WithEvents lblSum2Title As System.Windows.Forms.Label
    Friend WithEvents lblSumPresent As System.Windows.Forms.Label
    Friend WithEvents pnlSum3 As System.Windows.Forms.Panel
    Friend WithEvents lblSum3Title As System.Windows.Forms.Label
    Friend WithEvents lblSumLate As System.Windows.Forms.Label
    Friend WithEvents pnlSum4 As System.Windows.Forms.Panel
    Friend WithEvents lblSum4Title As System.Windows.Forms.Label
    Friend WithEvents lblSumOpen As System.Windows.Forms.Label
    Friend WithEvents tabLogs As System.Windows.Forms.TabControl
    Friend WithEvents tabAttendance As System.Windows.Forms.TabPage
    Friend WithEvents dgvAttendance As System.Windows.Forms.DataGridView
    Friend WithEvents tabAudit As System.Windows.Forms.TabPage
    Friend WithEvents dgvAudit As System.Windows.Forms.DataGridView
    Friend WithEvents prtDoc As System.Drawing.Printing.PrintDocument

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpRoot = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlFilterCard = New System.Windows.Forms.Panel()
        Me.tlpFilters = New System.Windows.Forms.TableLayoutPanel()
        Me.lblFrom = New System.Windows.Forms.Label()
        Me.dtpFrom = New System.Windows.Forms.DateTimePicker()
        Me.lblTo = New System.Windows.Forms.Label()
        Me.dtpTo = New System.Windows.Forms.DateTimePicker()
        Me.lblMode = New System.Windows.Forms.Label()
        Me.cmbMode = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.flpActions = New System.Windows.Forms.FlowLayoutPanel()
        Me.btnFilter = New System.Windows.Forms.Button()
        Me.btnExportCsv = New System.Windows.Forms.Button()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnBackupDb = New System.Windows.Forms.Button()
        Me.tlpSummary = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlSum1 = New System.Windows.Forms.Panel()
        Me.lblSum1Title = New System.Windows.Forms.Label()
        Me.lblSumTotal = New System.Windows.Forms.Label()
        Me.pnlSum2 = New System.Windows.Forms.Panel()
        Me.lblSum2Title = New System.Windows.Forms.Label()
        Me.lblSumPresent = New System.Windows.Forms.Label()
        Me.pnlSum3 = New System.Windows.Forms.Panel()
        Me.lblSum3Title = New System.Windows.Forms.Label()
        Me.lblSumLate = New System.Windows.Forms.Label()
        Me.pnlSum4 = New System.Windows.Forms.Panel()
        Me.lblSum4Title = New System.Windows.Forms.Label()
        Me.lblSumOpen = New System.Windows.Forms.Label()
        Me.tabLogs = New System.Windows.Forms.TabControl()
        Me.tabAttendance = New System.Windows.Forms.TabPage()
        Me.dgvAttendance = New System.Windows.Forms.DataGridView()
        Me.tabAudit = New System.Windows.Forms.TabPage()
        Me.dgvAudit = New System.Windows.Forms.DataGridView()
        Me.prtDoc = New System.Drawing.Printing.PrintDocument()
        Me.tlpRoot.SuspendLayout()
        Me.pnlFilterCard.SuspendLayout()
        Me.tlpFilters.SuspendLayout()
        Me.flpActions.SuspendLayout()
        Me.tlpSummary.SuspendLayout()
        Me.pnlSum1.SuspendLayout()
        Me.pnlSum2.SuspendLayout()
        Me.pnlSum3.SuspendLayout()
        Me.pnlSum4.SuspendLayout()
        Me.tabLogs.SuspendLayout()
        Me.tabAttendance.SuspendLayout()
        CType(Me.dgvAttendance, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabAudit.SuspendLayout()
        CType(Me.dgvAudit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.tlpRoot.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.tlpRoot.ColumnCount = 1
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Controls.Add(Me.pnlFilterCard, 0, 0)
        Me.tlpRoot.Controls.Add(Me.tlpSummary, 0, 1)
        Me.tlpRoot.Controls.Add(Me.tabLogs, 0, 2)
        Me.tlpRoot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRoot.RowCount = 3
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 114.0!))
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 74.0!))
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Size = New System.Drawing.Size(964, 620)
        Me.pnlFilterCard.BackColor = System.Drawing.Color.White
        Me.pnlFilterCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFilterCard.Controls.Add(Me.flpActions)
        Me.pnlFilterCard.Controls.Add(Me.tlpFilters)
        Me.pnlFilterCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlFilterCard.Margin = New System.Windows.Forms.Padding(0, 0, 0, 10)
        Me.pnlFilterCard.Padding = New System.Windows.Forms.Padding(14, 8, 14, 8)
        Me.tlpFilters.ColumnCount = 5
        Me.tlpFilters.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 148.0!))
        Me.tlpFilters.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 148.0!))
        Me.tlpFilters.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 156.0!))
        Me.tlpFilters.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140.0!))
        Me.tlpFilters.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFilters.Controls.Add(Me.lblFrom, 0, 0)
        Me.tlpFilters.Controls.Add(Me.dtpFrom, 0, 1)
        Me.tlpFilters.Controls.Add(Me.lblTo, 1, 0)
        Me.tlpFilters.Controls.Add(Me.dtpTo, 1, 1)
        Me.tlpFilters.Controls.Add(Me.lblMode, 2, 0)
        Me.tlpFilters.Controls.Add(Me.cmbMode, 2, 1)
        Me.tlpFilters.Controls.Add(Me.lblStatus, 3, 0)
        Me.tlpFilters.Controls.Add(Me.cmbStatus, 3, 1)
        Me.tlpFilters.Controls.Add(Me.lblSearch, 4, 0)
        Me.tlpFilters.Controls.Add(Me.txtSearch, 4, 1)
        Me.tlpFilters.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpFilters.RowCount = 2
        Me.tlpFilters.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19.0!))
        Me.tlpFilters.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.tlpFilters.Size = New System.Drawing.Size(934, 50)
        Me.lblFrom.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.lblFrom.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblFrom.Text = "From"
        Me.dtpFrom.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtpFrom.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpFrom.Margin = New System.Windows.Forms.Padding(0, 2, 10, 2)
        Me.lblTo.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.lblTo.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblTo.Text = "To"
        Me.dtpTo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtpTo.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpTo.Margin = New System.Windows.Forms.Padding(0, 2, 10, 2)
        Me.lblMode.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.lblMode.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblMode.Text = "Mode"
        Me.cmbMode.Dock = System.Windows.Forms.DockStyle.Fill
        Me.cmbMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMode.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmbMode.Margin = New System.Windows.Forms.Padding(0, 2, 10, 2)
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStatus.Text = "Status"
        Me.cmbStatus.Dock = System.Windows.Forms.DockStyle.Fill
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cmbStatus.Margin = New System.Windows.Forms.Padding(0, 2, 10, 2)
        Me.lblSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.lblSearch.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblSearch.Text = "Student / Course"
        Me.txtSearch.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.txtSearch.Margin = New System.Windows.Forms.Padding(0, 2, 0, 2)
        Me.txtSearch.MaxLength = 60
        Me.flpActions.Controls.Add(Me.btnFilter)
        Me.flpActions.Controls.Add(Me.btnExportCsv)
        Me.flpActions.Controls.Add(Me.btnPrint)
        Me.flpActions.Controls.Add(Me.btnBackupDb)
        Me.flpActions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.flpActions.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.btnFilter.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFilter.FlatAppearance.BorderSize = 0
        Me.btnFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFilter.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnFilter.ForeColor = System.Drawing.Color.White
        Me.btnFilter.Margin = New System.Windows.Forms.Padding(0, 2, 8, 0)
        Me.btnFilter.Size = New System.Drawing.Size(96, 30)
        Me.btnFilter.Text = "Filter"
        Me.btnFilter.UseVisualStyleBackColor = False
        Me.btnExportCsv.BackColor = System.Drawing.Color.FromArgb(16, 185, 129)
        Me.btnExportCsv.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnExportCsv.FlatAppearance.BorderSize = 0
        Me.btnExportCsv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExportCsv.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnExportCsv.ForeColor = System.Drawing.Color.White
        Me.btnExportCsv.Margin = New System.Windows.Forms.Padding(0, 2, 8, 0)
        Me.btnExportCsv.Size = New System.Drawing.Size(112, 30)
        Me.btnExportCsv.Text = "Export CSV"
        Me.btnExportCsv.UseVisualStyleBackColor = False
        Me.btnPrint.BackColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPrint.FlatAppearance.BorderSize = 0
        Me.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPrint.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPrint.ForeColor = System.Drawing.Color.White
        Me.btnPrint.Margin = New System.Windows.Forms.Padding(0, 2, 8, 0)
        Me.btnPrint.Size = New System.Drawing.Size(96, 30)
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = False
        Me.btnBackupDb.BackColor = System.Drawing.Color.FromArgb(245, 158, 11)
        Me.btnBackupDb.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBackupDb.FlatAppearance.BorderSize = 0
        Me.btnBackupDb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBackupDb.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnBackupDb.ForeColor = System.Drawing.Color.White
        Me.btnBackupDb.Margin = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.btnBackupDb.Size = New System.Drawing.Size(116, 30)
        Me.btnBackupDb.Text = "Backup DB"
        Me.btnBackupDb.UseVisualStyleBackColor = False
        Me.tlpSummary.ColumnCount = 4
        Me.tlpSummary.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpSummary.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpSummary.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpSummary.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpSummary.Controls.Add(Me.pnlSum1, 0, 0)
        Me.tlpSummary.Controls.Add(Me.pnlSum2, 1, 0)
        Me.tlpSummary.Controls.Add(Me.pnlSum3, 2, 0)
        Me.tlpSummary.Controls.Add(Me.pnlSum4, 3, 0)
        Me.tlpSummary.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpSummary.Margin = New System.Windows.Forms.Padding(0, 0, 0, 10)
        Me.tlpSummary.RowCount = 1
        Me.tlpSummary.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.pnlSum1.BackColor = System.Drawing.Color.White
        Me.pnlSum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlSum1.Controls.Add(Me.lblSumTotal)
        Me.pnlSum1.Controls.Add(Me.lblSum1Title)
        Me.pnlSum1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlSum1.Margin = New System.Windows.Forms.Padding(0, 0, 8, 0)
        Me.pnlSum1.Padding = New System.Windows.Forms.Padding(12, 8, 12, 6)
        Me.lblSum1Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblSum1Title.Font = New System.Drawing.Font("Segoe UI Semibold", 8.5!, System.Drawing.FontStyle.Bold)
        Me.lblSum1Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSum1Title.Size = New System.Drawing.Size(200, 18)
        Me.lblSum1Title.Text = "TOTAL RECORDS"
        Me.lblSumTotal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSumTotal.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblSumTotal.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.lblSumTotal.Text = "0"
        Me.lblSumTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.pnlSum2.BackColor = System.Drawing.Color.White
        Me.pnlSum2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlSum2.Controls.Add(Me.lblSumPresent)
        Me.pnlSum2.Controls.Add(Me.lblSum2Title)
        Me.pnlSum2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlSum2.Margin = New System.Windows.Forms.Padding(4, 0, 8, 0)
        Me.pnlSum2.Padding = New System.Windows.Forms.Padding(12, 8, 12, 6)
        Me.lblSum2Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblSum2Title.Font = New System.Drawing.Font("Segoe UI Semibold", 8.5!, System.Drawing.FontStyle.Bold)
        Me.lblSum2Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSum2Title.Size = New System.Drawing.Size(200, 18)
        Me.lblSum2Title.Text = "PRESENT"
        Me.lblSumPresent.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSumPresent.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblSumPresent.ForeColor = System.Drawing.Color.FromArgb(16, 185, 129)
        Me.lblSumPresent.Text = "0"
        Me.lblSumPresent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.pnlSum3.BackColor = System.Drawing.Color.White
        Me.pnlSum3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlSum3.Controls.Add(Me.lblSumLate)
        Me.pnlSum3.Controls.Add(Me.lblSum3Title)
        Me.pnlSum3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlSum3.Margin = New System.Windows.Forms.Padding(4, 0, 8, 0)
        Me.pnlSum3.Padding = New System.Windows.Forms.Padding(12, 8, 12, 6)
        Me.lblSum3Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblSum3Title.Font = New System.Drawing.Font("Segoe UI Semibold", 8.5!, System.Drawing.FontStyle.Bold)
        Me.lblSum3Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSum3Title.Size = New System.Drawing.Size(200, 18)
        Me.lblSum3Title.Text = "LATE"
        Me.lblSumLate.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSumLate.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblSumLate.ForeColor = System.Drawing.Color.FromArgb(245, 158, 11)
        Me.lblSumLate.Text = "0"
        Me.lblSumLate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.pnlSum4.BackColor = System.Drawing.Color.White
        Me.pnlSum4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlSum4.Controls.Add(Me.lblSumOpen)
        Me.pnlSum4.Controls.Add(Me.lblSum4Title)
        Me.pnlSum4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlSum4.Margin = New System.Windows.Forms.Padding(4, 0, 0, 0)
        Me.pnlSum4.Padding = New System.Windows.Forms.Padding(12, 8, 12, 6)
        Me.lblSum4Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblSum4Title.Font = New System.Drawing.Font("Segoe UI Semibold", 8.5!, System.Drawing.FontStyle.Bold)
        Me.lblSum4Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSum4Title.Size = New System.Drawing.Size(200, 18)
        Me.lblSum4Title.Text = "ACTIVE IN"
        Me.lblSumOpen.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSumOpen.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblSumOpen.ForeColor = System.Drawing.Color.FromArgb(14, 165, 233)
        Me.lblSumOpen.Text = "0"
        Me.lblSumOpen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.tabLogs.Controls.Add(Me.tabAttendance)
        Me.tabLogs.Controls.Add(Me.tabAudit)
        Me.tabLogs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabLogs.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.tabLogs.Margin = New System.Windows.Forms.Padding(0)
        Me.tabAttendance.BackColor = System.Drawing.Color.White
        Me.tabAttendance.Controls.Add(Me.dgvAttendance)
        Me.tabAttendance.Padding = New System.Windows.Forms.Padding(10)
        Me.tabAttendance.Text = "Attendance Logs"
        Me.dgvAttendance.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvAttendance.Name = "dgvAttendance"
        Me.tabAudit.BackColor = System.Drawing.Color.White
        Me.tabAudit.Controls.Add(Me.dgvAudit)
        Me.tabAudit.Padding = New System.Windows.Forms.Padding(10)
        Me.tabAudit.Text = "Audit Logs"
        Me.dgvAudit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvAudit.Name = "dgvAudit"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.ClientSize = New System.Drawing.Size(964, 620)
        Me.Controls.Add(Me.tlpRoot)
        Me.Name = "frmReports"
        Me.Text = "Reports"
        Me.tlpRoot.ResumeLayout(False)
        Me.pnlFilterCard.ResumeLayout(False)
        Me.tlpFilters.ResumeLayout(False)
        Me.tlpFilters.PerformLayout()
        Me.flpActions.ResumeLayout(False)
        Me.tlpSummary.ResumeLayout(False)
        Me.pnlSum1.ResumeLayout(False)
        Me.pnlSum2.ResumeLayout(False)
        Me.pnlSum3.ResumeLayout(False)
        Me.pnlSum4.ResumeLayout(False)
        Me.tabLogs.ResumeLayout(False)
        Me.tabAttendance.ResumeLayout(False)
        CType(Me.dgvAttendance, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabAudit.ResumeLayout(False)
        CType(Me.dgvAudit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
