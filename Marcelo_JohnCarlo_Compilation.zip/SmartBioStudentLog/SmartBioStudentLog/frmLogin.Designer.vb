<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents pnlBrand As System.Windows.Forms.Panel
    Friend WithEvents pnlForm As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblUser As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents lblPass As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents chkShowPassword As System.Windows.Forms.CheckBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents btnSignIn As System.Windows.Forms.Button
    Friend WithEvents pnlDivider As System.Windows.Forms.Panel
    Friend WithEvents btnOpenKiosk As System.Windows.Forms.Button
    Friend WithEvents lblDefaultHint As System.Windows.Forms.Label
    Friend WithEvents tmrLockout As System.Windows.Forms.Timer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlBrand = New System.Windows.Forms.Panel()
        Me.pnlForm = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblPass = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.chkShowPassword = New System.Windows.Forms.CheckBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.btnSignIn = New System.Windows.Forms.Button()
        Me.pnlDivider = New System.Windows.Forms.Panel()
        Me.btnOpenKiosk = New System.Windows.Forms.Button()
        Me.lblDefaultHint = New System.Windows.Forms.Label()
        Me.tmrLockout = New System.Windows.Forms.Timer(Me.components)
        Me.pnlForm.SuspendLayout()
        Me.SuspendLayout()
        Me.pnlBrand.BackColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.pnlBrand.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlBrand.Location = New System.Drawing.Point(0, 0)
        Me.pnlBrand.Name = "pnlBrand"
        Me.pnlBrand.Size = New System.Drawing.Size(320, 460)
        Me.pnlBrand.TabIndex = 0
        Me.pnlForm.BackColor = System.Drawing.Color.White
        Me.pnlForm.Controls.Add(Me.lblTitle)
        Me.pnlForm.Controls.Add(Me.lblUser)
        Me.pnlForm.Controls.Add(Me.txtUsername)
        Me.pnlForm.Controls.Add(Me.lblPass)
        Me.pnlForm.Controls.Add(Me.txtPassword)
        Me.pnlForm.Controls.Add(Me.chkShowPassword)
        Me.pnlForm.Controls.Add(Me.lblStatus)
        Me.pnlForm.Controls.Add(Me.btnSignIn)
        Me.pnlForm.Controls.Add(Me.pnlDivider)
        Me.pnlForm.Controls.Add(Me.btnOpenKiosk)
        Me.pnlForm.Controls.Add(Me.lblDefaultHint)
        Me.pnlForm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlForm.Location = New System.Drawing.Point(320, 0)
        Me.pnlForm.Name = "pnlForm"
        Me.pnlForm.Size = New System.Drawing.Size(460, 460)
        Me.pnlForm.TabIndex = 1
        Me.lblTitle.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblTitle.Location = New System.Drawing.Point(70, 46)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(320, 36)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Sign In"
        Me.lblUser.Font = New System.Drawing.Font("Segoe UI Semibold", 9.25!, System.Drawing.FontStyle.Bold)
        Me.lblUser.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblUser.Location = New System.Drawing.Point(70, 98)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(320, 18)
        Me.lblUser.TabIndex = 1
        Me.lblUser.Text = "Username"
        Me.txtUsername.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUsername.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.txtUsername.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.txtUsername.Location = New System.Drawing.Point(70, 120)
        Me.txtUsername.MaxLength = 50
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(320, 26)
        Me.txtUsername.TabIndex = 2
        Me.txtUsername.Text = "admin"
        Me.lblPass.Font = New System.Drawing.Font("Segoe UI Semibold", 9.25!, System.Drawing.FontStyle.Bold)
        Me.lblPass.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblPass.Location = New System.Drawing.Point(70, 160)
        Me.lblPass.Name = "lblPass"
        Me.lblPass.Size = New System.Drawing.Size(320, 18)
        Me.lblPass.TabIndex = 3
        Me.lblPass.Text = "Password"
        Me.txtPassword.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPassword.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.txtPassword.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.txtPassword.Location = New System.Drawing.Point(70, 182)
        Me.txtPassword.MaxLength = 64
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(320, 26)
        Me.txtPassword.TabIndex = 4
        Me.txtPassword.Text = "admin123"
        Me.txtPassword.UseSystemPasswordChar = True
        Me.chkShowPassword.AutoSize = True
        Me.chkShowPassword.Font = New System.Drawing.Font("Segoe UI", 8.75!)
        Me.chkShowPassword.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.chkShowPassword.Location = New System.Drawing.Point(70, 216)
        Me.chkShowPassword.Name = "chkShowPassword"
        Me.chkShowPassword.Size = New System.Drawing.Size(108, 19)
        Me.chkShowPassword.TabIndex = 5
        Me.chkShowPassword.Text = "Show password"
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 8.75!, System.Drawing.FontStyle.Bold)
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(220, 38, 38)
        Me.lblStatus.Location = New System.Drawing.Point(70, 242)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(320, 22)
        Me.lblStatus.TabIndex = 6
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSignIn.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnSignIn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSignIn.FlatAppearance.BorderSize = 0
        Me.btnSignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSignIn.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnSignIn.ForeColor = System.Drawing.Color.White
        Me.btnSignIn.Location = New System.Drawing.Point(70, 272)
        Me.btnSignIn.Name = "btnSignIn"
        Me.btnSignIn.Size = New System.Drawing.Size(320, 40)
        Me.btnSignIn.TabIndex = 7
        Me.btnSignIn.Text = "Sign In"
        Me.btnSignIn.UseVisualStyleBackColor = False
        Me.pnlDivider.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.pnlDivider.Location = New System.Drawing.Point(70, 328)
        Me.pnlDivider.Name = "pnlDivider"
        Me.pnlDivider.Size = New System.Drawing.Size(320, 1)
        Me.pnlDivider.TabIndex = 8
        Me.btnOpenKiosk.BackColor = System.Drawing.Color.FromArgb(16, 185, 129)
        Me.btnOpenKiosk.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOpenKiosk.FlatAppearance.BorderSize = 0
        Me.btnOpenKiosk.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOpenKiosk.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnOpenKiosk.ForeColor = System.Drawing.Color.White
        Me.btnOpenKiosk.Location = New System.Drawing.Point(70, 344)
        Me.btnOpenKiosk.Name = "btnOpenKiosk"
        Me.btnOpenKiosk.Size = New System.Drawing.Size(320, 38)
        Me.btnOpenKiosk.TabIndex = 9
        Me.btnOpenKiosk.Text = "Attendance Kiosk"
        Me.btnOpenKiosk.UseVisualStyleBackColor = False
        Me.lblDefaultHint.Font = New System.Drawing.Font("Segoe UI", 8.5!)
        Me.lblDefaultHint.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184)
        Me.lblDefaultHint.Location = New System.Drawing.Point(70, 404)
        Me.lblDefaultHint.Name = "lblDefaultHint"
        Me.lblDefaultHint.Size = New System.Drawing.Size(320, 20)
        Me.lblDefaultHint.TabIndex = 10
        Me.lblDefaultHint.Text = "Default: admin / admin123"
        Me.lblDefaultHint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.tmrLockout.Interval = 1000
        Me.AcceptButton = Me.btnSignIn
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(780, 460)
        Me.Controls.Add(Me.pnlForm)
        Me.Controls.Add(Me.pnlBrand)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmLogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Smart Bio Student Log"
        Me.pnlForm.ResumeLayout(False)
        Me.pnlForm.PerformLayout()
        Me.ResumeLayout(False)
    End Sub
End Class
