<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTeachers
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents tlpRoot As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlFormCard As System.Windows.Forms.Panel
    Friend WithEvents lblCardTitle As System.Windows.Forms.Label
    Friend WithEvents lblEmpNo As System.Windows.Forms.Label
    Friend WithEvents txtEmployeeNo As System.Windows.Forms.TextBox
    Friend WithEvents lblFullName As System.Windows.Forms.Label
    Friend WithEvents txtFullName As System.Windows.Forms.TextBox
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblDept As System.Windows.Forms.Label
    Friend WithEvents txtDepartment As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents pnlGridCard As System.Windows.Forms.Panel
    Friend WithEvents tlpFilter As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblListTitle As System.Windows.Forms.Label
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents dgvTeachers As System.Windows.Forms.DataGridView

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tlpRoot = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlFormCard = New System.Windows.Forms.Panel()
        Me.lblCardTitle = New System.Windows.Forms.Label()
        Me.lblEmpNo = New System.Windows.Forms.Label()
        Me.txtEmployeeNo = New System.Windows.Forms.TextBox()
        Me.lblFullName = New System.Windows.Forms.Label()
        Me.txtFullName = New System.Windows.Forms.TextBox()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblDept = New System.Windows.Forms.Label()
        Me.txtDepartment = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.pnlGridCard = New System.Windows.Forms.Panel()
        Me.tlpFilter = New System.Windows.Forms.TableLayoutPanel()
        Me.lblListTitle = New System.Windows.Forms.Label()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.dgvTeachers = New System.Windows.Forms.DataGridView()
        Me.tlpRoot.SuspendLayout()
        Me.pnlFormCard.SuspendLayout()
        Me.pnlGridCard.SuspendLayout()
        Me.tlpFilter.SuspendLayout()
        CType(Me.dgvTeachers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.tlpRoot.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.tlpRoot.ColumnCount = 2
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320.0!))
        Me.tlpRoot.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Controls.Add(Me.pnlFormCard, 0, 0)
        Me.tlpRoot.Controls.Add(Me.pnlGridCard, 1, 0)
        Me.tlpRoot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRoot.RowCount = 1
        Me.tlpRoot.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpRoot.Size = New System.Drawing.Size(964, 620)
        Me.pnlFormCard.BackColor = System.Drawing.Color.White
        Me.pnlFormCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFormCard.Controls.Add(Me.lblCardTitle)
        Me.pnlFormCard.Controls.Add(Me.lblEmpNo)
        Me.pnlFormCard.Controls.Add(Me.txtEmployeeNo)
        Me.pnlFormCard.Controls.Add(Me.lblFullName)
        Me.pnlFormCard.Controls.Add(Me.txtFullName)
        Me.pnlFormCard.Controls.Add(Me.lblContact)
        Me.pnlFormCard.Controls.Add(Me.txtContact)
        Me.pnlFormCard.Controls.Add(Me.lblEmail)
        Me.pnlFormCard.Controls.Add(Me.txtEmail)
        Me.pnlFormCard.Controls.Add(Me.lblDept)
        Me.pnlFormCard.Controls.Add(Me.txtDepartment)
        Me.pnlFormCard.Controls.Add(Me.lblStatus)
        Me.pnlFormCard.Controls.Add(Me.cmbStatus)
        Me.pnlFormCard.Controls.Add(Me.btnSave)
        Me.pnlFormCard.Controls.Add(Me.btnClear)
        Me.pnlFormCard.Controls.Add(Me.btnDelete)
        Me.pnlFormCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlFormCard.Margin = New System.Windows.Forms.Padding(0, 0, 14, 0)
        Me.lblCardTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblCardTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblCardTitle.Location = New System.Drawing.Point(18, 14)
        Me.lblCardTitle.Size = New System.Drawing.Size(270, 24)
        Me.lblCardTitle.Text = "Teacher Details"
        Me.lblEmpNo.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblEmpNo.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblEmpNo.Location = New System.Drawing.Point(18, 48)
        Me.lblEmpNo.Size = New System.Drawing.Size(270, 18)
        Me.lblEmpNo.Text = "Employee No."
        Me.txtEmployeeNo.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtEmployeeNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmployeeNo.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtEmployeeNo.Location = New System.Drawing.Point(18, 68)
        Me.txtEmployeeNo.MaxLength = 25
        Me.txtEmployeeNo.Size = New System.Drawing.Size(270, 25)
        Me.lblFullName.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblFullName.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblFullName.Location = New System.Drawing.Point(18, 102)
        Me.lblFullName.Size = New System.Drawing.Size(270, 18)
        Me.lblFullName.Text = "Full Name"
        Me.txtFullName.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtFullName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFullName.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtFullName.Location = New System.Drawing.Point(18, 122)
        Me.txtFullName.MaxLength = 100
        Me.txtFullName.Size = New System.Drawing.Size(270, 25)
        Me.lblContact.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblContact.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblContact.Location = New System.Drawing.Point(18, 156)
        Me.lblContact.Size = New System.Drawing.Size(270, 18)
        Me.lblContact.Text = "Contact No."
        Me.txtContact.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtContact.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtContact.Location = New System.Drawing.Point(18, 176)
        Me.txtContact.MaxLength = 20
        Me.txtContact.Size = New System.Drawing.Size(270, 25)
        Me.lblEmail.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblEmail.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblEmail.Location = New System.Drawing.Point(18, 210)
        Me.lblEmail.Size = New System.Drawing.Size(270, 18)
        Me.lblEmail.Text = "Email"
        Me.txtEmail.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmail.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtEmail.Location = New System.Drawing.Point(18, 230)
        Me.txtEmail.MaxLength = 100
        Me.txtEmail.Size = New System.Drawing.Size(270, 25)
        Me.lblDept.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblDept.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblDept.Location = New System.Drawing.Point(18, 264)
        Me.lblDept.Size = New System.Drawing.Size(270, 18)
        Me.lblDept.Text = "Department"
        Me.txtDepartment.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtDepartment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDepartment.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.txtDepartment.Location = New System.Drawing.Point(18, 284)
        Me.txtDepartment.MaxLength = 80
        Me.txtDepartment.Size = New System.Drawing.Size(270, 25)
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblStatus.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStatus.Location = New System.Drawing.Point(18, 318)
        Me.lblStatus.Size = New System.Drawing.Size(270, 18)
        Me.lblStatus.Text = "Status"
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.cmbStatus.Location = New System.Drawing.Point(18, 338)
        Me.cmbStatus.Size = New System.Drawing.Size(270, 24)
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(18, 378)
        Me.btnSave.Size = New System.Drawing.Size(130, 36)
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatAppearance.BorderSize = 0
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.btnClear.Location = New System.Drawing.Point(158, 378)
        Me.btnClear.Size = New System.Drawing.Size(130, 36)
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(239, 68, 68)
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(18, 422)
        Me.btnDelete.Size = New System.Drawing.Size(270, 34)
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        Me.pnlGridCard.BackColor = System.Drawing.Color.White
        Me.pnlGridCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlGridCard.Controls.Add(Me.dgvTeachers)
        Me.pnlGridCard.Controls.Add(Me.tlpFilter)
        Me.pnlGridCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlGridCard.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlGridCard.Padding = New System.Windows.Forms.Padding(14)
        Me.tlpFilter.ColumnCount = 3
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.AutoSize))
        Me.tlpFilter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 210.0!))
        Me.tlpFilter.Controls.Add(Me.lblListTitle, 0, 0)
        Me.tlpFilter.Controls.Add(Me.lblSearch, 1, 0)
        Me.tlpFilter.Controls.Add(Me.txtSearch, 2, 0)
        Me.tlpFilter.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpFilter.RowCount = 1
        Me.tlpFilter.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpFilter.Size = New System.Drawing.Size(614, 42)
        Me.lblListTitle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblListTitle.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblListTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblListTitle.Text = "Faculty List"
        Me.lblListTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSearch.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSearch.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSearch.Margin = New System.Windows.Forms.Padding(6, 0, 8, 0)
        Me.lblSearch.Text = "Search"
        Me.txtSearch.Anchor = System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.txtSearch.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtSearch.MaxLength = 50
        Me.dgvTeachers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvTeachers.Name = "dgvTeachers"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.ClientSize = New System.Drawing.Size(964, 620)
        Me.Controls.Add(Me.tlpRoot)
        Me.Name = "frmTeachers"
        Me.Text = "Teachers"
        Me.tlpRoot.ResumeLayout(False)
        Me.pnlFormCard.ResumeLayout(False)
        Me.pnlFormCard.PerformLayout()
        Me.pnlGridCard.ResumeLayout(False)
        Me.tlpFilter.ResumeLayout(False)
        Me.tlpFilter.PerformLayout()
        CType(Me.dgvTeachers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
