Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Diagnostics
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.IO
Imports System.Media
Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports System.Text
Imports System.Threading
Imports System.Windows.Forms

Public Class frmBiometric
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"
    Private Const WINBIO_TYPE_FINGERPRINT As UInteger = 8UI
    Private Const WINBIO_POOL_SYSTEM As UInteger = 1UI
    Private Const WINBIO_FLAG_DEFAULT As UInteger = 0UI
    Private Const WINBIO_I_MORE_DATA As Integer = &H90001
    Private Const WINBIO_E_CANCELED As Integer = &H80098004
    Private Const WINBIO_E_CAPTURE_ABORTED As Integer = &H80098006
    Private Const WINBIO_E_ENROLLMENT_IN_PROGRESS As Integer = &H80098007
    Private Const WINBIO_E_BAD_CAPTURE As Integer = &H80098008
    Private Const WINBIO_E_DATABASE_FULL As Integer = &H80098018
    Private Const WINBIO_E_DUPLICATE_ENROLLMENT As Integer = &H8009801C
    Private Const WINBIO_E_DUPLICATE_TEMPLATE As Integer = &H8009802B
    Private Const WINBIO_E_INVALID_SUBFACTOR As Integer = &H8009804B
    Private Const E_ACCESSDENIED As Integer = &H80070005
    Private Const UNIT_SCHEMA_STRIDE As Integer = 2588

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioEnumBiometricUnits(ByVal Factor As UInteger, ByRef UnitSchemaArray As IntPtr, ByRef UnitCount As IntPtr) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioOpenSession(ByVal Factor As UInteger, ByVal PoolType As UInteger, ByVal Flags As UInteger, ByVal UnitArray As IntPtr, ByVal UnitCount As IntPtr, ByVal DatabaseId As IntPtr, ByRef SessionHandle As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioCloseSession(ByVal SessionHandle As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioCancel(ByVal SessionHandle As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioFree(ByVal Address As IntPtr) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioEnrollBegin(ByVal SessionHandle As UInteger, ByVal SubFactor As Byte, ByVal UnitId As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioEnrollCapture(ByVal SessionHandle As UInteger, ByRef RejectDetail As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioEnrollCommit(ByVal SessionHandle As UInteger, ByVal Identity As IntPtr, ByRef IsNewTemplate As Byte) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioEnrollDiscard(ByVal SessionHandle As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioIdentify(ByVal SessionHandle As UInteger, ByRef UnitId As UInteger, ByVal Identity As IntPtr, ByRef SubFactor As Byte, ByRef RejectDetail As UInteger) As Integer
    End Function

    <DllImport("winbio.dll")> _
    Private Shared Function WinBioDeleteTemplate(ByVal SessionHandle As UInteger, ByVal UnitId As UInteger, ByVal Identity As IntPtr, ByVal SubFactor As Byte) As Integer
    End Function

    Private Shared _activeInstance As frmBiometric

    Public Property LoggedAdminId As Integer = 1
    Public Property PreselectedStudentId As Integer = 0

    Private _selectedStudentId As Integer = 0
    Private _selectedStudentNo As String = ""
    Private _selectedStudentName As String = ""
    Private _hasActiveTemplate As Boolean = False
    Private _capturing As Boolean = False

    Private _wbfReady As Boolean = False
    Private _wbfUnitId As UInteger = 0UI
    Private _wbfSensorName As String = "USB Biometric Scanner"
    Private _wbfSession As UInteger = 0UI
    Private _wbfThread As Thread
    Private ReadOnly _wbfLock As New Object()

    Private _asmDev As Assembly
    Private _asmEng As Assembly
    Private _dpReady As Boolean = False
    Private _dpCapturer As Object
    Private _dpEnroller As Object

    Private Sub frmBiometric_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            _activeInstance = Me
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvStudents)

            cmbFinger.Items.Clear()
            cmbFinger.Items.AddRange(New Object() {
                "Right Index", "Right Thumb", "Right Middle", "Right Ring", "Right Little",
                "Left Index", "Left Thumb", "Left Middle", "Left Ring", "Left Little"
            })
            cmbFinger.SelectedIndex = 0

            DrawCapacitiveScannerGraphic(0, "IDLE")
            DetectConnectedScanner()
            LoadStudentBiometricGrid()

            If PreselectedStudentId > 0 Then
                SelectRowByStudentId(PreselectedStudentId)
            End If
        Catch ex As Exception
            MessageBox.Show("Failed to initialize Biometric Enrollment:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmBiometric_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        StopAllCapture()
        If _activeInstance Is Me Then _activeInstance = Nothing
    End Sub

    Private Sub frmBiometric_HandleDestroyed(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.HandleDestroyed
        StopAllCapture()
        If _activeInstance Is Me Then _activeInstance = Nothing
    End Sub

    Public Shared Sub ReleaseHardwareTemplate(ByVal templateBytes As Byte())
        If templateBytes Is Nothing OrElse templateBytes.Length < 12 Then Return
        Try
            Dim text As String = Encoding.UTF8.GetString(templateBytes)
            If Not text.StartsWith("WBFBIO1|") Then Return

            Dim parts As String() = text.Split("|"c)
            If parts.Length < 4 Then Return

            Dim savedUnit As UInteger = 0UI
            UInteger.TryParse(parts(1), savedUnit)
            Dim subFactor As Byte = 0
            If Not Byte.TryParse(parts(2), subFactor) OrElse subFactor = 0 Then Return
            Dim idBytes As Byte() = HexToBytes(parts(3))
            If idBytes Is Nothing OrElse idBytes.Length < 76 Then Return

            Dim liveUnit As UInteger = savedUnit
            Dim schemaPtr As IntPtr = IntPtr.Zero
            Dim countPtr As IntPtr = IntPtr.Zero
            Try
                If WinBioEnumBiometricUnits(WINBIO_TYPE_FINGERPRINT, schemaPtr, countPtr) = 0 AndAlso countPtr.ToInt64() > 0 Then
                    liveUnit = CUInt(Marshal.ReadInt32(schemaPtr, 0))
                End If
            Finally
                If schemaPtr <> IntPtr.Zero Then WinBioFree(schemaPtr)
            End Try
            If liveUnit = 0UI Then Return

            Dim sess As UInteger = 0UI
            Dim hr As Integer = WinBioOpenSession(WINBIO_TYPE_FINGERPRINT, WINBIO_POOL_SYSTEM, WINBIO_FLAG_DEFAULT, IntPtr.Zero, IntPtr.Zero, New IntPtr(1), sess)
            If hr <> 0 Then
                hr = WinBioOpenSession(WINBIO_TYPE_FINGERPRINT, WINBIO_POOL_SYSTEM, WINBIO_FLAG_DEFAULT, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, sess)
            End If
            If hr = 0 AndAlso sess <> 0UI Then
                Dim idPtr As IntPtr = Marshal.AllocHGlobal(80)
                Try
                    For k As Integer = 0 To 79
                        Marshal.WriteByte(idPtr, k, 0)
                    Next
                    Marshal.Copy(idBytes, 0, idPtr, 76)
                    WinBioDeleteTemplate(sess, liveUnit, idPtr, subFactor)
                Finally
                    Marshal.FreeHGlobal(idPtr)
                    WinBioCloseSession(sess)
                End Try
            End If
        Catch
        End Try
    End Sub

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try
        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 36
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 34
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.25F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub DetectConnectedScanner()
        _wbfReady = False
        _dpReady = False
        _wbfUnitId = 0UI

        Try
            Dim schemaPtr As IntPtr = IntPtr.Zero
            Dim countPtr As IntPtr = IntPtr.Zero
            Try
                Dim hr As Integer = WinBioEnumBiometricUnits(WINBIO_TYPE_FINGERPRINT, schemaPtr, countPtr)
                If hr = 0 AndAlso countPtr.ToInt64() > 0 AndAlso schemaPtr <> IntPtr.Zero Then
                    _wbfUnitId = CUInt(Marshal.ReadInt32(schemaPtr, 0))
                    Dim desc As String = Marshal.PtrToStringUni(New IntPtr(schemaPtr.ToInt64() + 532L))
                    Dim model As String = Marshal.PtrToStringUni(New IntPtr(schemaPtr.ToInt64() + 1556L))
                    Dim cleanName As String = If(Not String.IsNullOrEmpty(desc), desc.Trim(), If(Not String.IsNullOrEmpty(model), model.Trim(), "USB Capacitive Scanner"))
                    If cleanName.Length > 34 Then cleanName = cleanName.Substring(0, 34).Trim()
                    _wbfSensorName = cleanName
                    _wbfReady = True

                    lblDeviceBadge.Text = "Connected: " & _wbfSensorName
                    lblDeviceBadge.BackColor = Color.FromArgb(220, 252, 231)
                    lblDeviceBadge.ForeColor = Color.FromArgb(22, 101, 52)
                    Return
                End If
            Finally
                If schemaPtr <> IntPtr.Zero Then WinBioFree(schemaPtr)
            End Try
        Catch
        End Try

        Try
            _asmDev = TryLoadDpAssembly("DPFPDevNET")
            _asmEng = TryLoadDpAssembly("DPFPEngNET")
            If _asmDev IsNot Nothing AndAlso _asmEng IsNot Nothing Then
                Dim readersType As Type = _asmDev.GetType("DPFP.Capture.ReadersCollection")
                If readersType IsNot Nothing Then
                    Dim rc As Object = Activator.CreateInstance(readersType)
                    Dim cnt As Integer = Convert.ToInt32(readersType.GetProperty("Count").GetValue(rc, Nothing))
                    If cnt > 0 Then
                        _dpReady = True
                        lblDeviceBadge.Text = "Connected: DigitalPersona USB"
                        lblDeviceBadge.BackColor = Color.FromArgb(220, 252, 231)
                        lblDeviceBadge.ForeColor = Color.FromArgb(22, 101, 52)
                        Return
                    End If
                End If
            End If
        Catch
        End Try

        lblDeviceBadge.Text = "No USB Scanner Detected — Plug In Sensor"
        lblDeviceBadge.BackColor = Color.FromArgb(254, 226, 226)
        lblDeviceBadge.ForeColor = Color.FromArgb(185, 28, 28)
    End Sub

    Private Sub btnDetectScanner_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDetectScanner.Click
        If _capturing Then Return
        DetectConnectedScanner()
        If _wbfReady OrElse _dpReady Then
            lblScanPrompt.Text = "USB Scanner Ready"
        Else
            lblScanPrompt.Text = "Connect USB scanner & check Windows Biometrics"
        End If
    End Sub

    Private Sub ActivateHostWindow()
        Try
            Dim topForm As Form = TryCast(Me.TopLevelControl, Form)
            If topForm IsNot Nothing Then
                topForm.Activate()
            Else
                Me.Activate()
            End If
            Me.Focus()
        Catch
        End Try
    End Sub

    Private Function FingerNameToSubFactor(ByVal fingerName As String) As Byte
        Select Case fingerName
            Case "Right Thumb" : Return 1
            Case "Right Index" : Return 2
            Case "Right Middle" : Return 3
            Case "Right Ring" : Return 4
            Case "Right Little" : Return 5
            Case "Left Thumb" : Return 6
            Case "Left Index" : Return 7
            Case "Left Middle" : Return 8
            Case "Left Ring" : Return 9
            Case "Left Little" : Return 10
            Case Else : Return 2
        End Select
    End Function

    Private Function GetUsedWbfSubFactors(ByVal excludeStudentId As Integer) As HashSet(Of Byte)
        Dim used As New HashSet(Of Byte)()
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using cmd As New SqlCeCommand("SELECT studentid, template_data FROM BIOMETRIC_DATA WHERE status = 'Active'", conn)
                    Using rdr As SqlCeDataReader = cmd.ExecuteReader()
                        While rdr.Read()
                            Dim sid As Integer = Convert.ToInt32(rdr("studentid"))
                            If sid = excludeStudentId Then Continue While
                            Dim raw As Byte() = TryCast(rdr("template_data"), Byte())
                            If raw Is Nothing OrElse raw.Length < 12 Then Continue While
                            Dim s As String = Encoding.UTF8.GetString(raw)
                            If s.StartsWith("WBFBIO1|") Then
                                Dim p As String() = s.Split("|"c)
                                If p.Length >= 3 Then
                                    Dim sf As Byte = 0
                                    If Byte.TryParse(p(2), sf) AndAlso sf > 0 Then used.Add(sf)
                                End If
                            End If
                        End While
                    End Using
                End Using
            End Using
        Catch
        End Try
        Return used
    End Function

    Private Function FindExistingTemplateOwner(ByVal subFactor As Byte, ByVal idHex As String, ByVal excludeStudentId As Integer) As String
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using cmd As New SqlCeCommand( _
                    "SELECT b.studentid, b.template_data, s.student_number + ' - ' + s.last_name + ', ' + s.first_name AS owner_label " & _
                    "FROM BIOMETRIC_DATA b INNER JOIN STUDENTS s ON b.studentid = s.studentid WHERE b.status = 'Active'", conn)
                    Using rdr As SqlCeDataReader = cmd.ExecuteReader()
                        While rdr.Read()
                            Dim sid As Integer = Convert.ToInt32(rdr("studentid"))
                            If sid = excludeStudentId Then Continue While
                            Dim raw As Byte() = TryCast(rdr("template_data"), Byte())
                            If raw Is Nothing OrElse raw.Length < 12 Then Continue While
                            Dim txt As String = Encoding.UTF8.GetString(raw)
                            If txt.StartsWith("WBFBIO1|") Then
                                Dim p As String() = txt.Split("|"c)
                                If p.Length >= 4 Then
                                    Dim savedSf As Byte = 0
                                    Byte.TryParse(p(2), savedSf)
                                    If savedSf = subFactor AndAlso String.Equals(p(3), idHex, StringComparison.OrdinalIgnoreCase) Then
                                        Return Convert.ToString(rdr("owner_label"))
                                    End If
                                End If
                            End If
                        End While
                    End Using
                End Using
            End Using
        Catch
        End Try
        Return ""
    End Function

    Private Sub StartWbfCapture(ByVal preferredFinger As String, ByVal studentId As Integer)
        Dim preferredSub As Byte = FingerNameToSubFactor(preferredFinger)
        Dim usedSlots As HashSet(Of Byte) = GetUsedWbfSubFactors(studentId)

        Dim candidates As New List(Of Byte)()
        If Not usedSlots.Contains(preferredSub) Then candidates.Add(preferredSub)
        For b As Integer = &HF5 To &HFE
            Dim sb As Byte = CByte(b)
            If Not usedSlots.Contains(sb) AndAlso Not candidates.Contains(sb) Then candidates.Add(sb)
        Next
        For b As Integer = 1 To 10
            Dim sb As Byte = CByte(b)
            If Not usedSlots.Contains(sb) AndAlso Not candidates.Contains(sb) Then candidates.Add(sb)
        Next

        If candidates.Count = 0 Then
            ResetCaptureUi()
            MessageBox.Show("All hardware fingerprint slots on this Windows Biometric sensor are currently full. Revoke an unused student template first.", "Sensor Memory Full", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim unitId As UInteger = _wbfUnitId
        Dim sensorModel As String = _wbfSensorName

        _wbfThread = New Thread(Sub() RunWbfEnrollmentLoop(unitId, candidates, studentId, sensorModel))
        _wbfThread.IsBackground = True
        _wbfThread.Start()
    End Sub

    Private Sub RunWbfEnrollmentLoop(ByVal unitId As UInteger, ByVal candidates As List(Of Byte), ByVal studentId As Integer, ByVal sensorModel As String)
        Dim sess As UInteger = 0UI
        Dim enrollStarted As Boolean = False

        Try
            Dim hr As Integer = WinBioOpenSession(WINBIO_TYPE_FINGERPRINT, WINBIO_POOL_SYSTEM, WINBIO_FLAG_DEFAULT, IntPtr.Zero, IntPtr.Zero, New IntPtr(1), sess)
            If hr <> 0 Then
                hr = WinBioOpenSession(WINBIO_TYPE_FINGERPRINT, WINBIO_POOL_SYSTEM, WINBIO_FLAG_DEFAULT, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, sess)
            End If

            If hr <> 0 OrElse sess = 0UI Then
                PostEnrollError("Cannot open USB Biometric session (" & FormatWinBioHr(hr) & "). Ensure Windows Biometric Service is running.")
                Return
            End If

            SyncLock _wbfLock
                _wbfSession = sess
            End SyncLock

            If Not _capturing Then Return

            Dim chosenSub As Byte = 0
            Dim lastBeginHr As Integer = 0

            For Each cand As Byte In candidates
                If Not _capturing Then Return
                Dim bHr As Integer = WinBioEnrollBegin(sess, cand, unitId)
                If bHr = WINBIO_E_ENROLLMENT_IN_PROGRESS Then
                    WinBioEnrollDiscard(sess)
                    bHr = WinBioEnrollBegin(sess, cand, unitId)
                End If
                If bHr = 0 Then
                    chosenSub = cand
                    enrollStarted = True
                    Exit For
                End If
                lastBeginHr = bHr
                If bHr = E_ACCESSDENIED Then
                    PostEnrollAccessDenied()
                    Return
                End If
                If bHr <> WINBIO_E_DUPLICATE_ENROLLMENT AndAlso bHr <> WINBIO_E_INVALID_SUBFACTOR Then
                    Exit For
                End If
            Next

            If Not enrollStarted OrElse chosenSub = 0 Then
                If lastBeginHr = WINBIO_E_DUPLICATE_ENROLLMENT OrElse lastBeginHr = WINBIO_E_DATABASE_FULL Then
                    PostEnrollError("All sensor finger slots on this Windows account are occupied. Remove unused fingerprints in Windows Sign-in Options or revoke a template.")
                Else
                    PostEnrollError("Unable to start sensor capture (" & FormatWinBioHr(lastBeginHr) & "). Keep this window active and retry.")
                End If
                Return
            End If

            PostEnrollProgress(0, "Touch finger flat on sensor pad...")

            Dim goodTouches As Integer = 0
            While _capturing
                Dim reject As UInteger = 0UI
                Dim cHr As Integer = WinBioEnrollCapture(sess, reject)

                If cHr = WINBIO_I_MORE_DATA Then
                    goodTouches += 1
                    SystemSounds.Beep.Play()
                    PostEnrollProgress(goodTouches, "Scan " & goodTouches.ToString() & " OK — lift & touch again")
                ElseIf cHr = 0 Then
                    goodTouches += 1
                    SystemSounds.Asterisk.Play()
                    PostEnrollProgress(Math.Max(4, goodTouches), "Finalizing template...")
                    Exit While
                ElseIf cHr = WINBIO_E_BAD_CAPTURE Then
                    PostEnrollProgress(goodTouches, FormatRejectReason(reject))
                ElseIf cHr = WINBIO_E_CANCELED OrElse cHr = WINBIO_E_CAPTURE_ABORTED Then
                    WinBioEnrollDiscard(sess)
                    enrollStarted = False
                    Return
                Else
                    WinBioEnrollDiscard(sess)
                    enrollStarted = False
                    PostEnrollError("Capture interrupted (" & FormatWinBioHr(cHr) & ").")
                    Return
                End If
            End While

            If Not _capturing Then
                If enrollStarted Then WinBioEnrollDiscard(sess)
                Return
            End If

            Dim idPtr As IntPtr = Marshal.AllocHGlobal(80)
            Try
                For k As Integer = 0 To 79
                    Marshal.WriteByte(idPtr, k, 0)
                Next
                Dim isNew As Byte = 0
                Dim cmHr As Integer = WinBioEnrollCommit(sess, idPtr, isNew)
                enrollStarted = False

                If cmHr = 0 Then
                    Dim idBytes(75) As Byte
                    Marshal.Copy(idPtr, idBytes, 0, 76)
                    Dim idHex As String = BytesToHex(idBytes)

                    Dim dupOwner As String = FindExistingTemplateOwner(chosenSub, idHex, studentId)
                    If Not String.IsNullOrEmpty(dupOwner) Then
                        PostEnrollError("Duplicate fingerprint! This finger is already enrolled to " & dupOwner & ".")
                        Return
                    End If

                    Dim payload As String = "WBFBIO1|" & unitId.ToString() & "|" & chosenSub.ToString() & "|" & idHex
                    PostEnrollSuccess(Encoding.UTF8.GetBytes(payload), sensorModel)
                ElseIf cmHr = WINBIO_E_DUPLICATE_TEMPLATE Then
                    WinBioEnrollDiscard(sess)
                    PostEnrollProgress(goodTouches, "Finger exists on sensor — touch once more to verify...")

                    For k As Integer = 0 To 79
                        Marshal.WriteByte(idPtr, k, 0)
                    Next
                    Dim idUnit As UInteger = 0UI
                    Dim idSub As Byte = 0
                    Dim idRej As UInteger = 0UI
                    Dim idHr As Integer = WinBioIdentify(sess, idUnit, idPtr, idSub, idRej)

                    If idHr = 0 Then
                        Dim exBytes(75) As Byte
                        Marshal.Copy(idPtr, exBytes, 0, 76)
                        Dim exHex As String = BytesToHex(exBytes)
                        Dim existingOwner As String = FindExistingTemplateOwner(idSub, exHex, studentId)
                        If Not String.IsNullOrEmpty(existingOwner) Then
                            PostEnrollError("Duplicate Blocked: That finger is already registered to " & existingOwner & ".")
                        Else
                            Dim linkPayload As String = "WBFBIO1|" & idUnit.ToString() & "|" & idSub.ToString() & "|" & exHex
                            PostLinkExistingConfirm(Encoding.UTF8.GetBytes(linkPayload), sensorModel)
                        End If
                    Else
                        PostEnrollError("This finger is already enrolled on the sensor. Use an unenrolled finger.")
                    End If
                Else
                    WinBioEnrollDiscard(sess)
                    PostEnrollError("Could not commit fingerprint template (" & FormatWinBioHr(cmHr) & ").")
                End If
            Finally
                Marshal.FreeHGlobal(idPtr)
            End Try
        Catch ex As Exception
            PostEnrollError("Scanner error: " & ex.Message)
        Finally
            If enrollStarted AndAlso sess <> 0UI Then
                Try
                    WinBioEnrollDiscard(sess)
                Catch
                End Try
            End If
            SyncLock _wbfLock
                If _wbfSession = sess Then _wbfSession = 0UI
            End SyncLock
            If sess <> 0UI Then
                Try
                    WinBioCloseSession(sess)
                Catch
                End Try
            End If
        End Try
    End Sub

    Private Sub PostEnrollProgress(ByVal touches As Integer, ByVal promptText As String)
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          If Not _capturing Then Return
                                          Dim barVal As Integer = Math.Max(0, Math.Min(prgSamples.Maximum, touches))
                                          prgSamples.Value = barVal
                                          lblScanPrompt.Text = promptText
                                          DrawCapacitiveScannerGraphic(barVal, "SCAN")
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Sub PostEnrollAccessDenied()
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          ResetCaptureUi()
                                          lblScanPrompt.Text = "Administrator required"
                                          If MessageBox.Show("Windows Biometric Service requires Administrator privileges to enroll new fingerprints onto the USB sensor." & Environment.NewLine & Environment.NewLine & "Restart Smart Bio Student Log as Administrator now?", "Administrator Required", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                                              Try
                                                  Dim psi As New ProcessStartInfo()
                                                  psi.FileName = Application.ExecutablePath
                                                  psi.UseShellExecute = True
                                                  psi.Verb = "runas"
                                                  Process.Start(psi)
                                                  Application.Exit()
                                              Catch
                                                  MessageBox.Show("Right-click Visual Studio 2010 (or SmartBioStudentLog.exe) and choose 'Run as administrator'.", "Elevation Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                              End Try
                                          End If
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Sub PostEnrollError(ByVal errMsg As String)
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          ResetCaptureUi()
                                          lblScanPrompt.Text = "Capture stopped"
                                          MessageBox.Show(errMsg, "Biometric Scanner", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Sub PostEnrollSuccess(ByVal rawTemplate As Byte(), ByVal modelName As String)
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          SaveEnrolledTemplate(rawTemplate, modelName, "Excellent")
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Sub PostLinkExistingConfirm(ByVal rawTemplate As Byte(), ByVal modelName As String)
        If Me.IsDisposed OrElse Not Me.IsHandleCreated Then Return
        Try
            Me.BeginInvoke(New Action(Sub()
                                          If MessageBox.Show("This fingerprint is already stored in Windows Hello on this PC and is not assigned to any student." & Environment.NewLine & Environment.NewLine & "Link this fingerprint to " & _selectedStudentName & "?", "Link Existing Sensor Template", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                                              SaveEnrolledTemplate(rawTemplate, modelName, "Excellent")
                                          Else
                                              ResetCaptureUi()
                                          End If
                                      End Sub))
        Catch
        End Try
    End Sub

    Private Function FormatRejectReason(ByVal rejectCode As UInteger) As String
        Select Case rejectCode
            Case 1UI : Return "Place finger slightly lower on pad"
            Case 2UI : Return "Place finger slightly higher on pad"
            Case 3UI : Return "Move finger slightly to the right"
            Case 4UI : Return "Move finger slightly to the left"
            Case 5UI, 9UI : Return "Hold finger steady on pad longer"
            Case 6UI : Return "Lift and press finger cleanly"
            Case 7UI, 10UI : Return "Wipe sensor & press finger flat"
            Case 8UI : Return "Keep finger straight and flat"
            Case Else : Return "Try pressing finger flat on pad again"
        End Select
    End Function

    Private Function FormatWinBioHr(ByVal hr As Integer) As String
        Return "0x" & hr.ToString("X8")
    End Function

    Private Function TryLoadDpAssembly(ByVal simpleName As String) As Assembly
        Try
            Return Assembly.Load(simpleName)
        Catch
        End Try
        Dim probeDirs As String() = New String() {
            Application.StartupPath,
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "DigitalPersona\One Touch SDK\.NET\Bin"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles), "DigitalPersona\One Touch SDK\.NET\Bin"),
            "C:\Program Files (x86)\DigitalPersona\One Touch SDK\.NET\Bin"
        }
        For Each folder As String In probeDirs
            Try
                If Not String.IsNullOrEmpty(folder) AndAlso Directory.Exists(folder) Then
                    Dim dll As String = Path.Combine(folder, simpleName & ".dll")
                    If File.Exists(dll) Then Return Assembly.LoadFrom(dll)
                End If
            Catch
            End Try
        Next
        Return Nothing
    End Function

    Private Function CreateDpEventProxy(ByVal handlerInterface As Type) As Object
        Dim asmName As New AssemblyName("DpEnrollProxy_" & Guid.NewGuid().ToString("N"))
        Dim asmBuilder As AssemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(asmName, AssemblyBuilderAccess.Run)
        Dim modBuilder As ModuleBuilder = asmBuilder.DefineDynamicModule("MainMod")
        Dim tb As TypeBuilder = modBuilder.DefineType("DpProxyImpl", TypeAttributes.Public Or TypeAttributes.Class)
        tb.AddInterfaceImplementation(handlerInterface)

        Dim dispatchMi As MethodInfo = GetType(frmBiometric).GetMethod("OnDpHardwareEvent", BindingFlags.Public Or BindingFlags.Static)

        For Each mi As MethodInfo In handlerInterface.GetMethods()
            Dim pInfos As ParameterInfo() = mi.GetParameters()
            Dim pTypes(pInfos.Length - 1) As Type
            For i As Integer = 0 To pInfos.Length - 1
                pTypes(i) = pInfos(i).ParameterType
            Next

            Dim mb As MethodBuilder = tb.DefineMethod(mi.Name, MethodAttributes.Public Or MethodAttributes.Virtual Or MethodAttributes.Final Or MethodAttributes.HideBySig Or MethodAttributes.NewSlot, mi.ReturnType, pTypes)
            Dim il As ILGenerator = mb.GetILGenerator()
            il.Emit(OpCodes.Ldstr, mi.Name)
            If pTypes.Length >= 2 Then
                il.Emit(OpCodes.Ldarg_2)
                If pTypes(1).IsValueType Then il.Emit(OpCodes.Box, pTypes(1))
            Else
                il.Emit(OpCodes.Ldnull)
            End If
            If pTypes.Length >= 3 Then
                il.Emit(OpCodes.Ldarg_3)
                If pTypes(2).IsValueType Then il.Emit(OpCodes.Box, pTypes(2))
            Else
                il.Emit(OpCodes.Ldnull)
            End If
            il.Emit(OpCodes.Call, dispatchMi)
            il.Emit(OpCodes.Ret)
            tb.DefineMethodOverride(mb, mi)
        Next

        Return Activator.CreateInstance(tb.CreateType())
    End Function

    Public Shared Sub OnDpHardwareEvent(ByVal eventName As String, ByVal arg1 As Object, ByVal arg2 As Object)
        Dim inst As frmBiometric = _activeInstance
        If inst Is Nothing OrElse inst.IsDisposed Then Return
        Try
            inst.BeginInvoke(New Action(Of String, Object, Object)(AddressOf inst.HandleDpEventOnUi), eventName, arg1, arg2)
        Catch
        End Try
    End Sub

    Private Sub HandleDpEventOnUi(ByVal eventName As String, ByVal arg1 As Object, ByVal arg2 As Object)
        If Not _capturing Then Return
        If eventName = "OnComplete" AndAlso arg2 IsNot Nothing Then
            ProcessDpSample(arg2)
        End If
    End Sub

    Private Sub ProcessDpSample(ByVal sample As Object)
        Try
            Dim extractorType As Type = _asmEng.GetType("DPFP.Processing.FeatureExtraction")
            Dim purposeType As Type = _asmEng.GetType("DPFP.Processing.DataPurpose")
            Dim feedbackType As Type = _asmDev.GetType("DPFP.Capture.CaptureFeedback")
            Dim featureSetType As Type = _asmDev.GetType("DPFP.FeatureSet")

            Dim extractor As Object = Activator.CreateInstance(extractorType)
            Dim purposeEnroll As Object = [Enum].Parse(purposeType, "Enrollment")
            Dim feedback As Object = [Enum].ToObject(feedbackType, 0)
            Dim featureSet As Object = Nothing

            Dim createMi As MethodInfo = extractorType.GetMethod("CreateFeatureSet", New Type() {sample.GetType(), purposeType, feedbackType.MakeByRefType(), featureSetType.MakeByRefType()})
            If createMi Is Nothing Then Return

            Dim callArgs As Object() = New Object() {sample, purposeEnroll, feedback, featureSet}
            createMi.Invoke(extractor, callArgs)
            Dim extractedFeatures As Object = callArgs(3)

            If extractedFeatures Is Nothing Then
                lblScanPrompt.Text = "Poor quality — press finger flat again"
                Return
            End If

            Dim enrType As Type = _dpEnroller.GetType()
            enrType.GetMethod("AddFeatures").Invoke(_dpEnroller, New Object() {extractedFeatures})

            Dim needed As Integer = Convert.ToInt32(enrType.GetProperty("FeaturesNeeded").GetValue(_dpEnroller, Nothing))
            Dim captured As Integer = Math.Max(0, Math.Min(4, 4 - needed))
            prgSamples.Value = captured
            DrawCapacitiveScannerGraphic(captured, "SCAN")
            lblScanPrompt.Text = captured.ToString() & " / 4 Samples"

            Dim statusText As String = enrType.GetProperty("TemplateStatus").GetValue(_dpEnroller, Nothing).ToString()
            If statusText = "Ready" Then
                Dim tmpl As Object = enrType.GetProperty("Template").GetValue(_dpEnroller, Nothing)
                Using ms As New MemoryStream()
                    tmpl.GetType().GetMethod("Serialize", New Type() {GetType(Stream)}).Invoke(tmpl, New Object() {ms})
                    SaveEnrolledTemplate(ms.ToArray(), "DigitalPersona USB", "Excellent")
                End Using
            ElseIf statusText = "Failed" Then
                enrType.GetMethod("Clear").Invoke(_dpEnroller, Nothing)
                prgSamples.Value = 0
                lblScanPrompt.Text = "Mismatch — touch 4 times again"
            End If
        Catch ex As Exception
            ResetCaptureUi()
            MessageBox.Show("Scanner error:" & Environment.NewLine & ex.Message, "Scanner Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub StartDpCapture()
        Try
            Dim enrType As Type = _asmEng.GetType("DPFP.Processing.Enrollment")
            _dpEnroller = Activator.CreateInstance(enrType)

            Dim capType As Type = _asmDev.GetType("DPFP.Capture.Capture")
            Dim handlerIface As Type = _asmDev.GetType("DPFP.Capture.EventHandler")
            _dpCapturer = Activator.CreateInstance(capType)
            Dim proxy As Object = CreateDpEventProxy(handlerIface)
            capType.GetProperty("EventHandler").SetValue(_dpCapturer, proxy, Nothing)
            capType.GetMethod("StartCapture").Invoke(_dpCapturer, Nothing)
        Catch ex As Exception
            ResetCaptureUi()
            MessageBox.Show("Unable to start scanner:" & Environment.NewLine & ex.Message, "Scanner Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub StopAllCapture()
        _capturing = False

        Dim sessToCancel As UInteger = 0UI
        SyncLock _wbfLock
            sessToCancel = _wbfSession
        End SyncLock
        If sessToCancel <> 0UI Then
            Try
                WinBioCancel(sessToCancel)
            Catch
            End Try
        End If

        If _wbfThread IsNot Nothing AndAlso _wbfThread.IsAlive Then
            Try
                _wbfThread.Join(350)
            Catch
            End Try
        End If
        _wbfThread = Nothing

        Try
            If _dpCapturer IsNot Nothing Then
                _dpCapturer.GetType().GetMethod("StopCapture").Invoke(_dpCapturer, Nothing)
                Dim disp As IDisposable = TryCast(_dpCapturer, IDisposable)
                If disp IsNot Nothing Then disp.Dispose()
                _dpCapturer = Nothing
            End If
        Catch
        End Try
    End Sub

    Private Sub LoadStudentBiometricGrid()
        Using conn As New SqlCeConnection(ConnStr)
            conn.Open()
            Dim q As String = txtSearch.Text.Trim()
            Dim sql As String = _
                "SELECT s.studentid, s.student_number, s.last_name + ', ' + s.first_name AS full_name, s.program, s.section, " & _
                "COALESCE(b.finger_position, 'None') AS finger_position, " & _
                "CASE WHEN b.biometricid IS NULL THEN 'Unenrolled' ELSE 'Enrolled' END AS bio_status " & _
                "FROM STUDENTS s LEFT JOIN BIOMETRIC_DATA b ON s.studentid = b.studentid AND b.status = 'Active' " & _
                "WHERE s.status = 'Active'"

            Using cmd As New SqlCeCommand()
                cmd.Connection = conn
                If Not String.IsNullOrEmpty(q) Then
                    sql &= " AND (s.student_number LIKE @q OR s.last_name LIKE @q OR s.first_name LIKE @q)"
                    cmd.Parameters.AddWithValue("@q", "%" & q & "%")
                End If
                sql &= " ORDER BY s.last_name ASC, s.first_name ASC"
                cmd.CommandText = sql

                Dim dt As New DataTable()
                Using da As New SqlCeDataAdapter(cmd)
                    da.Fill(dt)
                End Using
                dgvStudents.DataSource = dt
            End Using
        End Using

        If dgvStudents.Columns.Contains("studentid") Then dgvStudents.Columns("studentid").Visible = False
        If dgvStudents.Columns.Contains("student_number") Then dgvStudents.Columns("student_number").HeaderText = "Student No."
        If dgvStudents.Columns.Contains("full_name") Then dgvStudents.Columns("full_name").HeaderText = "Full Name"
        If dgvStudents.Columns.Contains("program") Then dgvStudents.Columns("program").HeaderText = "Program"
        If dgvStudents.Columns.Contains("section") Then dgvStudents.Columns("section").HeaderText = "Section"
        If dgvStudents.Columns.Contains("finger_position") Then dgvStudents.Columns("finger_position").HeaderText = "Finger"
        If dgvStudents.Columns.Contains("bio_status") Then dgvStudents.Columns("bio_status").HeaderText = "Status"
    End Sub

    Private Sub SelectRowByStudentId(ByVal studentId As Integer)
        For Each row As DataGridViewRow In dgvStudents.Rows
            If Convert.ToInt32(row.Cells("studentid").Value) = studentId Then
                row.Selected = True
                dgvStudents.CurrentCell = row.Cells("student_number")
                ApplyCurrentRowSelection()
                Exit For
            End If
        Next
    End Sub

    Private Sub ApplyCurrentRowSelection()
        If dgvStudents.CurrentRow Is Nothing Then Return
        Dim drv As DataRowView = TryCast(dgvStudents.CurrentRow.DataBoundItem, DataRowView)
        If drv Is Nothing Then Return

        _selectedStudentId = Convert.ToInt32(drv("studentid"))
        _selectedStudentNo = Convert.ToString(drv("student_number"))
        _selectedStudentName = Convert.ToString(drv("full_name"))
        _hasActiveTemplate = (Convert.ToString(drv("bio_status")) = "Enrolled")

        lblSelectedStudent.Text = _selectedStudentNo & " — " & _selectedStudentName
        Dim fp As String = Convert.ToString(drv("finger_position"))
        If fp <> "None" AndAlso cmbFinger.Items.Contains(fp) Then
            cmbFinger.Text = fp
        End If

        ResetCaptureUi()
    End Sub

    Private Sub dgvStudents_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvStudents.CellClick
        If e.RowIndex < 0 Then Return
        ApplyCurrentRowSelection()
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearch.TextChanged
        LoadStudentBiometricGrid()
    End Sub

    Private Sub ResetCaptureUi()
        StopAllCapture()
        prgSamples.Value = 0
        btnStartEnroll.Text = "Start Capture"
        btnStartEnroll.BackColor = Color.FromArgb(37, 99, 235)
        btnDetectScanner.Enabled = True
        If _hasActiveTemplate Then
            lblScanPrompt.Text = "Active template enrolled"
            DrawCapacitiveScannerGraphic(4, "READY")
        Else
            lblScanPrompt.Text = "Ready to enroll"
            DrawCapacitiveScannerGraphic(0, "IDLE")
        End If
    End Sub

    Private Sub btnStartEnroll_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnStartEnroll.Click
        If _capturing Then
            ResetCaptureUi()
            Return
        End If

        If _selectedStudentId <= 0 Then
            MessageBox.Show("Select a student from the list first.", "No Student Selected", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        DetectConnectedScanner()
        If Not _wbfReady AndAlso Not _dpReady Then
            MessageBox.Show("No wired USB biometric fingerprint scanner was detected." & Environment.NewLine & Environment.NewLine & "1. Plug in your USB capacitive fingerprint scanner." & Environment.NewLine & "2. Confirm it appears under Device Manager > Biometric devices." & Environment.NewLine & "3. Click Detect Scanner and try again.", "USB Scanner Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        If _hasActiveTemplate Then
            If MessageBox.Show("Replace existing fingerprint template for " & _selectedStudentName & "?", "Overwrite Template", MessageBoxButtons.YesNo, MessageBoxIcon.Question) <> DialogResult.Yes Then
                Return
            End If
            ReleaseActiveStudentHardwareSlot(_selectedStudentId)
        End If

        ActivateHostWindow()
        _capturing = True
        prgSamples.Value = 0
        btnStartEnroll.Text = "Cancel"
        btnStartEnroll.BackColor = Color.FromArgb(100, 116, 139)
        btnDetectScanner.Enabled = False
        lblScanPrompt.Text = "Touch finger flat on sensor pad..."
        DrawCapacitiveScannerGraphic(0, "SCAN")

        If _wbfReady Then
            StartWbfCapture(cmbFinger.Text, _selectedStudentId)
        ElseIf _dpReady Then
            StartDpCapture()
        End If
    End Sub

    Private Sub ReleaseActiveStudentHardwareSlot(ByVal studentId As Integer)
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using cmd As New SqlCeCommand("SELECT template_data FROM BIOMETRIC_DATA WHERE studentid = @sid AND status = 'Active'", conn)
                    cmd.Parameters.AddWithValue("@sid", studentId)
                    Using rdr As SqlCeDataReader = cmd.ExecuteReader()
                        While rdr.Read()
                            Dim raw As Byte() = TryCast(rdr("template_data"), Byte())
                            If raw IsNot Nothing Then ReleaseHardwareTemplate(raw)
                        End While
                    End Using
                End Using
            End Using
        Catch
        End Try
    End Sub

    Private Sub SaveEnrolledTemplate(ByVal templateBytes As Byte(), ByVal scannerModel As String, ByVal qualityLabel As String)
        StopAllCapture()
        btnStartEnroll.Text = "Start Capture"
        btnStartEnroll.BackColor = Color.FromArgb(37, 99, 235)
        btnDetectScanner.Enabled = True

        Try
            Dim hashHex As String = ComputeBytesSha256(templateBytes)
            Dim aidObj As Object = If(LoggedAdminId > 0, CObj(LoggedAdminId), CObj(DBNull.Value))
            Dim cleanModel As String = If(String.IsNullOrEmpty(scannerModel), "USB Capacitive Scanner", scannerModel)
            If cleanModel.Length > 58 Then cleanModel = cleanModel.Substring(0, 58)

            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                Using revCmd As New SqlCeCommand("UPDATE BIOMETRIC_DATA SET status = 'Replaced' WHERE studentid = @sid AND status = 'Active'", conn)
                    revCmd.Parameters.AddWithValue("@sid", _selectedStudentId)
                    revCmd.ExecuteNonQuery()
                End Using

                Using insCmd As New SqlCeCommand("INSERT INTO BIOMETRIC_DATA (studentid, enrolled_by, biometric_type, finger_position, template_data, template_hash, sample_quality, scanner_model, status, date_captured) VALUES (@sid, @aid, 'Fingerprint', @fp, @td, @th, @sq, @sm, 'Active', @dt)", conn)
                    insCmd.Parameters.AddWithValue("@sid", _selectedStudentId)
                    insCmd.Parameters.AddWithValue("@aid", aidObj)
                    insCmd.Parameters.AddWithValue("@fp", cmbFinger.Text)
                    insCmd.Parameters.Add("@td", SqlDbType.Image, templateBytes.Length).Value = templateBytes
                    insCmd.Parameters.AddWithValue("@th", hashHex)
                    insCmd.Parameters.AddWithValue("@sq", qualityLabel)
                    insCmd.Parameters.AddWithValue("@sm", cleanModel)
                    insCmd.Parameters.AddWithValue("@dt", DateTime.Now)
                    insCmd.ExecuteNonQuery()
                End Using

                Using audCmd As New SqlCeCommand("INSERT INTO AUDIT_LOGS (adminid, action_type, module_name, record_ref, description, device_info, logged_at) VALUES (@aid, 'ENROLL_BIO', 'Biometrics', @ref, @dsc, @dev, @dt)", conn)
                    audCmd.Parameters.AddWithValue("@aid", aidObj)
                    audCmd.Parameters.AddWithValue("@ref", _selectedStudentNo)
                    audCmd.Parameters.AddWithValue("@dsc", "Enrolled " & cmbFinger.Text & " for " & _selectedStudentName)
                    audCmd.Parameters.AddWithValue("@dev", cleanModel)
                    audCmd.Parameters.AddWithValue("@dt", DateTime.Now)
                    audCmd.ExecuteNonQuery()
                End Using
            End Using

            _hasActiveTemplate = True
            prgSamples.Value = prgSamples.Maximum
            DrawCapacitiveScannerGraphic(4, "READY")
            lblScanPrompt.Text = "Enrolled Successfully"
            Dim keepId As Integer = _selectedStudentId
            LoadStudentBiometricGrid()
            SelectRowByStudentId(keepId)
            MessageBox.Show("Fingerprint enrolled for " & _selectedStudentName & ".", "Enrollment Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Failed to save biometric template:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnRevoke_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRevoke.Click
        If _capturing Then
            MessageBox.Show("Cancel the active capture first.", "Capture Active", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        If _selectedStudentId <= 0 Then
            MessageBox.Show("Select a student first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        If Not _hasActiveTemplate Then
            MessageBox.Show("Selected student has no active fingerprint template.", "Nothing to Revoke", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        If MessageBox.Show("Revoke active fingerprint template for " & _selectedStudentName & "?", "Confirm Revoke", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) <> DialogResult.Yes Then
            Return
        End If

        Try
            ReleaseActiveStudentHardwareSlot(_selectedStudentId)
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using cmd As New SqlCeCommand("UPDATE BIOMETRIC_DATA SET status = 'Revoked' WHERE studentid = @sid AND status = 'Active'", conn)
                    cmd.Parameters.AddWithValue("@sid", _selectedStudentId)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            Dim keepId As Integer = _selectedStudentId
            LoadStudentBiometricGrid()
            SelectRowByStudentId(keepId)
            MessageBox.Show("Biometric template revoked and cleared from scanner.", "Revoked", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Revoke error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Shared Function BytesToHex(ByVal data As Byte()) As String
        Dim sb As New StringBuilder(data.Length * 2)
        For Each b As Byte In data
            sb.Append(b.ToString("X2"))
        Next
        Return sb.ToString()
    End Function

    Private Shared Function HexToBytes(ByVal hex As String) As Byte()
        If String.IsNullOrEmpty(hex) OrElse (hex.Length Mod 2) <> 0 Then Return Nothing
        Dim out((hex.Length \ 2) - 1) As Byte
        For i As Integer = 0 To out.Length - 1
            out(i) = Convert.ToByte(hex.Substring(i * 2, 2), 16)
        Next
        Return out
    End Function

    Private Function ComputeBytesSha256(ByVal data As Byte()) As String
        Using sha As SHA256 = SHA256.Create()
            Dim hash As Byte() = sha.ComputeHash(data)
            Dim sb As New StringBuilder()
            For Each b As Byte In hash
                sb.Append(b.ToString("x2"))
            Next
            Return sb.ToString()
        End Using
    End Function

    Private Sub DrawCapacitiveScannerGraphic(ByVal progressCount As Integer, ByVal state As String)
        Dim bmp As New Bitmap(200, 210)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.SmoothingMode = SmoothingMode.AntiAlias
            g.Clear(Color.FromArgb(241, 245, 249))

            Using cablePen As New Pen(Color.FromArgb(30, 41, 59), 6.0F)
                g.DrawLine(cablePen, 100, 0, 100, 22)
            End Using

            Dim bodyRect As New Rectangle(42, 18, 116, 162)
            Using bodyBrush As New LinearGradientBrush(bodyRect, Color.FromArgb(232, 232, 228), Color.FromArgb(196, 198, 194), LinearGradientMode.Vertical)
                FillRoundedRect(g, bodyBrush, bodyRect, 18)
            End Using
            Using borderPen As New Pen(Color.FromArgb(160, 164, 168), 1.5F)
                DrawRoundedRect(g, borderPen, bodyRect, 18)
            End Using

            Using lockPen As New Pen(Color.FromArgb(71, 85, 105), 1.8F), lockBrush As New SolidBrush(Color.FromArgb(71, 85, 105))
                g.DrawArc(lockPen, 95, 31, 10, 10, 180, 180)
                g.FillRectangle(lockBrush, 93, 36, 14, 10)
            End Using

            Dim grooveRect As New Rectangle(66, 56, 68, 106)
            Using grooveBrush As New LinearGradientBrush(grooveRect, Color.FromArgb(182, 184, 180), Color.FromArgb(220, 222, 218), LinearGradientMode.Vertical)
                FillRoundedRect(g, grooveBrush, grooveRect, 28)
            End Using

            Dim padRect As New Rectangle(76, 80, 48, 48)
            Using padBrush As New SolidBrush(Color.FromArgb(15, 23, 42))
                FillRoundedRect(g, padBrush, padRect, 5)
            End Using

            Dim glowColor As Color = Color.FromArgb(100, 116, 139)
            If state = "SCAN" Then glowColor = Color.FromArgb(56, 189, 248)
            If state = "READY" Then glowColor = Color.FromArgb(34, 197, 94)

            Using glowPen As New Pen(glowColor, 2.2F)
                DrawRoundedRect(g, glowPen, padRect, 5)
            End Using

            For i As Integer = 1 To 3
                Dim rPad As Integer = i * 6
                Dim ridgeActive As Boolean = (progressCount >= i) OrElse (state = "READY")
                Dim rc As Color = If(ridgeActive, glowColor, Color.FromArgb(51, 65, 85))
                Using rp As New Pen(rc, 1.6F)
                    g.DrawArc(rp, 100 - rPad, 104 - rPad, rPad * 2, rPad * 2, 200, 140)
                    g.DrawArc(rp, 100 - rPad, 104 - rPad + 4, rPad * 2, rPad * 2, 20, 140)
                End Using
            Next

            Using f As New Font("Segoe UI Semibold", 8.25F, FontStyle.Bold), br As New SolidBrush(Color.FromArgb(51, 65, 85))
                Dim caption As String = "STANDBY"
                If state = "SCAN" Then caption = "TOUCH SENSOR PAD"
                If state = "READY" Then caption = "TEMPLATE ENROLLED"
                Dim sf As New StringFormat()
                sf.Alignment = StringAlignment.Center
                g.DrawString(caption, f, br, New RectangleF(0, 186, 200, 20), sf)
            End Using
        End Using

        If picFinger.Image IsNot Nothing Then picFinger.Image.Dispose()
        picFinger.Image = bmp
    End Sub

    Private Sub FillRoundedRect(ByVal g As Graphics, ByVal br As Brush, ByVal r As Rectangle, ByVal rad As Integer)
        Using gp As New GraphicsPath()
            Dim d As Integer = rad * 2
            gp.AddArc(r.X, r.Y, d, d, 180, 90)
            gp.AddArc(r.Right - d, r.Y, d, d, 270, 90)
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90)
            gp.AddArc(r.X, r.Bottom - d, d, d, 90, 90)
            gp.CloseFigure()
            g.FillPath(br, gp)
        End Using
    End Sub

    Private Sub DrawRoundedRect(ByVal g As Graphics, ByVal p As Pen, ByVal r As Rectangle, ByVal rad As Integer)
        Using gp As New GraphicsPath()
            Dim d As Integer = rad * 2
            gp.AddArc(r.X, r.Y, d, d, 180, 90)
            gp.AddArc(r.Right - d, r.Y, d, d, 270, 90)
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90)
            gp.AddArc(r.X, r.Bottom - d, d, d, 90, 90)
            gp.CloseFigure()
            g.DrawPath(p, gp)
        End Using
    End Sub
End Class
