Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("Smart Bio Student Log")> 
<Assembly: AssemblyDescription("Smart Biometric Student Attendance & Logging System (SQL Server Compact 3.5 + Wired USB Biometric Scanner)")> 
<Assembly: AssemblyCompany("Smart Bio Academic Systems")> 
<Assembly: AssemblyProduct("SmartBioStudentLog")> 
<Assembly: AssemblyCopyright("Copyright © 2026")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 
<Assembly: Guid("3d8e6a14-92b1-48c7-8f19-6c40b21a2010")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
