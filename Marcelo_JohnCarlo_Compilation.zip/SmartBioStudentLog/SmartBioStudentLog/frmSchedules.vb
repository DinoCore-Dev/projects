Option Explicit On

Imports System.Data
Imports System.Data.SqlServerCe
Imports System.Drawing
Imports System.Reflection
Imports System.Windows.Forms

Public Class frmSchedules
    Private Const ConnStr As String = "Data Source=|DataDirectory|\SmartBioStudentLog.sdf;Max Database Size=256;Persist Security Info=False;"

    Public Property LoggedAdminId As Integer = 1
    Private _selectedScheduleId As Integer = 0

    Private Sub frmSchedules_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Try
            frmLogin.EnsureDatabaseReady()
            StyleGrid(dgvSchedules)
            StyleGrid(dgvRoster)

            cmbDays.Items.Clear()
            cmbDays.Items.AddRange(New Object() {"Daily", "Mon/Wed/Fri", "Tue/Thu", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"})
            cmbDays.SelectedIndex = 0

            cmbStatus.Items.Clear()
            cmbStatus.Items.AddRange(New Object() {"Active", "Closed"})
            cmbStatus.SelectedIndex = 0

            dtpStart.Value = DateTime.Today.AddHours(8)
            dtpEnd.Value = DateTime.Today.AddHours(9).AddMinutes(30)
            txtSection.Text = "BSIT 3A"
            txtRoom.Text = "CompLab 1"
            txtSemester.Text = "1st Sem 2026-2027"

            LoadLookups()
            LoadSchedules()
            LoadRoster()
        Catch ex As Exception
            MessageBox.Show("Failed to initialize Schedules:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub StyleGrid(ByVal dgv As DataGridView)
        Try
            Dim pi As PropertyInfo = dgv.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
            If pi IsNot Nothing Then pi.SetValue(dgv, True, Nothing)
        Catch
        End Try
        dgv.BackgroundColor = Color.White
        dgv.BorderStyle = BorderStyle.None
        dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgv.GridColor = Color.FromArgb(226, 232, 240)
        dgv.EnableHeadersVisualStyles = False
        dgv.RowHeadersVisible = False
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgv.MultiSelect = False
        dgv.AllowUserToAddRows = False
        dgv.AllowUserToDeleteRows = False
        dgv.AllowUserToResizeRows = False
        dgv.ReadOnly = True
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        dgv.ColumnHeadersHeight = 35
        dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59)
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        dgv.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI Semibold", 9.0F, FontStyle.Bold)
        dgv.ColumnHeadersDefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.RowTemplate.Height = 32
        dgv.DefaultCellStyle.BackColor = Color.White
        dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42)
        dgv.DefaultCellStyle.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular)
        dgv.DefaultCellStyle.Padding = New Padding(8, 0, 8, 0)
        dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254)
        dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138)
        dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252)
    End Sub

    Private Sub LoadLookups()
        Using conn As New SqlCeConnection(ConnStr)
            conn.Open()

            Dim dtCourses As New DataTable()
            Using daC As New SqlCeDataAdapter("SELECT courseid, course_code + ' - ' + course_name AS display_text FROM COURSES WHERE status = 'Active' ORDER BY course_code ASC", conn)
                daC.Fill(dtCourses)
            End Using
            cmbCourse.DataSource = dtCourses
            cmbCourse.ValueMember = "courseid"
            cmbCourse.DisplayMember = "display_text"

            Dim dtTeachers As New DataTable()
            Using daT As New SqlCeDataAdapter("SELECT teacherid, full_name FROM TEACHERS WHERE status = 'Active' ORDER BY full_name ASC", conn)
                daT.Fill(dtTeachers)
            End Using
            cmbTeacher.DataSource = dtTeachers
            cmbTeacher.ValueMember = "teacherid"
            cmbTeacher.DisplayMember = "full_name"

            Dim dtStuds As New DataTable()
            Using daS As New SqlCeDataAdapter("SELECT studentid, student_number + ' - ' + last_name + ', ' + first_name AS display_text FROM STUDENTS WHERE status = 'Active' ORDER BY last_name ASC", conn)
                daS.Fill(dtStuds)
            End Using
            cmbRosterStudent.DataSource = dtStuds
            cmbRosterStudent.ValueMember = "studentid"
            cmbRosterStudent.DisplayMember = "display_text"
        End Using
    End Sub

    Private Sub LoadSchedules()
        Using conn As New SqlCeConnection(ConnStr)
            conn.Open()
            Dim dt As New DataTable()
            Using da As New SqlCeDataAdapter( _
                "SELECT sc.scheduleid, sc.courseid, sc.teacherid, c.course_code, t.full_name AS teacher_name, " & _
                "sc.section, sc.day_of_week, sc.time_start, sc.time_end, sc.room, sc.grace_minutes, sc.semester, sc.status " & _
                "FROM SCHEDULES sc INNER JOIN COURSES c ON sc.courseid = c.courseid " & _
                "INNER JOIN TEACHERS t ON sc.teacherid = t.teacherid ORDER BY sc.time_start ASC", conn)
                da.Fill(dt)
            End Using
            dgvSchedules.DataSource = dt
        End Using

        Dim hideCols As String() = New String() {"scheduleid", "courseid", "teacherid", "semester"}
        For Each col As String In hideCols
            If dgvSchedules.Columns.Contains(col) Then dgvSchedules.Columns(col).Visible = False
        Next
        If dgvSchedules.Columns.Contains("course_code") Then dgvSchedules.Columns("course_code").HeaderText = "Course"
        If dgvSchedules.Columns.Contains("teacher_name") Then dgvSchedules.Columns("teacher_name").HeaderText = "Teacher"
        If dgvSchedules.Columns.Contains("section") Then dgvSchedules.Columns("section").HeaderText = "Section"
        If dgvSchedules.Columns.Contains("day_of_week") Then dgvSchedules.Columns("day_of_week").HeaderText = "Days"
        If dgvSchedules.Columns.Contains("time_start") Then dgvSchedules.Columns("time_start").HeaderText = "Start"
        If dgvSchedules.Columns.Contains("time_end") Then dgvSchedules.Columns("time_end").HeaderText = "End"
        If dgvSchedules.Columns.Contains("room") Then dgvSchedules.Columns("room").HeaderText = "Room"
        If dgvSchedules.Columns.Contains("grace_minutes") Then dgvSchedules.Columns("grace_minutes").HeaderText = "Grace"
        If dgvSchedules.Columns.Contains("status") Then dgvSchedules.Columns("status").HeaderText = "Status"
    End Sub

    Private Sub LoadRoster()
        If _selectedScheduleId <= 0 Then
            dgvRoster.DataSource = Nothing
            lblRosterTitle.Text = "Class Roster"
            Return
        End If

        Using conn As New SqlCeConnection(ConnStr)
            conn.Open()
            Dim dt As New DataTable()
            Using cmd As New SqlCeCommand( _
                "SELECT ce.enrollmentid, s.student_number AS [Student No.], s.last_name + ', ' + s.first_name AS [Full Name], " & _
                "s.program AS [Program], s.year_level AS [Year], s.section AS [Section] " & _
                "FROM CLASS_ENROLLMENTS ce INNER JOIN STUDENTS s ON ce.studentid = s.studentid " & _
                "WHERE ce.scheduleid = @scid AND ce.status = 'Enrolled' ORDER BY s.last_name ASC", conn)
                cmd.Parameters.AddWithValue("@scid", _selectedScheduleId)
                Using da As New SqlCeDataAdapter(cmd)
                    da.Fill(dt)
                End Using
            End Using
            dgvRoster.DataSource = dt
            If dgvRoster.Columns.Contains("enrollmentid") Then dgvRoster.Columns("enrollmentid").Visible = False
        End Using
    End Sub

    Private Function ParseTimeMins(ByVal hhmm As String) As Integer
        If String.IsNullOrEmpty(hhmm) Then Return -1
        Dim p As String() = hhmm.Split(":"c)
        If p.Length < 2 Then Return -1
        Dim h As Integer = 0
        Dim m As Integer = 0
        If Integer.TryParse(p(0), h) AndAlso Integer.TryParse(p(1), m) Then Return h * 60 + m
        Return -1
    End Function

    Private Function MatchesDay(ByVal pattern As String, ByVal d As DateTime) As Boolean
        Dim u As String = If(pattern, "").ToUpperInvariant()
        If u = "DAILY" Then Return d.DayOfWeek <> DayOfWeek.Sunday
        Select Case d.DayOfWeek
            Case DayOfWeek.Monday : Return u.Contains("MON")
            Case DayOfWeek.Tuesday : Return u.Contains("TUE")
            Case DayOfWeek.Wednesday : Return u.Contains("WED")
            Case DayOfWeek.Thursday : Return u.Contains("THU")
            Case DayOfWeek.Friday : Return u.Contains("FRI")
            Case DayOfWeek.Saturday : Return u.Contains("SAT")
            Case DayOfWeek.Sunday : Return u.Contains("SUN")
        End Select
        Return False
    End Function

    Private Function DaysOverlap(ByVal d1 As String, ByVal d2 As String) As Boolean
        Dim refMon As New DateTime(2026, 10, 19)
        For i As Integer = 0 To 6
            Dim dt As DateTime = refMon.AddDays(i)
            If MatchesDay(d1, dt) AndAlso MatchesDay(d2, dt) Then Return True
        Next
        Return False
    End Function

    Private Sub dgvSchedules_CellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvSchedules.CellClick
        If e.RowIndex < 0 OrElse dgvSchedules.CurrentRow Is Nothing Then Return
        Try
            Dim drv As DataRowView = TryCast(dgvSchedules.CurrentRow.DataBoundItem, DataRowView)
            If drv Is Nothing Then Return

            _selectedScheduleId = Convert.ToInt32(drv("scheduleid"))
            cmbCourse.SelectedValue = Convert.ToInt32(drv("courseid"))
            cmbTeacher.SelectedValue = Convert.ToInt32(drv("teacherid"))
            txtSection.Text = Convert.ToString(drv("section"))
            cmbDays.Text = Convert.ToString(drv("day_of_week"))

            Dim stM As Integer = ParseTimeMins(Convert.ToString(drv("time_start")))
            Dim enM As Integer = ParseTimeMins(Convert.ToString(drv("time_end")))
            If stM >= 0 Then dtpStart.Value = DateTime.Today.AddMinutes(stM)
            If enM >= 0 Then dtpEnd.Value = DateTime.Today.AddMinutes(enM)

            txtRoom.Text = If(IsDBNull(drv("room")), "", Convert.ToString(drv("room")))
            nudGrace.Value = Math.Max(0, Math.Min(60, Convert.ToInt32(drv("grace_minutes"))))
            txtSemester.Text = If(IsDBNull(drv("semester")), "", Convert.ToString(drv("semester")))
            cmbStatus.Text = Convert.ToString(drv("status"))
            btnSave.Text = "Update"

            lblRosterTitle.Text = "Roster — " & Convert.ToString(drv("course_code")) & " (" & Convert.ToString(drv("section")) & ")"
            LoadRoster()
        Catch ex As Exception
            MessageBox.Show("Selection error:" & Environment.NewLine & ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub ClearInputs()
        _selectedScheduleId = 0
        txtSection.Text = "BSIT 3A"
        If cmbDays.Items.Count > 0 Then cmbDays.SelectedIndex = 0
        dtpStart.Value = DateTime.Today.AddHours(8)
        dtpEnd.Value = DateTime.Today.AddHours(9).AddMinutes(30)
        txtRoom.Text = "CompLab 1"
        nudGrace.Value = 15
        If cmbStatus.Items.Count > 0 Then cmbStatus.SelectedIndex = 0
        btnSave.Text = "Save"
        dgvSchedules.ClearSelection()
        LoadRoster()
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ClearInputs()
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        If cmbCourse.SelectedValue Is Nothing Then
            MessageBox.Show("Add an active Course first.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        If cmbTeacher.SelectedValue Is Nothing Then
            MessageBox.Show("Add an active Teacher first.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim sec As String = txtSection.Text.Trim()
        Dim rm As String = txtRoom.Text.Trim()
        Dim sem As String = txtSemester.Text.Trim()
        Dim ts As String = dtpStart.Value.ToString("HH:mm")
        Dim te As String = dtpEnd.Value.ToString("HH:mm")

        If String.IsNullOrEmpty(sec) Then
            MessageBox.Show("Section is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtSection.Focus()
            Return
        End If
        If String.IsNullOrEmpty(rm) Then
            MessageBox.Show("Room is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtRoom.Focus()
            Return
        End If

        Dim newStart As Integer = ParseTimeMins(ts)
        Dim newEnd As Integer = ParseTimeMins(te)
        If newEnd - newStart < 30 Then
            MessageBox.Show("End Time must be at least 30 minutes after Start Time.", "Invalid Time Range", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            dtpEnd.Focus()
            Return
        End If

        Dim cid As Integer = Convert.ToInt32(cmbCourse.SelectedValue)
        Dim tid As Integer = Convert.ToInt32(cmbTeacher.SelectedValue)
        Dim dayPat As String = cmbDays.Text

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()

                If cmbStatus.Text = "Active" Then
                    Dim dtActive As New DataTable()
                    Using da As New SqlCeDataAdapter( _
                        "SELECT sc.scheduleid, sc.teacherid, sc.room, sc.day_of_week, sc.time_start, sc.time_end, c.course_code, t.full_name " & _
                        "FROM SCHEDULES sc INNER JOIN COURSES c ON sc.courseid = c.courseid " & _
                        "INNER JOIN TEACHERS t ON sc.teacherid = t.teacherid WHERE sc.status = 'Active'", conn)
                        da.Fill(dtActive)
                    End Using

                    For Each r As DataRow In dtActive.Rows
                        Dim exId As Integer = Convert.ToInt32(r("scheduleid"))
                        If exId = _selectedScheduleId Then Continue For

                        Dim exDays As String = Convert.ToString(r("day_of_week"))
                        If DaysOverlap(dayPat, exDays) Then
                            Dim exStart As Integer = ParseTimeMins(Convert.ToString(r("time_start")))
                            Dim exEnd As Integer = ParseTimeMins(Convert.ToString(r("time_end")))
                            If newStart < exEnd AndAlso newEnd > exStart Then
                                If Convert.ToInt32(r("teacherid")) = tid Then
                                    MessageBox.Show("Teacher conflict with " & Convert.ToString(r("course_code")) & " (" & Convert.ToString(r("time_start")) & "-" & Convert.ToString(r("time_end")) & ").", "Schedule Conflict", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                    Return
                                End If
                                If String.Equals(Convert.ToString(r("room")).Trim(), rm, StringComparison.OrdinalIgnoreCase) Then
                                    MessageBox.Show("Room '" & rm & "' is occupied by " & Convert.ToString(r("course_code")) & " (" & Convert.ToString(r("time_start")) & "-" & Convert.ToString(r("time_end")) & ").", "Room Conflict", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                    Return
                                End If
                            End If
                        End If
                    Next
                End If

                If _selectedScheduleId = 0 Then
                    Using cmd As New SqlCeCommand("INSERT INTO SCHEDULES (courseid, teacherid, section, day_of_week, time_start, time_end, room, grace_minutes, semester, status) VALUES (@cid, @tid, @sec, @dow, @ts, @te, @rm, @gr, @sem, @st)", conn)
                        cmd.Parameters.AddWithValue("@cid", cid)
                        cmd.Parameters.AddWithValue("@tid", tid)
                        cmd.Parameters.AddWithValue("@sec", sec)
                        cmd.Parameters.AddWithValue("@dow", dayPat)
                        cmd.Parameters.AddWithValue("@ts", ts)
                        cmd.Parameters.AddWithValue("@te", te)
                        cmd.Parameters.AddWithValue("@rm", rm)
                        cmd.Parameters.AddWithValue("@gr", Convert.ToInt32(nudGrace.Value))
                        cmd.Parameters.AddWithValue("@sem", sem)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.ExecuteNonQuery()
                    End Using
                    MessageBox.Show("Schedule saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    Using cmd As New SqlCeCommand("UPDATE SCHEDULES SET courseid=@cid, teacherid=@tid, section=@sec, day_of_week=@dow, time_start=@ts, time_end=@te, room=@rm, grace_minutes=@gr, semester=@sem, status=@st WHERE scheduleid=@id", conn)
                        cmd.Parameters.AddWithValue("@cid", cid)
                        cmd.Parameters.AddWithValue("@tid", tid)
                        cmd.Parameters.AddWithValue("@sec", sec)
                        cmd.Parameters.AddWithValue("@dow", dayPat)
                        cmd.Parameters.AddWithValue("@ts", ts)
                        cmd.Parameters.AddWithValue("@te", te)
                        cmd.Parameters.AddWithValue("@rm", rm)
                        cmd.Parameters.AddWithValue("@gr", Convert.ToInt32(nudGrace.Value))
                        cmd.Parameters.AddWithValue("@sem", sem)
                        cmd.Parameters.AddWithValue("@st", cmbStatus.Text)
                        cmd.Parameters.AddWithValue("@id", _selectedScheduleId)
                        cmd.ExecuteNonQuery()
                    End Using
                    MessageBox.Show("Schedule updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using

            LoadSchedules()
        Catch ex As Exception
            MessageBox.Show("Error saving schedule:" & Environment.NewLine & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click
        If _selectedScheduleId <= 0 Then
            MessageBox.Show("Select a schedule from the list first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using chkCmd As New SqlCeCommand("SELECT COUNT(*) FROM ATTENDANCE_LOGS WHERE scheduleid = @id", conn)
                    chkCmd.Parameters.AddWithValue("@id", _selectedScheduleId)
                    If Convert.ToInt32(chkCmd.ExecuteScalar()) > 0 Then
                        If MessageBox.Show("This schedule has attendance records. Set status to Closed instead?", "Schedule In Use", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                            Using upCmd As New SqlCeCommand("UPDATE SCHEDULES SET status = 'Closed' WHERE scheduleid = @id", conn)
                                upCmd.Parameters.AddWithValue("@id", _selectedScheduleId)
                                upCmd.ExecuteNonQuery()
                            End Using
                            ClearInputs()
                            LoadSchedules()
                        End If
                        Return
                    End If
                End Using

                If MessageBox.Show("Delete selected schedule?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
                    Using delCmd As New SqlCeCommand("DELETE FROM SCHEDULES WHERE scheduleid = @id", conn)
                        delCmd.Parameters.AddWithValue("@id", _selectedScheduleId)
                        delCmd.ExecuteNonQuery()
                    End Using
                    ClearInputs()
                    LoadSchedules()
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Delete error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnAddStudent_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddStudent.Click
        If _selectedScheduleId <= 0 Then
            MessageBox.Show("Select a class schedule first.", "No Schedule Selected", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        If cmbRosterStudent.SelectedValue Is Nothing Then
            MessageBox.Show("No active students available.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim sid As Integer = Convert.ToInt32(cmbRosterStudent.SelectedValue)
        Try
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using chkCmd As New SqlCeCommand("SELECT COUNT(*) FROM CLASS_ENROLLMENTS WHERE studentid = @sid AND scheduleid = @scid AND status = 'Enrolled'", conn)
                    chkCmd.Parameters.AddWithValue("@sid", sid)
                    chkCmd.Parameters.AddWithValue("@scid", _selectedScheduleId)
                    If Convert.ToInt32(chkCmd.ExecuteScalar()) > 0 Then
                        MessageBox.Show("Student is already enrolled in this schedule.", "Duplicate Enrollment", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Return
                    End If
                End Using

                Using insCmd As New SqlCeCommand("INSERT INTO CLASS_ENROLLMENTS (studentid, scheduleid, date_enrolled, status) VALUES (@sid, @scid, @dt, 'Enrolled')", conn)
                    insCmd.Parameters.AddWithValue("@sid", sid)
                    insCmd.Parameters.AddWithValue("@scid", _selectedScheduleId)
                    insCmd.Parameters.AddWithValue("@dt", DateTime.Now)
                    insCmd.ExecuteNonQuery()
                End Using
            End Using
            LoadRoster()
        Catch ex As Exception
            MessageBox.Show("Enrollment error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnRemoveStudent_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnRemoveStudent.Click
        If dgvRoster.CurrentRow Is Nothing Then
            MessageBox.Show("Select a student from the roster first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        Try
            Dim eid As Integer = Convert.ToInt32(dgvRoster.CurrentRow.Cells("enrollmentid").Value)
            Using conn As New SqlCeConnection(ConnStr)
                conn.Open()
                Using delCmd As New SqlCeCommand("DELETE FROM CLASS_ENROLLMENTS WHERE enrollmentid = @id", conn)
                    delCmd.Parameters.AddWithValue("@id", eid)
                    delCmd.ExecuteNonQuery()
                End Using
            End Using
            LoadRoster()
        Catch ex As Exception
            MessageBox.Show("Remove error:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
