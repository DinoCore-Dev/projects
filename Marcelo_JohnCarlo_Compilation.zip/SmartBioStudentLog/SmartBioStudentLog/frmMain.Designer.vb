<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents pnlSidebar As System.Windows.Forms.Panel
    Friend WithEvents pnlBrandTop As System.Windows.Forms.Panel
    Friend WithEvents lblBrandTitle As System.Windows.Forms.Label
    Friend WithEvents lblBrandSub As System.Windows.Forms.Label
    Friend WithEvents btnNavDashboard As System.Windows.Forms.Button
    Friend WithEvents btnNavKiosk As System.Windows.Forms.Button
    Friend WithEvents btnNavStudents As System.Windows.Forms.Button
    Friend WithEvents btnNavBiometric As System.Windows.Forms.Button
    Friend WithEvents btnNavCourses As System.Windows.Forms.Button
    Friend WithEvents btnNavTeachers As System.Windows.Forms.Button
    Friend WithEvents btnNavSchedules As System.Windows.Forms.Button
    Friend WithEvents btnNavReports As System.Windows.Forms.Button
    Friend WithEvents btnNavAdmins As System.Windows.Forms.Button
    Friend WithEvents pnlLogoutHost As System.Windows.Forms.Panel
    Friend WithEvents btnSignOut As System.Windows.Forms.Button
    Friend WithEvents tlpHeader As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents lblPageTitle As System.Windows.Forms.Label
    Friend WithEvents lblSessionClock As System.Windows.Forms.Label
    Friend WithEvents pnlHeaderLine As System.Windows.Forms.Panel
    Friend WithEvents pnlWorkspace As System.Windows.Forms.Panel
    Friend WithEvents pnlDashboardHome As System.Windows.Forms.Panel
    Friend WithEvents tlpKpis As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlKpi1 As System.Windows.Forms.Panel
    Friend WithEvents lblKpi1Title As System.Windows.Forms.Label
    Friend WithEvents lblKpi1Val As System.Windows.Forms.Label
    Friend WithEvents pnlKpi2 As System.Windows.Forms.Panel
    Friend WithEvents lblKpi2Title As System.Windows.Forms.Label
    Friend WithEvents lblKpi2Val As System.Windows.Forms.Label
    Friend WithEvents pnlKpi3 As System.Windows.Forms.Panel
    Friend WithEvents lblKpi3Title As System.Windows.Forms.Label
    Friend WithEvents lblKpi3Val As System.Windows.Forms.Label
    Friend WithEvents pnlKpi4 As System.Windows.Forms.Panel
    Friend WithEvents lblKpi4Title As System.Windows.Forms.Label
    Friend WithEvents lblKpi4Val As System.Windows.Forms.Label
    Friend WithEvents tlpDashGrids As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlLogsCard As System.Windows.Forms.Panel
    Friend WithEvents lblLogsCardTitle As System.Windows.Forms.Label
    Friend WithEvents dgvDashLogs As System.Windows.Forms.DataGridView
    Friend WithEvents pnlSchedCard As System.Windows.Forms.Panel
    Friend WithEvents lblSchedCardTitle As System.Windows.Forms.Label
    Friend WithEvents dgvDashSchedules As System.Windows.Forms.DataGridView
    Friend WithEvents tmrClock As System.Windows.Forms.Timer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlSidebar = New System.Windows.Forms.Panel()
        Me.pnlBrandTop = New System.Windows.Forms.Panel()
        Me.lblBrandTitle = New System.Windows.Forms.Label()
        Me.lblBrandSub = New System.Windows.Forms.Label()
        Me.btnNavDashboard = New System.Windows.Forms.Button()
        Me.btnNavKiosk = New System.Windows.Forms.Button()
        Me.btnNavStudents = New System.Windows.Forms.Button()
        Me.btnNavBiometric = New System.Windows.Forms.Button()
        Me.btnNavCourses = New System.Windows.Forms.Button()
        Me.btnNavTeachers = New System.Windows.Forms.Button()
        Me.btnNavSchedules = New System.Windows.Forms.Button()
        Me.btnNavReports = New System.Windows.Forms.Button()
        Me.btnNavAdmins = New System.Windows.Forms.Button()
        Me.pnlLogoutHost = New System.Windows.Forms.Panel()
        Me.btnSignOut = New System.Windows.Forms.Button()
        Me.tlpHeader = New System.Windows.Forms.TableLayoutPanel()
        Me.lblPageTitle = New System.Windows.Forms.Label()
        Me.lblSessionClock = New System.Windows.Forms.Label()
        Me.pnlHeaderLine = New System.Windows.Forms.Panel()
        Me.pnlWorkspace = New System.Windows.Forms.Panel()
        Me.pnlDashboardHome = New System.Windows.Forms.Panel()
        Me.tlpKpis = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlKpi1 = New System.Windows.Forms.Panel()
        Me.lblKpi1Title = New System.Windows.Forms.Label()
        Me.lblKpi1Val = New System.Windows.Forms.Label()
        Me.pnlKpi2 = New System.Windows.Forms.Panel()
        Me.lblKpi2Title = New System.Windows.Forms.Label()
        Me.lblKpi2Val = New System.Windows.Forms.Label()
        Me.pnlKpi3 = New System.Windows.Forms.Panel()
        Me.lblKpi3Title = New System.Windows.Forms.Label()
        Me.lblKpi3Val = New System.Windows.Forms.Label()
        Me.pnlKpi4 = New System.Windows.Forms.Panel()
        Me.lblKpi4Title = New System.Windows.Forms.Label()
        Me.lblKpi4Val = New System.Windows.Forms.Label()
        Me.tlpDashGrids = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlLogsCard = New System.Windows.Forms.Panel()
        Me.lblLogsCardTitle = New System.Windows.Forms.Label()
        Me.dgvDashLogs = New System.Windows.Forms.DataGridView()
        Me.pnlSchedCard = New System.Windows.Forms.Panel()
        Me.lblSchedCardTitle = New System.Windows.Forms.Label()
        Me.dgvDashSchedules = New System.Windows.Forms.DataGridView()
        Me.tmrClock = New System.Windows.Forms.Timer(Me.components)
        Me.pnlSidebar.SuspendLayout()
        Me.pnlBrandTop.SuspendLayout()
        Me.pnlLogoutHost.SuspendLayout()
        Me.tlpHeader.SuspendLayout()
        Me.pnlWorkspace.SuspendLayout()
        Me.pnlDashboardHome.SuspendLayout()
        Me.tlpKpis.SuspendLayout()
        Me.pnlKpi1.SuspendLayout()
        Me.pnlKpi2.SuspendLayout()
        Me.pnlKpi3.SuspendLayout()
        Me.pnlKpi4.SuspendLayout()
        Me.tlpDashGrids.SuspendLayout()
        Me.pnlLogsCard.SuspendLayout()
        CType(Me.dgvDashLogs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSchedCard.SuspendLayout()
        CType(Me.dgvDashSchedules, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.pnlSidebar.Controls.Add(Me.btnNavAdmins)
        Me.pnlSidebar.Controls.Add(Me.btnNavReports)
        Me.pnlSidebar.Controls.Add(Me.btnNavSchedules)
        Me.pnlSidebar.Controls.Add(Me.btnNavTeachers)
        Me.pnlSidebar.Controls.Add(Me.btnNavCourses)
        Me.pnlSidebar.Controls.Add(Me.btnNavBiometric)
        Me.pnlSidebar.Controls.Add(Me.btnNavStudents)
        Me.pnlSidebar.Controls.Add(Me.btnNavKiosk)
        Me.pnlSidebar.Controls.Add(Me.btnNavDashboard)
        Me.pnlSidebar.Controls.Add(Me.pnlBrandTop)
        Me.pnlSidebar.Controls.Add(Me.pnlLogoutHost)
        Me.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlSidebar.Location = New System.Drawing.Point(0, 0)
        Me.pnlSidebar.Name = "pnlSidebar"
        Me.pnlSidebar.Size = New System.Drawing.Size(220, 720)
        Me.pnlSidebar.TabIndex = 0
        Me.pnlBrandTop.BackColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.pnlBrandTop.Controls.Add(Me.lblBrandTitle)
        Me.pnlBrandTop.Controls.Add(Me.lblBrandSub)
        Me.pnlBrandTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBrandTop.Location = New System.Drawing.Point(0, 0)
        Me.pnlBrandTop.Name = "pnlBrandTop"
        Me.pnlBrandTop.Size = New System.Drawing.Size(220, 72)
        Me.pnlBrandTop.TabIndex = 0
        Me.lblBrandTitle.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Bold)
        Me.lblBrandTitle.ForeColor = System.Drawing.Color.White
        Me.lblBrandTitle.Location = New System.Drawing.Point(18, 12)
        Me.lblBrandTitle.Name = "lblBrandTitle"
        Me.lblBrandTitle.Size = New System.Drawing.Size(184, 28)
        Me.lblBrandTitle.TabIndex = 0
        Me.lblBrandTitle.Text = "Smart Bio"
        Me.lblBrandSub.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblBrandSub.ForeColor = System.Drawing.Color.FromArgb(56, 189, 248)
        Me.lblBrandSub.Location = New System.Drawing.Point(18, 40)
        Me.lblBrandSub.Name = "lblBrandSub"
        Me.lblBrandSub.Size = New System.Drawing.Size(184, 20)
        Me.lblBrandSub.TabIndex = 1
        Me.lblBrandSub.Text = "Student Log"
        Me.btnNavDashboard.Location = New System.Drawing.Point(12, 84)
        Me.btnNavDashboard.Name = "btnNavDashboard"
        Me.btnNavDashboard.Size = New System.Drawing.Size(196, 38)
        Me.btnNavDashboard.TabIndex = 1
        Me.btnNavDashboard.Text = "  Dashboard"
        Me.btnNavKiosk.Location = New System.Drawing.Point(12, 128)
        Me.btnNavKiosk.Name = "btnNavKiosk"
        Me.btnNavKiosk.Size = New System.Drawing.Size(196, 38)
        Me.btnNavKiosk.TabIndex = 2
        Me.btnNavKiosk.Text = "  Attendance Kiosk"
        Me.btnNavStudents.Location = New System.Drawing.Point(12, 172)
        Me.btnNavStudents.Name = "btnNavStudents"
        Me.btnNavStudents.Size = New System.Drawing.Size(196, 38)
        Me.btnNavStudents.TabIndex = 3
        Me.btnNavStudents.Text = "  Students"
        Me.btnNavBiometric.Location = New System.Drawing.Point(12, 216)
        Me.btnNavBiometric.Name = "btnNavBiometric"
        Me.btnNavBiometric.Size = New System.Drawing.Size(196, 38)
        Me.btnNavBiometric.TabIndex = 4
        Me.btnNavBiometric.Text = "  Biometrics"
        Me.btnNavCourses.Location = New System.Drawing.Point(12, 260)
        Me.btnNavCourses.Name = "btnNavCourses"
        Me.btnNavCourses.Size = New System.Drawing.Size(196, 38)
        Me.btnNavCourses.TabIndex = 5
        Me.btnNavCourses.Text = "  Courses"
        Me.btnNavTeachers.Location = New System.Drawing.Point(12, 304)
        Me.btnNavTeachers.Name = "btnNavTeachers"
        Me.btnNavTeachers.Size = New System.Drawing.Size(196, 38)
        Me.btnNavTeachers.TabIndex = 6
        Me.btnNavTeachers.Text = "  Teachers"
        Me.btnNavSchedules.Location = New System.Drawing.Point(12, 348)
        Me.btnNavSchedules.Name = "btnNavSchedules"
        Me.btnNavSchedules.Size = New System.Drawing.Size(196, 38)
        Me.btnNavSchedules.TabIndex = 7
        Me.btnNavSchedules.Text = "  Schedules"
        Me.btnNavReports.Location = New System.Drawing.Point(12, 392)
        Me.btnNavReports.Name = "btnNavReports"
        Me.btnNavReports.Size = New System.Drawing.Size(196, 38)
        Me.btnNavReports.TabIndex = 8
        Me.btnNavReports.Text = "  Reports & Backup"
        Me.btnNavAdmins.Location = New System.Drawing.Point(12, 436)
        Me.btnNavAdmins.Name = "btnNavAdmins"
        Me.btnNavAdmins.Size = New System.Drawing.Size(196, 38)
        Me.btnNavAdmins.TabIndex = 9
        Me.btnNavAdmins.Text = "  Admins"
        Me.pnlLogoutHost.Controls.Add(Me.btnSignOut)
        Me.pnlLogoutHost.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlLogoutHost.Location = New System.Drawing.Point(0, 658)
        Me.pnlLogoutHost.Name = "pnlLogoutHost"
        Me.pnlLogoutHost.Padding = New System.Windows.Forms.Padding(12)
        Me.pnlLogoutHost.Size = New System.Drawing.Size(220, 62)
        Me.pnlLogoutHost.TabIndex = 10
        Me.btnSignOut.BackColor = System.Drawing.Color.FromArgb(51, 65, 85)
        Me.btnSignOut.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSignOut.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnSignOut.FlatAppearance.BorderSize = 0
        Me.btnSignOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSignOut.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnSignOut.ForeColor = System.Drawing.Color.White
        Me.btnSignOut.Location = New System.Drawing.Point(12, 12)
        Me.btnSignOut.Name = "btnSignOut"
        Me.btnSignOut.Size = New System.Drawing.Size(196, 38)
        Me.btnSignOut.TabIndex = 0
        Me.btnSignOut.Text = "Sign Out"
        Me.btnSignOut.UseVisualStyleBackColor = False
        Me.tlpHeader.BackColor = System.Drawing.Color.White
        Me.tlpHeader.ColumnCount = 2
        Me.tlpHeader.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpHeader.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpHeader.Controls.Add(Me.lblPageTitle, 0, 0)
        Me.tlpHeader.Controls.Add(Me.lblSessionClock, 1, 0)
        Me.tlpHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpHeader.Location = New System.Drawing.Point(220, 0)
        Me.tlpHeader.Name = "tlpHeader"
        Me.tlpHeader.RowCount = 1
        Me.tlpHeader.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpHeader.Size = New System.Drawing.Size(1000, 56)
        Me.tlpHeader.TabIndex = 1
        Me.lblPageTitle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblPageTitle.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold)
        Me.lblPageTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblPageTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblPageTitle.Margin = New System.Windows.Forms.Padding(0)
        Me.lblPageTitle.Name = "lblPageTitle"
        Me.lblPageTitle.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
        Me.lblPageTitle.Size = New System.Drawing.Size(500, 56)
        Me.lblPageTitle.TabIndex = 0
        Me.lblPageTitle.Text = "Dashboard"
        Me.lblPageTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSessionClock.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblSessionClock.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.lblSessionClock.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblSessionClock.Location = New System.Drawing.Point(500, 0)
        Me.lblSessionClock.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSessionClock.Name = "lblSessionClock"
        Me.lblSessionClock.Padding = New System.Windows.Forms.Padding(0, 0, 20, 0)
        Me.lblSessionClock.Size = New System.Drawing.Size(500, 56)
        Me.lblSessionClock.TabIndex = 1
        Me.lblSessionClock.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.pnlHeaderLine.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.pnlHeaderLine.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeaderLine.Location = New System.Drawing.Point(220, 56)
        Me.pnlHeaderLine.Name = "pnlHeaderLine"
        Me.pnlHeaderLine.Size = New System.Drawing.Size(1000, 1)
        Me.pnlHeaderLine.TabIndex = 2
        Me.pnlWorkspace.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.pnlWorkspace.Controls.Add(Me.pnlDashboardHome)
        Me.pnlWorkspace.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlWorkspace.Location = New System.Drawing.Point(220, 57)
        Me.pnlWorkspace.Name = "pnlWorkspace"
        Me.pnlWorkspace.Padding = New System.Windows.Forms.Padding(18)
        Me.pnlWorkspace.Size = New System.Drawing.Size(1000, 663)
        Me.pnlWorkspace.TabIndex = 3
        Me.pnlDashboardHome.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.pnlDashboardHome.Controls.Add(Me.tlpDashGrids)
        Me.pnlDashboardHome.Controls.Add(Me.tlpKpis)
        Me.pnlDashboardHome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlDashboardHome.Location = New System.Drawing.Point(18, 18)
        Me.pnlDashboardHome.Name = "pnlDashboardHome"
        Me.pnlDashboardHome.Size = New System.Drawing.Size(964, 627)
        Me.pnlDashboardHome.TabIndex = 0
        Me.tlpKpis.ColumnCount = 4
        Me.tlpKpis.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpKpis.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpKpis.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpKpis.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tlpKpis.Controls.Add(Me.pnlKpi1, 0, 0)
        Me.tlpKpis.Controls.Add(Me.pnlKpi2, 1, 0)
        Me.tlpKpis.Controls.Add(Me.pnlKpi3, 2, 0)
        Me.tlpKpis.Controls.Add(Me.pnlKpi4, 3, 0)
        Me.tlpKpis.Dock = System.Windows.Forms.DockStyle.Top
        Me.tlpKpis.Location = New System.Drawing.Point(0, 0)
        Me.tlpKpis.Name = "tlpKpis"
        Me.tlpKpis.RowCount = 1
        Me.tlpKpis.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpKpis.Size = New System.Drawing.Size(964, 108)
        Me.tlpKpis.TabIndex = 0
        Me.pnlKpi1.BackColor = System.Drawing.Color.White
        Me.pnlKpi1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlKpi1.Controls.Add(Me.lblKpi1Val)
        Me.pnlKpi1.Controls.Add(Me.lblKpi1Title)
        Me.pnlKpi1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlKpi1.Margin = New System.Windows.Forms.Padding(0, 0, 10, 14)
        Me.pnlKpi1.Name = "pnlKpi1"
        Me.pnlKpi1.TabIndex = 0
        Me.lblKpi1Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblKpi1Title.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi1Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblKpi1Title.Padding = New System.Windows.Forms.Padding(14, 10, 0, 0)
        Me.lblKpi1Title.Size = New System.Drawing.Size(229, 28)
        Me.lblKpi1Title.Text = "Active Students"
        Me.lblKpi1Val.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblKpi1Val.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi1Val.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.lblKpi1Val.Padding = New System.Windows.Forms.Padding(14, 0, 0, 6)
        Me.lblKpi1Val.Text = "0"
        Me.lblKpi1Val.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.pnlKpi2.BackColor = System.Drawing.Color.White
        Me.pnlKpi2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlKpi2.Controls.Add(Me.lblKpi2Val)
        Me.pnlKpi2.Controls.Add(Me.lblKpi2Title)
        Me.pnlKpi2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlKpi2.Margin = New System.Windows.Forms.Padding(4, 0, 6, 14)
        Me.pnlKpi2.Name = "pnlKpi2"
        Me.pnlKpi2.TabIndex = 1
        Me.lblKpi2Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblKpi2Title.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi2Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblKpi2Title.Padding = New System.Windows.Forms.Padding(14, 10, 0, 0)
        Me.lblKpi2Title.Size = New System.Drawing.Size(229, 28)
        Me.lblKpi2Title.Text = "Biometric Enrolled"
        Me.lblKpi2Val.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblKpi2Val.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi2Val.ForeColor = System.Drawing.Color.FromArgb(16, 185, 129)
        Me.lblKpi2Val.Padding = New System.Windows.Forms.Padding(14, 0, 0, 6)
        Me.lblKpi2Val.Text = "0"
        Me.lblKpi2Val.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.pnlKpi3.BackColor = System.Drawing.Color.White
        Me.pnlKpi3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlKpi3.Controls.Add(Me.lblKpi3Val)
        Me.pnlKpi3.Controls.Add(Me.lblKpi3Title)
        Me.pnlKpi3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlKpi3.Margin = New System.Windows.Forms.Padding(6, 0, 4, 14)
        Me.pnlKpi3.Name = "pnlKpi3"
        Me.pnlKpi3.TabIndex = 2
        Me.lblKpi3Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblKpi3Title.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi3Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblKpi3Title.Padding = New System.Windows.Forms.Padding(14, 10, 0, 0)
        Me.lblKpi3Title.Size = New System.Drawing.Size(229, 28)
        Me.lblKpi3Title.Text = "Today's Logs"
        Me.lblKpi3Val.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblKpi3Val.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi3Val.ForeColor = System.Drawing.Color.FromArgb(245, 158, 11)
        Me.lblKpi3Val.Padding = New System.Windows.Forms.Padding(14, 0, 0, 6)
        Me.lblKpi3Val.Text = "0"
        Me.lblKpi3Val.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.pnlKpi4.BackColor = System.Drawing.Color.White
        Me.pnlKpi4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlKpi4.Controls.Add(Me.lblKpi4Val)
        Me.pnlKpi4.Controls.Add(Me.lblKpi4Title)
        Me.pnlKpi4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlKpi4.Margin = New System.Windows.Forms.Padding(10, 0, 0, 14)
        Me.pnlKpi4.Name = "pnlKpi4"
        Me.pnlKpi4.TabIndex = 3
        Me.lblKpi4Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblKpi4Title.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi4Title.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblKpi4Title.Padding = New System.Windows.Forms.Padding(14, 10, 0, 0)
        Me.lblKpi4Title.Size = New System.Drawing.Size(229, 28)
        Me.lblKpi4Title.Text = "Active Schedules"
        Me.lblKpi4Val.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblKpi4Val.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblKpi4Val.ForeColor = System.Drawing.Color.FromArgb(14, 165, 233)
        Me.lblKpi4Val.Padding = New System.Windows.Forms.Padding(14, 0, 0, 6)
        Me.lblKpi4Val.Text = "0"
        Me.lblKpi4Val.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.tlpDashGrids.ColumnCount = 2
        Me.tlpDashGrids.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tlpDashGrids.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tlpDashGrids.Controls.Add(Me.pnlLogsCard, 0, 0)
        Me.tlpDashGrids.Controls.Add(Me.pnlSchedCard, 1, 0)
        Me.tlpDashGrids.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpDashGrids.Location = New System.Drawing.Point(0, 108)
        Me.tlpDashGrids.Name = "tlpDashGrids"
        Me.tlpDashGrids.RowCount = 1
        Me.tlpDashGrids.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpDashGrids.Size = New System.Drawing.Size(964, 519)
        Me.tlpDashGrids.TabIndex = 1
        Me.pnlLogsCard.BackColor = System.Drawing.Color.White
        Me.pnlLogsCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlLogsCard.Controls.Add(Me.dgvDashLogs)
        Me.pnlLogsCard.Controls.Add(Me.lblLogsCardTitle)
        Me.pnlLogsCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlLogsCard.Margin = New System.Windows.Forms.Padding(0, 0, 8, 0)
        Me.pnlLogsCard.Padding = New System.Windows.Forms.Padding(14)
        Me.pnlLogsCard.TabIndex = 0
        Me.lblLogsCardTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblLogsCardTitle.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold)
        Me.lblLogsCardTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblLogsCardTitle.Size = New System.Drawing.Size(540, 32)
        Me.lblLogsCardTitle.Text = "Today's Attendance"
        Me.dgvDashLogs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDashLogs.Name = "dgvDashLogs"
        Me.dgvDashLogs.TabIndex = 1
        Me.pnlSchedCard.BackColor = System.Drawing.Color.White
        Me.pnlSchedCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlSchedCard.Controls.Add(Me.dgvDashSchedules)
        Me.pnlSchedCard.Controls.Add(Me.lblSchedCardTitle)
        Me.pnlSchedCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlSchedCard.Margin = New System.Windows.Forms.Padding(8, 0, 0, 0)
        Me.pnlSchedCard.Padding = New System.Windows.Forms.Padding(14)
        Me.pnlSchedCard.TabIndex = 1
        Me.lblSchedCardTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblSchedCardTitle.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold)
        Me.lblSchedCardTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblSchedCardTitle.Size = New System.Drawing.Size(350, 32)
        Me.lblSchedCardTitle.Text = "Class Schedules"
        Me.dgvDashSchedules.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDashSchedules.Name = "dgvDashSchedules"
        Me.dgvDashSchedules.TabIndex = 1
        Me.tmrClock.Enabled = True
        Me.tmrClock.Interval = 1000
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1220, 720)
        Me.Controls.Add(Me.pnlWorkspace)
        Me.Controls.Add(Me.pnlHeaderLine)
        Me.Controls.Add(Me.tlpHeader)
        Me.Controls.Add(Me.pnlSidebar)
        Me.MinimumSize = New System.Drawing.Size(1060, 650)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Smart Bio Student Log"
        Me.pnlSidebar.ResumeLayout(False)
        Me.pnlBrandTop.ResumeLayout(False)
        Me.pnlLogoutHost.ResumeLayout(False)
        Me.tlpHeader.ResumeLayout(False)
        Me.pnlWorkspace.ResumeLayout(False)
        Me.pnlDashboardHome.ResumeLayout(False)
        Me.tlpKpis.ResumeLayout(False)
        Me.pnlKpi1.ResumeLayout(False)
        Me.pnlKpi2.ResumeLayout(False)
        Me.pnlKpi3.ResumeLayout(False)
        Me.pnlKpi4.ResumeLayout(False)
        Me.tlpDashGrids.ResumeLayout(False)
        Me.pnlLogsCard.ResumeLayout(False)
        CType(Me.dgvDashLogs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSchedCard.ResumeLayout(False)
        CType(Me.dgvDashSchedules, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
