<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAttendanceKiosk
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblHeaderTitle As System.Windows.Forms.Label
    Friend WithEvents lblLiveDate As System.Windows.Forms.Label
    Friend WithEvents lblLiveClock As System.Windows.Forms.Label
    Friend WithEvents btnCloseKiosk As System.Windows.Forms.Button
    Friend WithEvents tlpMain As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlScannerCard As System.Windows.Forms.Panel
    Friend WithEvents lblDeviceBadge As System.Windows.Forms.Label
    Friend WithEvents lblMode As System.Windows.Forms.Label
    Friend WithEvents cmbMode As System.Windows.Forms.ComboBox
    Friend WithEvents lblSchedule As System.Windows.Forms.Label
    Friend WithEvents cmbSchedule As System.Windows.Forms.ComboBox
    Friend WithEvents picScanner As System.Windows.Forms.PictureBox
    Friend WithEvents lblVerifyBanner As System.Windows.Forms.Label
    Friend WithEvents lblStudentResult As System.Windows.Forms.Label
    Friend WithEvents btnReconnectScanner As System.Windows.Forms.Button
    Friend WithEvents pnlLogsCard As System.Windows.Forms.Panel
    Friend WithEvents lblLogsHeader As System.Windows.Forms.Label
    Friend WithEvents dgvTodayLogs As System.Windows.Forms.DataGridView
    Friend WithEvents tmrClock As System.Windows.Forms.Timer
    Friend WithEvents tmrBannerReset As System.Windows.Forms.Timer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.btnCloseKiosk = New System.Windows.Forms.Button()
        Me.lblLiveClock = New System.Windows.Forms.Label()
        Me.lblLiveDate = New System.Windows.Forms.Label()
        Me.lblHeaderTitle = New System.Windows.Forms.Label()
        Me.tlpMain = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlScannerCard = New System.Windows.Forms.Panel()
        Me.lblDeviceBadge = New System.Windows.Forms.Label()
        Me.lblMode = New System.Windows.Forms.Label()
        Me.cmbMode = New System.Windows.Forms.ComboBox()
        Me.lblSchedule = New System.Windows.Forms.Label()
        Me.cmbSchedule = New System.Windows.Forms.ComboBox()
        Me.picScanner = New System.Windows.Forms.PictureBox()
        Me.lblVerifyBanner = New System.Windows.Forms.Label()
        Me.lblStudentResult = New System.Windows.Forms.Label()
        Me.btnReconnectScanner = New System.Windows.Forms.Button()
        Me.pnlLogsCard = New System.Windows.Forms.Panel()
        Me.dgvTodayLogs = New System.Windows.Forms.DataGridView()
        Me.lblLogsHeader = New System.Windows.Forms.Label()
        Me.tmrClock = New System.Windows.Forms.Timer(Me.components)
        Me.tmrBannerReset = New System.Windows.Forms.Timer(Me.components)
        Me.pnlHeader.SuspendLayout()
        Me.tlpMain.SuspendLayout()
        Me.pnlScannerCard.SuspendLayout()
        CType(Me.picScanner, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlLogsCard.SuspendLayout()
        CType(Me.dgvTodayLogs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        Me.pnlHeader.BackColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.pnlHeader.Controls.Add(Me.btnCloseKiosk)
        Me.pnlHeader.Controls.Add(Me.lblLiveClock)
        Me.pnlHeader.Controls.Add(Me.lblLiveDate)
        Me.pnlHeader.Controls.Add(Me.lblHeaderTitle)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Size = New System.Drawing.Size(1020, 66)
        Me.btnCloseKiosk.Anchor = System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right
        Me.btnCloseKiosk.BackColor = System.Drawing.Color.FromArgb(239, 68, 68)
        Me.btnCloseKiosk.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCloseKiosk.FlatAppearance.BorderSize = 0
        Me.btnCloseKiosk.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCloseKiosk.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnCloseKiosk.ForeColor = System.Drawing.Color.White
        Me.btnCloseKiosk.Location = New System.Drawing.Point(922, 16)
        Me.btnCloseKiosk.Size = New System.Drawing.Size(80, 34)
        Me.btnCloseKiosk.Text = "Exit"
        Me.btnCloseKiosk.UseVisualStyleBackColor = False
        Me.lblLiveClock.Anchor = System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right
        Me.lblLiveClock.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblLiveClock.ForeColor = System.Drawing.Color.FromArgb(56, 189, 248)
        Me.lblLiveClock.Location = New System.Drawing.Point(710, 12)
        Me.lblLiveClock.Size = New System.Drawing.Size(200, 40)
        Me.lblLiveClock.Text = "08:00:00 AM"
        Me.lblLiveClock.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblLiveDate.Anchor = System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right
        Me.lblLiveDate.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.lblLiveDate.ForeColor = System.Drawing.Color.FromArgb(203, 213, 225)
        Me.lblLiveDate.Location = New System.Drawing.Point(475, 20)
        Me.lblLiveDate.Size = New System.Drawing.Size(230, 26)
        Me.lblLiveDate.Text = "Thursday, Oct 22, 2026"
        Me.lblLiveDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblHeaderTitle.AutoSize = True
        Me.lblHeaderTitle.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold)
        Me.lblHeaderTitle.ForeColor = System.Drawing.Color.White
        Me.lblHeaderTitle.Location = New System.Drawing.Point(18, 19)
        Me.lblHeaderTitle.Text = "Biometric Attendance Kiosk"
        Me.tlpMain.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.tlpMain.ColumnCount = 2
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 356.0!))
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMain.Controls.Add(Me.pnlScannerCard, 0, 0)
        Me.tlpMain.Controls.Add(Me.pnlLogsCard, 1, 0)
        Me.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpMain.Padding = New System.Windows.Forms.Padding(14)
        Me.tlpMain.RowCount = 1
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMain.Size = New System.Drawing.Size(1020, 584)
        Me.pnlScannerCard.BackColor = System.Drawing.Color.White
        Me.pnlScannerCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlScannerCard.Controls.Add(Me.lblDeviceBadge)
        Me.pnlScannerCard.Controls.Add(Me.lblMode)
        Me.pnlScannerCard.Controls.Add(Me.cmbMode)
        Me.pnlScannerCard.Controls.Add(Me.lblSchedule)
        Me.pnlScannerCard.Controls.Add(Me.cmbSchedule)
        Me.pnlScannerCard.Controls.Add(Me.picScanner)
        Me.pnlScannerCard.Controls.Add(Me.lblVerifyBanner)
        Me.pnlScannerCard.Controls.Add(Me.lblStudentResult)
        Me.pnlScannerCard.Controls.Add(Me.btnReconnectScanner)
        Me.pnlScannerCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlScannerCard.Margin = New System.Windows.Forms.Padding(0, 0, 12, 0)
        Me.lblDeviceBadge.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.lblDeviceBadge.Font = New System.Drawing.Font("Segoe UI Semibold", 8.5!, System.Drawing.FontStyle.Bold)
        Me.lblDeviceBadge.ForeColor = System.Drawing.Color.FromArgb(30, 64, 175)
        Me.lblDeviceBadge.Location = New System.Drawing.Point(18, 16)
        Me.lblDeviceBadge.Size = New System.Drawing.Size(308, 28)
        Me.lblDeviceBadge.Text = "Checking USB Biometric Sensor..."
        Me.lblDeviceBadge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblMode.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblMode.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblMode.Location = New System.Drawing.Point(18, 56)
        Me.lblMode.Size = New System.Drawing.Size(308, 18)
        Me.lblMode.Text = "Attendance Mode"
        Me.cmbMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMode.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.cmbMode.Location = New System.Drawing.Point(18, 76)
        Me.cmbMode.Size = New System.Drawing.Size(308, 26)
        Me.lblSchedule.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSchedule.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblSchedule.Location = New System.Drawing.Point(18, 112)
        Me.lblSchedule.Size = New System.Drawing.Size(308, 18)
        Me.lblSchedule.Text = "Class Schedule"
        Me.cmbSchedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSchedule.Font = New System.Drawing.Font("Segoe UI", 9.25!)
        Me.cmbSchedule.Location = New System.Drawing.Point(18, 132)
        Me.cmbSchedule.Size = New System.Drawing.Size(308, 26)
        Me.picScanner.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.picScanner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picScanner.Location = New System.Drawing.Point(62, 170)
        Me.picScanner.Size = New System.Drawing.Size(220, 214)
        Me.lblVerifyBanner.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.lblVerifyBanner.Font = New System.Drawing.Font("Segoe UI", 10.5!, System.Drawing.FontStyle.Bold)
        Me.lblVerifyBanner.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59)
        Me.lblVerifyBanner.Location = New System.Drawing.Point(18, 396)
        Me.lblVerifyBanner.Size = New System.Drawing.Size(308, 34)
        Me.lblVerifyBanner.Text = "PLACE FINGER ON PAD"
        Me.lblVerifyBanner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStudentResult.BackColor = System.Drawing.Color.FromArgb(248, 250, 252)
        Me.lblStudentResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStudentResult.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblStudentResult.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105)
        Me.lblStudentResult.Location = New System.Drawing.Point(18, 438)
        Me.lblStudentResult.Padding = New System.Windows.Forms.Padding(6)
        Me.lblStudentResult.Size = New System.Drawing.Size(308, 56)
        Me.lblStudentResult.Text = "Waiting for fingerprint touch..."
        Me.lblStudentResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnReconnectScanner.BackColor = System.Drawing.Color.FromArgb(37, 99, 235)
        Me.btnReconnectScanner.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReconnectScanner.FlatAppearance.BorderSize = 0
        Me.btnReconnectScanner.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReconnectScanner.Font = New System.Drawing.Font("Segoe UI Semibold", 9.5!, System.Drawing.FontStyle.Bold)
        Me.btnReconnectScanner.ForeColor = System.Drawing.Color.White
        Me.btnReconnectScanner.Location = New System.Drawing.Point(18, 504)
        Me.btnReconnectScanner.Size = New System.Drawing.Size(308, 36)
        Me.btnReconnectScanner.Text = "Detect / Reconnect Scanner"
        Me.btnReconnectScanner.UseVisualStyleBackColor = False
        Me.pnlLogsCard.BackColor = System.Drawing.Color.White
        Me.pnlLogsCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlLogsCard.Controls.Add(Me.dgvTodayLogs)
        Me.pnlLogsCard.Controls.Add(Me.lblLogsHeader)
        Me.pnlLogsCard.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlLogsCard.Margin = New System.Windows.Forms.Padding(0)
        Me.pnlLogsCard.Padding = New System.Windows.Forms.Padding(14)
        Me.dgvTodayLogs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvTodayLogs.Name = "dgvTodayLogs"
        Me.lblLogsHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblLogsHeader.Font = New System.Drawing.Font("Segoe UI", 11.5!, System.Drawing.FontStyle.Bold)
        Me.lblLogsHeader.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42)
        Me.lblLogsHeader.Size = New System.Drawing.Size(606, 36)
        Me.lblLogsHeader.Text = "Today's Live Attendance"
        Me.tmrClock.Enabled = True
        Me.tmrClock.Interval = 1000
        Me.tmrBannerReset.Interval = 3500
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(241, 245, 249)
        Me.ClientSize = New System.Drawing.Size(1020, 650)
        Me.Controls.Add(Me.tlpMain)
        Me.Controls.Add(Me.pnlHeader)
        Me.MinimumSize = New System.Drawing.Size(960, 620)
        Me.Name = "frmAttendanceKiosk"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Smart Bio — Attendance Kiosk"
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.tlpMain.ResumeLayout(False)
        Me.pnlScannerCard.ResumeLayout(False)
        CType(Me.picScanner, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlLogsCard.ResumeLayout(False)
        CType(Me.dgvTodayLogs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub
End Class
